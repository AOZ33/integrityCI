<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-18 09:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 09:32:04 --> No URI present. Default controller set.
DEBUG - 2022-01-18 09:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 09:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 09:32:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 09:32:04 --> Total execution time: 0.0301
DEBUG - 2022-01-18 09:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 09:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-18 09:32:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-18 09:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 09:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 09:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 09:32:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 09:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 09:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 09:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 09:32:18 --> Total execution time: 0.0059
DEBUG - 2022-01-18 09:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 09:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 09:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 09:32:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-18 09:32:21 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 91052896 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-18 09:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 09:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 09:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 09:34:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 09:34:13 --> Total execution time: 0.0340
DEBUG - 2022-01-18 10:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:29:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:29:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:29:19 --> Total execution time: 0.0075
DEBUG - 2022-01-18 10:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:36:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-18 10:36:14 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 91174368 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-18 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:44:57 --> Total execution time: 0.0064
DEBUG - 2022-01-18 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:48:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:48:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:48:40 --> Total execution time: 0.0067
DEBUG - 2022-01-18 10:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 10:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 10:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 10:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 10:50:45 --> Total execution time: 0.0067
DEBUG - 2022-01-18 11:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:00:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:00:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:00:45 --> Total execution time: 0.0059
DEBUG - 2022-01-18 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:04:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:04:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:04:36 --> Total execution time: 0.0059
DEBUG - 2022-01-18 11:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:12:34 --> Total execution time: 0.0061
DEBUG - 2022-01-18 11:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:18:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:18:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:18:30 --> Total execution time: 0.0058
DEBUG - 2022-01-18 11:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:27:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:27:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:27:16 --> Total execution time: 0.0058
DEBUG - 2022-01-18 11:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:28:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 11:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 11:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 11:28:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 11:28:38 --> Total execution time: 0.0061
DEBUG - 2022-01-18 12:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:07:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 12:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:07:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 12:07:39 --> Total execution time: 0.0066
DEBUG - 2022-01-18 12:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:49:44 --> No URI present. Default controller set.
DEBUG - 2022-01-18 12:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:49:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 12:49:44 --> Total execution time: 0.0318
DEBUG - 2022-01-18 12:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:49:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-18 12:49:44 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-18 12:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:49:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 12:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:49:53 --> Total execution time: 0.0053
DEBUG - 2022-01-18 12:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:50:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-18 12:50:02 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 92387896 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-18 12:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:50:04 --> Total execution time: 0.0040
DEBUG - 2022-01-18 12:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:53:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-18 12:53:44 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 92387896 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-18 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 12:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 12:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 12:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 12:56:02 --> Total execution time: 0.0333
DEBUG - 2022-01-18 13:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:14:31 --> Total execution time: 0.0064
DEBUG - 2022-01-18 13:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:28:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-18 13:28:48 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 92509376 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-18 13:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:33:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:33:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:33:20 --> Total execution time: 0.0059
DEBUG - 2022-01-18 13:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:42:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:42:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:42:17 --> Total execution time: 0.0068
DEBUG - 2022-01-18 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:56:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 13:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 13:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 13:56:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 13:56:37 --> Total execution time: 0.0061
DEBUG - 2022-01-18 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:11:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:11:36 --> Total execution time: 0.0342
DEBUG - 2022-01-18 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:11:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:11:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:11:38 --> Total execution time: 0.0036
DEBUG - 2022-01-18 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:19:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:19:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:19:16 --> Total execution time: 0.0066
DEBUG - 2022-01-18 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:26:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:26:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:26:25 --> Total execution time: 0.0065
DEBUG - 2022-01-18 14:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:30:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:30:57 --> Total execution time: 0.0084
DEBUG - 2022-01-18 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:44:16 --> Total execution time: 0.0061
DEBUG - 2022-01-18 14:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:49:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:49:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:49:16 --> Total execution time: 0.0063
DEBUG - 2022-01-18 14:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:51:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:51:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:51:11 --> Total execution time: 0.0064
DEBUG - 2022-01-18 14:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 14:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 14:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 14:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 14:54:39 --> Total execution time: 0.0058
DEBUG - 2022-01-18 15:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 15:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 15:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 15:00:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 15:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 15:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 15:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 15:00:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 15:00:28 --> Total execution time: 0.0062
DEBUG - 2022-01-18 15:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 15:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 15:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 15:06:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 15:06:35 --> Total execution time: 0.2346
DEBUG - 2022-01-18 15:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 15:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 15:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 15:26:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-18 15:26:16 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 93968760 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-18 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:29:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:29:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:29:16 --> Total execution time: 0.0068
DEBUG - 2022-01-18 16:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:31:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:31:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:31:14 --> Total execution time: 0.0065
DEBUG - 2022-01-18 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:39:36 --> Total execution time: 0.0061
DEBUG - 2022-01-18 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:45:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:45:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:45:32 --> Total execution time: 0.0065
DEBUG - 2022-01-18 16:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:47:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:47:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:47:46 --> Total execution time: 0.0059
DEBUG - 2022-01-18 16:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:51:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:51:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:51:39 --> Total execution time: 0.0058
DEBUG - 2022-01-18 16:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:55:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-18 16:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-18 16:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-18 16:55:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-18 16:55:07 --> Total execution time: 0.0069
