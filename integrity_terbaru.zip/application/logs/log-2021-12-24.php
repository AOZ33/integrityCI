<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-24 00:33:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 00:33:09 --> No URI present. Default controller set.
DEBUG - 2021-12-24 00:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 00:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 00:33:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 00:33:09 --> Total execution time: 0.0314
DEBUG - 2021-12-24 00:33:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 00:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 00:33:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 02:27:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 02:27:26 --> No URI present. Default controller set.
DEBUG - 2021-12-24 02:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 02:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 02:27:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 02:27:26 --> Total execution time: 0.0312
DEBUG - 2021-12-24 02:27:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 02:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 02:27:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 10:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:38:40 --> No URI present. Default controller set.
DEBUG - 2021-12-24 10:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 10:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 10:38:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 10:38:40 --> Total execution time: 0.0307
DEBUG - 2021-12-24 10:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:38:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 10:38:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 10:38:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:38:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 10:38:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 10:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 10:42:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 10:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 10:42:05 --> Total execution time: 0.0075
DEBUG - 2021-12-24 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 10:42:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 10:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 10:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 10:42:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 10:42:07 --> Total execution time: 0.0056
DEBUG - 2021-12-24 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 10:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 10:42:30 --> Total execution time: 0.0067
DEBUG - 2021-12-24 10:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 10:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 10:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 10:42:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 10:42:34 --> Total execution time: 0.0098
DEBUG - 2021-12-24 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:12:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:12:03 --> Total execution time: 0.0345
DEBUG - 2021-12-24 11:12:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:12:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:12:29 --> Total execution time: 0.0103
DEBUG - 2021-12-24 11:14:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:14:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:14:24 --> Total execution time: 0.0333
DEBUG - 2021-12-24 11:20:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:20:27 --> No URI present. Default controller set.
DEBUG - 2021-12-24 11:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:20:27 --> Total execution time: 0.0305
DEBUG - 2021-12-24 11:21:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:21:50 --> No URI present. Default controller set.
DEBUG - 2021-12-24 11:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:21:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:21:50 --> Total execution time: 0.0313
DEBUG - 2021-12-24 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:21:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 11:21:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 11:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:21:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 11:21:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 11:26:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:26:08 --> No URI present. Default controller set.
DEBUG - 2021-12-24 11:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:26:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:26:08 --> Total execution time: 0.0314
DEBUG - 2021-12-24 11:26:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 11:26:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 11:26:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 11:26:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 11:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:26:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:26:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:26:49 --> Total execution time: 0.0072
DEBUG - 2021-12-24 11:26:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:26:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 11:26:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:27:13 --> Total execution time: 0.0052
DEBUG - 2021-12-24 11:27:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:27:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:27:16 --> Total execution time: 0.0100
DEBUG - 2021-12-24 11:27:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:27:37 --> Total execution time: 0.0050
DEBUG - 2021-12-24 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:27:52 --> Total execution time: 0.0062
DEBUG - 2021-12-24 11:27:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:27:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 11:27:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 11:28:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:28:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:28:12 --> Total execution time: 0.0072
DEBUG - 2021-12-24 11:28:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:28:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:28:22 --> Total execution time: 0.0055
DEBUG - 2021-12-24 11:28:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:28:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 11:28:23 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:30:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 11:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 11:30:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 11:30:12 --> Total execution time: 0.0042
DEBUG - 2021-12-24 11:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 11:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 11:30:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 12:33:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:33:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:33:15 --> Total execution time: 0.0395
DEBUG - 2021-12-24 12:34:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:34:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:34:42 --> Total execution time: 0.0333
DEBUG - 2021-12-24 12:34:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:34:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:34:45 --> Total execution time: 0.0090
DEBUG - 2021-12-24 12:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:35:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:35:58 --> Total execution time: 0.0321
DEBUG - 2021-12-24 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:52:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 12:52:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2021-12-24 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:52:58 --> No URI present. Default controller set.
DEBUG - 2021-12-24 12:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:52:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:52:58 --> Total execution time: 0.0233
DEBUG - 2021-12-24 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:52:58 --> No URI present. Default controller set.
DEBUG - 2021-12-24 12:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:52:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:52:58 --> Total execution time: 0.0037
DEBUG - 2021-12-24 12:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 12:52:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 12:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:52:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 12:52:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 12:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:53:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:53:08 --> Total execution time: 0.0071
DEBUG - 2021-12-24 12:54:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:54:59 --> Total execution time: 0.0327
DEBUG - 2021-12-24 12:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:55:01 --> Total execution time: 0.0055
DEBUG - 2021-12-24 12:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:55:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:55:02 --> Total execution time: 0.0103
DEBUG - 2021-12-24 12:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 12:56:02 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-24 12:56:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:56:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:56:03 --> Total execution time: 0.0292
DEBUG - 2021-12-24 12:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:58:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:58:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:58:09 --> Total execution time: 0.0042
DEBUG - 2021-12-24 12:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:58:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 12:58:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 12:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:58:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:58:28 --> Total execution time: 0.0059
DEBUG - 2021-12-24 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:58:53 --> Total execution time: 0.0054
DEBUG - 2021-12-24 12:58:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:58:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:58:55 --> Total execution time: 0.0056
DEBUG - 2021-12-24 12:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:59:01 --> Total execution time: 0.0061
DEBUG - 2021-12-24 12:59:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:59:03 --> Total execution time: 0.0077
DEBUG - 2021-12-24 12:59:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:59:04 --> Total execution time: 0.0058
DEBUG - 2021-12-24 12:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:59:06 --> Total execution time: 0.0057
DEBUG - 2021-12-24 12:59:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:59:08 --> Total execution time: 0.0046
DEBUG - 2021-12-24 12:59:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:59:09 --> Total execution time: 0.0050
DEBUG - 2021-12-24 12:59:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 12:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 12:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 12:59:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 12:59:12 --> Total execution time: 0.0099
DEBUG - 2021-12-24 13:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:06:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:06:04 --> Total execution time: 0.0389
DEBUG - 2021-12-24 13:06:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:06:46 --> Total execution time: 0.0365
DEBUG - 2021-12-24 13:07:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:07:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:07:03 --> Total execution time: 0.0090
DEBUG - 2021-12-24 13:07:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:07:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:07:32 --> Total execution time: 0.0091
DEBUG - 2021-12-24 13:08:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:16 --> Total execution time: 0.0322
DEBUG - 2021-12-24 13:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:08:18 --> Total execution time: 0.0060
DEBUG - 2021-12-24 13:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:08:18 --> Total execution time: 0.0095
DEBUG - 2021-12-24 13:08:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:20 --> Total execution time: 0.0057
DEBUG - 2021-12-24 13:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:21 --> Total execution time: 0.0063
DEBUG - 2021-12-24 13:08:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:23 --> Total execution time: 0.0061
DEBUG - 2021-12-24 13:08:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:24 --> Total execution time: 0.0060
DEBUG - 2021-12-24 13:08:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:26 --> Total execution time: 0.0052
DEBUG - 2021-12-24 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:29 --> Total execution time: 0.0050
DEBUG - 2021-12-24 13:08:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:30 --> Total execution time: 0.0064
DEBUG - 2021-12-24 13:08:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:31 --> Total execution time: 0.0050
DEBUG - 2021-12-24 13:08:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:33 --> Total execution time: 0.0046
DEBUG - 2021-12-24 13:08:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:34 --> Total execution time: 0.0059
DEBUG - 2021-12-24 13:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:39 --> Total execution time: 0.0061
DEBUG - 2021-12-24 13:08:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:40 --> Total execution time: 0.0047
DEBUG - 2021-12-24 13:08:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:41 --> Total execution time: 0.0051
DEBUG - 2021-12-24 13:08:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:43 --> Total execution time: 0.0048
DEBUG - 2021-12-24 13:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:48 --> Total execution time: 0.0048
DEBUG - 2021-12-24 13:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:50 --> Total execution time: 0.0046
DEBUG - 2021-12-24 13:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:51 --> Total execution time: 0.0047
DEBUG - 2021-12-24 13:08:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:08:52 --> Total execution time: 0.0057
DEBUG - 2021-12-24 13:45:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:45:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:45:28 --> Total execution time: 0.0382
DEBUG - 2021-12-24 13:50:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:50:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:50:07 --> Total execution time: 0.0346
DEBUG - 2021-12-24 13:50:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:50:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:50:09 --> Total execution time: 0.0048
DEBUG - 2021-12-24 13:50:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:50:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:50:18 --> Total execution time: 0.0091
DEBUG - 2021-12-24 13:50:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:50:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:50:21 --> Total execution time: 0.0051
DEBUG - 2021-12-24 13:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:50:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:50:23 --> Total execution time: 0.0079
DEBUG - 2021-12-24 13:52:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:52:52 --> Total execution time: 0.0343
DEBUG - 2021-12-24 13:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:52:55 --> Total execution time: 0.0060
DEBUG - 2021-12-24 13:52:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:52:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:52:57 --> Total execution time: 0.0091
DEBUG - 2021-12-24 13:53:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:53:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:53:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 13:53:17 --> Total execution time: 0.0069
DEBUG - 2021-12-24 13:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 13:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 13:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 13:53:35 --> Total execution time: 0.0052
DEBUG - 2021-12-24 14:05:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:05:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:05:14 --> Total execution time: 0.0345
DEBUG - 2021-12-24 14:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:05:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:05:16 --> Total execution time: 0.0098
DEBUG - 2021-12-24 14:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:05:46 --> Total execution time: 0.0059
DEBUG - 2021-12-24 14:08:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:08:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:08:10 --> Total execution time: 0.0375
DEBUG - 2021-12-24 14:08:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:08:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:08:12 --> Total execution time: 0.0080
DEBUG - 2021-12-24 14:08:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:08:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:08:14 --> Total execution time: 0.0059
DEBUG - 2021-12-24 14:08:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:08:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:08:33 --> Total execution time: 0.0073
DEBUG - 2021-12-24 14:08:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:08:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:08:45 --> Total execution time: 0.0049
DEBUG - 2021-12-24 14:09:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:09:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:09:53 --> Total execution time: 0.0356
DEBUG - 2021-12-24 14:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:10:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:10:06 --> Total execution time: 0.0059
DEBUG - 2021-12-24 14:19:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:19:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:19:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:19:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:19:03 --> Total execution time: 0.0084
DEBUG - 2021-12-24 14:19:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:19:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:19:05 --> Total execution time: 0.0104
DEBUG - 2021-12-24 14:20:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:20:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:20:05 --> Total execution time: 0.0359
DEBUG - 2021-12-24 14:20:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:20:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:20:28 --> Total execution time: 0.0072
DEBUG - 2021-12-24 14:20:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:20:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:20:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:20:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:20:54 --> Total execution time: 0.0082
DEBUG - 2021-12-24 14:22:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:22:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:22:19 --> Total execution time: 0.0367
DEBUG - 2021-12-24 14:22:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:22:38 --> Total execution time: 0.0056
DEBUG - 2021-12-24 14:23:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:23:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:23:59 --> Total execution time: 0.0368
DEBUG - 2021-12-24 14:24:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:24:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:24:01 --> Total execution time: 0.0054
DEBUG - 2021-12-24 14:24:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:24:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:24:30 --> Total execution time: 0.0081
DEBUG - 2021-12-24 14:25:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:25:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-24 14:25:04 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Data.php 29
DEBUG - 2021-12-24 14:25:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:25:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:25:04 --> Total execution time: 0.0115
DEBUG - 2021-12-24 14:25:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:25:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:25:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:25:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:25:17 --> Total execution time: 0.0083
DEBUG - 2021-12-24 14:27:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:27:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:27:09 --> Total execution time: 0.0335
DEBUG - 2021-12-24 14:27:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:27:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:27:30 --> Total execution time: 0.0098
DEBUG - 2021-12-24 14:27:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:27:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:27:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:27:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:27:53 --> Total execution time: 0.0079
DEBUG - 2021-12-24 14:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:28:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:28:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:28:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:28:55 --> Total execution time: 0.0108
DEBUG - 2021-12-24 14:30:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:30:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:30:03 --> Total execution time: 0.0336
DEBUG - 2021-12-24 14:36:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:36:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:36:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:36:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:36:46 --> Total execution time: 0.0082
DEBUG - 2021-12-24 14:42:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:42:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:42:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:42:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:42:47 --> Total execution time: 0.0071
DEBUG - 2021-12-24 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:43:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:43:12 --> Total execution time: 0.0102
DEBUG - 2021-12-24 14:43:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:43:15 --> Total execution time: 0.0050
DEBUG - 2021-12-24 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:49:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:49:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:49:01 --> Total execution time: 0.0077
DEBUG - 2021-12-24 14:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:49:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:49:04 --> Total execution time: 0.0099
DEBUG - 2021-12-24 14:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:49:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:49:07 --> Total execution time: 0.0050
DEBUG - 2021-12-24 14:52:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:52:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:52:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:52:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:52:25 --> Total execution time: 0.0073
DEBUG - 2021-12-24 14:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:56:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:56:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:56:34 --> Total execution time: 0.0078
DEBUG - 2021-12-24 14:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:56:35 --> Total execution time: 0.0061
DEBUG - 2021-12-24 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:56:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:56:38 --> Total execution time: 0.0117
DEBUG - 2021-12-24 14:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 14:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 14:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 14:56:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 14:56:55 --> Total execution time: 0.0052
DEBUG - 2021-12-24 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:00:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:00:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:00:56 --> Total execution time: 0.0068
DEBUG - 2021-12-24 15:04:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:04:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:04:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:04:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:04:47 --> Total execution time: 0.0073
DEBUG - 2021-12-24 15:04:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:04:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:04:50 --> Total execution time: 0.0135
DEBUG - 2021-12-24 15:04:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:04:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:04:53 --> Total execution time: 0.0050
DEBUG - 2021-12-24 15:06:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:06:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:06:40 --> Total execution time: 0.0424
DEBUG - 2021-12-24 15:06:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:06:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:06:56 --> Total execution time: 0.0059
DEBUG - 2021-12-24 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:08:38 --> No URI present. Default controller set.
DEBUG - 2021-12-24 15:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:08:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:08:38 --> Total execution time: 0.0316
DEBUG - 2021-12-24 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 15:08:38 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 15:08:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:08:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 15:08:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 15:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:09:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:09:14 --> Total execution time: 0.0068
DEBUG - 2021-12-24 15:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:09:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:09:19 --> Total execution time: 0.0111
DEBUG - 2021-12-24 15:09:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:09:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:09:34 --> Total execution time: 0.0098
DEBUG - 2021-12-24 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:10:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:10:16 --> Total execution time: 0.0385
DEBUG - 2021-12-24 15:10:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:10:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:10:17 --> Total execution time: 0.0062
DEBUG - 2021-12-24 15:10:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:10:19 --> Total execution time: 0.0049
DEBUG - 2021-12-24 15:10:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:10:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:10:22 --> Total execution time: 0.0096
DEBUG - 2021-12-24 15:10:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:10:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:10:46 --> Total execution time: 0.0052
DEBUG - 2021-12-24 15:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:11:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:11:29 --> Total execution time: 0.0388
DEBUG - 2021-12-24 15:11:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:11:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:11:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:11:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:11:43 --> Total execution time: 0.0052
DEBUG - 2021-12-24 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:12:20 --> Total execution time: 0.0335
DEBUG - 2021-12-24 15:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:12:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:12:22 --> Total execution time: 0.0117
DEBUG - 2021-12-24 15:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:12:22 --> Total execution time: 0.0065
DEBUG - 2021-12-24 15:12:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:12:23 --> Total execution time: 0.0059
DEBUG - 2021-12-24 15:12:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:12:26 --> Total execution time: 0.0068
DEBUG - 2021-12-24 15:12:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:12:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:12:32 --> Total execution time: 0.0106
DEBUG - 2021-12-24 15:14:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:14:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:14:08 --> Total execution time: 0.0399
DEBUG - 2021-12-24 15:15:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:15:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:15:32 --> Total execution time: 0.0325
DEBUG - 2021-12-24 15:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:16:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 15:16:02 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-24 15:16:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:16:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:16:05 --> Total execution time: 0.0116
DEBUG - 2021-12-24 15:16:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:16:58 --> Total execution time: 0.0373
DEBUG - 2021-12-24 15:21:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:21:01 --> No URI present. Default controller set.
DEBUG - 2021-12-24 15:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:21:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:21:01 --> Total execution time: 0.0310
DEBUG - 2021-12-24 15:21:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 15:21:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 15:21:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:21:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 15:21:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:21:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:21:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:21:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:21:18 --> Total execution time: 0.0076
DEBUG - 2021-12-24 15:21:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:21:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:21:22 --> Total execution time: 0.0138
DEBUG - 2021-12-24 15:21:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:21:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-24 15:21:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2021-12-24 15:21:24 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2021-12-24 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:35:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:35:55 --> Total execution time: 0.0404
DEBUG - 2021-12-24 15:35:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:35:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:38:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:38:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:38:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:38:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:38:46 --> Total execution time: 0.0330
DEBUG - 2021-12-24 15:39:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:39:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:39:52 --> Total execution time: 0.0389
DEBUG - 2021-12-24 15:39:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:39:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:39:54 --> Total execution time: 0.0059
DEBUG - 2021-12-24 15:43:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:43:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:43:24 --> Total execution time: 0.0358
DEBUG - 2021-12-24 15:43:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:43:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:43:27 --> Total execution time: 0.0053
DEBUG - 2021-12-24 15:43:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:43:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:43:28 --> Total execution time: 0.0120
DEBUG - 2021-12-24 15:43:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:43:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:43:30 --> Total execution time: 0.0051
DEBUG - 2021-12-24 15:44:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:44:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:44:15 --> Total execution time: 0.0324
DEBUG - 2021-12-24 15:44:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:44:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:44:17 --> Total execution time: 0.0110
DEBUG - 2021-12-24 15:44:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:44:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:44:18 --> Total execution time: 0.0056
DEBUG - 2021-12-24 15:44:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:44:19 --> Total execution time: 0.0053
DEBUG - 2021-12-24 15:44:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:44:20 --> Total execution time: 0.0049
DEBUG - 2021-12-24 15:44:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:44:20 --> Total execution time: 0.0105
DEBUG - 2021-12-24 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:57:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:57:27 --> Total execution time: 0.0415
DEBUG - 2021-12-24 15:57:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 15:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 15:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 15:57:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 15:57:31 --> Total execution time: 0.0059
DEBUG - 2021-12-24 16:15:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:33 --> Total execution time: 0.0411
DEBUG - 2021-12-24 16:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:36 --> Total execution time: 0.0053
DEBUG - 2021-12-24 16:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:36 --> Total execution time: 0.0049
DEBUG - 2021-12-24 16:15:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:37 --> Total execution time: 0.0098
DEBUG - 2021-12-24 16:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:38 --> Total execution time: 0.0054
DEBUG - 2021-12-24 16:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:39 --> Total execution time: 0.0118
DEBUG - 2021-12-24 16:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:39 --> Total execution time: 0.0052
DEBUG - 2021-12-24 16:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:40 --> Total execution time: 0.0089
DEBUG - 2021-12-24 16:15:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:43 --> Total execution time: 0.0101
DEBUG - 2021-12-24 16:15:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:15:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:15:56 --> Total execution time: 0.0051
DEBUG - 2021-12-24 16:23:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:23:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:23:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:23:42 --> Total execution time: 0.0073
DEBUG - 2021-12-24 16:23:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:23:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:23:44 --> Total execution time: 0.0064
DEBUG - 2021-12-24 16:23:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:23:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:23:45 --> Total execution time: 0.0116
DEBUG - 2021-12-24 16:23:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:23:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:23:48 --> Total execution time: 0.0048
DEBUG - 2021-12-24 16:24:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:24:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:24:20 --> Total execution time: 0.0388
DEBUG - 2021-12-24 16:24:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:24:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:24:32 --> Total execution time: 0.0058
DEBUG - 2021-12-24 16:25:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:25:52 --> No URI present. Default controller set.
DEBUG - 2021-12-24 16:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:25:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:25:52 --> Total execution time: 0.0305
DEBUG - 2021-12-24 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:25:54 --> No URI present. Default controller set.
DEBUG - 2021-12-24 16:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:25:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:25:54 --> Total execution time: 0.0043
DEBUG - 2021-12-24 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 16:25:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 16:25:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:25:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 16:25:55 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 16:25:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:25:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 16:25:55 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 16:26:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:26:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:26:10 --> Total execution time: 0.0048
DEBUG - 2021-12-24 16:26:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 16:26:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-24 16:26:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:26:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:26:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:26:22 --> Total execution time: 0.0065
DEBUG - 2021-12-24 16:26:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:26:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:26:26 --> Total execution time: 0.0061
DEBUG - 2021-12-24 16:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:29:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:29:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:29:11 --> Total execution time: 0.0061
DEBUG - 2021-12-24 16:29:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:29:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:29:31 --> Total execution time: 0.0144
DEBUG - 2021-12-24 16:31:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:31:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:31:11 --> Total execution time: 0.0332
DEBUG - 2021-12-24 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:34:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:34:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:34:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:34:57 --> Total execution time: 0.0071
DEBUG - 2021-12-24 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:38:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:38:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:38:52 --> Total execution time: 0.0071
DEBUG - 2021-12-24 16:40:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:40:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:40:27 --> Total execution time: 0.0067
DEBUG - 2021-12-24 16:46:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:46:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:46:13 --> Total execution time: 0.0341
DEBUG - 2021-12-24 16:46:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:46:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:46:27 --> Total execution time: 0.0156
DEBUG - 2021-12-24 16:46:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:46:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:46:30 --> Total execution time: 0.0053
DEBUG - 2021-12-24 16:51:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:51:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:51:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:51:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:51:20 --> Total execution time: 0.0073
DEBUG - 2021-12-24 16:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:53:34 --> Total execution time: 0.0078
DEBUG - 2021-12-24 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:58:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:58:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:58:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:58:55 --> Total execution time: 0.0073
DEBUG - 2021-12-24 16:59:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:59:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:59:03 --> Total execution time: 0.0129
DEBUG - 2021-12-24 16:59:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 16:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 16:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 16:59:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 16:59:05 --> Total execution time: 0.0049
DEBUG - 2021-12-24 17:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 17:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 17:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 17:02:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 17:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 17:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 17:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 17:02:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 17:02:11 --> Total execution time: 0.0081
DEBUG - 2021-12-24 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 17:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 17:07:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 17:07:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 17:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 17:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 17:07:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 17:07:35 --> Total execution time: 0.0075
DEBUG - 2021-12-24 17:07:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 17:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 17:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 17:07:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 17:07:37 --> Total execution time: 0.0067
DEBUG - 2021-12-24 17:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 17:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 17:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 17:07:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 17:07:38 --> Total execution time: 0.0139
DEBUG - 2021-12-24 18:51:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 18:51:27 --> No URI present. Default controller set.
DEBUG - 2021-12-24 18:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 18:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 18:51:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-24 18:51:27 --> Total execution time: 0.0315
DEBUG - 2021-12-24 18:51:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 18:51:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 18:51:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-24 19:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 19:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-24 19:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-24 19:25:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-24 19:25:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2021-12-24 19:25:19 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2021-12-24 19:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-24 19:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-24 19:25:19 --> 404 Page Not Found: Faviconico/index
