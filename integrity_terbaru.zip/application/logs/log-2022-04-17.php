<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-17 11:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-17 11:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-17 11:47:14 --> 404 Page Not Found: Wp-content/index
