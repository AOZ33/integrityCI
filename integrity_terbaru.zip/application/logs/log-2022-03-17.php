<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-17 10:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:35 --> No URI present. Default controller set.
DEBUG - 2022-03-17 10:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 10:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 10:00:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 10:00:35 --> Total execution time: 0.0306
DEBUG - 2022-03-17 10:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 10:00:35 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 10:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 10:00:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 10:00:37 --> Total execution time: 0.0031
DEBUG - 2022-03-17 10:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 10:00:38 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:44 --> No URI present. Default controller set.
DEBUG - 2022-03-17 10:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 10:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 10:00:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 10:00:44 --> Total execution time: 0.0036
DEBUG - 2022-03-17 10:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 10:00:44 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:45 --> No URI present. Default controller set.
DEBUG - 2022-03-17 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 10:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 10:00:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 10:00:45 --> Total execution time: 0.0031
DEBUG - 2022-03-17 10:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 10:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 10:00:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 10:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 10:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 10:00:46 --> Total execution time: 0.0061
DEBUG - 2022-03-17 10:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 10:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 10:00:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 10:00:48 --> Total execution time: 0.0115
DEBUG - 2022-03-17 10:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 10:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 10:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 10:00:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 10:00:49 --> Total execution time: 0.0043
DEBUG - 2022-03-17 11:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 11:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 11:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 11:21:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 11:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 11:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 11:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 11:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 11:21:26 --> Total execution time: 0.0070
DEBUG - 2022-03-17 11:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 11:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 11:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 11:45:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 11:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 11:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 11:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 11:45:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 11:45:33 --> Total execution time: 0.0072
DEBUG - 2022-03-17 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 11:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 11:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 11:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 11:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 11:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 11:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 11:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 11:52:40 --> Total execution time: 0.0065
DEBUG - 2022-03-17 12:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 12:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 12:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 12:02:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 12:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 12:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 12:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 12:02:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 12:02:25 --> Total execution time: 0.0070
DEBUG - 2022-03-17 12:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 12:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 12:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 12:13:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 12:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 12:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 12:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 12:13:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 12:13:39 --> Total execution time: 0.0068
DEBUG - 2022-03-17 13:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:05:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:05:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:05:33 --> Total execution time: 0.0072
DEBUG - 2022-03-17 13:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:13:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:13:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:13:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:13:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:13:02 --> Total execution time: 0.0064
DEBUG - 2022-03-17 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:25:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:25:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:25:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:25:27 --> Total execution time: 0.0067
DEBUG - 2022-03-17 13:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:40:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:40:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:40:39 --> Total execution time: 0.0067
DEBUG - 2022-03-17 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:43:53 --> Total execution time: 0.0053
DEBUG - 2022-03-17 13:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:46:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:46:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:46:47 --> Total execution time: 0.0070
DEBUG - 2022-03-17 13:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:51:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:51:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:51:02 --> Total execution time: 0.0064
DEBUG - 2022-03-17 13:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:51:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:51:09 --> Total execution time: 0.0115
DEBUG - 2022-03-17 13:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 13:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 13:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 13:51:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 13:51:16 --> Total execution time: 0.0044
DEBUG - 2022-03-17 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:01:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:01:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:01:14 --> Total execution time: 0.0073
DEBUG - 2022-03-17 14:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:04:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:04:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:04:49 --> Total execution time: 0.0052
DEBUG - 2022-03-17 14:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:15:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:15:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:15:21 --> Total execution time: 0.0063
DEBUG - 2022-03-17 14:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:36:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:36:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:36:27 --> Total execution time: 0.0065
DEBUG - 2022-03-17 14:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:39:36 --> Total execution time: 0.0056
DEBUG - 2022-03-17 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:41:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:41:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:41:23 --> Total execution time: 0.0051
DEBUG - 2022-03-17 14:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:43:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:43:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:43:03 --> Total execution time: 0.0051
DEBUG - 2022-03-17 14:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:45:20 --> No URI present. Default controller set.
DEBUG - 2022-03-17 14:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:45:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:45:20 --> Total execution time: 0.0304
DEBUG - 2022-03-17 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 14:45:21 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-17 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:45:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 14:45:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 14:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:45:25 --> No URI present. Default controller set.
DEBUG - 2022-03-17 14:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:45:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:45:25 --> Total execution time: 0.0048
DEBUG - 2022-03-17 14:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:46:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:46:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:46:40 --> Total execution time: 0.0062
DEBUG - 2022-03-17 14:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:51:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:51:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:51:04 --> Total execution time: 0.0066
DEBUG - 2022-03-17 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:53:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 14:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 14:53:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 14:53:41 --> Total execution time: 0.0057
DEBUG - 2022-03-17 14:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 14:56:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 14:56:50 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:02:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:02:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:02:29 --> Total execution time: 0.0070
DEBUG - 2022-03-17 15:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:03:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:03:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:03:57 --> Total execution time: 0.0051
DEBUG - 2022-03-17 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:04:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:04:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:04:21 --> Total execution time: 0.0036
DEBUG - 2022-03-17 15:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:06:45 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:06:46 --> Total execution time: 0.0313
DEBUG - 2022-03-17 15:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:06:46 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:06:46 --> Total execution time: 0.0034
DEBUG - 2022-03-17 15:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:06:46 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:06:46 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:06:46 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:06:46 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-03-17 15:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:06:46 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:06:46 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:06:46 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:06:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:06:46 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:06:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:06:46 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:07:12 --> Total execution time: 0.0054
DEBUG - 2022-03-17 15:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:29 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:09:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:09:29 --> Total execution time: 0.0310
DEBUG - 2022-03-17 15:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:29 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:30 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:09:30 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:09:30 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:09:30 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:09:30 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:30 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:30 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:09:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:09:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:09:33 --> Total execution time: 0.0056
DEBUG - 2022-03-17 15:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:09:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:09:50 --> Total execution time: 0.0051
DEBUG - 2022-03-17 15:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:50 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:50 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:09:50 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:09:50 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:50 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:09:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:50 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:09:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:09:51 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:10:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:10:19 --> Total execution time: 0.0059
DEBUG - 2022-03-17 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:10:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:10:20 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:10:20 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-03-17 15:10:20 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:10:20 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:10:20 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:10:24 --> Total execution time: 0.0052
DEBUG - 2022-03-17 15:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:27 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:10:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:10:27 --> Total execution time: 0.0030
DEBUG - 2022-03-17 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:10:58 --> Total execution time: 0.0046
DEBUG - 2022-03-17 15:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:02 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:11:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:11:02 --> Total execution time: 0.0031
DEBUG - 2022-03-17 15:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:02 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:11:02 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:02 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:02 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:11:02 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:02 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:02 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:28 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:11:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:11:28 --> Total execution time: 0.0041
DEBUG - 2022-03-17 15:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:28 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:28 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:11:28 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:28 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:11:28 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:28 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:28 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:45 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:11:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:11:45 --> Total execution time: 0.0041
DEBUG - 2022-03-17 15:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:47 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:50 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:11:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:11:50 --> Total execution time: 0.0039
DEBUG - 2022-03-17 15:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:50 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:50 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:50 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:11:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:50 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-03-17 15:11:50 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:11:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:11:51 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:12:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:12:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:12:05 --> Total execution time: 0.0041
DEBUG - 2022-03-17 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:19 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:12:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:12:19 --> Total execution time: 0.0054
DEBUG - 2022-03-17 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:12:19 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:12:19 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:12:19 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:12:19 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:12:19 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:12:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:12:20 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:07 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:14:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:14:07 --> Total execution time: 0.0318
DEBUG - 2022-03-17 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:14:07 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:14:07 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:14:07 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:14:07 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:14:07 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:14:07 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:14:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:14:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:14:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:14:44 --> Total execution time: 0.0058
DEBUG - 2022-03-17 15:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:07 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:16:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:16:07 --> Total execution time: 0.0307
DEBUG - 2022-03-17 15:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:07 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:16:07 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:16:07 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:16:07 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:16:07 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:07 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:07 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:08 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:31 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:16:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:16:31 --> Total execution time: 0.0044
DEBUG - 2022-03-17 15:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:31 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:31 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:31 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:16:31 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:16:31 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:31 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:31 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:50 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:16:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:16:50 --> Total execution time: 0.0042
DEBUG - 2022-03-17 15:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:51 --> 404 Page Not Found: Assets/https:
ERROR - 2022-03-17 15:16:51 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:51 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:16:51 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:16:51 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:51 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:16:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:16:51 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:19:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:19:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:19:59 --> Total execution time: 0.0068
DEBUG - 2022-03-17 15:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:22:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:22:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:22:13 --> Total execution time: 0.0052
DEBUG - 2022-03-17 15:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:23:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:23:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:23:23 --> Total execution time: 0.0046
DEBUG - 2022-03-17 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:31 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:31 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-17 15:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:27:31 --> Total execution time: 0.0312
DEBUG - 2022-03-17 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:31 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:31 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:31 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:31 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:27:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:31 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:32 --> 404 Page Not Found: Images/bg-1.jpg
DEBUG - 2022-03-17 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:48 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:27:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:27:48 --> Total execution time: 0.0050
DEBUG - 2022-03-17 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:48 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:48 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:27:48 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:27:48 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:27:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:27:48 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:28:51 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:28:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:28:51 --> Total execution time: 0.0049
DEBUG - 2022-03-17 15:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:28:51 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:28:51 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:28:51 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:28:51 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:28:51 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:28:51 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:28:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:28:51 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:04 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:29:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:29:04 --> Total execution time: 0.0047
DEBUG - 2022-03-17 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:04 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:04 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:04 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:29:04 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:29:04 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:29:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:04 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:55 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:29:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:29:55 --> Total execution time: 0.0043
DEBUG - 2022-03-17 15:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:55 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:55 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:55 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:55 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:29:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:29:55 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:30:04 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:30:45 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:30:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:30:45 --> Total execution time: 0.0042
DEBUG - 2022-03-17 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:30:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:30:45 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:30:45 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:30:45 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:30:45 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:30:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:30:45 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:30:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:30:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:31:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:31:11 --> Total execution time: 0.0041
DEBUG - 2022-03-17 15:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:31:11 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:31:11 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:31:11 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:31:11 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:31:11 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:31:11 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:31:11 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:31:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:32:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:32:23 --> Total execution time: 0.0040
DEBUG - 2022-03-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:23 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:23 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:23 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:32:23 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:32:23 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:23 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:32:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:32:35 --> Total execution time: 0.0042
DEBUG - 2022-03-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:35 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:35 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:32:35 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:32:35 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:35 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:32:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:35 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:32:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:32:43 --> Total execution time: 0.0040
DEBUG - 2022-03-17 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:43 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:43 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:32:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:43 --> 404 Page Not Found: Js/main.js
ERROR - 2022-03-17 15:32:43 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:32:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:32:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:33:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:33:30 --> Total execution time: 0.0042
DEBUG - 2022-03-17 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:33:30 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:33:30 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:33:30 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:33:30 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:33:30 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:33:30 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:33:30 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:33 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:33:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:33:33 --> Total execution time: 0.0041
DEBUG - 2022-03-17 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:33:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:33:33 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:33:33 --> 404 Page Not Found: Js/jquery.min.js
ERROR - 2022-03-17 15:33:33 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:33:33 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:33:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:33:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:33:33 --> Total execution time: 0.0073
DEBUG - 2022-03-17 15:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:36:15 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:36:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:36:15 --> Total execution time: 0.0314
DEBUG - 2022-03-17 15:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:36:15 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:36:15 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:36:15 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:36:15 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:36:15 --> UTF-8 Support Enabled
ERROR - 2022-03-17 15:36:15 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:36:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:36:15 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:37:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:37:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:37:34 --> Total execution time: 0.0049
DEBUG - 2022-03-17 15:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:13 --> No URI present. Default controller set.
DEBUG - 2022-03-17 15:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:39:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:39:13 --> Total execution time: 0.0308
DEBUG - 2022-03-17 15:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:39:14 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 15:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:39:14 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 15:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:39:14 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 15:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:39:14 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 15:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 15:39:14 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 15:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:39:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:39:32 --> Total execution time: 0.0051
DEBUG - 2022-03-17 15:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:39:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:39:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:39:44 --> Total execution time: 0.0035
DEBUG - 2022-03-17 15:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:39:45 --> Total execution time: 0.0074
DEBUG - 2022-03-17 15:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:39:49 --> Total execution time: 0.0053
DEBUG - 2022-03-17 15:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:46:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:46:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:46:26 --> Total execution time: 0.0070
DEBUG - 2022-03-17 15:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:49:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:49:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:49:05 --> Total execution time: 0.0053
DEBUG - 2022-03-17 15:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:52:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 15:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 15:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 15:52:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 15:52:39 --> Total execution time: 0.0050
DEBUG - 2022-03-17 16:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:12:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:12:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:12:18 --> Total execution time: 0.0080
DEBUG - 2022-03-17 16:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:15:19 --> Total execution time: 0.0049
DEBUG - 2022-03-17 16:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:17:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:17:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:17:00 --> Total execution time: 0.0047
DEBUG - 2022-03-17 16:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:28:42 --> Total execution time: 0.0058
DEBUG - 2022-03-17 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:31:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:31:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:31:29 --> Total execution time: 0.0056
DEBUG - 2022-03-17 16:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:34:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:34:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:34:31 --> Total execution time: 0.0049
DEBUG - 2022-03-17 16:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:36:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:36:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:36:36 --> Total execution time: 0.0051
DEBUG - 2022-03-17 16:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:41:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:41:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:41:18 --> Total execution time: 0.0067
DEBUG - 2022-03-17 16:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:43:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:43:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:43:54 --> Total execution time: 0.0054
DEBUG - 2022-03-17 16:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:45:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:45:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:45:48 --> Total execution time: 0.0040
DEBUG - 2022-03-17 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:50:02 --> Total execution time: 0.0067
DEBUG - 2022-03-17 16:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:50:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:50:21 --> Total execution time: 0.0147
DEBUG - 2022-03-17 16:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:51:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:51:41 --> Total execution time: 0.0336
DEBUG - 2022-03-17 16:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:53:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:53:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:53:28 --> Total execution time: 0.0053
DEBUG - 2022-03-17 16:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:55:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:55:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:55:06 --> Total execution time: 0.0037
DEBUG - 2022-03-17 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 16:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 16:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 16:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 16:57:51 --> Total execution time: 0.0048
DEBUG - 2022-03-17 17:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:00:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:00:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:00:11 --> Total execution time: 0.0057
DEBUG - 2022-03-17 17:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:02:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:02:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:02:32 --> Total execution time: 0.0050
DEBUG - 2022-03-17 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:04:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:04:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:04:34 --> Total execution time: 0.0052
DEBUG - 2022-03-17 17:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:06:18 --> Total execution time: 0.0041
DEBUG - 2022-03-17 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:08:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:08:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:08:27 --> Total execution time: 0.0059
DEBUG - 2022-03-17 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:25:28 --> No URI present. Default controller set.
DEBUG - 2022-03-17 17:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:25:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:25:28 --> Total execution time: 0.0305
DEBUG - 2022-03-17 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 17:25:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 17:25:28 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 17:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:25:28 --> UTF-8 Support Enabled
ERROR - 2022-03-17 17:25:28 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-17 17:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 17:25:28 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 17:25:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 17:25:28 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 17:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:26:38 --> No URI present. Default controller set.
DEBUG - 2022-03-17 17:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 17:26:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 17:26:38 --> Total execution time: 0.0055
DEBUG - 2022-03-17 17:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 17:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 17:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-17 17:50:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 17:50:42 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 21:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 21:59:26 --> No URI present. Default controller set.
DEBUG - 2022-03-17 21:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 21:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 21:59:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-17 21:59:26 --> Total execution time: 0.0313
DEBUG - 2022-03-17 21:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 21:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 21:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 21:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 21:59:26 --> UTF-8 Support Enabled
ERROR - 2022-03-17 21:59:26 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-03-17 21:59:26 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-17 21:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 21:59:26 --> UTF-8 Support Enabled
ERROR - 2022-03-17 21:59:26 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-17 21:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 21:59:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-17 21:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 21:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 21:59:26 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-17 21:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 21:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 21:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-17 21:59:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 21:59:53 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:00:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:00:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:00:41 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:00:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:00:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:00:45 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:00:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:00:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:00:53 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:00:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:00:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:00:56 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:01:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 22:01:47 --> 404 Page Not Found: Integrity/application
DEBUG - 2022-03-17 22:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:01:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:01:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:01:50 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:02:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:02:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:02:00 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 22:02:10 --> 404 Page Not Found: Sitemapxml/index
DEBUG - 2022-03-17 22:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:02:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:02:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:02:11 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 22:02:15 --> 404 Page Not Found: Robottxt/index
DEBUG - 2022-03-17 22:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:02:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:02:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:02:16 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:02:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:02:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:02:17 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:02:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:02:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-17 22:02:21 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-17 22:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:02:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:02:37 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
DEBUG - 2022-03-17 22:02:37 --> Total execution time: 0.0047
DEBUG - 2022-03-17 22:02:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-17 22:02:43 --> 404 Page Not Found: Appointment/aasdas
DEBUG - 2022-03-17 22:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:02:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:02:44 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
DEBUG - 2022-03-17 22:02:44 --> Total execution time: 0.0033
DEBUG - 2022-03-17 22:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:02:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:02:45 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
DEBUG - 2022-03-17 22:02:45 --> Total execution time: 0.0032
DEBUG - 2022-03-17 22:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:03:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:03:14 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
DEBUG - 2022-03-17 22:03:14 --> Total execution time: 0.0045
DEBUG - 2022-03-17 22:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:03:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:03:16 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
DEBUG - 2022-03-17 22:03:16 --> Total execution time: 0.0032
DEBUG - 2022-03-17 22:03:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-17 22:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-17 22:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-17 22:03:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-17 22:03:50 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
DEBUG - 2022-03-17 22:03:50 --> Total execution time: 0.0045
