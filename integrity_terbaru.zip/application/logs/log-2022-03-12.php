<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-12 02:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-12 02:39:11 --> No URI present. Default controller set.
DEBUG - 2022-03-12 02:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-12 02:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-12 02:39:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 02:39:11 --> Total execution time: 0.0308
DEBUG - 2022-03-12 08:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-12 08:14:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-12 08:14:55 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-12 08:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-12 08:14:59 --> No URI present. Default controller set.
DEBUG - 2022-03-12 08:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-12 08:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-12 08:14:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 08:14:59 --> Total execution time: 0.0232
DEBUG - 2022-03-12 13:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-12 13:53:25 --> No URI present. Default controller set.
DEBUG - 2022-03-12 13:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-12 13:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-12 13:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-12 13:53:25 --> Total execution time: 0.0312
