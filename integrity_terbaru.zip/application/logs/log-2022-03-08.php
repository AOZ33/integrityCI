<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-08 02:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 02:06:04 --> No URI present. Default controller set.
DEBUG - 2022-03-08 02:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 02:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 02:06:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 02:06:04 --> Total execution time: 0.0307
DEBUG - 2022-03-08 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:27:59 --> No URI present. Default controller set.
DEBUG - 2022-03-08 10:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:27:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:27:59 --> Total execution time: 0.0300
DEBUG - 2022-03-08 10:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:27:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 10:27:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-08 10:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:28:00 --> No URI present. Default controller set.
DEBUG - 2022-03-08 10:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:28:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:28:00 --> Total execution time: 0.0036
DEBUG - 2022-03-08 10:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:28:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:28:05 --> Total execution time: 0.0060
DEBUG - 2022-03-08 10:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:31:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:31:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:31:55 --> Total execution time: 0.0505
DEBUG - 2022-03-08 10:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:32:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:32:13 --> Total execution time: 0.0053
DEBUG - 2022-03-08 10:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:32:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:32:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:32:25 --> Total execution time: 0.0185
DEBUG - 2022-03-08 10:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 10:50:36 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-08 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:50:39 --> Total execution time: 0.0074
DEBUG - 2022-03-08 10:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:52:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:04 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:52:04 --> Total execution time: 0.0511
DEBUG - 2022-03-08 10:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:52:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:52:06 --> Total execution time: 0.0195
DEBUG - 2022-03-08 10:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:52:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:52:43 --> Total execution time: 0.0190
DEBUG - 2022-03-08 10:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:52:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:52:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:52:51 --> Total execution time: 0.0160
DEBUG - 2022-03-08 10:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:53:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 10:53:00 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-08 10:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:53:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:53:01 --> Total execution time: 0.0040
DEBUG - 2022-03-08 10:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:53:03 --> Total execution time: 0.0040
DEBUG - 2022-03-08 10:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:53:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:53:05 --> Total execution time: 0.0168
DEBUG - 2022-03-08 10:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:53:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:53:20 --> Total execution time: 0.0179
DEBUG - 2022-03-08 10:53:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:53:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:53:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:53:21 --> Total execution time: 0.0158
DEBUG - 2022-03-08 10:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 10:55:01 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-08 10:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:55:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:55:03 --> Total execution time: 0.0044
DEBUG - 2022-03-08 10:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:55:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:55:07 --> Total execution time: 0.0194
DEBUG - 2022-03-08 10:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:55:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:55:30 --> Total execution time: 0.0183
DEBUG - 2022-03-08 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:55:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:55:33 --> Total execution time: 0.0160
DEBUG - 2022-03-08 10:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:55:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:55:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:55:34 --> Total execution time: 0.0157
DEBUG - 2022-03-08 10:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:58:23 --> No URI present. Default controller set.
DEBUG - 2022-03-08 10:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:58:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:58:23 --> Total execution time: 0.0310
DEBUG - 2022-03-08 10:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:58:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 10:58:23 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-08 10:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:58:23 --> No URI present. Default controller set.
DEBUG - 2022-03-08 10:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:58:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:58:23 --> Total execution time: 0.0033
DEBUG - 2022-03-08 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:58:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 10:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:58:26 --> Total execution time: 0.0055
DEBUG - 2022-03-08 10:58:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 10:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 10:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 10:58:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 326
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-08 10:58:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
DEBUG - 2022-03-08 10:58:29 --> Total execution time: 0.0234
DEBUG - 2022-03-08 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:04:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:04:00 --> Total execution time: 0.0407
DEBUG - 2022-03-08 11:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:05:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:05:39 --> Total execution time: 0.0337
DEBUG - 2022-03-08 11:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:05:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:05:42 --> Total execution time: 0.0091
DEBUG - 2022-03-08 11:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:06:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:06:04 --> Total execution time: 0.0090
DEBUG - 2022-03-08 11:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:06:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:06:26 --> Total execution time: 0.0056
DEBUG - 2022-03-08 11:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:06:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:06:33 --> Total execution time: 0.0077
DEBUG - 2022-03-08 11:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:08:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:08:09 --> Total execution time: 0.0320
DEBUG - 2022-03-08 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:12:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:12:37 --> Total execution time: 0.0405
DEBUG - 2022-03-08 11:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:15:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:15:33 --> Total execution time: 0.0099
DEBUG - 2022-03-08 11:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:15:37 --> Total execution time: 0.0042
DEBUG - 2022-03-08 11:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:15:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:15:50 --> Total execution time: 0.0088
DEBUG - 2022-03-08 11:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:16:01 --> Total execution time: 0.0040
DEBUG - 2022-03-08 11:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:19:23 --> No URI present. Default controller set.
DEBUG - 2022-03-08 11:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:19:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:19:23 --> Total execution time: 0.0299
DEBUG - 2022-03-08 11:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:19:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 11:19:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-08 11:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:33:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:33:33 --> Total execution time: 0.0413
DEBUG - 2022-03-08 11:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:34:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:34:03 --> Total execution time: 0.0074
DEBUG - 2022-03-08 11:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:35:38 --> Total execution time: 0.0114
DEBUG - 2022-03-08 11:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:35:42 --> Total execution time: 0.0061
DEBUG - 2022-03-08 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:35:45 --> Total execution time: 0.0059
DEBUG - 2022-03-08 11:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:51 --> Total execution time: 0.0047
DEBUG - 2022-03-08 11:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:54 --> Total execution time: 0.0048
DEBUG - 2022-03-08 11:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:57 --> Total execution time: 0.0042
DEBUG - 2022-03-08 11:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:35:59 --> Total execution time: 0.0042
DEBUG - 2022-03-08 11:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:36:01 --> Total execution time: 0.0069
DEBUG - 2022-03-08 11:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:36:11 --> Total execution time: 0.0063
DEBUG - 2022-03-08 11:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:21 --> Total execution time: 0.0039
DEBUG - 2022-03-08 11:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:28 --> Total execution time: 0.0044
DEBUG - 2022-03-08 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:32 --> Total execution time: 0.0044
DEBUG - 2022-03-08 11:36:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:35 --> Total execution time: 0.0043
DEBUG - 2022-03-08 11:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:39 --> Total execution time: 0.0046
DEBUG - 2022-03-08 11:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:43 --> Total execution time: 0.0051
DEBUG - 2022-03-08 11:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:36:46 --> Total execution time: 0.0042
DEBUG - 2022-03-08 11:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:37:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:37:04 --> Total execution time: 0.0085
DEBUG - 2022-03-08 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:38:25 --> Total execution time: 0.0092
DEBUG - 2022-03-08 11:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:38:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:38:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:38:42 --> Total execution time: 0.0099
DEBUG - 2022-03-08 11:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:38:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:38:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:38:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:38:58 --> Total execution time: 0.0089
DEBUG - 2022-03-08 11:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:48:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:48:23 --> Total execution time: 0.0419
DEBUG - 2022-03-08 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:50:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:50:32 --> Total execution time: 0.0088
DEBUG - 2022-03-08 11:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:50:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:50:35 --> Total execution time: 0.0049
DEBUG - 2022-03-08 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:50:45 --> Total execution time: 0.0035
DEBUG - 2022-03-08 11:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:50:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:50:56 --> Total execution time: 0.0084
DEBUG - 2022-03-08 11:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:51:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:51:03 --> Total execution time: 0.0091
DEBUG - 2022-03-08 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:51:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:51:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:51:09 --> Total execution time: 0.0077
DEBUG - 2022-03-08 11:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:51:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:51:33 --> Total execution time: 0.0126
DEBUG - 2022-03-08 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:51:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:51:41 --> Total execution time: 0.0100
DEBUG - 2022-03-08 11:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:51:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:51:56 --> Total execution time: 0.0068
DEBUG - 2022-03-08 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:52:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:52:02 --> Total execution time: 0.0038
DEBUG - 2022-03-08 11:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:53:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:53:32 --> Total execution time: 0.0325
DEBUG - 2022-03-08 11:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:53:40 --> Total execution time: 0.0102
DEBUG - 2022-03-08 11:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:53:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:53:41 --> Total execution time: 0.0038
DEBUG - 2022-03-08 11:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:54:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:54:46 --> Total execution time: 0.0059
DEBUG - 2022-03-08 11:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:54:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:54:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:54:48 --> Total execution time: 0.0039
DEBUG - 2022-03-08 11:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:50 --> No URI present. Default controller set.
DEBUG - 2022-03-08 11:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:54:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:54:50 --> Total execution time: 0.0039
DEBUG - 2022-03-08 11:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 11:54:51 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-08 11:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:54:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:54:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:54:56 --> Total execution time: 0.0052
DEBUG - 2022-03-08 11:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:54:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:54:57 --> Total execution time: 0.0100
DEBUG - 2022-03-08 11:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:54:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:54:59 --> Total execution time: 0.0110
DEBUG - 2022-03-08 11:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:55:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:55:00 --> Total execution time: 0.0061
DEBUG - 2022-03-08 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:55:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:55:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:55:03 --> Total execution time: 0.0076
DEBUG - 2022-03-08 11:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:55:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:55:04 --> Total execution time: 0.0046
DEBUG - 2022-03-08 11:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:56:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:56:23 --> Total execution time: 0.0377
DEBUG - 2022-03-08 11:56:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:56:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:56:24 --> Total execution time: 0.0041
DEBUG - 2022-03-08 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:56:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:56:27 --> Total execution time: 0.0037
DEBUG - 2022-03-08 11:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:56:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:56:31 --> Total execution time: 0.0043
DEBUG - 2022-03-08 11:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:56:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:56:35 --> Total execution time: 0.0038
DEBUG - 2022-03-08 11:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:57:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:57:30 --> Total execution time: 0.0053
DEBUG - 2022-03-08 11:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:57:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:57:33 --> Total execution time: 0.0043
DEBUG - 2022-03-08 11:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:57:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:57:37 --> Total execution time: 0.0053
DEBUG - 2022-03-08 11:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:57:41 --> Total execution time: 0.0069
DEBUG - 2022-03-08 11:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:57:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:57:43 --> Total execution time: 0.0090
DEBUG - 2022-03-08 11:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:58:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:58:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:58:12 --> Total execution time: 0.0097
DEBUG - 2022-03-08 11:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:17 --> Total execution time: 0.0089
DEBUG - 2022-03-08 11:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:18 --> Total execution time: 0.0064
DEBUG - 2022-03-08 11:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:20 --> Total execution time: 0.0038
DEBUG - 2022-03-08 11:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:37 --> Total execution time: 0.0055
DEBUG - 2022-03-08 11:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:39 --> Total execution time: 0.0040
DEBUG - 2022-03-08 11:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:41 --> Total execution time: 0.0076
DEBUG - 2022-03-08 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:42 --> Total execution time: 0.0036
DEBUG - 2022-03-08 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:44 --> Total execution time: 0.0037
DEBUG - 2022-03-08 11:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 11:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 11:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 11:59:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 11:59:47 --> Total execution time: 0.0039
DEBUG - 2022-03-08 12:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:00:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:00:29 --> Total execution time: 0.0050
DEBUG - 2022-03-08 12:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:00:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:00:31 --> Total execution time: 0.0042
DEBUG - 2022-03-08 12:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:00:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:00:33 --> Total execution time: 0.0071
DEBUG - 2022-03-08 12:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:00:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:00:35 --> Total execution time: 0.0036
DEBUG - 2022-03-08 12:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:00:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:00:37 --> Total execution time: 0.0046
DEBUG - 2022-03-08 12:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:27:14 --> Total execution time: 0.0364
DEBUG - 2022-03-08 12:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:27:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:27:17 --> Total execution time: 0.0109
DEBUG - 2022-03-08 12:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:27:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:27:20 --> Total execution time: 0.0042
DEBUG - 2022-03-08 12:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:28:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:28:21 --> Total execution time: 0.0052
DEBUG - 2022-03-08 12:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:29:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:29:54 --> Total execution time: 0.0335
DEBUG - 2022-03-08 12:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:36:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:36:50 --> Total execution time: 0.0351
DEBUG - 2022-03-08 12:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:37:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:37:20 --> Total execution time: 0.0070
DEBUG - 2022-03-08 12:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:38:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:38:08 --> Total execution time: 0.0058
DEBUG - 2022-03-08 12:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:38:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:38:38 --> Total execution time: 0.0052
DEBUG - 2022-03-08 12:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:40:28 --> Total execution time: 0.0391
DEBUG - 2022-03-08 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:41:13 --> Total execution time: 0.0071
DEBUG - 2022-03-08 12:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:41:20 --> Total execution time: 0.0047
DEBUG - 2022-03-08 12:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:52:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:52:04 --> Total execution time: 0.0429
DEBUG - 2022-03-08 12:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:52:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:52:10 --> Total execution time: 0.0046
DEBUG - 2022-03-08 12:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:52:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:52:12 --> Total execution time: 0.0037
DEBUG - 2022-03-08 12:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:52:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:52:18 --> Total execution time: 0.0045
DEBUG - 2022-03-08 12:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:52:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:52:22 --> Total execution time: 0.0061
DEBUG - 2022-03-08 12:58:52 --> UTF-8 Support Enabled
ERROR - 2022-03-08 12:58:52 --> Severity: error --> Exception: Call to a member function setDefaultController() on null /home/dunr4521/public_html/integrity/application/config/routes.php 55
DEBUG - 2022-03-08 12:58:54 --> UTF-8 Support Enabled
ERROR - 2022-03-08 12:58:54 --> Severity: error --> Exception: Call to a member function setDefaultController() on null /home/dunr4521/public_html/integrity/application/config/routes.php 55
DEBUG - 2022-03-08 12:58:55 --> UTF-8 Support Enabled
ERROR - 2022-03-08 12:58:55 --> Severity: error --> Exception: Call to a member function setDefaultController() on null /home/dunr4521/public_html/integrity/application/config/routes.php 55
DEBUG - 2022-03-08 12:59:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 12:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 12:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 12:59:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 12:59:16 --> Total execution time: 0.0370
DEBUG - 2022-03-08 13:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:04:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 13:04:02 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-08 13:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:04:02 --> Total execution time: 0.0348
DEBUG - 2022-03-08 13:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:05:35 --> Total execution time: 0.0329
DEBUG - 2022-03-08 13:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 13:05:36 --> 404 Page Not Found: Assets/css
DEBUG - 2022-03-08 13:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 13:05:36 --> 404 Page Not Found: Assets/css
DEBUG - 2022-03-08 13:05:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 13:05:36 --> 404 Page Not Found: Assets/js
DEBUG - 2022-03-08 13:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:07:11 --> Total execution time: 0.0316
DEBUG - 2022-03-08 13:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:07:40 --> Total execution time: 0.0049
DEBUG - 2022-03-08 13:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:09:01 --> Total execution time: 0.0318
DEBUG - 2022-03-08 13:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:09:21 --> Total execution time: 0.0045
DEBUG - 2022-03-08 13:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:10:41 --> Total execution time: 0.0331
DEBUG - 2022-03-08 13:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:10:59 --> Total execution time: 0.0056
DEBUG - 2022-03-08 13:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 13:11:32 --> Total execution time: 0.0135
DEBUG - 2022-03-08 13:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 13:12:34 --> Total execution time: 0.0085
DEBUG - 2022-03-08 13:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:12:36 --> Total execution time: 0.0037
DEBUG - 2022-03-08 13:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:13:11 --> Total execution time: 0.0049
DEBUG - 2022-03-08 13:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:13:14 --> Total execution time: 0.0039
DEBUG - 2022-03-08 13:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:13:47 --> Total execution time: 0.0048
DEBUG - 2022-03-08 13:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:13:54 --> Total execution time: 0.0040
DEBUG - 2022-03-08 13:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:41:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 13:41:27 --> Total execution time: 0.0416
DEBUG - 2022-03-08 13:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:41:29 --> Total execution time: 0.0054
DEBUG - 2022-03-08 13:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:41:57 --> Total execution time: 0.0051
DEBUG - 2022-03-08 13:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:55:28 --> Total execution time: 0.0337
DEBUG - 2022-03-08 13:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:55:31 --> Total execution time: 0.0042
DEBUG - 2022-03-08 13:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:56:06 --> Total execution time: 0.0056
DEBUG - 2022-03-08 13:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:56:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 13:56:12 --> Total execution time: 0.0121
DEBUG - 2022-03-08 13:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:56:14 --> Total execution time: 0.0038
DEBUG - 2022-03-08 13:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:56:15 --> Total execution time: 0.0042
DEBUG - 2022-03-08 13:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:56:20 --> Total execution time: 0.0060
DEBUG - 2022-03-08 13:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:57:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 13:57:05 --> Total execution time: 0.0081
DEBUG - 2022-03-08 13:57:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:57:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 13:57:10 --> Total execution time: 0.0045
DEBUG - 2022-03-08 13:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:57:46 --> Total execution time: 0.0054
DEBUG - 2022-03-08 13:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:58:13 --> Total execution time: 0.0051
DEBUG - 2022-03-08 13:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 13:58:22 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 28
ERROR - 2022-03-08 13:58:22 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 30
ERROR - 2022-03-08 13:58:22 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 32
DEBUG - 2022-03-08 13:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:58:22 --> Total execution time: 0.0036
DEBUG - 2022-03-08 13:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 13:58:36 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 28
ERROR - 2022-03-08 13:58:36 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 30
ERROR - 2022-03-08 13:58:36 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 32
DEBUG - 2022-03-08 13:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:58:36 --> Total execution time: 0.0043
DEBUG - 2022-03-08 13:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 13:58:46 --> Severity: error --> Exception: Call to undefined method Spk_model::detail() /home/dunr4521/public_html/integrity/application/controllers/Spk.php 44
DEBUG - 2022-03-08 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 13:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 13:58:48 --> Total execution time: 0.0046
DEBUG - 2022-03-08 14:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:00:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:00:19 --> Total execution time: 0.0337
DEBUG - 2022-03-08 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:01:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:01:14 --> Total execution time: 0.0068
DEBUG - 2022-03-08 14:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:01:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:01:17 --> Total execution time: 0.0050
DEBUG - 2022-03-08 14:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:01:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:01:17 --> Total execution time: 0.0038
DEBUG - 2022-03-08 14:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:01:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:01:39 --> Total execution time: 0.0059
DEBUG - 2022-03-08 14:02:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:02:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:02:24 --> Total execution time: 0.0053
DEBUG - 2022-03-08 14:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:02:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:02:53 --> Total execution time: 0.0059
DEBUG - 2022-03-08 14:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:04:03 --> Total execution time: 0.0059
DEBUG - 2022-03-08 14:04:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:04:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:04:04 --> Total execution time: 0.0034
DEBUG - 2022-03-08 14:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 14:04:06 --> Severity: error --> Exception: Call to undefined method Spk_model::detail() /home/dunr4521/public_html/integrity/application/controllers/Spk.php 44
DEBUG - 2022-03-08 14:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:04:07 --> Total execution time: 0.0042
DEBUG - 2022-03-08 14:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 14:04:25 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 30
ERROR - 2022-03-08 14:04:25 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 32
DEBUG - 2022-03-08 14:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:04:25 --> Total execution time: 0.0036
DEBUG - 2022-03-08 14:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 14:04:45 --> Severity: error --> Exception: Call to undefined method Spk_model::detail() /home/dunr4521/public_html/integrity/application/controllers/Spk.php 44
DEBUG - 2022-03-08 14:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:04:48 --> Total execution time: 0.0037
DEBUG - 2022-03-08 14:04:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:04:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:04:54 --> Total execution time: 0.0040
DEBUG - 2022-03-08 14:05:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:05:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:05:23 --> Total execution time: 0.0147
DEBUG - 2022-03-08 14:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:05:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:05:25 --> Total execution time: 0.0049
DEBUG - 2022-03-08 14:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:06:02 --> Total execution time: 0.0054
DEBUG - 2022-03-08 14:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 14:06:04 --> Severity: error --> Exception: Call to undefined method Spk_model::detail() /home/dunr4521/public_html/integrity/application/controllers/Spk.php 44
DEBUG - 2022-03-08 14:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:08:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:08:19 --> Total execution time: 0.0349
DEBUG - 2022-03-08 14:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:08:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:08:21 --> Total execution time: 0.0042
DEBUG - 2022-03-08 14:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:08:26 --> Total execution time: 0.0037
DEBUG - 2022-03-08 14:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 14:09:11 --> Severity: error --> Exception: Call to undefined method Spk_model::detail() /home/dunr4521/public_html/integrity/application/controllers/Spk.php 44
DEBUG - 2022-03-08 14:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:09:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 14:09:45 --> 404 Page Not Found: Dataphp/appointment
DEBUG - 2022-03-08 14:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:10:47 --> Total execution time: 0.0080
DEBUG - 2022-03-08 14:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:12:31 --> Total execution time: 0.0333
DEBUG - 2022-03-08 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:12:32 --> Total execution time: 0.0036
DEBUG - 2022-03-08 14:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:12:32 --> Total execution time: 0.0035
DEBUG - 2022-03-08 14:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:12:49 --> Total execution time: 0.0055
DEBUG - 2022-03-08 14:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:12:55 --> Total execution time: 0.0044
DEBUG - 2022-03-08 14:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:14:22 --> Total execution time: 0.0333
DEBUG - 2022-03-08 14:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:14:23 --> Total execution time: 0.0036
DEBUG - 2022-03-08 14:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:15:00 --> Total execution time: 0.0057
DEBUG - 2022-03-08 14:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:15:23 --> Total execution time: 0.0057
DEBUG - 2022-03-08 14:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:15:25 --> Total execution time: 0.0039
DEBUG - 2022-03-08 14:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:16:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:16:16 --> Total execution time: 0.0141
DEBUG - 2022-03-08 14:16:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:16:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:16:55 --> Total execution time: 0.0048
DEBUG - 2022-03-08 14:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:16:59 --> Total execution time: 0.0055
DEBUG - 2022-03-08 14:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:17:04 --> Total execution time: 0.0056
DEBUG - 2022-03-08 14:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:17:08 --> Total execution time: 0.0037
DEBUG - 2022-03-08 14:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:17:48 --> Total execution time: 0.0055
DEBUG - 2022-03-08 14:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:19:07 --> Total execution time: 0.0319
DEBUG - 2022-03-08 14:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:19:34 --> Total execution time: 0.0055
DEBUG - 2022-03-08 14:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:19:37 --> Total execution time: 0.0045
DEBUG - 2022-03-08 14:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:19:40 --> Total execution time: 0.0035
DEBUG - 2022-03-08 14:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:20:40 --> Total execution time: 0.0047
DEBUG - 2022-03-08 14:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 14:20:50 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 28
ERROR - 2022-03-08 14:20:50 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 30
ERROR - 2022-03-08 14:20:50 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 32
ERROR - 2022-03-08 14:20:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/system/core/Exceptions.php:271) /home/dunr4521/public_html/integrity/system/helpers/url_helper.php 564
DEBUG - 2022-03-08 14:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:21:00 --> Total execution time: 0.0047
DEBUG - 2022-03-08 14:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:21:02 --> Total execution time: 0.0057
DEBUG - 2022-03-08 14:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:21:04 --> Total execution time: 0.0039
DEBUG - 2022-03-08 14:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:21:42 --> Total execution time: 0.0058
DEBUG - 2022-03-08 14:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:21:45 --> Total execution time: 0.0061
DEBUG - 2022-03-08 14:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:21:49 --> Total execution time: 0.0041
DEBUG - 2022-03-08 14:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 14:22:27 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 30
ERROR - 2022-03-08 14:22:27 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Lamaran.php 32
ERROR - 2022-03-08 14:22:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/system/core/Exceptions.php:271) /home/dunr4521/public_html/integrity/system/helpers/url_helper.php 564
DEBUG - 2022-03-08 14:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:22:30 --> Total execution time: 0.0049
DEBUG - 2022-03-08 14:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:22:41 --> Total execution time: 0.0037
DEBUG - 2022-03-08 14:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:26:40 --> Total execution time: 0.0340
DEBUG - 2022-03-08 14:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:26:43 --> Total execution time: 0.0050
DEBUG - 2022-03-08 14:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:27:07 --> Total execution time: 0.0052
DEBUG - 2022-03-08 14:27:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:27:39 --> Total execution time: 0.0058
DEBUG - 2022-03-08 14:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:28:35 --> Total execution time: 0.0058
DEBUG - 2022-03-08 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:28:48 --> Total execution time: 0.0038
DEBUG - 2022-03-08 14:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:28:59 --> Total execution time: 0.0035
DEBUG - 2022-03-08 14:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:30:09 --> Total execution time: 0.0049
DEBUG - 2022-03-08 14:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:30:11 --> Total execution time: 0.0047
DEBUG - 2022-03-08 14:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:30:17 --> Total execution time: 0.0039
DEBUG - 2022-03-08 14:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:33:41 --> Total execution time: 0.0328
DEBUG - 2022-03-08 14:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:34:05 --> Total execution time: 0.0063
DEBUG - 2022-03-08 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:40:45 --> Total execution time: 0.0343
DEBUG - 2022-03-08 14:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:40:51 --> Total execution time: 0.0051
DEBUG - 2022-03-08 14:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:41:54 --> Total execution time: 0.0051
DEBUG - 2022-03-08 14:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:41:58 --> Total execution time: 0.0050
DEBUG - 2022-03-08 14:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:41:58 --> Total execution time: 0.0055
DEBUG - 2022-03-08 14:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:05 --> Total execution time: 0.0046
DEBUG - 2022-03-08 14:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:08 --> Total execution time: 0.0046
DEBUG - 2022-03-08 14:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:12 --> Total execution time: 0.0035
DEBUG - 2022-03-08 14:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:15 --> Total execution time: 0.0039
DEBUG - 2022-03-08 14:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:29 --> Total execution time: 0.0061
DEBUG - 2022-03-08 14:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:40 --> Total execution time: 0.0045
DEBUG - 2022-03-08 14:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:42:54 --> Total execution time: 0.0035
DEBUG - 2022-03-08 14:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:43:45 --> Total execution time: 0.0043
DEBUG - 2022-03-08 14:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:43:47 --> Total execution time: 0.0043
DEBUG - 2022-03-08 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:44:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:44:04 --> Total execution time: 0.0137
DEBUG - 2022-03-08 14:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 14:45:24 --> Total execution time: 0.0074
DEBUG - 2022-03-08 14:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:27 --> Total execution time: 0.0038
DEBUG - 2022-03-08 14:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:49 --> Total execution time: 0.0040
DEBUG - 2022-03-08 14:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:50 --> Total execution time: 0.0034
DEBUG - 2022-03-08 14:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:45:56 --> Total execution time: 0.0036
DEBUG - 2022-03-08 14:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:46:47 --> Total execution time: 0.0060
DEBUG - 2022-03-08 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:46:57 --> Total execution time: 0.0035
DEBUG - 2022-03-08 14:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:48:14 --> Total execution time: 0.0331
DEBUG - 2022-03-08 14:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:48:18 --> Total execution time: 0.0042
DEBUG - 2022-03-08 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:48:28 --> Total execution time: 0.0038
DEBUG - 2022-03-08 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:48:28 --> Total execution time: 0.0034
DEBUG - 2022-03-08 14:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:48:31 --> Total execution time: 0.0038
DEBUG - 2022-03-08 14:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:48:33 --> Total execution time: 0.0038
DEBUG - 2022-03-08 14:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:49:52 --> Total execution time: 0.0335
DEBUG - 2022-03-08 14:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:54:09 --> Total execution time: 0.0345
DEBUG - 2022-03-08 14:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 14:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 14:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 14:54:23 --> Total execution time: 0.0066
DEBUG - 2022-03-08 15:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:01:14 --> Total execution time: 0.0343
DEBUG - 2022-03-08 15:01:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:01:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:01:38 --> Total execution time: 0.0054
DEBUG - 2022-03-08 15:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:01:46 --> Total execution time: 0.0038
DEBUG - 2022-03-08 15:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:01:54 --> Total execution time: 0.0034
DEBUG - 2022-03-08 15:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:02:06 --> Total execution time: 0.0040
DEBUG - 2022-03-08 15:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:02:09 --> Total execution time: 0.0049
DEBUG - 2022-03-08 15:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:02:14 --> Total execution time: 0.0051
DEBUG - 2022-03-08 15:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:02:20 --> Total execution time: 0.0043
DEBUG - 2022-03-08 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:02:27 --> Total execution time: 0.0042
DEBUG - 2022-03-08 15:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:02:37 --> Total execution time: 0.0036
DEBUG - 2022-03-08 15:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:04:09 --> Total execution time: 0.0324
DEBUG - 2022-03-08 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:04:21 --> No URI present. Default controller set.
DEBUG - 2022-03-08 15:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:04:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:04:21 --> Total execution time: 0.0046
DEBUG - 2022-03-08 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:04:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-08 15:04:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-08 15:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:04:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:04:29 --> Total execution time: 0.0051
DEBUG - 2022-03-08 15:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:04:34 --> Total execution time: 0.0057
DEBUG - 2022-03-08 15:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:04:37 --> Total execution time: 0.0059
DEBUG - 2022-03-08 15:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:05:04 --> Total execution time: 0.0057
DEBUG - 2022-03-08 15:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:05:10 --> Total execution time: 0.0037
DEBUG - 2022-03-08 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:05:22 --> Total execution time: 0.0040
DEBUG - 2022-03-08 15:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:05:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:05:24 --> Total execution time: 0.0117
DEBUG - 2022-03-08 15:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:06:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:06:12 --> Total execution time: 0.0077
DEBUG - 2022-03-08 15:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:06:14 --> Total execution time: 0.0037
DEBUG - 2022-03-08 15:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:06:51 --> Total execution time: 0.0034
DEBUG - 2022-03-08 15:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:08:28 --> Total execution time: 0.0325
DEBUG - 2022-03-08 15:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:08:30 --> Total execution time: 0.0049
DEBUG - 2022-03-08 15:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:09:58 --> Total execution time: 0.0323
DEBUG - 2022-03-08 15:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:10:08 --> Total execution time: 0.0046
DEBUG - 2022-03-08 15:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:11:32 --> Total execution time: 0.0384
DEBUG - 2022-03-08 15:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:12:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:12:48 --> Total execution time: 0.0365
DEBUG - 2022-03-08 15:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:13:48 --> Total execution time: 0.0055
DEBUG - 2022-03-08 15:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:13:50 --> Total execution time: 0.0051
DEBUG - 2022-03-08 15:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:14:29 --> Total execution time: 0.0052
DEBUG - 2022-03-08 15:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:14:41 --> Total execution time: 0.0049
DEBUG - 2022-03-08 15:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:14:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:14:51 --> Total execution time: 0.0080
DEBUG - 2022-03-08 15:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:14:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:14:56 --> Total execution time: 0.0123
DEBUG - 2022-03-08 15:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:15:00 --> Total execution time: 0.0133
DEBUG - 2022-03-08 15:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:15:15 --> Total execution time: 0.0062
DEBUG - 2022-03-08 15:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:17 --> Total execution time: 0.0045
DEBUG - 2022-03-08 15:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:21 --> Total execution time: 0.0036
DEBUG - 2022-03-08 15:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:33 --> Total execution time: 0.0060
DEBUG - 2022-03-08 15:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:37 --> Total execution time: 0.0039
DEBUG - 2022-03-08 15:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:15:39 --> Total execution time: 0.0034
DEBUG - 2022-03-08 15:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:16:58 --> Total execution time: 0.0345
DEBUG - 2022-03-08 15:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:17:40 --> Total execution time: 0.0055
DEBUG - 2022-03-08 15:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:20:30 --> Total execution time: 0.0325
DEBUG - 2022-03-08 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:20:49 --> Total execution time: 0.0049
DEBUG - 2022-03-08 15:21:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:21:06 --> Total execution time: 0.0049
DEBUG - 2022-03-08 15:21:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:21:42 --> Total execution time: 0.0062
DEBUG - 2022-03-08 15:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:21:43 --> Total execution time: 0.0047
DEBUG - 2022-03-08 15:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:21:57 --> Total execution time: 0.0038
DEBUG - 2022-03-08 15:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:22:14 --> Total execution time: 0.0056
DEBUG - 2022-03-08 15:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:22:48 --> Total execution time: 0.0051
DEBUG - 2022-03-08 15:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:22:59 --> Total execution time: 0.0041
DEBUG - 2022-03-08 15:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:23:00 --> Total execution time: 0.0042
DEBUG - 2022-03-08 15:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:23:06 --> Total execution time: 0.0045
DEBUG - 2022-03-08 15:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:23:09 --> Total execution time: 0.0041
DEBUG - 2022-03-08 15:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:23:22 --> Total execution time: 0.0051
DEBUG - 2022-03-08 15:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:23:40 --> Total execution time: 0.0051
DEBUG - 2022-03-08 15:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:23:47 --> Total execution time: 0.0042
DEBUG - 2022-03-08 15:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:26:34 --> Total execution time: 0.0328
DEBUG - 2022-03-08 15:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:26:49 --> Total execution time: 0.0050
DEBUG - 2022-03-08 15:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:27:49 --> Total execution time: 0.0052
DEBUG - 2022-03-08 15:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:27:59 --> Total execution time: 0.0043
DEBUG - 2022-03-08 15:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:27:59 --> Total execution time: 0.0041
DEBUG - 2022-03-08 15:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:28:15 --> Total execution time: 0.0048
DEBUG - 2022-03-08 15:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:28:21 --> Total execution time: 0.0042
DEBUG - 2022-03-08 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:28:24 --> Total execution time: 0.0050
DEBUG - 2022-03-08 15:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:28:26 --> Total execution time: 0.0038
DEBUG - 2022-03-08 15:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:29:25 --> Total execution time: 0.0054
DEBUG - 2022-03-08 15:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:29:38 --> Total execution time: 0.0053
DEBUG - 2022-03-08 15:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:29:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:29:38 --> Total execution time: 0.0129
DEBUG - 2022-03-08 15:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:29:42 --> Total execution time: 0.0035
DEBUG - 2022-03-08 15:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:29:51 --> Total execution time: 0.0037
DEBUG - 2022-03-08 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:29:53 --> Total execution time: 0.0034
DEBUG - 2022-03-08 15:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:29:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:29:56 --> Total execution time: 0.0131
DEBUG - 2022-03-08 15:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:30:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:30:01 --> Total execution time: 0.0068
DEBUG - 2022-03-08 15:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:30:27 --> Total execution time: 0.0052
DEBUG - 2022-03-08 15:31:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:31:56 --> Total execution time: 0.0353
DEBUG - 2022-03-08 15:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:34:02 --> Total execution time: 0.0333
DEBUG - 2022-03-08 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:34:18 --> Total execution time: 0.0050
DEBUG - 2022-03-08 15:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:34:49 --> Total execution time: 0.0060
DEBUG - 2022-03-08 15:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:35:06 --> Total execution time: 0.0052
DEBUG - 2022-03-08 15:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:35:07 --> Total execution time: 0.0035
DEBUG - 2022-03-08 15:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:35:08 --> Total execution time: 0.0036
DEBUG - 2022-03-08 15:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:35:16 --> Total execution time: 0.0035
DEBUG - 2022-03-08 15:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:35:28 --> Total execution time: 0.0049
DEBUG - 2022-03-08 15:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:36:02 --> Total execution time: 0.0048
DEBUG - 2022-03-08 15:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:36:16 --> Total execution time: 0.0049
DEBUG - 2022-03-08 15:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:37:49 --> Total execution time: 0.0333
DEBUG - 2022-03-08 15:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:38:26 --> Total execution time: 0.0052
DEBUG - 2022-03-08 15:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:39:20 --> Total execution time: 0.0067
DEBUG - 2022-03-08 15:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:39:22 --> Total execution time: 0.0039
DEBUG - 2022-03-08 15:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:40:26 --> Total execution time: 0.0057
DEBUG - 2022-03-08 15:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:40:29 --> Total execution time: 0.0041
DEBUG - 2022-03-08 15:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:42:19 --> Total execution time: 0.0335
DEBUG - 2022-03-08 15:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:42:21 --> Total execution time: 0.0038
DEBUG - 2022-03-08 15:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:43:34 --> Total execution time: 0.0325
DEBUG - 2022-03-08 15:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:43:35 --> Total execution time: 0.0035
DEBUG - 2022-03-08 15:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:43:58 --> Total execution time: 0.0053
DEBUG - 2022-03-08 15:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:43:59 --> Total execution time: 0.0064
DEBUG - 2022-03-08 15:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:44:05 --> Total execution time: 0.0129
DEBUG - 2022-03-08 15:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:44:08 --> Total execution time: 0.0115
DEBUG - 2022-03-08 15:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:44:14 --> Total execution time: 0.0101
DEBUG - 2022-03-08 15:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:44:17 --> Total execution time: 0.0065
DEBUG - 2022-03-08 15:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:44:27 --> Total execution time: 0.0060
DEBUG - 2022-03-08 15:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:29 --> Total execution time: 0.0049
DEBUG - 2022-03-08 15:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:34 --> Total execution time: 0.0035
DEBUG - 2022-03-08 15:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:44:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:44:49 --> Total execution time: 0.0099
DEBUG - 2022-03-08 15:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:45:03 --> Total execution time: 0.0054
DEBUG - 2022-03-08 15:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:45:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 15:45:04 --> Total execution time: 0.0047
DEBUG - 2022-03-08 15:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:45:36 --> Total execution time: 0.0058
DEBUG - 2022-03-08 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:46:04 --> Total execution time: 0.0052
DEBUG - 2022-03-08 15:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:46:26 --> Total execution time: 0.0051
DEBUG - 2022-03-08 15:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:46:48 --> Total execution time: 0.0055
DEBUG - 2022-03-08 15:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:46:52 --> Total execution time: 0.0037
DEBUG - 2022-03-08 15:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:47:08 --> Total execution time: 0.0050
DEBUG - 2022-03-08 15:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:47:08 --> Total execution time: 0.0042
DEBUG - 2022-03-08 15:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:47:09 --> Total execution time: 0.0038
DEBUG - 2022-03-08 15:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:47:09 --> Total execution time: 0.0036
DEBUG - 2022-03-08 15:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:48:10 --> Total execution time: 0.0061
DEBUG - 2022-03-08 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:48:40 --> Total execution time: 0.0055
DEBUG - 2022-03-08 15:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:49:24 --> Total execution time: 0.0048
DEBUG - 2022-03-08 15:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:50:57 --> Total execution time: 0.0339
DEBUG - 2022-03-08 15:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:59:37 --> Total execution time: 0.0352
DEBUG - 2022-03-08 15:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 15:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 15:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 15:59:48 --> Total execution time: 0.0039
DEBUG - 2022-03-08 16:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:00:48 --> Total execution time: 0.0064
DEBUG - 2022-03-08 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:00:52 --> Total execution time: 0.0036
DEBUG - 2022-03-08 16:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:00:54 --> Total execution time: 0.0038
DEBUG - 2022-03-08 16:00:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:00:56 --> Total execution time: 0.0044
DEBUG - 2022-03-08 16:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:02:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 16:02:04 --> Total execution time: 0.0142
DEBUG - 2022-03-08 16:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:10:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 16:10:20 --> Total execution time: 0.0404
DEBUG - 2022-03-08 16:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:10:27 --> Total execution time: 0.0057
DEBUG - 2022-03-08 16:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:10:29 --> Total execution time: 0.0047
DEBUG - 2022-03-08 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:10:36 --> Total execution time: 0.0057
DEBUG - 2022-03-08 16:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:10:38 --> Total execution time: 0.0048
DEBUG - 2022-03-08 16:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:11:17 --> Total execution time: 0.0053
DEBUG - 2022-03-08 16:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:11:18 --> Total execution time: 0.0044
DEBUG - 2022-03-08 16:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:11:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-08 16:11:29 --> Total execution time: 0.0112
DEBUG - 2022-03-08 16:11:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:11:37 --> Total execution time: 0.0049
DEBUG - 2022-03-08 16:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:11:39 --> Total execution time: 0.0038
DEBUG - 2022-03-08 16:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:12:39 --> Total execution time: 0.0048
DEBUG - 2022-03-08 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:13:53 --> Total execution time: 0.0054
DEBUG - 2022-03-08 16:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 16:14:16 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Editor.php 27
ERROR - 2022-03-08 16:14:16 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Editor.php 29
ERROR - 2022-03-08 16:14:16 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Editor.php 31
ERROR - 2022-03-08 16:14:16 --> Query error: Unknown column 'phone' in 'field list' - Invalid query: UPDATE `editor` SET `name` = 'Hanny Alia Hasanah & Ahmad Siddik', `phone` = NULL, `date` = NULL, `place_p` = NULL, `w_prewed` = NULL, `photograper` = NULL, `videograper` = NULL, `crew` = NULL, `note` = ''
WHERE `id` = '7'
ERROR - 2022-03-08 16:14:16 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/system/core/Exceptions.php:271) /home/dunr4521/public_html/integrity/system/helpers/url_helper.php 564
DEBUG - 2022-03-08 16:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:14:23 --> Total execution time: 0.0039
DEBUG - 2022-03-08 16:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-08 16:14:30 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Editor.php 27
ERROR - 2022-03-08 16:14:30 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Editor.php 29
ERROR - 2022-03-08 16:14:30 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Editor.php 31
ERROR - 2022-03-08 16:14:30 --> Query error: Unknown column 'phone' in 'field list' - Invalid query: UPDATE `editor` SET `name` = 'Hanny Alia Hasanah & Ahmad Siddik', `phone` = NULL, `date` = NULL, `place_p` = NULL, `w_prewed` = NULL, `photograper` = NULL, `videograper` = NULL, `crew` = NULL, `note` = ''
WHERE `id` = '7'
ERROR - 2022-03-08 16:14:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/system/core/Exceptions.php:271) /home/dunr4521/public_html/integrity/system/helpers/url_helper.php 564
DEBUG - 2022-03-08 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:15:28 --> Total execution time: 0.0071
DEBUG - 2022-03-08 16:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:15:29 --> Total execution time: 0.0038
DEBUG - 2022-03-08 16:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:17:42 --> Total execution time: 0.0337
DEBUG - 2022-03-08 16:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:17:43 --> Total execution time: 0.0036
DEBUG - 2022-03-08 16:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:17:54 --> Total execution time: 0.0037
DEBUG - 2022-03-08 16:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:20:31 --> Total execution time: 0.0318
DEBUG - 2022-03-08 16:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:20:43 --> Total execution time: 0.0040
DEBUG - 2022-03-08 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:20:49 --> Total execution time: 0.0050
DEBUG - 2022-03-08 16:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:21:23 --> Total execution time: 0.0057
DEBUG - 2022-03-08 16:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-08 16:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-08 16:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-08 16:43:57 --> Total execution time: 0.0345
