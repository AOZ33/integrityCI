<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-21 03:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-21 03:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-21 03:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-21 03:58:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-21 03:58:21 --> Total execution time: 0.2045
DEBUG - 2022-07-21 03:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-21 03:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-21 03:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-21 03:59:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-21 03:59:10 --> Total execution time: 0.1445
DEBUG - 2022-07-21 06:28:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-21 06:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-21 06:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-21 06:28:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-21 06:28:04 --> Total execution time: 0.1311
