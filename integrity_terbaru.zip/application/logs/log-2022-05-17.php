<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-17 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:22 --> No URI present. Default controller set.
DEBUG - 2022-05-17 03:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:14:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:14:22 --> Total execution time: 0.0568
DEBUG - 2022-05-17 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:14:22 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-17 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:14:22 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-17 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:14:22 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-17 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:14:22 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-17 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:14:22 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-17 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:14:22 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-17 03:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:14:22 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-17 03:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:14:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:14:23 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-17 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:15:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:15:43 --> Total execution time: 0.0066
DEBUG - 2022-05-17 03:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:16:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:16:02 --> Total execution time: 0.0153
DEBUG - 2022-05-17 03:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:28:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:28:51 --> Total execution time: 0.0562
DEBUG - 2022-05-17 03:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:38:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:38:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:38:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:38:03 --> Total execution time: 0.0055
DEBUG - 2022-05-17 03:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:38:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:38:17 --> Total execution time: 0.0158
DEBUG - 2022-05-17 03:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:38:25 --> Total execution time: 0.0155
DEBUG - 2022-05-17 03:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:00 --> Total execution time: 0.0163
DEBUG - 2022-05-17 03:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:08 --> Total execution time: 0.0265
DEBUG - 2022-05-17 03:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:18 --> No URI present. Default controller set.
DEBUG - 2022-05-17 03:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:18 --> Total execution time: 0.0037
DEBUG - 2022-05-17 03:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:18 --> 404 Page Not Found: Assets/https:
ERROR - 2022-05-17 03:39:18 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-17 03:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:18 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-17 03:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:18 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-17 03:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:18 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-17 03:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:18 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:19 --> No URI present. Default controller set.
DEBUG - 2022-05-17 03:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:19 --> Total execution time: 0.0023
DEBUG - 2022-05-17 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:19 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-17 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:19 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-17 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:19 --> UTF-8 Support Enabled
ERROR - 2022-05-17 03:39:19 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-17 03:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:19 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-17 03:39:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 03:39:19 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-17 03:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:20 --> Total execution time: 0.0032
DEBUG - 2022-05-17 03:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:25 --> Total execution time: 0.0282
DEBUG - 2022-05-17 03:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:39:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:39:28 --> Total execution time: 0.0037
DEBUG - 2022-05-17 03:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:50:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:50:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:50:36 --> Total execution time: 0.0061
DEBUG - 2022-05-17 03:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:50:44 --> Total execution time: 0.0202
DEBUG - 2022-05-17 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:50:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:50:51 --> Total execution time: 0.0162
DEBUG - 2022-05-17 03:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:50:56 --> Total execution time: 0.0051
DEBUG - 2022-05-17 03:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:50:57 --> Total execution time: 0.0052
DEBUG - 2022-05-17 03:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:50:58 --> Total execution time: 0.0026
DEBUG - 2022-05-17 03:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:50:59 --> Total execution time: 0.0042
DEBUG - 2022-05-17 03:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:03 --> Total execution time: 0.0030
DEBUG - 2022-05-17 03:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:07 --> Total execution time: 0.0029
DEBUG - 2022-05-17 03:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:13 --> Total execution time: 0.0025
DEBUG - 2022-05-17 03:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:14 --> Total execution time: 0.0023
DEBUG - 2022-05-17 03:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:16 --> Total execution time: 0.0027
DEBUG - 2022-05-17 03:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:17 --> Total execution time: 0.0029
DEBUG - 2022-05-17 03:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:19 --> Total execution time: 0.0039
DEBUG - 2022-05-17 03:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:51:23 --> Total execution time: 0.0022
DEBUG - 2022-05-17 03:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:51:26 --> Total execution time: 0.0026
DEBUG - 2022-05-17 03:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:54:43 --> Total execution time: 0.0439
DEBUG - 2022-05-17 03:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:54:50 --> Total execution time: 0.0064
DEBUG - 2022-05-17 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:54:52 --> Total execution time: 0.0043
DEBUG - 2022-05-17 03:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:54:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:54:55 --> Total execution time: 0.0175
DEBUG - 2022-05-17 03:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:54:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:54:55 --> Total execution time: 0.0064
DEBUG - 2022-05-17 03:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:54:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:54:57 --> Total execution time: 0.0064
DEBUG - 2022-05-17 03:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 03:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 03:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 03:54:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 03:55:00 --> Total execution time: 0.0097
DEBUG - 2022-05-17 04:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:11:26 --> Total execution time: 0.0048
DEBUG - 2022-05-17 04:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:17:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:17:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:17:46 --> Total execution time: 0.0045
DEBUG - 2022-05-17 04:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:24:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:24:58 --> Total execution time: 0.0528
DEBUG - 2022-05-17 04:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:25:00 --> Total execution time: 0.0047
DEBUG - 2022-05-17 04:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 04:25:02 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /home/nsnmt.com/integrity/application/views/personal/index.php 223
DEBUG - 2022-05-17 04:25:02 --> Total execution time: 0.0050
DEBUG - 2022-05-17 04:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 04:28:19 --> Severity: Warning --> number_format() expects parameter 1 to be float, string given /home/nsnmt.com/integrity/application/views/personal/index.php 223
DEBUG - 2022-05-17 04:28:19 --> Total execution time: 0.0041
DEBUG - 2022-05-17 04:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:29:09 --> Total execution time: 0.0040
DEBUG - 2022-05-17 04:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:29:13 --> Total execution time: 0.0034
DEBUG - 2022-05-17 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:29:15 --> Total execution time: 0.0029
DEBUG - 2022-05-17 04:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:32:53 --> Total execution time: 0.0481
DEBUG - 2022-05-17 04:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:32:55 --> Total execution time: 0.0062
DEBUG - 2022-05-17 04:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:32:57 --> Total execution time: 0.0036
DEBUG - 2022-05-17 04:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:32:59 --> Total execution time: 0.0032
DEBUG - 2022-05-17 04:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:33:08 --> Total execution time: 0.0109
DEBUG - 2022-05-17 04:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:33:18 --> Total execution time: 0.0103
DEBUG - 2022-05-17 04:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:20 --> Total execution time: 0.0034
DEBUG - 2022-05-17 04:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:21 --> Total execution time: 0.1096
DEBUG - 2022-05-17 04:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:33:23 --> Total execution time: 0.0254
DEBUG - 2022-05-17 04:33:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:26 --> Total execution time: 0.0166
DEBUG - 2022-05-17 04:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:28 --> Total execution time: 0.0031
DEBUG - 2022-05-17 04:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:31 --> Total execution time: 0.0025
DEBUG - 2022-05-17 04:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:33:31 --> Total execution time: 0.0143
DEBUG - 2022-05-17 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:33:41 --> Total execution time: 0.0231
DEBUG - 2022-05-17 04:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:33:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:33:44 --> Total execution time: 0.0230
DEBUG - 2022-05-17 04:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:35:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:35:02 --> Total execution time: 0.0544
DEBUG - 2022-05-17 04:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:35:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:35:08 --> Total execution time: 0.0081
DEBUG - 2022-05-17 04:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:35:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:35:19 --> Total execution time: 0.0059
DEBUG - 2022-05-17 04:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:35:24 --> Total execution time: 0.0053
DEBUG - 2022-05-17 04:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:35:26 --> Total execution time: 0.0032
DEBUG - 2022-05-17 04:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:35:33 --> Total execution time: 0.0026
DEBUG - 2022-05-17 04:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:36:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:36:09 --> Total execution time: 0.0031
DEBUG - 2022-05-17 04:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:36:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:36:13 --> Total execution time: 0.0066
DEBUG - 2022-05-17 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:36:25 --> Total execution time: 0.0023
DEBUG - 2022-05-17 04:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:36:26 --> Total execution time: 0.0550
DEBUG - 2022-05-17 04:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:36:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:36:28 --> Total execution time: 0.0041
DEBUG - 2022-05-17 04:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:36:30 --> Total execution time: 0.0051
DEBUG - 2022-05-17 04:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:36:36 --> Total execution time: 0.0041
DEBUG - 2022-05-17 04:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:37:15 --> Total execution time: 0.0027
DEBUG - 2022-05-17 04:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:37:17 --> Total execution time: 0.0048
DEBUG - 2022-05-17 04:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:37:19 --> Total execution time: 0.0032
DEBUG - 2022-05-17 04:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:37:27 --> Total execution time: 0.0026
DEBUG - 2022-05-17 04:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:38:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:38:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:38:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:38:46 --> Total execution time: 0.0027
DEBUG - 2022-05-17 04:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:40:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:40:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:40:57 --> Total execution time: 0.0023
DEBUG - 2022-05-17 04:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:44:16 --> Total execution time: 0.0049
DEBUG - 2022-05-17 04:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:50:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:50:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:50:00 --> Total execution time: 0.0055
DEBUG - 2022-05-17 04:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:53:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:53:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:53:48 --> Total execution time: 0.0048
DEBUG - 2022-05-17 04:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:57:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 04:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 04:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 04:57:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 04:57:16 --> Total execution time: 0.0048
DEBUG - 2022-05-17 05:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:02:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:02:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:02:35 --> Total execution time: 0.0043
DEBUG - 2022-05-17 05:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:04:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:04:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:04:25 --> Total execution time: 0.0028
DEBUG - 2022-05-17 05:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:06:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:06:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:06:49 --> Total execution time: 0.0030
DEBUG - 2022-05-17 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:10:58 --> No URI present. Default controller set.
DEBUG - 2022-05-17 05:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:10:58 --> Total execution time: 0.0422
DEBUG - 2022-05-17 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 05:10:58 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-17 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 05:10:58 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-17 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 05:10:58 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-17 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 05:10:58 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-17 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 05:10:58 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-17 05:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:10:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 05:10:58 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:11:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:11:16 --> Total execution time: 0.0043
DEBUG - 2022-05-17 05:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 05:11:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 05:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:11:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:11:39 --> Total execution time: 0.0156
DEBUG - 2022-05-17 05:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:14:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:14:40 --> Total execution time: 0.0183
DEBUG - 2022-05-17 05:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:14:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:14:50 --> Total execution time: 0.0201
DEBUG - 2022-05-17 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:16:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:16:28 --> Total execution time: 0.0107
DEBUG - 2022-05-17 05:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:16:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:16:36 --> Total execution time: 0.0043
DEBUG - 2022-05-17 05:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:17:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:17:19 --> Total execution time: 0.0075
DEBUG - 2022-05-17 05:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:17:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:17:27 --> Total execution time: 0.0084
DEBUG - 2022-05-17 05:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:17:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:17:29 --> Total execution time: 0.0062
DEBUG - 2022-05-17 05:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:17:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:17:35 --> Total execution time: 0.0063
DEBUG - 2022-05-17 05:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:17:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:17:39 --> Total execution time: 0.0118
DEBUG - 2022-05-17 05:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:18:11 --> Total execution time: 0.0053
DEBUG - 2022-05-17 05:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:18:14 --> Total execution time: 0.0069
DEBUG - 2022-05-17 05:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:18:16 --> Total execution time: 0.0044
DEBUG - 2022-05-17 05:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:18:31 --> Total execution time: 0.0082
DEBUG - 2022-05-17 05:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:18:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:18:37 --> Total execution time: 0.0036
DEBUG - 2022-05-17 05:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:19:59 --> Total execution time: 0.0031
DEBUG - 2022-05-17 05:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:20:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:20:02 --> Total execution time: 0.0027
DEBUG - 2022-05-17 05:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:20:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 05:20:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-17 05:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:20:04 --> Total execution time: 0.0025
DEBUG - 2022-05-17 05:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:20:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:20:11 --> Total execution time: 0.0070
DEBUG - 2022-05-17 05:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:20:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:20:20 --> Total execution time: 0.0041
DEBUG - 2022-05-17 05:20:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:20:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:20:55 --> Total execution time: 0.0072
DEBUG - 2022-05-17 05:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:20:59 --> Total execution time: 0.0033
DEBUG - 2022-05-17 05:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:21:05 --> Total execution time: 0.0046
DEBUG - 2022-05-17 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:21:14 --> Total execution time: 0.0031
DEBUG - 2022-05-17 05:21:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:21:22 --> Total execution time: 0.0036
DEBUG - 2022-05-17 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:21:45 --> Total execution time: 0.0036
DEBUG - 2022-05-17 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 05:22:40 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 05:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:22:40 --> Total execution time: 0.0034
DEBUG - 2022-05-17 05:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:22:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:22:45 --> Total execution time: 0.0082
DEBUG - 2022-05-17 05:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:22:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:22:49 --> Total execution time: 0.0069
DEBUG - 2022-05-17 05:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:22:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:22:52 --> Total execution time: 0.0031
DEBUG - 2022-05-17 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:24:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:24:24 --> Total execution time: 0.0068
DEBUG - 2022-05-17 05:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:24:33 --> Total execution time: 0.0038
DEBUG - 2022-05-17 05:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:24:49 --> Total execution time: 0.0030
DEBUG - 2022-05-17 05:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:24:54 --> Total execution time: 0.0027
DEBUG - 2022-05-17 05:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:25:17 --> Total execution time: 0.0026
DEBUG - 2022-05-17 05:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:25:19 --> Total execution time: 0.0034
DEBUG - 2022-05-17 05:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 05:25:28 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 05:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:25:28 --> Total execution time: 0.0037
DEBUG - 2022-05-17 05:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 05:25:38 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 05:25:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:25:38 --> Total execution time: 0.0032
DEBUG - 2022-05-17 05:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 05:26:06 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 05:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:26:07 --> Total execution time: 0.0033
DEBUG - 2022-05-17 05:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 05:26:22 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 05:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:26:22 --> Total execution time: 0.0030
DEBUG - 2022-05-17 05:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:26:46 --> Total execution time: 0.0041
DEBUG - 2022-05-17 05:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:26:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:26:52 --> Total execution time: 0.0296
DEBUG - 2022-05-17 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:26:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:26:54 --> Total execution time: 0.0255
DEBUG - 2022-05-17 05:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:26:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:26:58 --> Total execution time: 0.0052
DEBUG - 2022-05-17 05:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:27:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:27:13 --> Total execution time: 0.0030
DEBUG - 2022-05-17 05:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:27:47 --> No URI present. Default controller set.
DEBUG - 2022-05-17 05:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:27:47 --> Total execution time: 0.0073
DEBUG - 2022-05-17 05:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:28:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:28:30 --> Total execution time: 0.0053
DEBUG - 2022-05-17 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:29:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:29:20 --> Total execution time: 0.0053
DEBUG - 2022-05-17 05:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:30:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:30:15 --> Total execution time: 0.0136
DEBUG - 2022-05-17 05:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:30:19 --> Total execution time: 0.0048
DEBUG - 2022-05-17 05:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:30:24 --> Total execution time: 0.0071
DEBUG - 2022-05-17 05:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 05:30:57 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 05:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:30:57 --> Total execution time: 0.0043
DEBUG - 2022-05-17 05:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:31:01 --> Total execution time: 0.0072
DEBUG - 2022-05-17 05:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:31:06 --> Total execution time: 0.0054
DEBUG - 2022-05-17 05:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:31:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:31:10 --> Total execution time: 0.0067
DEBUG - 2022-05-17 05:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:31:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:31:20 --> Total execution time: 0.0181
DEBUG - 2022-05-17 05:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:37:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:37:13 --> Total execution time: 0.0527
DEBUG - 2022-05-17 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:37:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:37:24 --> Total execution time: 0.0031
DEBUG - 2022-05-17 05:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:37:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:37:46 --> Total execution time: 0.0029
DEBUG - 2022-05-17 05:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:37:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:37:50 --> Total execution time: 0.0028
DEBUG - 2022-05-17 05:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:37:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:37:57 --> Total execution time: 0.0030
DEBUG - 2022-05-17 05:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:38:28 --> Total execution time: 0.0071
DEBUG - 2022-05-17 05:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:38:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:38:33 --> Total execution time: 0.0044
DEBUG - 2022-05-17 05:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:39:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:39:27 --> Total execution time: 0.0071
DEBUG - 2022-05-17 05:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:39:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:39:31 --> Total execution time: 0.0036
DEBUG - 2022-05-17 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:40:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:40:39 --> Total execution time: 0.0079
DEBUG - 2022-05-17 05:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:40:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:40:49 --> Total execution time: 0.0191
DEBUG - 2022-05-17 05:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:40:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:40:55 --> Total execution time: 0.0147
DEBUG - 2022-05-17 05:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:41:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:41:00 --> Total execution time: 0.0032
DEBUG - 2022-05-17 05:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:41:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:41:26 --> Total execution time: 0.0033
DEBUG - 2022-05-17 05:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:41:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:41:56 --> Total execution time: 0.0087
DEBUG - 2022-05-17 05:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:42:02 --> Total execution time: 0.0064
DEBUG - 2022-05-17 05:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:42:32 --> Total execution time: 0.0095
DEBUG - 2022-05-17 05:42:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:42:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:42:35 --> Total execution time: 0.0047
DEBUG - 2022-05-17 05:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:43:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:43:18 --> Total execution time: 0.0078
DEBUG - 2022-05-17 05:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:43:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:43:20 --> Total execution time: 0.0029
DEBUG - 2022-05-17 05:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:44:16 --> Total execution time: 0.0072
DEBUG - 2022-05-17 05:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:44:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:44:29 --> Total execution time: 0.0131
DEBUG - 2022-05-17 05:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:44:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:44:35 --> Total execution time: 0.0175
DEBUG - 2022-05-17 05:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:44:37 --> Total execution time: 0.0122
DEBUG - 2022-05-17 05:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:44:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:44:41 --> Total execution time: 0.0030
DEBUG - 2022-05-17 05:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:45:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:45:39 --> Total execution time: 0.0039
DEBUG - 2022-05-17 05:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:46:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:46:08 --> Total execution time: 0.0096
DEBUG - 2022-05-17 05:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:46:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:46:11 --> Total execution time: 0.0039
DEBUG - 2022-05-17 05:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:47:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:47:00 --> Total execution time: 0.0079
DEBUG - 2022-05-17 05:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:47:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:47:04 --> Total execution time: 0.0034
DEBUG - 2022-05-17 05:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:48:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:48:26 --> Total execution time: 0.0067
DEBUG - 2022-05-17 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:48:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:48:32 --> Total execution time: 0.0185
DEBUG - 2022-05-17 05:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:48:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:48:43 --> Total execution time: 0.0046
DEBUG - 2022-05-17 05:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:48:56 --> No URI present. Default controller set.
DEBUG - 2022-05-17 05:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:48:56 --> Total execution time: 0.0065
DEBUG - 2022-05-17 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:49:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:49:37 --> Total execution time: 0.0056
DEBUG - 2022-05-17 05:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:49:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:49:51 --> Total execution time: 0.0156
DEBUG - 2022-05-17 05:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:49:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:49:56 --> Total execution time: 0.0029
DEBUG - 2022-05-17 05:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:50:45 --> No URI present. Default controller set.
DEBUG - 2022-05-17 05:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:50:45 --> Total execution time: 0.0056
DEBUG - 2022-05-17 05:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:52:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:52:07 --> Total execution time: 0.0030
DEBUG - 2022-05-17 05:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:52:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:52:58 --> Total execution time: 0.0037
DEBUG - 2022-05-17 05:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:53:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:53:47 --> Total execution time: 0.0036
DEBUG - 2022-05-17 05:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:55:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:55:14 --> Total execution time: 0.0037
DEBUG - 2022-05-17 05:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:55:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:55:25 --> Total execution time: 0.0169
DEBUG - 2022-05-17 05:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:55:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:55:30 --> Total execution time: 0.0033
DEBUG - 2022-05-17 05:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:55:52 --> No URI present. Default controller set.
DEBUG - 2022-05-17 05:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:55:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:55:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:55:52 --> Total execution time: 0.0036
DEBUG - 2022-05-17 05:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:56:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:56:25 --> Total execution time: 0.0027
DEBUG - 2022-05-17 05:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:56:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:56:56 --> Total execution time: 0.0039
DEBUG - 2022-05-17 05:57:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 05:57:38 --> Total execution time: 0.0028
DEBUG - 2022-05-17 05:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:15 --> Total execution time: 0.0053
DEBUG - 2022-05-17 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:28 --> Total execution time: 0.0043
DEBUG - 2022-05-17 05:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:32 --> Total execution time: 0.0035
DEBUG - 2022-05-17 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:36 --> Total execution time: 0.0038
DEBUG - 2022-05-17 05:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:40 --> Total execution time: 0.0040
DEBUG - 2022-05-17 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:43 --> Total execution time: 0.0038
DEBUG - 2022-05-17 05:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:58:49 --> Total execution time: 0.0038
DEBUG - 2022-05-17 05:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 05:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 05:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 05:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:01:43 --> No URI present. Default controller set.
DEBUG - 2022-05-17 06:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:01:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:01:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:01:43 --> Total execution time: 0.0106
DEBUG - 2022-05-17 06:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:01:48 --> Total execution time: 0.0039
DEBUG - 2022-05-17 06:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:01:53 --> Total execution time: 0.0043
DEBUG - 2022-05-17 06:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:01:57 --> Total execution time: 0.0034
DEBUG - 2022-05-17 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:00 --> Total execution time: 0.0035
DEBUG - 2022-05-17 06:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:04 --> Total execution time: 0.0040
DEBUG - 2022-05-17 06:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:07 --> Total execution time: 0.0034
DEBUG - 2022-05-17 06:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:11 --> Total execution time: 0.0033
DEBUG - 2022-05-17 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:02:28 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:28 --> Total execution time: 0.0054
DEBUG - 2022-05-17 06:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:02:45 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:45 --> Total execution time: 0.0034
DEBUG - 2022-05-17 06:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:02:58 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:02:58 --> Total execution time: 0.0042
DEBUG - 2022-05-17 06:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:03:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:03:02 --> Total execution time: 0.0047
DEBUG - 2022-05-17 06:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:03:11 --> Total execution time: 0.0227
DEBUG - 2022-05-17 06:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:03:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:03:25 --> Total execution time: 0.0211
DEBUG - 2022-05-17 06:03:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:03:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:03:33 --> Total execution time: 0.0038
DEBUG - 2022-05-17 06:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:03:45 --> No URI present. Default controller set.
DEBUG - 2022-05-17 06:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:03:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:03:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:03:45 --> Total execution time: 0.0035
DEBUG - 2022-05-17 06:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:05:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:05:01 --> Total execution time: 0.0042
DEBUG - 2022-05-17 06:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:05:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:05:08 --> Total execution time: 0.0333
DEBUG - 2022-05-17 06:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:06:13 --> Total execution time: 0.0097
DEBUG - 2022-05-17 06:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:17 --> Total execution time: 0.0062
DEBUG - 2022-05-17 06:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:20 --> Total execution time: 0.0055
DEBUG - 2022-05-17 06:06:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:23 --> Total execution time: 0.0060
DEBUG - 2022-05-17 06:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:34 --> Total execution time: 0.0064
DEBUG - 2022-05-17 06:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:36 --> Total execution time: 0.0033
DEBUG - 2022-05-17 06:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:43 --> Total execution time: 0.0030
DEBUG - 2022-05-17 06:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:45 --> Total execution time: 0.0038
DEBUG - 2022-05-17 06:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:06:56 --> Total execution time: 0.0066
DEBUG - 2022-05-17 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:07 --> Total execution time: 0.0038
DEBUG - 2022-05-17 06:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:11 --> Total execution time: 0.0057
DEBUG - 2022-05-17 06:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:07:14 --> Total execution time: 0.0096
DEBUG - 2022-05-17 06:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:07:19 --> Total execution time: 0.0092
DEBUG - 2022-05-17 06:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:07:53 --> Total execution time: 0.0080
DEBUG - 2022-05-17 06:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:07:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:07:57 --> Total execution time: 0.0056
DEBUG - 2022-05-17 06:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:08:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:08:22 --> Total execution time: 0.0049
DEBUG - 2022-05-17 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:08:25 --> Total execution time: 0.0042
DEBUG - 2022-05-17 06:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:08:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:08:30 --> Total execution time: 0.0035
DEBUG - 2022-05-17 06:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:11:14 --> Total execution time: 0.0031
DEBUG - 2022-05-17 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:12:26 --> No URI present. Default controller set.
DEBUG - 2022-05-17 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:12:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:12:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 06:12:26 --> Total execution time: 0.0086
DEBUG - 2022-05-17 06:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:12:30 --> Total execution time: 0.0027
DEBUG - 2022-05-17 06:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:12:37 --> Total execution time: 0.0029
DEBUG - 2022-05-17 06:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:13:05 --> Total execution time: 0.0034
DEBUG - 2022-05-17 06:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:13:11 --> Total execution time: 0.0023
DEBUG - 2022-05-17 06:13:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:13:44 --> Total execution time: 0.0030
DEBUG - 2022-05-17 06:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:13:50 --> Total execution time: 0.0033
DEBUG - 2022-05-17 06:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:14:31 --> Total execution time: 0.0049
DEBUG - 2022-05-17 06:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:14:37 --> Total execution time: 0.0041
DEBUG - 2022-05-17 06:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:15:28 --> Total execution time: 0.0052
DEBUG - 2022-05-17 06:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:15:36 --> Total execution time: 0.0024
DEBUG - 2022-05-17 06:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:16:31 --> Total execution time: 0.0045
DEBUG - 2022-05-17 06:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:16:37 --> Total execution time: 0.0027
DEBUG - 2022-05-17 06:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:17:02 --> Total execution time: 0.0036
DEBUG - 2022-05-17 06:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:17:05 --> Total execution time: 0.0035
DEBUG - 2022-05-17 06:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:17:09 --> Total execution time: 0.0028
DEBUG - 2022-05-17 06:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:17:17 --> Total execution time: 0.0026
DEBUG - 2022-05-17 06:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:17:20 --> Total execution time: 0.0027
DEBUG - 2022-05-17 06:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:17:33 --> Total execution time: 0.0030
DEBUG - 2022-05-17 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:17:36 --> Total execution time: 0.0036
DEBUG - 2022-05-17 06:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:02 --> Total execution time: 0.0058
DEBUG - 2022-05-17 06:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:07 --> Total execution time: 0.0033
DEBUG - 2022-05-17 06:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:16 --> Total execution time: 0.0031
DEBUG - 2022-05-17 06:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:21 --> Total execution time: 0.0021
DEBUG - 2022-05-17 06:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:23 --> Total execution time: 0.0026
DEBUG - 2022-05-17 06:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:37 --> Total execution time: 0.0025
DEBUG - 2022-05-17 06:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:44 --> Total execution time: 0.0029
DEBUG - 2022-05-17 06:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:18:54 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:55 --> Total execution time: 0.0032
DEBUG - 2022-05-17 06:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:18:58 --> Total execution time: 0.0043
DEBUG - 2022-05-17 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:19:02 --> Total execution time: 0.0033
DEBUG - 2022-05-17 06:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:19:32 --> Total execution time: 0.0029
DEBUG - 2022-05-17 06:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:19:37 --> Total execution time: 0.0029
DEBUG - 2022-05-17 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:20:23 --> Total execution time: 0.0059
DEBUG - 2022-05-17 06:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:20:46 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:20:47 --> Total execution time: 0.0046
DEBUG - 2022-05-17 06:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:20:50 --> Total execution time: 0.0047
DEBUG - 2022-05-17 06:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:20:56 --> Total execution time: 0.0053
DEBUG - 2022-05-17 06:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:21:01 --> Total execution time: 0.0064
DEBUG - 2022-05-17 06:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:21:12 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:21:12 --> Total execution time: 0.0045
DEBUG - 2022-05-17 06:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:21:16 --> Total execution time: 0.0071
DEBUG - 2022-05-17 06:21:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:21:32 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:21:33 --> Total execution time: 0.0079
DEBUG - 2022-05-17 06:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:21:36 --> Total execution time: 0.0031
DEBUG - 2022-05-17 06:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:21:50 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:21:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:21:50 --> Total execution time: 0.0035
DEBUG - 2022-05-17 06:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:21:52 --> Total execution time: 0.0030
DEBUG - 2022-05-17 06:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:22:10 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:22:10 --> Total execution time: 0.0035
DEBUG - 2022-05-17 06:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:22:13 --> Total execution time: 0.0030
DEBUG - 2022-05-17 06:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-17 06:22:35 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-17 06:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:22:36 --> Total execution time: 0.0041
DEBUG - 2022-05-17 06:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:22:38 --> Total execution time: 0.0035
DEBUG - 2022-05-17 06:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:22:43 --> Total execution time: 0.0049
DEBUG - 2022-05-17 06:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:22:51 --> Total execution time: 0.0037
DEBUG - 2022-05-17 06:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:22:57 --> Total execution time: 0.0030
DEBUG - 2022-05-17 06:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:23:04 --> Total execution time: 0.0043
DEBUG - 2022-05-17 06:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:23:09 --> Total execution time: 0.0032
DEBUG - 2022-05-17 06:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:23:49 --> Total execution time: 0.0030
DEBUG - 2022-05-17 06:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:23:55 --> Total execution time: 0.0029
DEBUG - 2022-05-17 06:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:24:37 --> Total execution time: 0.0045
DEBUG - 2022-05-17 06:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:24:44 --> Total execution time: 0.0046
DEBUG - 2022-05-17 06:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:24:56 --> Total execution time: 0.0047
DEBUG - 2022-05-17 06:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:25:02 --> Total execution time: 0.0087
DEBUG - 2022-05-17 06:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:25:12 --> Total execution time: 0.0063
DEBUG - 2022-05-17 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:25:16 --> Total execution time: 0.0051
DEBUG - 2022-05-17 06:25:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:25:32 --> Total execution time: 0.0045
DEBUG - 2022-05-17 06:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:25:34 --> Total execution time: 0.0064
DEBUG - 2022-05-17 06:25:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:25:41 --> Total execution time: 0.0035
DEBUG - 2022-05-17 06:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:25:48 --> Total execution time: 0.0038
DEBUG - 2022-05-17 06:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:25:51 --> Total execution time: 0.0029
DEBUG - 2022-05-17 06:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:26:02 --> Total execution time: 0.0032
DEBUG - 2022-05-17 06:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:26:05 --> Total execution time: 0.0028
DEBUG - 2022-05-17 06:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:26:12 --> Total execution time: 0.0040
DEBUG - 2022-05-17 06:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:26:37 --> Total execution time: 0.0034
DEBUG - 2022-05-17 06:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:26:44 --> Total execution time: 0.0028
DEBUG - 2022-05-17 06:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:26:48 --> Total execution time: 0.0089
DEBUG - 2022-05-17 06:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:26:56 --> Total execution time: 0.0054
DEBUG - 2022-05-17 06:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:27:01 --> Total execution time: 0.0046
DEBUG - 2022-05-17 06:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:43:55 --> Total execution time: 0.0495
DEBUG - 2022-05-17 06:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:43:59 --> Total execution time: 0.0058
DEBUG - 2022-05-17 06:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:44:14 --> Total execution time: 0.0057
DEBUG - 2022-05-17 06:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:44:18 --> Total execution time: 0.0055
DEBUG - 2022-05-17 06:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:44:25 --> Total execution time: 0.0057
DEBUG - 2022-05-17 06:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:44:32 --> Total execution time: 0.0031
DEBUG - 2022-05-17 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:44:39 --> Total execution time: 0.0037
DEBUG - 2022-05-17 06:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:44:42 --> Total execution time: 0.0038
DEBUG - 2022-05-17 06:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:45:36 --> Total execution time: 0.0046
DEBUG - 2022-05-17 06:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:45:41 --> Total execution time: 0.0038
DEBUG - 2022-05-17 06:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:48:51 --> Total execution time: 0.0388
DEBUG - 2022-05-17 06:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:48:51 --> Total execution time: 0.0594
DEBUG - 2022-05-17 06:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:49:48 --> Total execution time: 0.0042
DEBUG - 2022-05-17 06:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 06:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 06:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 06:54:18 --> Total execution time: 0.0411
DEBUG - 2022-05-17 07:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:01:21 --> Total execution time: 0.0440
DEBUG - 2022-05-17 07:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:01:27 --> Total execution time: 0.0071
DEBUG - 2022-05-17 07:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:01:41 --> Total execution time: 0.0038
DEBUG - 2022-05-17 07:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:01:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 07:01:44 --> Total execution time: 0.0155
DEBUG - 2022-05-17 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:02:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 07:02:12 --> Total execution time: 0.0090
DEBUG - 2022-05-17 07:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:02:14 --> Total execution time: 0.0042
DEBUG - 2022-05-17 07:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:02:16 --> Total execution time: 0.0037
DEBUG - 2022-05-17 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:22:11 --> Total execution time: 0.0474
DEBUG - 2022-05-17 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-17 07:22:11 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-17 07:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:30:06 --> Total execution time: 0.0433
DEBUG - 2022-05-17 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:30:08 --> Total execution time: 0.0067
DEBUG - 2022-05-17 07:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:30:13 --> Total execution time: 0.0049
DEBUG - 2022-05-17 07:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:30:16 --> Total execution time: 0.0043
DEBUG - 2022-05-17 07:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:30:17 --> Total execution time: 0.0024
DEBUG - 2022-05-17 07:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:30:20 --> Total execution time: 0.0054
DEBUG - 2022-05-17 07:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:30:22 --> Total execution time: 0.0064
DEBUG - 2022-05-17 07:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:30:57 --> Total execution time: 0.0045
DEBUG - 2022-05-17 07:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:57:39 --> Total execution time: 0.0439
DEBUG - 2022-05-17 07:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:58:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 07:58:50 --> Total execution time: 0.0111
DEBUG - 2022-05-17 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:59:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 07:59:14 --> Total execution time: 0.0085
DEBUG - 2022-05-17 07:59:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:59:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:59:15 --> Total execution time: 0.0031
DEBUG - 2022-05-17 07:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 07:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 07:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 07:59:38 --> Total execution time: 0.0032
DEBUG - 2022-05-17 08:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:03:54 --> Total execution time: 0.0056
DEBUG - 2022-05-17 08:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:04:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-17 08:04:00 --> Total execution time: 0.0089
DEBUG - 2022-05-17 08:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:04:02 --> Total execution time: 0.0036
DEBUG - 2022-05-17 08:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:04:05 --> Total execution time: 0.0042
DEBUG - 2022-05-17 08:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:04:09 --> Total execution time: 0.0030
DEBUG - 2022-05-17 08:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:04:11 --> Total execution time: 0.0034
DEBUG - 2022-05-17 08:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:04:17 --> Total execution time: 0.0037
DEBUG - 2022-05-17 08:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:04:19 --> Total execution time: 0.0030
DEBUG - 2022-05-17 08:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:04:23 --> Total execution time: 0.0027
DEBUG - 2022-05-17 08:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:07:38 --> Total execution time: 0.0025
DEBUG - 2022-05-17 08:07:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:07:39 --> Total execution time: 0.0035
DEBUG - 2022-05-17 08:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:13:10 --> Total execution time: 0.0433
DEBUG - 2022-05-17 08:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:23:22 --> Total execution time: 0.0077
DEBUG - 2022-05-17 08:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:23:27 --> Total execution time: 0.0061
DEBUG - 2022-05-17 08:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:23:29 --> Total execution time: 0.0036
DEBUG - 2022-05-17 08:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:23:31 --> Total execution time: 0.0036
DEBUG - 2022-05-17 08:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:23:32 --> Total execution time: 0.0025
DEBUG - 2022-05-17 08:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:25:09 --> Total execution time: 0.0045
DEBUG - 2022-05-17 08:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:25:16 --> Total execution time: 0.0035
DEBUG - 2022-05-17 08:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-17 08:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-17 08:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-17 08:39:27 --> Total execution time: 0.0447
