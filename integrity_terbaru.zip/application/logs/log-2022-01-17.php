<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-17 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:06 --> No URI present. Default controller set.
DEBUG - 2022-01-17 09:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:41:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:41:06 --> Total execution time: 0.0304
DEBUG - 2022-01-17 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 09:41:06 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 09:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:41:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:41:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:41:25 --> Total execution time: 0.0037
DEBUG - 2022-01-17 09:41:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 09:41:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:41:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:41:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:41:32 --> Total execution time: 0.0029
DEBUG - 2022-01-17 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 09:41:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 09:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:41:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:41:46 --> Total execution time: 0.0063
DEBUG - 2022-01-17 09:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:41:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:41:49 --> Total execution time: 0.2142
DEBUG - 2022-01-17 09:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:47:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:47:04 --> Total execution time: 0.0344
DEBUG - 2022-01-17 09:47:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 09:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 09:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 09:47:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 09:47:05 --> Total execution time: 0.0046
DEBUG - 2022-01-17 10:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:14:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:14:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:14:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:14:40 --> Total execution time: 0.0063
DEBUG - 2022-01-17 10:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:19:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:19:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:19:38 --> Total execution time: 0.0061
DEBUG - 2022-01-17 10:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:22:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:22:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:22:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:22:30 --> Total execution time: 0.0061
DEBUG - 2022-01-17 10:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:29:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:29:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:29:51 --> Total execution time: 0.0063
DEBUG - 2022-01-17 10:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:34:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:34:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:34:44 --> Total execution time: 0.0062
DEBUG - 2022-01-17 10:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:36:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:36:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:36:53 --> Total execution time: 0.0060
DEBUG - 2022-01-17 10:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:41:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:41:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:41:10 --> Total execution time: 0.0063
DEBUG - 2022-01-17 10:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:44:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:44:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:44:01 --> Total execution time: 0.0060
DEBUG - 2022-01-17 10:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:50:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:50:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:50:20 --> Total execution time: 0.0064
DEBUG - 2022-01-17 10:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:51:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:51:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:51:51 --> Total execution time: 0.0057
DEBUG - 2022-01-17 10:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:54:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:54:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:54:09 --> Total execution time: 0.0062
DEBUG - 2022-01-17 10:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:58:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:58:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 10:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 10:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 10:58:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 10:58:19 --> Total execution time: 0.0063
DEBUG - 2022-01-17 11:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:03:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:03:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:03:12 --> Total execution time: 0.0056
DEBUG - 2022-01-17 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:07:29 --> Total execution time: 0.0060
DEBUG - 2022-01-17 11:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:09:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:09:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:09:35 --> Total execution time: 0.0054
DEBUG - 2022-01-17 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:15:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 11:15:15 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-17 11:15:15 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Meissy & Fajar (Istana Pengantin)', 'Meissy & Fajar', '13 jt + Slideshow 250rb', NULL, '4R(10)', 'custom 2 in 1', '20RP(2)', '16RP(1)', '', 'Acara & Grup', '', '', 'Full Editing', '', '', 'Jl. Uranus Tengah VII No.130 ', '081299093246', 'meissy.trukotami@gmail.com', '', 'Rp. 11.500.000', 'Rp. 1.000.000', 'Rp. 4.000.000', 'Rp. 6.750.000', '', '', '', '', '', '2020-08-08', '08:00', '11:00', '', '', '', '', '', '', '', '', '', '', 'Gedung Sesko AD', '', '2020-01-12', '2020-07-01', '2020-08-05', '', 'TBC', '', 'Tanpa', '', '')
DEBUG - 2022-01-17 11:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:15:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:15:15 --> Total execution time: 0.0062
DEBUG - 2022-01-17 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:17:54 --> Total execution time: 0.0060
DEBUG - 2022-01-17 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:24:18 --> Total execution time: 0.0059
DEBUG - 2022-01-17 11:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:26:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:26:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:26:40 --> Total execution time: 0.0061
DEBUG - 2022-01-17 11:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:33:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:33:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:33:23 --> Total execution time: 0.0066
DEBUG - 2022-01-17 11:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:35:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:35:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:35:21 --> Total execution time: 0.0062
DEBUG - 2022-01-17 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:39:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:39:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:39:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:39:45 --> Total execution time: 0.0057
DEBUG - 2022-01-17 11:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:42:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:42:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:42:24 --> Total execution time: 0.0057
DEBUG - 2022-01-17 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:44:37 --> Total execution time: 0.0059
DEBUG - 2022-01-17 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:51:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 11:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 11:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 11:51:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 11:51:48 --> Total execution time: 0.0065
DEBUG - 2022-01-17 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 12:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 12:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 12:00:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 12:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 12:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 12:00:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 12:00:50 --> Total execution time: 0.0060
DEBUG - 2022-01-17 12:04:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 12:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 12:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 12:04:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 12:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 12:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 12:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 12:04:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 12:04:23 --> Total execution time: 0.0060
DEBUG - 2022-01-17 13:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:19:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:19:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:19:17 --> Total execution time: 0.0066
DEBUG - 2022-01-17 13:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:21:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:21:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:21:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:21:27 --> Total execution time: 0.0056
DEBUG - 2022-01-17 13:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:24:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:24:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:24:47 --> Total execution time: 0.0059
DEBUG - 2022-01-17 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:26:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:26:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:26:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:26:25 --> Total execution time: 0.0060
DEBUG - 2022-01-17 13:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:31:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:31:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:31:46 --> Total execution time: 0.0064
DEBUG - 2022-01-17 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:35:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:35:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:35:32 --> Total execution time: 0.0060
DEBUG - 2022-01-17 13:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:41:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:41:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:41:58 --> Total execution time: 0.0062
DEBUG - 2022-01-17 13:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:45:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:45:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:45:52 --> Total execution time: 0.0061
DEBUG - 2022-01-17 13:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:46:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 13:46:01 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 13:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:47:44 --> No URI present. Default controller set.
DEBUG - 2022-01-17 13:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:47:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:47:44 --> Total execution time: 0.0304
DEBUG - 2022-01-17 13:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:47:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 13:47:44 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 13:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:47:45 --> No URI present. Default controller set.
DEBUG - 2022-01-17 13:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:47:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:47:45 --> Total execution time: 0.0033
DEBUG - 2022-01-17 13:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:47:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:47:52 --> Total execution time: 0.0052
DEBUG - 2022-01-17 13:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:47:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 13:47:54 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 13:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:02 --> Total execution time: 0.0035
DEBUG - 2022-01-17 13:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:06 --> Total execution time: 0.0037
DEBUG - 2022-01-17 13:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:07 --> Total execution time: 0.0035
DEBUG - 2022-01-17 13:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:08 --> Total execution time: 0.0033
DEBUG - 2022-01-17 13:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:09 --> Total execution time: 0.0047
DEBUG - 2022-01-17 13:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:10 --> Total execution time: 0.0041
DEBUG - 2022-01-17 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:11 --> Total execution time: 0.0052
DEBUG - 2022-01-17 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:11 --> Total execution time: 0.0045
DEBUG - 2022-01-17 13:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:13 --> Total execution time: 0.0037
DEBUG - 2022-01-17 13:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:15 --> Total execution time: 0.0037
DEBUG - 2022-01-17 13:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:16 --> Total execution time: 0.0049
DEBUG - 2022-01-17 13:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:27 --> Total execution time: 0.0046
DEBUG - 2022-01-17 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:35 --> Total execution time: 0.0037
DEBUG - 2022-01-17 13:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:37 --> Total execution time: 0.0047
DEBUG - 2022-01-17 13:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:39 --> Total execution time: 0.0055
DEBUG - 2022-01-17 13:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:41 --> Total execution time: 0.0046
DEBUG - 2022-01-17 13:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:43 --> Total execution time: 0.0048
DEBUG - 2022-01-17 13:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:45 --> Total execution time: 0.0037
DEBUG - 2022-01-17 13:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:45 --> No URI present. Default controller set.
DEBUG - 2022-01-17 13:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:48:45 --> Total execution time: 0.0035
DEBUG - 2022-01-17 13:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 13:48:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 13:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:46 --> No URI present. Default controller set.
DEBUG - 2022-01-17 13:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:48:46 --> Total execution time: 0.0033
DEBUG - 2022-01-17 13:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 13:48:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:48:56 --> Total execution time: 0.0033
DEBUG - 2022-01-17 13:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:49:02 --> Total execution time: 0.0036
DEBUG - 2022-01-17 13:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:49:03 --> Total execution time: 0.0033
DEBUG - 2022-01-17 13:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:49:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 13:49:05 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 13:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:49:43 --> No URI present. Default controller set.
DEBUG - 2022-01-17 13:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:49:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:49:43 --> Total execution time: 0.0044
DEBUG - 2022-01-17 13:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:49:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 13:49:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 13:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:13 --> Total execution time: 0.0043
DEBUG - 2022-01-17 13:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:20 --> Total execution time: 0.0037
DEBUG - 2022-01-17 13:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:22 --> Total execution time: 0.0034
DEBUG - 2022-01-17 13:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:28 --> Total execution time: 0.0048
DEBUG - 2022-01-17 13:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:33 --> Total execution time: 0.0044
DEBUG - 2022-01-17 13:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:39 --> Total execution time: 0.0036
DEBUG - 2022-01-17 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:45 --> Total execution time: 0.0033
DEBUG - 2022-01-17 13:50:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:50:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 13:50:46 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 13:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:52:55 --> Total execution time: 0.0346
DEBUG - 2022-01-17 13:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:53:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 13:53:16 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 13:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:53:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 13:53:26 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 13:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:53:36 --> Total execution time: 0.0042
DEBUG - 2022-01-17 13:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:53:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:53:39 --> Total execution time: 0.0036
DEBUG - 2022-01-17 13:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:53:41 --> Total execution time: 0.0035
DEBUG - 2022-01-17 13:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:56:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:56:41 --> Total execution time: 0.0330
DEBUG - 2022-01-17 13:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:56:45 --> No URI present. Default controller set.
DEBUG - 2022-01-17 13:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:56:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:56:45 --> Total execution time: 0.0042
DEBUG - 2022-01-17 13:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:56:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 13:56:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:56:48 --> No URI present. Default controller set.
DEBUG - 2022-01-17 13:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:56:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:56:48 --> Total execution time: 0.0036
DEBUG - 2022-01-17 13:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:58:28 --> No URI present. Default controller set.
DEBUG - 2022-01-17 13:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:58:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:58:28 --> Total execution time: 0.0316
DEBUG - 2022-01-17 13:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 13:58:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 13:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:58:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:58:35 --> Total execution time: 0.0042
DEBUG - 2022-01-17 13:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:58:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 13:58:35 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 13:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:58:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 13:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:58:41 --> Total execution time: 0.0053
DEBUG - 2022-01-17 13:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 13:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 13:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 13:58:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 13:58:43 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:11 --> No URI present. Default controller set.
DEBUG - 2022-01-17 14:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:05:11 --> Total execution time: 0.0315
DEBUG - 2022-01-17 14:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 14:05:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 14:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:12 --> No URI present. Default controller set.
DEBUG - 2022-01-17 14:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:05:12 --> Total execution time: 0.0039
DEBUG - 2022-01-17 14:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:05:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:18 --> Total execution time: 0.0056
DEBUG - 2022-01-17 14:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:05:20 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:26 --> Total execution time: 0.0037
DEBUG - 2022-01-17 14:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:27 --> Total execution time: 0.0038
DEBUG - 2022-01-17 14:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:29 --> Total execution time: 0.0040
DEBUG - 2022-01-17 14:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:31 --> Total execution time: 0.0038
DEBUG - 2022-01-17 14:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:36 --> Total execution time: 0.0050
DEBUG - 2022-01-17 14:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:05:37 --> Total execution time: 0.0037
DEBUG - 2022-01-17 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:15:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:15:20 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:19:39 --> No URI present. Default controller set.
DEBUG - 2022-01-17 14:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:19:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:19:39 --> Total execution time: 0.0302
DEBUG - 2022-01-17 14:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:19:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 14:19:39 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 14:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:19:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:19:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:19:46 --> Total execution time: 0.0032
DEBUG - 2022-01-17 14:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 14:19:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 14:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:19:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:19:54 --> Total execution time: 0.0056
DEBUG - 2022-01-17 14:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:19:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:19:56 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:27:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:27:38 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:32:10 --> No URI present. Default controller set.
DEBUG - 2022-01-17 14:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:32:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:32:10 --> Total execution time: 0.0303
DEBUG - 2022-01-17 14:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:32:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 14:32:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:32:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:32:13 --> Total execution time: 0.0050
DEBUG - 2022-01-17 14:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:32:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:32:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:32:50 --> Total execution time: 0.0050
DEBUG - 2022-01-17 14:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:33:12 --> No URI present. Default controller set.
DEBUG - 2022-01-17 14:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:33:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:33:12 --> Total execution time: 0.0043
DEBUG - 2022-01-17 14:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:33:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 14:33:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:33:19 --> Total execution time: 0.0033
DEBUG - 2022-01-17 14:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:33:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:33:20 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:34:05 --> Total execution time: 0.0048
DEBUG - 2022-01-17 14:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:41:58 --> No URI present. Default controller set.
DEBUG - 2022-01-17 14:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:41:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:41:58 --> Total execution time: 0.0305
DEBUG - 2022-01-17 14:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-17 14:41:58 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-17 14:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:42:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:42:12 --> Total execution time: 0.0054
DEBUG - 2022-01-17 14:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:42:14 --> Total execution time: 0.0036
DEBUG - 2022-01-17 14:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:42:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:42:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:44:28 --> Total execution time: 0.0340
DEBUG - 2022-01-17 14:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:44:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:44:42 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:47:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 14:47:01 --> Total execution time: 0.0343
DEBUG - 2022-01-17 14:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:50:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:50:12 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 14:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 14:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 14:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 14:52:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 14:52:38 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 15:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:03:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:03:22 --> Total execution time: 0.0337
DEBUG - 2022-01-17 15:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:11:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 15:11:25 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90445096 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 15:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:18:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:18:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:18:27 --> Total execution time: 0.0060
DEBUG - 2022-01-17 15:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:33:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:33:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:33:34 --> Total execution time: 0.0061
DEBUG - 2022-01-17 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:36:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:36:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:36:38 --> Total execution time: 0.0058
DEBUG - 2022-01-17 15:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:43:15 --> Total execution time: 0.0062
DEBUG - 2022-01-17 15:43:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:43:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 15:43:34 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90930960 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 15:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:49:13 --> Total execution time: 0.0339
DEBUG - 2022-01-17 15:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:49:24 --> Total execution time: 0.0043
DEBUG - 2022-01-17 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:49:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 15:49:30 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90930960 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 15:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:49:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:49:36 --> Total execution time: 0.0041
DEBUG - 2022-01-17 15:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:51:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 15:51:05 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90930960 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 15:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:51:08 --> Total execution time: 0.0042
DEBUG - 2022-01-17 15:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:51:11 --> Total execution time: 0.0036
DEBUG - 2022-01-17 15:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:51:13 --> Total execution time: 0.0055
DEBUG - 2022-01-17 15:51:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:51:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 15:51:14 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 90930960 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 15:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:55:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:55:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 15:55:47 --> Total execution time: 0.0063
DEBUG - 2022-01-17 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 15:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 15:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 15:55:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 15:55:55 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 91052896 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 16:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 16:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 16:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 16:18:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 16:18:18 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 91052896 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-17 16:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 16:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 16:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 16:25:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-17 16:25:44 --> Total execution time: 0.0337
DEBUG - 2022-01-17 16:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-17 16:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-17 16:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-17 16:26:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-17 16:26:47 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 91052896 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
