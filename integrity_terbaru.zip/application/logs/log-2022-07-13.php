<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-13 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:01:45 --> No URI present. Default controller set.
DEBUG - 2022-07-13 04:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:01:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:01:45 --> Total execution time: 0.1515
DEBUG - 2022-07-13 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:01:55 --> No URI present. Default controller set.
DEBUG - 2022-07-13 04:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:01:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:01:55 --> Total execution time: 0.0783
DEBUG - 2022-07-13 04:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:04 --> Total execution time: 0.1504
DEBUG - 2022-07-13 04:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:02:07 --> Total execution time: 0.0938
DEBUG - 2022-07-13 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:02:36 --> Total execution time: 0.1841
DEBUG - 2022-07-13 04:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:42 --> Total execution time: 0.1297
DEBUG - 2022-07-13 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:02:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:02:49 --> Total execution time: 0.0901
DEBUG - 2022-07-13 04:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:03:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:03:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:03:04 --> Total execution time: 0.2260
DEBUG - 2022-07-13 04:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:09:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:09:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:09:08 --> Total execution time: 0.0615
DEBUG - 2022-07-13 04:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:09:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:09:14 --> Total execution time: 0.0765
DEBUG - 2022-07-13 04:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:09:21 --> Total execution time: 0.1119
DEBUG - 2022-07-13 04:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:10:13 --> Total execution time: 0.1252
DEBUG - 2022-07-13 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:10:15 --> Total execution time: 0.1292
DEBUG - 2022-07-13 04:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:02 --> Total execution time: 0.1195
DEBUG - 2022-07-13 04:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:03 --> Total execution time: 0.1197
DEBUG - 2022-07-13 04:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:04 --> Total execution time: 0.1214
DEBUG - 2022-07-13 04:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:05 --> Total execution time: 0.1234
DEBUG - 2022-07-13 04:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:06 --> Total execution time: 0.1470
DEBUG - 2022-07-13 04:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:07 --> Total execution time: 0.1396
DEBUG - 2022-07-13 04:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:11:09 --> Total execution time: 0.1189
DEBUG - 2022-07-13 04:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:13 --> Total execution time: 0.1329
DEBUG - 2022-07-13 04:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:11:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:11:15 --> Total execution time: 0.2028
DEBUG - 2022-07-13 04:12:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:12:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:12:05 --> Total execution time: 0.2140
DEBUG - 2022-07-13 04:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:12:58 --> Total execution time: 0.1182
DEBUG - 2022-07-13 04:13:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:13:45 --> Total execution time: 0.0966
DEBUG - 2022-07-13 04:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:13:55 --> Total execution time: 0.1216
DEBUG - 2022-07-13 04:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:14:21 --> Total execution time: 0.1151
DEBUG - 2022-07-13 04:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:14:32 --> Total execution time: 0.1231
DEBUG - 2022-07-13 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:14:43 --> Total execution time: 0.1241
DEBUG - 2022-07-13 04:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:19:51 --> Total execution time: 0.1255
DEBUG - 2022-07-13 04:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:19:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:19:54 --> Total execution time: 0.1138
DEBUG - 2022-07-13 04:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:19:55 --> Total execution time: 0.1065
DEBUG - 2022-07-13 04:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:19:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:19:58 --> Total execution time: 0.1116
DEBUG - 2022-07-13 04:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:21 --> Total execution time: 0.0958
DEBUG - 2022-07-13 04:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:22 --> Total execution time: 0.1040
DEBUG - 2022-07-13 04:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:22 --> Total execution time: 0.0949
DEBUG - 2022-07-13 04:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:22 --> Total execution time: 0.1072
DEBUG - 2022-07-13 04:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:23 --> Total execution time: 0.1155
DEBUG - 2022-07-13 04:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:23 --> Total execution time: 0.1120
DEBUG - 2022-07-13 04:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:26 --> Total execution time: 0.1176
DEBUG - 2022-07-13 04:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:28 --> Total execution time: 0.0924
DEBUG - 2022-07-13 04:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:29 --> Total execution time: 0.1541
DEBUG - 2022-07-13 04:20:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:52 --> Total execution time: 0.1040
DEBUG - 2022-07-13 04:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:54 --> Total execution time: 0.1135
DEBUG - 2022-07-13 04:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:56 --> Total execution time: 0.1057
DEBUG - 2022-07-13 04:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:56 --> Total execution time: 0.0857
DEBUG - 2022-07-13 04:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:57 --> Total execution time: 0.0999
DEBUG - 2022-07-13 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:57 --> Total execution time: 0.1051
DEBUG - 2022-07-13 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:57 --> Total execution time: 0.1033
DEBUG - 2022-07-13 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:57 --> Total execution time: 0.0875
DEBUG - 2022-07-13 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:57 --> Total execution time: 0.0974
DEBUG - 2022-07-13 04:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:58 --> Total execution time: 0.0928
DEBUG - 2022-07-13 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:58 --> Total execution time: 0.1064
DEBUG - 2022-07-13 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:58 --> Total execution time: 0.1231
DEBUG - 2022-07-13 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:58 --> Total execution time: 0.0965
DEBUG - 2022-07-13 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:58 --> Total execution time: 0.1124
DEBUG - 2022-07-13 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:59 --> Total execution time: 0.0993
DEBUG - 2022-07-13 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:59 --> Total execution time: 0.1351
DEBUG - 2022-07-13 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:59 --> Total execution time: 0.1037
DEBUG - 2022-07-13 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:20:59 --> Total execution time: 0.0976
DEBUG - 2022-07-13 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:21:00 --> Total execution time: 0.1048
DEBUG - 2022-07-13 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:21:00 --> Total execution time: 0.0997
DEBUG - 2022-07-13 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:21:00 --> Total execution time: 0.1400
DEBUG - 2022-07-13 04:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:19 --> Total execution time: 0.1032
DEBUG - 2022-07-13 04:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:21:24 --> Total execution time: 0.2215
DEBUG - 2022-07-13 04:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:21:26 --> Total execution time: 0.1375
DEBUG - 2022-07-13 04:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:29 --> Total execution time: 0.1707
DEBUG - 2022-07-13 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:21:31 --> Total execution time: 0.1774
DEBUG - 2022-07-13 04:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:33 --> Total execution time: 0.1133
DEBUG - 2022-07-13 04:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:35 --> Total execution time: 0.1091
DEBUG - 2022-07-13 04:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:39 --> Total execution time: 0.1256
DEBUG - 2022-07-13 04:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:21:41 --> Total execution time: 0.1221
DEBUG - 2022-07-13 04:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:22:44 --> Total execution time: 0.1773
DEBUG - 2022-07-13 04:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:01 --> Total execution time: 0.1047
DEBUG - 2022-07-13 04:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:23:04 --> Total execution time: 0.0976
DEBUG - 2022-07-13 04:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:23:12 --> Total execution time: 0.1875
DEBUG - 2022-07-13 04:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:23:17 --> Total execution time: 0.1765
DEBUG - 2022-07-13 04:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:19 --> Total execution time: 0.1576
DEBUG - 2022-07-13 04:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:23:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:23:22 --> Total execution time: 0.0960
DEBUG - 2022-07-13 04:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:28:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:00 --> Total execution time: 0.1133
DEBUG - 2022-07-13 04:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:03 --> Total execution time: 0.1411
DEBUG - 2022-07-13 04:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:04 --> Total execution time: 0.0972
DEBUG - 2022-07-13 04:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:06 --> Total execution time: 0.1496
DEBUG - 2022-07-13 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:08 --> Total execution time: 0.1026
DEBUG - 2022-07-13 04:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:12 --> No URI present. Default controller set.
DEBUG - 2022-07-13 04:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:12 --> Total execution time: 0.1445
DEBUG - 2022-07-13 04:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:17 --> Total execution time: 0.1256
DEBUG - 2022-07-13 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:29:18 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:29:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:19 --> Total execution time: 0.1003
DEBUG - 2022-07-13 04:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:20 --> Total execution time: 0.1245
DEBUG - 2022-07-13 04:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:23 --> Total execution time: 0.0888
DEBUG - 2022-07-13 04:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:33 --> Total execution time: 0.1114
DEBUG - 2022-07-13 04:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:52 --> Total execution time: 0.1270
DEBUG - 2022-07-13 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:29:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:29:54 --> Total execution time: 0.1134
DEBUG - 2022-07-13 04:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:32:21 --> Total execution time: 0.1159
DEBUG - 2022-07-13 04:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:32:22 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:32:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:32:27 --> Total execution time: 0.0943
DEBUG - 2022-07-13 04:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:32:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:32:29 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:32:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:32:29 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:32:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:32:29 --> Total execution time: 0.0947
DEBUG - 2022-07-13 04:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:33:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:33:52 --> Total execution time: 0.1144
DEBUG - 2022-07-13 04:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:33:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:33:53 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:33:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:33:53 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:34:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:34:01 --> Total execution time: 0.1164
DEBUG - 2022-07-13 04:34:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:34:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:34:48 --> Total execution time: 0.1035
DEBUG - 2022-07-13 04:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:34:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:34:58 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:35:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:35:23 --> Total execution time: 0.1007
DEBUG - 2022-07-13 04:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:35:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:35:25 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:36:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:36:15 --> Total execution time: 0.0972
DEBUG - 2022-07-13 04:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:36:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:36:55 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-07-13 04:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:36:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:36:57 --> Total execution time: 0.1201
DEBUG - 2022-07-13 04:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:37:43 --> No URI present. Default controller set.
DEBUG - 2022-07-13 04:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:37:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:37:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:37:43 --> Total execution time: 0.1589
DEBUG - 2022-07-13 04:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:37:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:37:44 --> Total execution time: 0.1007
DEBUG - 2022-07-13 04:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:06 --> No URI present. Default controller set.
DEBUG - 2022-07-13 04:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:06 --> Total execution time: 0.1285
DEBUG - 2022-07-13 04:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:09 --> Total execution time: 0.1477
DEBUG - 2022-07-13 04:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:12 --> Total execution time: 0.1031
DEBUG - 2022-07-13 04:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:38:13 --> 404 Page Not Found: Loginphp/index
DEBUG - 2022-07-13 04:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:16 --> Total execution time: 0.1098
DEBUG - 2022-07-13 04:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:17 --> Total execution time: 0.0917
DEBUG - 2022-07-13 04:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:26 --> Total execution time: 0.0883
DEBUG - 2022-07-13 04:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:26 --> Total execution time: 0.1060
DEBUG - 2022-07-13 04:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:27 --> Total execution time: 0.1149
DEBUG - 2022-07-13 04:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:27 --> Total execution time: 0.1103
DEBUG - 2022-07-13 04:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:28 --> Total execution time: 0.1389
DEBUG - 2022-07-13 04:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:30 --> Total execution time: 0.1069
DEBUG - 2022-07-13 04:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:32 --> Total execution time: 0.1271
DEBUG - 2022-07-13 04:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:34 --> Total execution time: 0.1246
DEBUG - 2022-07-13 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:36 --> Total execution time: 0.1500
DEBUG - 2022-07-13 04:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:37 --> Total execution time: 0.0902
DEBUG - 2022-07-13 04:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:38 --> Total execution time: 0.1062
DEBUG - 2022-07-13 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:39 --> Total execution time: 0.1465
DEBUG - 2022-07-13 04:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:39 --> Total execution time: 0.1594
DEBUG - 2022-07-13 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:39 --> Total execution time: 0.1132
DEBUG - 2022-07-13 04:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:40 --> Total execution time: 0.1126
DEBUG - 2022-07-13 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:46 --> Total execution time: 0.1276
DEBUG - 2022-07-13 04:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:38:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:38:47 --> Total execution time: 0.0961
DEBUG - 2022-07-13 04:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:39:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:39:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:39:46 --> Total execution time: 0.1397
DEBUG - 2022-07-13 04:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:39:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:39:47 --> Total execution time: 0.0997
DEBUG - 2022-07-13 04:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:41:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:41:14 --> Total execution time: 0.0869
DEBUG - 2022-07-13 04:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:41:16 --> Total execution time: 0.1543
DEBUG - 2022-07-13 04:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:41:19 --> Total execution time: 0.1311
DEBUG - 2022-07-13 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:41:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:41:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:41:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:41:22 --> Total execution time: 0.1417
DEBUG - 2022-07-13 04:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:42:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:42:45 --> Total execution time: 0.0971
DEBUG - 2022-07-13 04:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:42:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:42:46 --> Total execution time: 0.1020
DEBUG - 2022-07-13 04:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:42:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:42:47 --> Total execution time: 0.1108
DEBUG - 2022-07-13 04:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:42:48 --> 404 Page Not Found: Forgot-passwordhtml/index
DEBUG - 2022-07-13 04:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:42:48 --> 404 Page Not Found: Forgot-passwordhtml/index
DEBUG - 2022-07-13 04:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:42:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:42:50 --> Total execution time: 0.1168
DEBUG - 2022-07-13 04:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:42:51 --> 404 Page Not Found: Forgot-passwordhtml/index
DEBUG - 2022-07-13 04:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:42:51 --> 404 Page Not Found: Forgot-passwordhtml/index
DEBUG - 2022-07-13 04:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:42:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:42:51 --> Total execution time: 0.0891
DEBUG - 2022-07-13 04:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:43:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:43:42 --> Total execution time: 0.1274
DEBUG - 2022-07-13 04:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:43:45 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:43:45 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:43:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:43:47 --> Total execution time: 0.1354
DEBUG - 2022-07-13 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:43:48 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:43:48 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:43:49 --> Total execution time: 0.0988
DEBUG - 2022-07-13 04:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:43:52 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:43:52 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:43:53 --> Total execution time: 0.0939
DEBUG - 2022-07-13 04:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:18 --> Total execution time: 0.0909
DEBUG - 2022-07-13 04:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:46:23 --> 404 Page Not Found: Auth/forgot-password.php
DEBUG - 2022-07-13 04:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:24 --> Total execution time: 0.1188
DEBUG - 2022-07-13 04:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:46:25 --> 404 Page Not Found: Auth/forgot-password.php
DEBUG - 2022-07-13 04:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:29 --> Total execution time: 0.0974
DEBUG - 2022-07-13 04:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:46:31 --> 404 Page Not Found: Auth/forgot-password.php
DEBUG - 2022-07-13 04:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:32 --> Total execution time: 0.1784
DEBUG - 2022-07-13 04:46:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:39 --> Total execution time: 0.1023
DEBUG - 2022-07-13 04:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:46:41 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:46:41 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:45 --> Total execution time: 0.1257
DEBUG - 2022-07-13 04:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:46:46 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:46:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:47 --> Total execution time: 0.1081
DEBUG - 2022-07-13 04:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:54 --> Total execution time: 0.1022
DEBUG - 2022-07-13 04:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:46:56 --> 404 Page Not Found: Auth/forgot-password.php
DEBUG - 2022-07-13 04:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:56 --> Total execution time: 0.1087
DEBUG - 2022-07-13 04:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:46:57 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:46:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:46:58 --> Total execution time: 0.1060
DEBUG - 2022-07-13 04:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:47:12 --> Total execution time: 0.1033
DEBUG - 2022-07-13 04:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:47:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:47:16 --> Total execution time: 0.1544
DEBUG - 2022-07-13 04:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:47:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:47:16 --> Total execution time: 0.1280
DEBUG - 2022-07-13 04:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:47:17 --> Total execution time: 0.1278
DEBUG - 2022-07-13 04:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:47:19 --> Total execution time: 0.1576
DEBUG - 2022-07-13 04:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:47:21 --> Total execution time: 0.1230
DEBUG - 2022-07-13 04:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:47:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:47:23 --> Total execution time: 0.1004
DEBUG - 2022-07-13 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:48:39 --> Total execution time: 0.1086
DEBUG - 2022-07-13 04:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:55:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:55:11 --> Total execution time: 0.1178
DEBUG - 2022-07-13 04:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:56:04 --> Total execution time: 0.1191
DEBUG - 2022-07-13 04:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:57:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:57:09 --> Total execution time: 0.1364
DEBUG - 2022-07-13 04:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:57:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:57:50 --> Total execution time: 0.1079
DEBUG - 2022-07-13 04:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:57:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:57:52 --> 404 Page Not Found: Forgot-password/index
DEBUG - 2022-07-13 04:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:57:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:57:53 --> Total execution time: 0.1186
DEBUG - 2022-07-13 04:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 04:57:55 --> 404 Page Not Found: Forgot-passwordphp/index
DEBUG - 2022-07-13 04:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 04:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 04:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 04:57:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 04:57:56 --> Total execution time: 0.1702
DEBUG - 2022-07-13 05:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:00:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:00:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:00:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:00:04 --> Total execution time: 0.1224
DEBUG - 2022-07-13 05:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:00:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:00:06 --> Total execution time: 0.1054
DEBUG - 2022-07-13 05:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:00:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:00:52 --> Total execution time: 0.1195
DEBUG - 2022-07-13 05:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:00:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:00:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:00:57 --> Total execution time: 0.1450
DEBUG - 2022-07-13 05:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:00:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:00:59 --> Total execution time: 0.1259
DEBUG - 2022-07-13 05:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:01:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:01:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:01:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:01:02 --> Total execution time: 0.1368
DEBUG - 2022-07-13 05:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:01:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:01:04 --> Total execution time: 0.1173
DEBUG - 2022-07-13 05:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:01:23 --> Total execution time: 0.1144
DEBUG - 2022-07-13 05:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:01:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:01:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:01:26 --> Total execution time: 0.1505
DEBUG - 2022-07-13 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:02:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:02:05 --> Total execution time: 0.1253
DEBUG - 2022-07-13 05:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:02:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:02:12 --> Total execution time: 0.0967
DEBUG - 2022-07-13 05:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:02:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:02:20 --> Total execution time: 0.1165
DEBUG - 2022-07-13 05:02:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:02:23 --> Total execution time: 0.1305
DEBUG - 2022-07-13 05:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:02:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:02:31 --> Total execution time: 0.1021
DEBUG - 2022-07-13 05:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:02:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:02:52 --> Total execution time: 0.1395
DEBUG - 2022-07-13 05:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:05:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:05:53 --> Total execution time: 0.1143
DEBUG - 2022-07-13 05:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:05:55 --> 404 Page Not Found: Forgot-password/index
DEBUG - 2022-07-13 05:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:05:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:05:55 --> 404 Page Not Found: Forgot-password/index
DEBUG - 2022-07-13 05:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:05:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:05:57 --> Total execution time: 0.0999
DEBUG - 2022-07-13 05:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:05:59 --> 404 Page Not Found: Forgot-password/index
DEBUG - 2022-07-13 05:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:05:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:05:59 --> 404 Page Not Found: Forgot-password/index
DEBUG - 2022-07-13 05:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:01 --> Total execution time: 0.1177
DEBUG - 2022-07-13 05:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:14 --> Total execution time: 0.0943
DEBUG - 2022-07-13 05:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:06:16 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:16 --> Total execution time: 0.1013
DEBUG - 2022-07-13 05:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:18 --> Total execution time: 0.1246
DEBUG - 2022-07-13 05:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:24 --> Total execution time: 0.1177
DEBUG - 2022-07-13 05:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:25 --> Total execution time: 0.1755
DEBUG - 2022-07-13 05:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:06:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:06:27 --> Total execution time: 0.1083
DEBUG - 2022-07-13 05:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:22 --> Total execution time: 0.1185
DEBUG - 2022-07-13 05:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:24 --> Total execution time: 0.1037
DEBUG - 2022-07-13 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:07:27 --> Total execution time: 0.1028
DEBUG - 2022-07-13 05:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:07:41 --> Total execution time: 0.1751
DEBUG - 2022-07-13 05:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:07:45 --> Total execution time: 0.1788
DEBUG - 2022-07-13 05:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:07:47 --> Total execution time: 0.1497
DEBUG - 2022-07-13 05:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:49 --> Total execution time: 0.1692
DEBUG - 2022-07-13 05:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:52 --> Total execution time: 0.1573
DEBUG - 2022-07-13 05:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:55 --> Total execution time: 0.1347
DEBUG - 2022-07-13 05:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:58 --> Total execution time: 0.1162
DEBUG - 2022-07-13 05:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:58 --> Total execution time: 0.2656
DEBUG - 2022-07-13 05:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:07:59 --> Total execution time: 0.1168
DEBUG - 2022-07-13 05:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:08:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:08:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:08:02 --> Total execution time: 0.0858
DEBUG - 2022-07-13 05:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:08:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:08:08 --> Total execution time: 0.1409
DEBUG - 2022-07-13 05:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:08:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:08:42 --> Total execution time: 0.2497
DEBUG - 2022-07-13 05:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:08:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:08:49 --> Total execution time: 0.2004
DEBUG - 2022-07-13 05:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:08:54 --> Total execution time: 0.1528
DEBUG - 2022-07-13 05:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:18 --> Total execution time: 0.1182
DEBUG - 2022-07-13 05:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:11:20 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:20 --> Total execution time: 0.1008
DEBUG - 2022-07-13 05:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:11:21 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:22 --> Total execution time: 0.0972
DEBUG - 2022-07-13 05:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:26 --> Total execution time: 0.1427
DEBUG - 2022-07-13 05:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:27 --> Total execution time: 0.1010
DEBUG - 2022-07-13 05:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:11:28 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:29 --> Total execution time: 0.0922
DEBUG - 2022-07-13 05:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:30 --> Total execution time: 0.1361
DEBUG - 2022-07-13 05:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:31 --> Total execution time: 0.1178
DEBUG - 2022-07-13 05:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:35 --> Total execution time: 0.1791
DEBUG - 2022-07-13 05:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:40 --> Total execution time: 0.0997
DEBUG - 2022-07-13 05:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:11:41 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:11:41 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:42 --> Total execution time: 0.0951
DEBUG - 2022-07-13 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:43 --> Total execution time: 0.1197
DEBUG - 2022-07-13 05:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:44 --> Total execution time: 0.1027
DEBUG - 2022-07-13 05:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:49 --> Total execution time: 0.1291
DEBUG - 2022-07-13 05:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:52 --> Total execution time: 0.1119
DEBUG - 2022-07-13 05:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:54 --> Total execution time: 0.1322
DEBUG - 2022-07-13 05:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:11:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:11:55 --> Total execution time: 0.1205
DEBUG - 2022-07-13 05:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:10 --> Total execution time: 0.0869
DEBUG - 2022-07-13 05:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:11 --> Total execution time: 0.0985
DEBUG - 2022-07-13 05:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:17 --> Total execution time: 0.1298
DEBUG - 2022-07-13 05:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:19 --> Total execution time: 0.1210
DEBUG - 2022-07-13 05:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:20 --> Total execution time: 0.1511
DEBUG - 2022-07-13 05:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:21 --> Total execution time: 0.0981
DEBUG - 2022-07-13 05:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:22 --> Total execution time: 0.1383
DEBUG - 2022-07-13 05:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:23 --> Total execution time: 0.0869
DEBUG - 2022-07-13 05:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:12:24 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:12:24 --> Total execution time: 0.0877
DEBUG - 2022-07-13 05:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:12:49 --> Total execution time: 0.1061
DEBUG - 2022-07-13 05:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:14:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:14:21 --> Total execution time: 0.1089
DEBUG - 2022-07-13 05:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:14:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:14:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:14:22 --> Total execution time: 0.0849
DEBUG - 2022-07-13 05:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:14:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:14:24 --> Total execution time: 0.1528
DEBUG - 2022-07-13 05:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:14:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:14:44 --> Total execution time: 0.1055
DEBUG - 2022-07-13 05:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:14:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:14:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:14:48 --> Total execution time: 0.1025
DEBUG - 2022-07-13 05:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:14:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:14:51 --> Total execution time: 0.1036
DEBUG - 2022-07-13 05:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:15:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:15:38 --> Total execution time: 0.0905
DEBUG - 2022-07-13 05:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:15:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:15:54 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:15:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:15:55 --> Total execution time: 0.0922
DEBUG - 2022-07-13 05:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:16:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:16:13 --> Total execution time: 0.0929
DEBUG - 2022-07-13 05:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:16:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:16:15 --> Total execution time: 0.0983
DEBUG - 2022-07-13 05:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:16:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:16:16 --> Total execution time: 0.1097
DEBUG - 2022-07-13 05:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:16:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:16:45 --> Total execution time: 0.1011
DEBUG - 2022-07-13 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:17:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:17:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:17:01 --> Total execution time: 0.0995
DEBUG - 2022-07-13 05:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:17:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:17:02 --> Total execution time: 0.1103
DEBUG - 2022-07-13 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:17:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:17:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:17:16 --> Total execution time: 0.1071
DEBUG - 2022-07-13 05:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:17:17 --> Total execution time: 0.1192
DEBUG - 2022-07-13 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:17:53 --> Total execution time: 0.1071
DEBUG - 2022-07-13 05:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:18:19 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:18:19 --> Total execution time: 0.1367
DEBUG - 2022-07-13 05:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:18:26 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:18:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:18:26 --> Total execution time: 0.1283
DEBUG - 2022-07-13 05:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:18:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:18:35 --> Total execution time: 0.1124
DEBUG - 2022-07-13 05:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:18:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:18:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:18:39 --> Total execution time: 0.1157
DEBUG - 2022-07-13 05:19:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:19:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:19:28 --> Total execution time: 0.1286
DEBUG - 2022-07-13 05:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:19:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:19:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:19:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:19:30 --> Total execution time: 0.1071
DEBUG - 2022-07-13 05:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:19:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:19:33 --> Total execution time: 0.1097
DEBUG - 2022-07-13 05:19:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:19:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:19:41 --> Total execution time: 0.1411
DEBUG - 2022-07-13 05:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:20:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:20:02 --> Total execution time: 0.0944
DEBUG - 2022-07-13 05:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:20:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:20:03 --> Total execution time: 0.1142
DEBUG - 2022-07-13 05:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:20:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:20:14 --> Total execution time: 0.1076
DEBUG - 2022-07-13 05:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:20:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:20:23 --> Total execution time: 0.1055
DEBUG - 2022-07-13 05:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:20:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:20:40 --> Total execution time: 0.1107
DEBUG - 2022-07-13 05:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:20:41 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:20:41 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:20:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:20:43 --> Total execution time: 0.1221
DEBUG - 2022-07-13 05:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:20:44 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:20:45 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:20:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:20:45 --> Total execution time: 0.1316
DEBUG - 2022-07-13 05:23:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:23:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:23:07 --> Total execution time: 0.1327
DEBUG - 2022-07-13 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:23:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:23:13 --> Total execution time: 0.1136
DEBUG - 2022-07-13 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:23:15 --> Total execution time: 0.1411
DEBUG - 2022-07-13 05:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:23:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:23:17 --> Total execution time: 0.0916
DEBUG - 2022-07-13 05:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:23:18 --> Total execution time: 0.1680
DEBUG - 2022-07-13 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:23:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:23:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:23:20 --> Total execution time: 0.1504
DEBUG - 2022-07-13 05:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:24:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:24:26 --> Total execution time: 0.0949
DEBUG - 2022-07-13 05:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:27:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:27:12 --> Total execution time: 0.0903
DEBUG - 2022-07-13 05:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:27:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:27:14 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:27:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:27:16 --> Total execution time: 0.1286
DEBUG - 2022-07-13 05:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:27:20 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:27:20 --> 404 Page Not Found: Auth/forgot-password
DEBUG - 2022-07-13 05:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:27:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:27:21 --> Total execution time: 0.1172
DEBUG - 2022-07-13 05:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:28:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:28:11 --> Total execution time: 0.0976
DEBUG - 2022-07-13 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:28:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:28:13 --> Total execution time: 0.1231
DEBUG - 2022-07-13 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:13 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:28:13 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:28:13 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:28:13 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:28:13 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:28:13 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:28:13 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:28:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:28:17 --> Total execution time: 0.1085
DEBUG - 2022-07-13 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:28:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:28:19 --> Total execution time: 0.1248
DEBUG - 2022-07-13 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:19 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:28:19 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:28:19 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:28:19 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:28:19 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:28:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:28:19 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:28:19 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:28:28 --> 404 Page Not Found: Auth/register.html
DEBUG - 2022-07-13 05:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:28:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:28:31 --> Total execution time: 0.1191
DEBUG - 2022-07-13 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:29:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:29:20 --> Total execution time: 0.0910
DEBUG - 2022-07-13 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:29:20 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:29:20 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 05:29:20 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:29:20 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:29:20 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:29:20 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:29:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:29:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:29:22 --> Total execution time: 0.0940
DEBUG - 2022-07-13 05:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:29:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:29:24 --> Total execution time: 0.1242
DEBUG - 2022-07-13 05:29:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:29:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:29:25 --> Total execution time: 0.1265
DEBUG - 2022-07-13 05:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:29:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:29:48 --> Total execution time: 0.0989
DEBUG - 2022-07-13 05:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:29:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:29:57 --> Total execution time: 0.1058
DEBUG - 2022-07-13 05:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:04 --> Total execution time: 0.1042
DEBUG - 2022-07-13 05:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:10 --> Total execution time: 0.1233
DEBUG - 2022-07-13 05:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:11 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 05:30:11 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:30:11 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:12 --> Total execution time: 0.1445
DEBUG - 2022-07-13 05:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:26 --> Total execution time: 0.1062
DEBUG - 2022-07-13 05:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:33 --> Total execution time: 0.1044
DEBUG - 2022-07-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:36 --> Total execution time: 0.1103
DEBUG - 2022-07-13 05:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:36 --> Total execution time: 0.0959
DEBUG - 2022-07-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:36 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:36 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:30:36 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:30:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:36 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 05:30:36 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:30:36 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:37 --> Total execution time: 0.0909
DEBUG - 2022-07-13 05:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:44 --> Total execution time: 0.1183
DEBUG - 2022-07-13 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:46 --> Total execution time: 0.1102
DEBUG - 2022-07-13 05:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:50 --> Total execution time: 0.0951
DEBUG - 2022-07-13 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:53 --> Total execution time: 0.1001
DEBUG - 2022-07-13 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:53 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:30:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:30:53 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:30:53 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:53 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:30:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:30:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:30:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:30:54 --> Total execution time: 0.1085
DEBUG - 2022-07-13 05:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:31:13 --> Total execution time: 0.1087
DEBUG - 2022-07-13 05:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:31:13 --> Total execution time: 0.0913
DEBUG - 2022-07-13 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:14 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:31:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:31:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:31:14 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:31:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:31:30 --> Total execution time: 0.0908
DEBUG - 2022-07-13 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:31:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:31:33 --> Total execution time: 0.1151
DEBUG - 2022-07-13 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:33 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:31:33 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:33 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:31:33 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:33 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:31:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:33 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 05:31:33 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:31:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:31:36 --> Total execution time: 0.1186
DEBUG - 2022-07-13 05:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:31:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:31:38 --> Total execution time: 0.1330
DEBUG - 2022-07-13 05:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:31:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:31:38 --> Total execution time: 0.1256
DEBUG - 2022-07-13 05:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:38 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:31:38 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:31:38 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:38 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:31:38 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:38 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:31:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:31:38 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:43 --> 404 Page Not Found: Auth/register.html
DEBUG - 2022-07-13 05:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:31:43 --> 404 Page Not Found: Auth/register.html
DEBUG - 2022-07-13 05:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:31:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:31:43 --> Total execution time: 0.0910
DEBUG - 2022-07-13 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:17 --> Total execution time: 0.1125
DEBUG - 2022-07-13 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:17 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:33:17 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:17 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:17 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:33:17 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 05:33:17 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:17 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:33:17 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:19 --> Total execution time: 0.0975
DEBUG - 2022-07-13 05:33:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:20 --> Total execution time: 0.1005
DEBUG - 2022-07-13 05:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:22 --> Total execution time: 0.0924
DEBUG - 2022-07-13 05:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:23 --> Total execution time: 0.0948
DEBUG - 2022-07-13 05:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:25 --> 404 Page Not Found: Auth/register
DEBUG - 2022-07-13 05:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:25 --> 404 Page Not Found: Auth/register
DEBUG - 2022-07-13 05:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:27 --> Total execution time: 0.1161
DEBUG - 2022-07-13 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:28 --> 404 Page Not Found: Auth/register
DEBUG - 2022-07-13 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:28 --> 404 Page Not Found: Auth/register
DEBUG - 2022-07-13 05:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:29 --> Total execution time: 0.1259
DEBUG - 2022-07-13 05:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:33:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:33:59 --> Total execution time: 0.1046
DEBUG - 2022-07-13 05:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:59 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:59 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:33:59 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:33:59 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:33:59 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:59 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:33:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:33:59 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:00 --> Total execution time: 0.0883
DEBUG - 2022-07-13 05:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:03 --> Total execution time: 0.1076
DEBUG - 2022-07-13 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:05 --> Total execution time: 0.0936
DEBUG - 2022-07-13 05:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:06 --> Total execution time: 0.0901
DEBUG - 2022-07-13 05:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:07 --> Total execution time: 0.0961
DEBUG - 2022-07-13 05:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:32 --> Total execution time: 0.0907
DEBUG - 2022-07-13 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:35 --> Total execution time: 0.0929
DEBUG - 2022-07-13 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:34:35 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:34:35 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:34:35 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:34:35 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:35 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:34:35 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:34:35 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:34:35 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:34:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:34:36 --> Total execution time: 0.0936
DEBUG - 2022-07-13 05:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:35:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:35:00 --> Total execution time: 0.0975
DEBUG - 2022-07-13 05:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:38:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:38:07 --> Total execution time: 0.0901
DEBUG - 2022-07-13 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:38:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:38:10 --> Total execution time: 0.0988
DEBUG - 2022-07-13 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:38:10 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:38:10 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:38:10 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:38:10 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:38:10 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:38:10 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:38:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:38:10 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:38:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:38:24 --> Total execution time: 0.0929
DEBUG - 2022-07-13 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:39:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:39:22 --> Total execution time: 0.1156
DEBUG - 2022-07-13 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:39:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:39:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:39:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:39:22 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:39:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:39:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:39:22 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 05:39:22 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:39:36 --> Total execution time: 0.0868
DEBUG - 2022-07-13 05:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:40:28 --> Total execution time: 0.0887
DEBUG - 2022-07-13 05:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:40:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:40:35 --> Total execution time: 0.0856
DEBUG - 2022-07-13 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:40:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:40:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:40:48 --> Total execution time: 0.0889
DEBUG - 2022-07-13 05:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:42:55 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:42:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:42:55 --> Total execution time: 0.0994
DEBUG - 2022-07-13 05:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:42:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:42:57 --> Total execution time: 0.1391
DEBUG - 2022-07-13 05:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:42:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:42:57 --> Total execution time: 0.1221
DEBUG - 2022-07-13 05:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:42:58 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:42:58 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:42:58 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:42:58 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:42:58 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:42:58 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:42:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:42:58 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:00 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:00 --> Total execution time: 0.1223
DEBUG - 2022-07-13 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:01 --> Total execution time: 0.1384
DEBUG - 2022-07-13 05:43:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:01 --> Total execution time: 0.1454
DEBUG - 2022-07-13 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:01 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:43:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:01 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:43:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:05 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:05 --> Total execution time: 0.0574
DEBUG - 2022-07-13 05:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:07 --> Total execution time: 0.0772
DEBUG - 2022-07-13 05:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:07 --> Total execution time: 0.0649
DEBUG - 2022-07-13 05:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:07 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:43:07 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:07 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:43:07 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:07 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:43:07 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:43:07 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:11 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:40 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:40 --> Total execution time: 0.1025
DEBUG - 2022-07-13 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:42 --> Total execution time: 0.0970
DEBUG - 2022-07-13 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:42 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:43:42 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:42 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:42 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:43:42 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:43:42 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:43:43 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:43:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:43:43 --> Total execution time: 0.1070
DEBUG - 2022-07-13 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:44:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:44:22 --> Total execution time: 0.1338
DEBUG - 2022-07-13 05:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:44:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:44:22 --> Total execution time: 0.1380
DEBUG - 2022-07-13 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:44:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:44:22 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 05:44:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:44:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:44:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:44:22 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:44:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:44:23 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:44:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:44:23 --> Total execution time: 0.1131
DEBUG - 2022-07-13 05:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:48:15 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:48:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:48:15 --> Total execution time: 0.0643
DEBUG - 2022-07-13 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:48:16 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:48:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:48:16 --> Total execution time: 0.0546
DEBUG - 2022-07-13 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:48:16 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:48:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:48:16 --> Total execution time: 0.0447
DEBUG - 2022-07-13 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:48:16 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:48:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:48:16 --> Total execution time: 0.0524
DEBUG - 2022-07-13 05:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:48:17 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:48:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:48:17 --> Total execution time: 0.0683
DEBUG - 2022-07-13 05:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:48:17 --> No URI present. Default controller set.
DEBUG - 2022-07-13 05:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:48:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:48:17 --> Total execution time: 0.0912
DEBUG - 2022-07-13 05:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:50:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:50:03 --> Total execution time: 0.1153
DEBUG - 2022-07-13 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:50:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:50:11 --> Total execution time: 0.1007
DEBUG - 2022-07-13 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:50:11 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:50:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:50:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:50:11 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:50:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:50:11 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:50:11 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:50:18 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:50:18 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:51:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:51:16 --> Total execution time: 0.1173
DEBUG - 2022-07-13 05:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:51:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:51:33 --> Total execution time: 0.1233
DEBUG - 2022-07-13 05:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:51:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:51:34 --> Total execution time: 0.1224
DEBUG - 2022-07-13 05:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:51:34 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:51:34 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:51:34 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 05:51:34 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:51:34 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:51:34 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:51:34 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:51:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:51:34 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:53:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:53:19 --> Total execution time: 0.1126
DEBUG - 2022-07-13 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:53:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:53:22 --> Total execution time: 0.0928
DEBUG - 2022-07-13 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:22 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:53:22 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:22 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:53:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:53:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:53:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:53:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:53:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:53:22 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:53:25 --> Total execution time: 0.1274
DEBUG - 2022-07-13 05:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:53:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:53:53 --> Total execution time: 0.1175
DEBUG - 2022-07-13 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:53:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:53:56 --> Total execution time: 0.1275
DEBUG - 2022-07-13 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:56 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:53:56 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:53:56 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:53:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:53:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:53:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:53:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:53:56 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:53:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:53:58 --> Total execution time: 0.1113
DEBUG - 2022-07-13 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:54:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:54:08 --> Total execution time: 0.1070
DEBUG - 2022-07-13 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:08 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:54:08 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:54:08 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:08 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:08 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:54:08 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:54:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:54:10 --> Total execution time: 0.1040
DEBUG - 2022-07-13 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:54:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:54:11 --> Total execution time: 0.1368
DEBUG - 2022-07-13 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:11 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:11 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:54:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:11 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:54:11 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:54:16 --> Total execution time: 0.1202
DEBUG - 2022-07-13 05:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:54:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:54:21 --> Total execution time: 0.1204
DEBUG - 2022-07-13 05:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:21 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:54:21 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:54:21 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:21 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:54:21 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:54:21 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:54:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:21 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:23 --> 404 Page Not Found: Auth/login.html
DEBUG - 2022-07-13 05:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:54:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:54:25 --> Total execution time: 0.1215
DEBUG - 2022-07-13 05:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:54:26 --> 404 Page Not Found: Auth/login.html
DEBUG - 2022-07-13 05:54:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:54:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:54:27 --> Total execution time: 0.0995
DEBUG - 2022-07-13 05:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:54:39 --> Total execution time: 0.1122
DEBUG - 2022-07-13 05:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:55:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:55:53 --> Total execution time: 0.1501
DEBUG - 2022-07-13 05:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:55:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:55:53 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:55:53 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:55:53 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:55:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:55:53 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:55:53 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:55:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:57:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:57:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:57:11 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 05:57:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:59:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:59:40 --> Total execution time: 0.1176
DEBUG - 2022-07-13 05:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:59:41 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 05:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:59:41 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 05:59:41 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:59:41 --> UTF-8 Support Enabled
ERROR - 2022-07-13 05:59:41 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:59:41 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 05:59:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 05:59:41 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 05:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:59:42 --> Total execution time: 0.0884
DEBUG - 2022-07-13 05:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 05:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 05:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 05:59:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 05:59:43 --> Total execution time: 0.0953
DEBUG - 2022-07-13 06:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:00 --> Total execution time: 0.0955
DEBUG - 2022-07-13 06:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 06:00:01 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 06:00:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:01 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 06:00:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:01 --> 404 Page Not Found: Auth/login
DEBUG - 2022-07-13 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:02 --> 404 Page Not Found: Auth/login
DEBUG - 2022-07-13 06:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:03 --> Total execution time: 0.1519
DEBUG - 2022-07-13 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:10 --> Total execution time: 0.0916
DEBUG - 2022-07-13 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:10 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:10 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 06:00:10 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 06:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:10 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 06:00:10 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:10 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-07-13 06:00:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-07-13 06:00:11 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-07-13 06:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:15 --> Total execution time: 0.1185
DEBUG - 2022-07-13 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:22 --> Total execution time: 0.0991
DEBUG - 2022-07-13 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:22 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 06:00:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:22 --> UTF-8 Support Enabled
ERROR - 2022-07-13 06:00:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 06:00:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:22 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-13 06:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:23 --> Total execution time: 0.1207
DEBUG - 2022-07-13 06:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:23 --> Total execution time: 0.1011
DEBUG - 2022-07-13 06:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:24 --> Total execution time: 0.1317
DEBUG - 2022-07-13 06:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:47 --> Total execution time: 0.1045
DEBUG - 2022-07-13 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:00:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:00:55 --> Total execution time: 0.1171
DEBUG - 2022-07-13 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:55 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 06:00:55 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:55 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:55 --> UTF-8 Support Enabled
ERROR - 2022-07-13 06:00:55 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 06:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:55 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 06:00:55 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:00:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:00:59 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 06:00:59 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-13 06:04:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:04:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:04:03 --> Total execution time: 0.1264
DEBUG - 2022-07-13 06:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:04:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:04:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:04:12 --> Total execution time: 0.2560
DEBUG - 2022-07-13 06:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:04:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:04:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:04:18 --> Total execution time: 0.0963
DEBUG - 2022-07-13 06:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:05:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:05:00 --> Total execution time: 0.1493
DEBUG - 2022-07-13 06:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:05:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:05:32 --> Total execution time: 0.1156
DEBUG - 2022-07-13 06:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:05:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:05:59 --> Total execution time: 0.1284
DEBUG - 2022-07-13 06:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:08:03 --> Total execution time: 0.1209
DEBUG - 2022-07-13 06:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:08:23 --> Total execution time: 0.0834
DEBUG - 2022-07-13 06:08:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:08:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:08:42 --> Total execution time: 0.1030
DEBUG - 2022-07-13 06:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:09:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:09:18 --> Total execution time: 0.0570
DEBUG - 2022-07-13 06:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:09:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:09:26 --> Total execution time: 0.0693
DEBUG - 2022-07-13 06:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:10:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:10:13 --> Total execution time: 0.1110
DEBUG - 2022-07-13 06:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:10:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:10:28 --> Total execution time: 0.0950
DEBUG - 2022-07-13 06:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:10:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:10:47 --> Total execution time: 0.0965
DEBUG - 2022-07-13 06:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:11:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:11:11 --> Total execution time: 0.0800
DEBUG - 2022-07-13 06:13:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:13:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:13:40 --> Total execution time: 0.1075
DEBUG - 2022-07-13 06:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:14:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:14:12 --> Total execution time: 0.1305
DEBUG - 2022-07-13 06:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:18:11 --> Total execution time: 0.1247
DEBUG - 2022-07-13 06:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:41:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:41:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:41:46 --> Total execution time: 0.1230
DEBUG - 2022-07-13 06:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:42:09 --> Total execution time: 0.1292
DEBUG - 2022-07-13 06:42:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:42:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:42:50 --> Total execution time: 0.1564
DEBUG - 2022-07-13 06:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:43:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:43:41 --> Total execution time: 0.1278
DEBUG - 2022-07-13 06:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:43:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:43:48 --> Total execution time: 0.1091
DEBUG - 2022-07-13 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:52:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:52:47 --> Total execution time: 0.1021
DEBUG - 2022-07-13 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:52:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:52:47 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:52:47 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-13 06:52:47 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:52:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-13 06:52:47 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-13 06:52:47 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-13 06:52:47 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-13 06:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 06:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 06:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 06:52:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 06:52:50 --> Total execution time: 0.1107
DEBUG - 2022-07-13 08:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 08:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 08:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 08:26:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 08:26:39 --> Total execution time: 0.1677
DEBUG - 2022-07-13 08:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 08:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 08:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 08:27:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 08:27:06 --> Total execution time: 0.1059
DEBUG - 2022-07-13 08:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 08:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 08:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 08:27:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 08:27:29 --> Total execution time: 0.0942
DEBUG - 2022-07-13 09:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 09:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 09:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 09:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 09:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 09:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 09:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 09:53:35 --> Total execution time: 0.1336
DEBUG - 2022-07-13 09:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 09:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 09:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 09:53:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 09:53:37 --> Total execution time: 0.1222
DEBUG - 2022-07-13 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 09:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 09:54:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 09:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 09:54:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 09:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 09:54:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 09:54:00 --> Total execution time: 0.1608
DEBUG - 2022-07-13 09:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 09:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 09:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 09:54:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 09:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 09:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 09:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 09:54:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 09:54:04 --> Total execution time: 0.0865
DEBUG - 2022-07-13 10:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-13 10:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-13 10:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-13 10:43:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-13 10:43:20 --> Total execution time: 0.0926
