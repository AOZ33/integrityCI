<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-14 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 09:41:12 --> No URI present. Default controller set.
DEBUG - 2022-01-14 09:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 09:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 09:41:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 09:41:12 --> Total execution time: 0.0316
DEBUG - 2022-01-14 09:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 09:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-14 09:41:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-14 09:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 09:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 09:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 09:41:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 09:41:20 --> Total execution time: 0.0042
DEBUG - 2022-01-14 09:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 09:41:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-14 09:41:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-14 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 09:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 09:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 09:41:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 09:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 09:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 09:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 09:41:32 --> Total execution time: 0.0062
DEBUG - 2022-01-14 09:45:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 09:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 09:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 09:45:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 09:45:49 --> Total execution time: 0.2060
DEBUG - 2022-01-14 09:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 09:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 09:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 09:52:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 09:52:20 --> Total execution time: 0.0346
DEBUG - 2022-01-14 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:20:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:20:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:20:31 --> Total execution time: 0.0067
DEBUG - 2022-01-14 10:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:25:03 --> Total execution time: 0.0064
DEBUG - 2022-01-14 10:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:26:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:26:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:26:40 --> Total execution time: 0.0052
DEBUG - 2022-01-14 10:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:29:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:29:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:29:10 --> Total execution time: 0.0056
DEBUG - 2022-01-14 10:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:35:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:35:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:35:30 --> Total execution time: 0.0060
DEBUG - 2022-01-14 10:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:40:28 --> Total execution time: 0.0066
DEBUG - 2022-01-14 10:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:46:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:46:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:46:21 --> Total execution time: 0.0057
DEBUG - 2022-01-14 10:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:51:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:51:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:51:46 --> Total execution time: 0.0057
DEBUG - 2022-01-14 10:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:58:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:58:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 10:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 10:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 10:58:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 10:58:05 --> Total execution time: 0.0061
DEBUG - 2022-01-14 11:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:03:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:03:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:03:14 --> Total execution time: 0.0061
DEBUG - 2022-01-14 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:05:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:05:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:05:07 --> Total execution time: 0.0057
DEBUG - 2022-01-14 11:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:12:10 --> Total execution time: 0.0059
DEBUG - 2022-01-14 11:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:15:06 --> Total execution time: 0.0048
DEBUG - 2022-01-14 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:17:53 --> Total execution time: 0.0052
DEBUG - 2022-01-14 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:19:13 --> Total execution time: 0.0050
DEBUG - 2022-01-14 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:24:18 --> Total execution time: 0.0060
DEBUG - 2022-01-14 11:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:30:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:30:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:30:01 --> Total execution time: 0.0070
DEBUG - 2022-01-14 11:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:35:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 11:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 11:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 11:35:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 11:35:22 --> Total execution time: 0.0064
DEBUG - 2022-01-14 13:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:16:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:16:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:16:46 --> Total execution time: 0.0070
DEBUG - 2022-01-14 13:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:19:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:19:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:19:35 --> Total execution time: 0.0048
DEBUG - 2022-01-14 13:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:19:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:19:40 --> Total execution time: 0.1932
DEBUG - 2022-01-14 13:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:20:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:20:58 --> Total execution time: 0.0331
DEBUG - 2022-01-14 13:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:27:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:27:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:27:08 --> Total execution time: 0.0064
DEBUG - 2022-01-14 13:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:30:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:30:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:30:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:30:53 --> Total execution time: 0.0059
DEBUG - 2022-01-14 13:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:34:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:34:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:34:25 --> Total execution time: 0.0056
DEBUG - 2022-01-14 13:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:41:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:41:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:41:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:41:20 --> Total execution time: 0.0059
DEBUG - 2022-01-14 13:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:45:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:45:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:45:45 --> Total execution time: 0.0151
DEBUG - 2022-01-14 13:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:49:45 --> Total execution time: 0.0060
DEBUG - 2022-01-14 13:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:53:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:53:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:53:10 --> Total execution time: 0.0049
DEBUG - 2022-01-14 13:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:57:35 --> Total execution time: 0.0070
DEBUG - 2022-01-14 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:58:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 13:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 13:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 13:58:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 13:58:49 --> Total execution time: 0.0049
DEBUG - 2022-01-14 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:01:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:01:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:01:28 --> Total execution time: 0.0049
DEBUG - 2022-01-14 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:05:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:05:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:05:38 --> Total execution time: 0.0051
DEBUG - 2022-01-14 14:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:09:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:09:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:09:08 --> Total execution time: 0.0070
DEBUG - 2022-01-14 14:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:13:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:13:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:13:33 --> Total execution time: 0.0059
DEBUG - 2022-01-14 14:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:17:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:17:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:17:27 --> Total execution time: 0.0065
DEBUG - 2022-01-14 14:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:22:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:22:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:22:14 --> Total execution time: 0.0056
DEBUG - 2022-01-14 14:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:24:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:24:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:24:32 --> Total execution time: 0.0053
DEBUG - 2022-01-14 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:27:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:27:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:27:57 --> Total execution time: 0.0054
DEBUG - 2022-01-14 14:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:32:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:32:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:32:08 --> Total execution time: 0.0062
DEBUG - 2022-01-14 14:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:33:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:33:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:33:39 --> Total execution time: 0.0053
DEBUG - 2022-01-14 14:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:38:25 --> Total execution time: 0.0055
DEBUG - 2022-01-14 14:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:38:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:38:32 --> Total execution time: 0.1967
DEBUG - 2022-01-14 14:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:40:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:40:48 --> Total execution time: 0.0321
DEBUG - 2022-01-14 14:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:40:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:40:51 --> Total execution time: 0.0044
DEBUG - 2022-01-14 14:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:43:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:43:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:43:23 --> Total execution time: 0.0054
DEBUG - 2022-01-14 14:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:46:13 --> Total execution time: 0.0063
DEBUG - 2022-01-14 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:46:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:46:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:46:53 --> Total execution time: 0.0047
DEBUG - 2022-01-14 14:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:52:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 14:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 14:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 14:52:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 14:52:35 --> Total execution time: 0.0058
DEBUG - 2022-01-14 15:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:04:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:04:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:04:14 --> Total execution time: 0.0063
DEBUG - 2022-01-14 15:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:24:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:24:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:24:16 --> Total execution time: 0.0063
DEBUG - 2022-01-14 15:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:25:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:25:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:25:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:25:40 --> Total execution time: 0.0048
DEBUG - 2022-01-14 15:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:50:58 --> Total execution time: 0.0064
DEBUG - 2022-01-14 15:53:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:53:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:53:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:53:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:53:02 --> Total execution time: 0.0053
DEBUG - 2022-01-14 15:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:53:25 --> Total execution time: 0.0039
DEBUG - 2022-01-14 15:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:58:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:58:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 15:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 15:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 15:58:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 15:58:50 --> Total execution time: 0.0057
DEBUG - 2022-01-14 16:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:04:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:04:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:04:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:04:37 --> Total execution time: 0.0062
DEBUG - 2022-01-14 16:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:06:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:06:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:06:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:06:52 --> Total execution time: 0.0050
DEBUG - 2022-01-14 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:15:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:15:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:15:16 --> Total execution time: 0.0057
DEBUG - 2022-01-14 16:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:21:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:21:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:21:59 --> Total execution time: 0.0067
DEBUG - 2022-01-14 16:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:27:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:27:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:27:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:27:38 --> Total execution time: 0.0063
DEBUG - 2022-01-14 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:30:33 --> Total execution time: 0.0057
DEBUG - 2022-01-14 16:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:31:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:31:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:31:42 --> Total execution time: 0.0042
DEBUG - 2022-01-14 16:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:34:30 --> Total execution time: 0.0054
DEBUG - 2022-01-14 16:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:38:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:38:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:38:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:38:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:38:44 --> Total execution time: 0.0046
DEBUG - 2022-01-14 16:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:39:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:39:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:39:49 --> Total execution time: 0.0044
DEBUG - 2022-01-14 16:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:39:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:39:54 --> Total execution time: 0.1752
DEBUG - 2022-01-14 16:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:46:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:46:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:46:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:46:20 --> Total execution time: 0.2255
DEBUG - 2022-01-14 16:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:49:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-14 16:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-14 16:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-14 16:49:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-14 16:49:26 --> Total execution time: 0.2235
