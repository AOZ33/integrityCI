<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-13 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:43 --> No URI present. Default controller set.
DEBUG - 2022-04-13 02:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 02:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 02:55:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 02:55:43 --> Total execution time: 0.0665
DEBUG - 2022-04-13 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 02:55:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 02:55:43 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-13 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 02:55:43 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-13 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 02:55:43 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-13 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 02:55:43 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-13 02:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 02:55:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-13 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 02:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 02:55:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 02:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 02:55:45 --> Total execution time: 0.0077
DEBUG - 2022-04-13 02:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 02:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 02:55:54 --> Total execution time: 0.0021
DEBUG - 2022-04-13 02:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 02:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 02:56:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 02:56:00 --> Total execution time: 0.0188
DEBUG - 2022-04-13 02:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 02:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 02:57:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 02:57:49 --> Total execution time: 0.0080
DEBUG - 2022-04-13 02:58:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 02:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 02:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 02:58:03 --> Total execution time: 0.0041
DEBUG - 2022-04-13 03:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:10:00 --> Total execution time: 0.0593
DEBUG - 2022-04-13 03:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:14:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:14:02 --> Total execution time: 0.0847
DEBUG - 2022-04-13 03:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:14:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 03:14:02 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-13 03:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:14:20 --> Total execution time: 0.0045
DEBUG - 2022-04-13 03:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:14:23 --> Total execution time: 0.0032
DEBUG - 2022-04-13 03:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:15:29 --> Total execution time: 0.0031
DEBUG - 2022-04-13 03:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:17:02 --> Total execution time: 0.0038
DEBUG - 2022-04-13 03:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:21:43 --> Total execution time: 0.0387
DEBUG - 2022-04-13 03:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:26:22 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 2 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:27:17 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 2 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:27:18 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 2 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:27:18 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 2 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:27:18 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 2 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:27:34 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 3 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:27:35 --> Total execution time: 0.0049
DEBUG - 2022-04-13 03:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:27:37 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 3 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:28:39 --> Total execution time: 0.0035
DEBUG - 2022-04-13 03:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:28:52 --> Total execution time: 0.0064
DEBUG - 2022-04-13 03:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:28:55 --> Total execution time: 0.0066
DEBUG - 2022-04-13 03:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:28:58 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 3 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:29:44 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 3 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:29:45 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 3 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:29:45 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 3 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:29:45 --> Severity: error --> Exception: Too few arguments to function Admin_model::getUser(), 0 passed in /home/nsnmt.com/integrity/application/controllers/Admin.php on line 70 and at least 3 expected /home/nsnmt.com/integrity/application/models/Admin_model.php 9
DEBUG - 2022-04-13 03:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:30:07 --> Total execution time: 0.0053
DEBUG - 2022-04-13 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:31:21 --> Total execution time: 0.0434
DEBUG - 2022-04-13 03:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:34:51 --> Total execution time: 0.0030
DEBUG - 2022-04-13 03:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:35:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:35:04 --> Total execution time: 0.0236
DEBUG - 2022-04-13 03:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:35:35 --> Total execution time: 0.0029
DEBUG - 2022-04-13 03:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:35:43 --> Total execution time: 0.0027
DEBUG - 2022-04-13 03:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:35:47 --> Total execution time: 0.0106
DEBUG - 2022-04-13 03:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:36:20 --> Total execution time: 0.0032
DEBUG - 2022-04-13 03:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:38:31 --> Total execution time: 0.0030
DEBUG - 2022-04-13 03:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:38:32 --> Total execution time: 0.0027
DEBUG - 2022-04-13 03:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:38:34 --> Total execution time: 0.0026
DEBUG - 2022-04-13 03:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:38:35 --> Total execution time: 0.0032
DEBUG - 2022-04-13 03:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:38:35 --> Total execution time: 0.0026
DEBUG - 2022-04-13 03:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:38:36 --> Total execution time: 0.0025
DEBUG - 2022-04-13 03:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:38:37 --> Total execution time: 0.0029
DEBUG - 2022-04-13 03:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:43:26 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:43:26 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:44:59 --> Query error: Not unique table/alias: 'user' - Invalid query: SELECT *
FROM `user`, `SELECT` `user`.*, `user_role`.`role`` FROM ``user`` JOIN ``user_role`` ON ``user`.`role_id` `=``user_role`.`id`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
AND  `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
 LIMIT 20, 10
ERROR - 2022-04-13 03:44:59 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/models/Admin_model.php 22
DEBUG - 2022-04-13 03:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:44:59 --> Query error: Not unique table/alias: 'user' - Invalid query: SELECT *
FROM `user`, `SELECT` `user`.*, `user_role`.`role`` FROM ``user`` JOIN ``user_role`` ON ``user`.`role_id` `=``user_role`.`id`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
AND  `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
 LIMIT 20, 10
ERROR - 2022-04-13 03:44:59 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/models/Admin_model.php 22
DEBUG - 2022-04-13 03:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:45:00 --> Query error: Not unique table/alias: 'user' - Invalid query: SELECT *
FROM `user`, `SELECT` `user`.*, `user_role`.`role`` FROM ``user`` JOIN ``user_role`` ON ``user`.`role_id` `=``user_role`.`id`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
AND  `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
 LIMIT 20, 10
ERROR - 2022-04-13 03:45:00 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/models/Admin_model.php 22
DEBUG - 2022-04-13 03:45:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:45:01 --> Query error: Not unique table/alias: 'user' - Invalid query: SELECT *
FROM `user`, `SELECT` `user`.*, `user_role`.`role`` FROM ``user`` JOIN ``user_role`` ON ``user`.`role_id` `=``user_role`.`id`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
AND  `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
 LIMIT 20, 10
ERROR - 2022-04-13 03:45:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/models/Admin_model.php 22
DEBUG - 2022-04-13 03:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:45:02 --> Query error: Not unique table/alias: 'user' - Invalid query: SELECT *
FROM `user`, `SELECT` `user`.*, `user_role`.`role`` FROM ``user`` JOIN ``user_role`` ON ``user`.`role_id` `=``user_role`.`id`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
AND  `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
 LIMIT 20, 10
ERROR - 2022-04-13 03:45:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/models/Admin_model.php 22
DEBUG - 2022-04-13 03:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:45:27 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:45:27 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:45:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:45:41 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:45:41 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:45:42 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:45:42 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:50:50 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:50:50 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:50:51 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:50:51 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:50:52 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:50:52 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:50:52 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:50:52 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:50:53 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:50:53 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:50:53 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:50:53 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:50:58 --> No URI present. Default controller set.
DEBUG - 2022-04-13 03:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:50:58 --> Total execution time: 0.0171
DEBUG - 2022-04-13 03:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:51:01 --> Query error: Unknown column 'role' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `user`
WHERE `name` LIKE '%nes%' ESCAPE '!'
OR  `email` LIKE '%nes%' ESCAPE '!'
OR  `role` LIKE '%nes%' ESCAPE '!'
OR  `is_active` LIKE '%nes%' ESCAPE '!'
ERROR - 2022-04-13 03:51:01 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/nsnmt.com/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-04-13 03:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:53:13 --> Severity: error --> Exception: Call to a member function create_links() on null /home/nsnmt.com/integrity/application/views/admin/index.php 95
DEBUG - 2022-04-13 03:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:53:14 --> Severity: error --> Exception: Call to a member function create_links() on null /home/nsnmt.com/integrity/application/views/admin/index.php 95
DEBUG - 2022-04-13 03:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:53:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:53:15 --> Total execution time: 0.0072
DEBUG - 2022-04-13 03:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-13 03:53:17 --> Severity: error --> Exception: Call to a member function create_links() on null /home/nsnmt.com/integrity/application/views/admin/index.php 95
DEBUG - 2022-04-13 03:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:53:41 --> Total execution time: 0.0025
DEBUG - 2022-04-13 03:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:53:44 --> Total execution time: 0.0023
DEBUG - 2022-04-13 03:53:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:53:47 --> Total execution time: 0.0032
DEBUG - 2022-04-13 03:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:53:49 --> Total execution time: 0.0030
DEBUG - 2022-04-13 03:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:53:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:53:50 --> Total execution time: 0.0035
DEBUG - 2022-04-13 03:53:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:53:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:53:52 --> Total execution time: 0.0028
DEBUG - 2022-04-13 03:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:54:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:54:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:54:08 --> Total execution time: 0.0022
DEBUG - 2022-04-13 03:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:54:13 --> Total execution time: 0.0041
DEBUG - 2022-04-13 03:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:54:19 --> Total execution time: 0.0044
DEBUG - 2022-04-13 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:54:21 --> Total execution time: 0.0053
DEBUG - 2022-04-13 03:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:54:37 --> Total execution time: 0.0028
DEBUG - 2022-04-13 03:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:26 --> Total execution time: 0.0040
DEBUG - 2022-04-13 03:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:30 --> Total execution time: 0.0020
DEBUG - 2022-04-13 03:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:32 --> Total execution time: 0.0023
DEBUG - 2022-04-13 03:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:35 --> Total execution time: 0.0032
DEBUG - 2022-04-13 03:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:38 --> Total execution time: 0.0039
DEBUG - 2022-04-13 03:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:39 --> Total execution time: 0.0051
DEBUG - 2022-04-13 03:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:42 --> Total execution time: 0.0024
DEBUG - 2022-04-13 03:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:44 --> Total execution time: 0.0027
DEBUG - 2022-04-13 03:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:47 --> Total execution time: 0.0034
DEBUG - 2022-04-13 03:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:48 --> Total execution time: 0.0023
DEBUG - 2022-04-13 03:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:54 --> Total execution time: 0.0055
DEBUG - 2022-04-13 03:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:56 --> Total execution time: 0.0027
DEBUG - 2022-04-13 03:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:55:58 --> Total execution time: 0.0060
DEBUG - 2022-04-13 03:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:56:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:56:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:56:10 --> Total execution time: 0.0353
DEBUG - 2022-04-13 03:56:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 03:56:10 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-13 03:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:57:26 --> Total execution time: 0.0028
DEBUG - 2022-04-13 03:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:57:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:57:44 --> Total execution time: 0.0023
DEBUG - 2022-04-13 03:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 03:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 03:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 03:57:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 03:57:47 --> Total execution time: 0.0022
DEBUG - 2022-04-13 04:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:01:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:01:49 --> Total execution time: 0.0408
DEBUG - 2022-04-13 04:06:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:06:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:06:25 --> Total execution time: 0.0436
DEBUG - 2022-04-13 04:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:07:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:07:18 --> Total execution time: 0.0041
DEBUG - 2022-04-13 04:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:07:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:07:19 --> Total execution time: 0.0022
DEBUG - 2022-04-13 04:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:07:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:07:43 --> Total execution time: 0.0022
DEBUG - 2022-04-13 04:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:07:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:07:44 --> Total execution time: 0.0020
DEBUG - 2022-04-13 04:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:07:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:07:44 --> Total execution time: 0.0020
DEBUG - 2022-04-13 04:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:07:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:07:44 --> Total execution time: 0.0022
DEBUG - 2022-04-13 04:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:07:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:07:45 --> Total execution time: 0.0021
DEBUG - 2022-04-13 04:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:07:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:07:50 --> Total execution time: 0.0024
DEBUG - 2022-04-13 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:08:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:08:55 --> Total execution time: 0.0023
DEBUG - 2022-04-13 04:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:09:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:09:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:09:11 --> Total execution time: 0.0022
DEBUG - 2022-04-13 04:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:17:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:17:21 --> Total execution time: 0.0386
DEBUG - 2022-04-13 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:18:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:18:03 --> Total execution time: 0.0040
DEBUG - 2022-04-13 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:18:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:18:03 --> Total execution time: 0.0022
DEBUG - 2022-04-13 04:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:19:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:19:08 --> Total execution time: 0.0034
DEBUG - 2022-04-13 04:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:20:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:20:41 --> Total execution time: 0.0384
DEBUG - 2022-04-13 04:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:20:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:20:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:20:44 --> Total execution time: 0.0024
DEBUG - 2022-04-13 04:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:20:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:20:49 --> Total execution time: 0.0027
DEBUG - 2022-04-13 04:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:21:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:21:31 --> Total execution time: 0.0045
DEBUG - 2022-04-13 04:21:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:21:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:21:36 --> Total execution time: 0.0034
DEBUG - 2022-04-13 04:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:22:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:22:58 --> Total execution time: 0.0406
DEBUG - 2022-04-13 04:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:23:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:23:01 --> Total execution time: 0.0049
DEBUG - 2022-04-13 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:23:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:23:03 --> Total execution time: 0.0035
DEBUG - 2022-04-13 04:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:23:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:23:06 --> Total execution time: 0.0037
DEBUG - 2022-04-13 04:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:25:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:25:46 --> Total execution time: 0.0382
DEBUG - 2022-04-13 04:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:25:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:25:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:25:53 --> Total execution time: 0.0041
DEBUG - 2022-04-13 04:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:26:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:26:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:26:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:26:12 --> Total execution time: 0.0029
DEBUG - 2022-04-13 04:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 04:35:09 --> Severity: error --> Exception: syntax error, unexpected ';', expecting identifier (T_STRING) or variable (T_VARIABLE) or '{' or '$' /home/nsnmt.com/integrity/application/controllers/Profile.php 43
DEBUG - 2022-04-13 04:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:36:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:36:49 --> Total execution time: 0.0411
DEBUG - 2022-04-13 04:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:37:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-13 04:37:19 --> The upload path does not appear to be valid.
DEBUG - 2022-04-13 04:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:37:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:37:19 --> Total execution time: 0.0028
DEBUG - 2022-04-13 04:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:39:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:39:11 --> Total execution time: 0.0391
DEBUG - 2022-04-13 04:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:39:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-13 04:39:25 --> The upload path does not appear to be valid.
DEBUG - 2022-04-13 04:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:39:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:39:25 --> Total execution time: 0.0021
DEBUG - 2022-04-13 04:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:39:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:39:28 --> Total execution time: 0.0023
DEBUG - 2022-04-13 04:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:39:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-13 04:39:43 --> The upload path does not appear to be valid.
DEBUG - 2022-04-13 04:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:39:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:39:43 --> Total execution time: 0.0024
DEBUG - 2022-04-13 04:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:40:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:40:49 --> Total execution time: 0.0042
DEBUG - 2022-04-13 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:40:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:40:51 --> Total execution time: 0.0023
DEBUG - 2022-04-13 04:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:41:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-13 04:41:03 --> The upload path does not appear to be valid.
DEBUG - 2022-04-13 04:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:41:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:41:03 --> Total execution time: 0.0024
DEBUG - 2022-04-13 04:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:41:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:41:10 --> Total execution time: 0.0023
DEBUG - 2022-04-13 04:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:41:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:41:22 --> Total execution time: 0.0108
DEBUG - 2022-04-13 04:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:41:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:41:33 --> Total execution time: 0.0031
DEBUG - 2022-04-13 04:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:50:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:50:37 --> Total execution time: 0.0403
DEBUG - 2022-04-13 04:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:54:16 --> Total execution time: 0.0424
DEBUG - 2022-04-13 04:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:55:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-13 04:55:26 --> Severity: error --> Exception: syntax error, unexpected ';' /home/nsnmt.com/integrity/application/views/data/detail.php 150
DEBUG - 2022-04-13 04:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 04:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 04:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 04:57:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 04:57:14 --> Total execution time: 0.0449
DEBUG - 2022-04-13 05:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:32:20 --> Total execution time: 0.0422
DEBUG - 2022-04-13 05:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:32:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:32:26 --> Total execution time: 0.0096
DEBUG - 2022-04-13 05:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:32:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:32:28 --> Total execution time: 0.0250
DEBUG - 2022-04-13 05:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 05:32:28 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-13 05:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:32:52 --> Total execution time: 0.0029
DEBUG - 2022-04-13 05:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:39:53 --> Total execution time: 0.0404
DEBUG - 2022-04-13 05:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:39:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:39:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:39:55 --> Total execution time: 0.0116
DEBUG - 2022-04-13 05:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:39:59 --> Total execution time: 0.0041
DEBUG - 2022-04-13 05:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:40:07 --> Total execution time: 0.0093
DEBUG - 2022-04-13 05:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:40:37 --> Total execution time: 0.0097
DEBUG - 2022-04-13 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:39 --> Total execution time: 0.0033
DEBUG - 2022-04-13 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:40:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:40:40 --> Total execution time: 0.0065
DEBUG - 2022-04-13 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:43 --> Total execution time: 0.0038
DEBUG - 2022-04-13 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:40:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:40:43 --> Total execution time: 0.0066
DEBUG - 2022-04-13 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:34 --> Total execution time: 0.0048
DEBUG - 2022-04-13 05:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:36 --> Total execution time: 0.0035
DEBUG - 2022-04-13 05:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:36 --> Total execution time: 0.0066
DEBUG - 2022-04-13 05:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:38 --> Total execution time: 0.0048
DEBUG - 2022-04-13 05:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:39 --> Total execution time: 0.0065
DEBUG - 2022-04-13 05:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:40 --> Total execution time: 0.0021
DEBUG - 2022-04-13 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:41 --> Total execution time: 0.0055
DEBUG - 2022-04-13 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:43 --> Total execution time: 0.0036
DEBUG - 2022-04-13 05:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:41:49 --> Total execution time: 0.0067
DEBUG - 2022-04-13 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:41:53 --> Total execution time: 0.0046
DEBUG - 2022-04-13 05:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:01 --> Total execution time: 0.0080
DEBUG - 2022-04-13 05:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:08 --> Total execution time: 0.0075
DEBUG - 2022-04-13 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:16 --> Total execution time: 0.0055
DEBUG - 2022-04-13 05:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:20 --> Total execution time: 0.0031
DEBUG - 2022-04-13 05:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:22 --> Total execution time: 0.0058
DEBUG - 2022-04-13 05:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:42:25 --> Total execution time: 0.0057
DEBUG - 2022-04-13 05:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:28 --> Total execution time: 0.0021
DEBUG - 2022-04-13 05:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:42:52 --> Total execution time: 0.0030
DEBUG - 2022-04-13 05:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:43:12 --> Total execution time: 0.0034
DEBUG - 2022-04-13 05:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:44:01 --> Total execution time: 0.0071
DEBUG - 2022-04-13 05:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:44:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:44:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:44:04 --> Total execution time: 0.0052
DEBUG - 2022-04-13 05:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:44:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:44:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:44:45 --> Total execution time: 0.0066
DEBUG - 2022-04-13 05:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:45:55 --> Total execution time: 0.0035
DEBUG - 2022-04-13 05:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:45:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:45:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:45:57 --> Total execution time: 0.0063
DEBUG - 2022-04-13 05:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:45:59 --> Total execution time: 0.0035
DEBUG - 2022-04-13 05:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:46:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:46:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:46:01 --> Total execution time: 0.0077
DEBUG - 2022-04-13 05:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:46:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:46:30 --> Total execution time: 0.0097
DEBUG - 2022-04-13 05:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:46:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:46:32 --> Total execution time: 0.0031
DEBUG - 2022-04-13 05:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 05:46:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 05:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:46:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:46:40 --> Total execution time: 0.0084
DEBUG - 2022-04-13 05:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:46:42 --> Total execution time: 0.0022
DEBUG - 2022-04-13 05:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:46:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:46:45 --> Total execution time: 0.0015
DEBUG - 2022-04-13 05:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 05:46:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:47:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:47:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:47:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:47:02 --> Total execution time: 0.0067
DEBUG - 2022-04-13 05:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:47:06 --> Total execution time: 0.0026
DEBUG - 2022-04-13 05:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:47:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:47:13 --> Total execution time: 0.0016
DEBUG - 2022-04-13 05:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:47:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 05:47:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:47:20 --> Total execution time: 0.0026
DEBUG - 2022-04-13 05:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:48:13 --> Total execution time: 0.0038
DEBUG - 2022-04-13 05:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:48:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:48:14 --> Total execution time: 0.0015
DEBUG - 2022-04-13 05:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 05:48:14 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:48:16 --> Total execution time: 0.0036
DEBUG - 2022-04-13 05:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:48:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:48:39 --> Total execution time: 0.0071
DEBUG - 2022-04-13 05:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:48:40 --> Total execution time: 0.0022
DEBUG - 2022-04-13 05:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:48:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:48:43 --> Total execution time: 0.0013
DEBUG - 2022-04-13 05:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:48:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 05:48:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 05:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:00 --> Total execution time: 0.0025
DEBUG - 2022-04-13 05:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:13 --> Total execution time: 0.0031
DEBUG - 2022-04-13 05:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:49:13 --> Total execution time: 0.0016
DEBUG - 2022-04-13 05:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 05:49:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 05:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:27 --> Total execution time: 0.0031
DEBUG - 2022-04-13 05:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:28 --> Total execution time: 0.0030
DEBUG - 2022-04-13 05:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:49:31 --> Total execution time: 0.0053
DEBUG - 2022-04-13 05:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 05:49:33 --> Total execution time: 0.0024
DEBUG - 2022-04-13 05:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:37 --> Total execution time: 0.0024
DEBUG - 2022-04-13 05:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 05:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 05:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 05:49:42 --> Total execution time: 0.0041
DEBUG - 2022-04-13 06:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:23:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:23:58 --> Total execution time: 0.0632
DEBUG - 2022-04-13 06:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:23:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 06:23:58 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-13 06:24:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:24:06 --> Total execution time: 0.0045
DEBUG - 2022-04-13 06:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:24:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:24:08 --> Total execution time: 0.0252
DEBUG - 2022-04-13 06:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:24:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 06:24:08 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-13 06:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:28:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:28:55 --> Total execution time: 0.0480
DEBUG - 2022-04-13 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:39:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:39:32 --> Total execution time: 0.0436
DEBUG - 2022-04-13 06:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:40:00 --> Total execution time: 0.0059
DEBUG - 2022-04-13 06:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:40:06 --> Total execution time: 0.0032
DEBUG - 2022-04-13 06:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:40:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:40:13 --> Total execution time: 0.0026
DEBUG - 2022-04-13 06:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:40:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 06:40:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 06:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:40:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:40:14 --> Total execution time: 0.0044
DEBUG - 2022-04-13 06:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:40:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 06:40:15 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-13 06:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:40:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:40:23 --> Total execution time: 0.0016
DEBUG - 2022-04-13 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:40:24 --> Total execution time: 0.0022
DEBUG - 2022-04-13 06:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:41:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:41:30 --> Total execution time: 0.0343
DEBUG - 2022-04-13 06:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:41:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 06:41:30 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-13 06:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:41:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:41:35 --> Total execution time: 0.0096
DEBUG - 2022-04-13 06:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:41:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:41:40 --> Total execution time: 0.0237
DEBUG - 2022-04-13 06:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:41:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 06:41:40 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-13 06:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:42:02 --> Total execution time: 0.0029
DEBUG - 2022-04-13 06:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-13 06:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-13 06:42:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-13 06:42:41 --> Total execution time: 0.0278
DEBUG - 2022-04-13 06:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-13 06:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-13 06:42:41 --> 404 Page Not Found: Img/undraw_posting_photo.svg
