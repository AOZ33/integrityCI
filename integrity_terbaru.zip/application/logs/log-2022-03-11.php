<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-11 09:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 09:43:37 --> No URI present. Default controller set.
DEBUG - 2022-03-11 09:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 09:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 09:43:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 09:43:37 --> Total execution time: 0.0304
DEBUG - 2022-03-11 09:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 09:43:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 09:43:37 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-11 09:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 09:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 09:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 09:43:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 09:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 09:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 09:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 09:43:39 --> Total execution time: 0.0069
DEBUG - 2022-03-11 09:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 09:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 09:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 09:43:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 09:43:41 --> Total execution time: 0.0119
DEBUG - 2022-03-11 09:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 09:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 09:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 09:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 09:52:55 --> Total execution time: 0.0337
DEBUG - 2022-03-11 10:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:24:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:24:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:24:38 --> Total execution time: 0.0067
DEBUG - 2022-03-11 10:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:28:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:28:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:28:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:28:00 --> Total execution time: 0.0067
DEBUG - 2022-03-11 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:36:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:36:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:36:05 --> Total execution time: 0.0063
DEBUG - 2022-03-11 10:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:43:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:43:54 --> Total execution time: 0.0066
DEBUG - 2022-03-11 10:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:57:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 10:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 10:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 10:57:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 10:57:48 --> Total execution time: 0.0077
DEBUG - 2022-03-11 11:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 11:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 11:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 11:00:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 11:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 11:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 11:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 11:00:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 11:00:22 --> Total execution time: 0.0065
DEBUG - 2022-03-11 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 11:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 11:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 11:28:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 11:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 11:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 11:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 11:28:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 11:28:41 --> Total execution time: 0.0080
DEBUG - 2022-03-11 12:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 12:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 12:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 12:46:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 12:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 12:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 12:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 12:46:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 12:46:45 --> Total execution time: 0.0075
DEBUG - 2022-03-11 13:09:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:32 --> No URI present. Default controller set.
DEBUG - 2022-03-11 13:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:09:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:09:32 --> Total execution time: 0.0309
DEBUG - 2022-03-11 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 13:09:33 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-11 13:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 13:09:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-11 13:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:34 --> No URI present. Default controller set.
DEBUG - 2022-03-11 13:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:09:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:09:34 --> Total execution time: 0.0037
DEBUG - 2022-03-11 13:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:09:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:09:40 --> Total execution time: 0.0062
DEBUG - 2022-03-11 13:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:09:43 --> Total execution time: 0.0041
DEBUG - 2022-03-11 13:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 13:09:43 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-11 13:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:09:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:09:48 --> Total execution time: 0.0112
DEBUG - 2022-03-11 13:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:09:54 --> Total execution time: 0.0043
DEBUG - 2022-03-11 13:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:09:58 --> Total execution time: 0.0037
DEBUG - 2022-03-11 13:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:09:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 13:09:58 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-11 13:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:26 --> No URI present. Default controller set.
DEBUG - 2022-03-11 13:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:20:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:20:26 --> Total execution time: 0.0316
DEBUG - 2022-03-11 13:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 13:20:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-11 13:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:26 --> No URI present. Default controller set.
DEBUG - 2022-03-11 13:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:20:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:20:26 --> Total execution time: 0.0038
DEBUG - 2022-03-11 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:20:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:20:29 --> Total execution time: 0.0068
DEBUG - 2022-03-11 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:20:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:20:29 --> Total execution time: 0.0032
DEBUG - 2022-03-11 13:20:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:20:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:20:37 --> Total execution time: 0.0114
DEBUG - 2022-03-11 13:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 13:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 13:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 13:20:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 13:20:41 --> Total execution time: 0.0054
DEBUG - 2022-03-11 14:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:35:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:35:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:35:25 --> Total execution time: 0.0080
DEBUG - 2022-03-11 14:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:40:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:40:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:40:14 --> Total execution time: 0.0058
DEBUG - 2022-03-11 14:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:51:48 --> Total execution time: 0.0339
DEBUG - 2022-03-11 14:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:51:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 14:51:48 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-11 14:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:54:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:54:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:54:34 --> Total execution time: 0.0066
DEBUG - 2022-03-11 14:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 14:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 14:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 14:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 14:58:56 --> Total execution time: 0.0061
DEBUG - 2022-03-11 17:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:29:53 --> No URI present. Default controller set.
DEBUG - 2022-03-11 17:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 17:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 17:29:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 17:29:53 --> Total execution time: 0.0330
DEBUG - 2022-03-11 17:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:29:53 --> No URI present. Default controller set.
DEBUG - 2022-03-11 17:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 17:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 17:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:29:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 17:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 17:29:53 --> Total execution time: 0.0037
ERROR - 2022-03-11 17:29:53 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-11 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 17:29:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-11 17:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-11 17:29:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-11 17:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 17:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 17:30:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 17:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 17:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 17:30:06 --> Total execution time: 0.0071
DEBUG - 2022-03-11 17:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 17:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 17:30:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 17:30:09 --> Total execution time: 0.0120
DEBUG - 2022-03-11 17:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-11 17:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-11 17:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-11 17:30:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-11 17:30:52 --> Total execution time: 0.0087
