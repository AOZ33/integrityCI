<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-14 15:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:51:16 --> No URI present. Default controller set.
DEBUG - 2022-05-14 15:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-14 15:51:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-14 15:51:16 --> Total execution time: 0.0525
DEBUG - 2022-05-14 15:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 15:51:17 --> No URI present. Default controller set.
DEBUG - 2022-05-14 15:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 15:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-14 15:51:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-14 15:51:17 --> Total execution time: 0.0058
DEBUG - 2022-05-14 19:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-14 19:29:02 --> No URI present. Default controller set.
DEBUG - 2022-05-14 19:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-14 19:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-14 19:29:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-14 19:29:02 --> Total execution time: 0.0390
