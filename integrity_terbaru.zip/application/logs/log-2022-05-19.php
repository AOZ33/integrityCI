<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-19 02:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:30:56 --> No URI present. Default controller set.
DEBUG - 2022-05-19 02:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 02:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 02:30:56 --> Total execution time: 0.0555
DEBUG - 2022-05-19 02:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 02:30:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-19 02:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 02:30:56 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-19 02:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 02:30:56 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-19 02:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 02:30:56 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-19 02:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 02:30:56 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-19 02:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 02:30:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 02:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 02:31:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 02:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 02:31:14 --> Total execution time: 0.0059
DEBUG - 2022-05-19 02:31:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 02:31:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 02:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 02:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 02:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 02:31:20 --> Total execution time: 0.0085
DEBUG - 2022-05-19 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:53 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:32:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 03:32:53 --> Total execution time: 0.0380
DEBUG - 2022-05-19 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:32:53 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-19 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:32:53 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-19 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:32:53 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-19 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:32:53 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-19 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:32:53 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-19 03:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:32:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 03:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:32:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 03:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:32:54 --> Total execution time: 0.0035
DEBUG - 2022-05-19 03:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:35:05 --> Total execution time: 0.0439
DEBUG - 2022-05-19 03:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:42:05 --> Total execution time: 0.0434
DEBUG - 2022-05-19 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:52 --> No URI present. Default controller set.
DEBUG - 2022-05-19 03:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:54:52 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-19 03:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:54:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 03:54:52 --> Total execution time: 0.0412
DEBUG - 2022-05-19 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:54:52 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-19 03:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:54:52 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-19 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:54:52 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-19 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:54:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-19 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:54:52 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-19 03:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 03:54:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-19 03:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:54:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 03:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:54:59 --> Total execution time: 0.0035
DEBUG - 2022-05-19 03:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:14 --> Total execution time: 0.0041
DEBUG - 2022-05-19 03:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:14 --> Total execution time: 0.0457
DEBUG - 2022-05-19 03:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:19 --> Total execution time: 0.0484
DEBUG - 2022-05-19 03:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:20 --> Total execution time: 0.0459
DEBUG - 2022-05-19 03:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:20 --> Total execution time: 0.0476
DEBUG - 2022-05-19 03:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:20 --> Total execution time: 0.0427
DEBUG - 2022-05-19 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:21 --> Total execution time: 0.0456
DEBUG - 2022-05-19 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:21 --> Total execution time: 0.0443
DEBUG - 2022-05-19 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:21 --> Total execution time: 0.0486
DEBUG - 2022-05-19 03:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:21 --> Total execution time: 0.0525
DEBUG - 2022-05-19 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:22 --> Total execution time: 0.0474
DEBUG - 2022-05-19 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:22 --> Total execution time: 0.0455
DEBUG - 2022-05-19 03:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:23 --> Total execution time: 0.0388
DEBUG - 2022-05-19 03:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:23 --> Total execution time: 0.0437
DEBUG - 2022-05-19 03:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:23 --> Total execution time: 0.0413
DEBUG - 2022-05-19 03:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:23 --> Total execution time: 0.0422
DEBUG - 2022-05-19 03:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:24 --> Total execution time: 0.0439
DEBUG - 2022-05-19 03:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:24 --> Total execution time: 0.0448
DEBUG - 2022-05-19 03:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:25 --> Total execution time: 0.0407
DEBUG - 2022-05-19 03:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:39 --> Total execution time: 0.0044
DEBUG - 2022-05-19 03:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:55:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 03:55:46 --> Total execution time: 0.0184
DEBUG - 2022-05-19 03:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:56:19 --> Total execution time: 0.0028
DEBUG - 2022-05-19 03:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 03:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 03:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 03:56:19 --> Total execution time: 0.0440
DEBUG - 2022-05-19 04:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:25:20 --> Total execution time: 0.0421
DEBUG - 2022-05-19 04:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:25:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 04:25:22 --> Total execution time: 0.0116
DEBUG - 2022-05-19 04:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:25:57 --> Total execution time: 0.0041
DEBUG - 2022-05-19 04:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:26:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 04:26:07 --> Total execution time: 0.0048
DEBUG - 2022-05-19 04:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
ERROR - 2022-05-19 04:31:13 --> Severity: Warning --> Invalid argument supplied for foreach() /home/nsnmt.com/integrity/application/views/editor/index.php 167
DEBUG - 2022-05-19 04:31:13 --> Total execution time: 0.0066
DEBUG - 2022-05-19 04:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-19 04:33:02 --> Severity: error --> Exception: Call to a member function getGaji_e() on null /home/nsnmt.com/integrity/application/controllers/Editor.php 72
DEBUG - 2022-05-19 04:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:33:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 04:33:07 --> Total execution time: 0.0060
DEBUG - 2022-05-19 04:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:33:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 04:33:32 --> Total execution time: 0.0147
DEBUG - 2022-05-19 04:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:33:34 --> Total execution time: 0.0081
DEBUG - 2022-05-19 04:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:33:55 --> Total execution time: 0.0114
DEBUG - 2022-05-19 04:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:33:58 --> Total execution time: 0.0068
DEBUG - 2022-05-19 04:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 04:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 04:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 04:47:26 --> Total execution time: 0.0639
DEBUG - 2022-05-19 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:19:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-19 06:19:02 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-05-19 06:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 06:44:36 --> Total execution time: 0.0432
DEBUG - 2022-05-19 06:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 06:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 06:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 06:44:37 --> Total execution time: 0.0049
DEBUG - 2022-05-19 07:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-19 07:11:23 --> Severity: error --> Exception: Call to a member function getGaji() on null /home/nsnmt.com/integrity/application/controllers/Prewedding.php 73
DEBUG - 2022-05-19 07:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 07:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 07:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 07:12:50 --> Total execution time: 0.0432
DEBUG - 2022-05-19 17:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-19 17:13:23 --> No URI present. Default controller set.
DEBUG - 2022-05-19 17:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-19 17:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-19 17:13:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-19 17:13:23 --> Total execution time: 0.0356
