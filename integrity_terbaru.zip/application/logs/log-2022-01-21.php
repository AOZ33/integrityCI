<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-21 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:29:08 --> No URI present. Default controller set.
DEBUG - 2022-01-21 13:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:29:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:29:08 --> Total execution time: 0.0306
DEBUG - 2022-01-21 13:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:29:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-21 13:29:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-21 13:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:29:09 --> No URI present. Default controller set.
DEBUG - 2022-01-21 13:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:29:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:29:09 --> Total execution time: 0.0033
DEBUG - 2022-01-21 13:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:29:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:29:31 --> Total execution time: 0.0068
DEBUG - 2022-01-21 13:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:29:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-21 13:29:33 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 105755360 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-21 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:44:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:44:05 --> Total execution time: 0.0347
DEBUG - 2022-01-21 13:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:51:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:51:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:51:49 --> Total execution time: 0.0061
DEBUG - 2022-01-21 13:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:56:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:56:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:56:57 --> Total execution time: 0.0057
DEBUG - 2022-01-21 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:58:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 13:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 13:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 13:58:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 13:58:59 --> Total execution time: 0.0062
DEBUG - 2022-01-21 14:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:01:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:01:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:01:58 --> Total execution time: 0.0060
DEBUG - 2022-01-21 14:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:06:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:06:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:06:11 --> Total execution time: 0.0061
DEBUG - 2022-01-21 14:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:10:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:10:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:10:05 --> Total execution time: 0.0061
DEBUG - 2022-01-21 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:14:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:14:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:14:53 --> Total execution time: 0.0071
DEBUG - 2022-01-21 14:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:19:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:19:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:19:25 --> Total execution time: 0.0057
DEBUG - 2022-01-21 14:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:21:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-21 14:21:34 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-21 14:21:35 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Terena Chintya & Dimas Galih', '', '5jt nesnu x keia', NULL, '', '', '', '', '', '', '', '', '', '', '', 'Jl. Gardenia 6 Blok E No.5 Cikarang Baru Bekasi', '0821227070061 (terena)', 'terenachintya@gmail.com', '@terenachintya & @dimgalsp', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-01-21 14:21:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:21:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:21:35 --> Total execution time: 0.0064
DEBUG - 2022-01-21 14:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:24:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:24:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:24:56 --> Total execution time: 0.0061
DEBUG - 2022-01-21 14:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:26:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:26:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:26:53 --> Total execution time: 0.0057
DEBUG - 2022-01-21 14:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:30:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:30:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:30:52 --> Total execution time: 0.0062
DEBUG - 2022-01-21 14:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:33:16 --> Total execution time: 0.0060
DEBUG - 2022-01-21 14:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:39:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:39:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:39:49 --> Total execution time: 0.0062
DEBUG - 2022-01-21 14:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:42:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:42:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:42:06 --> Total execution time: 0.0064
DEBUG - 2022-01-21 14:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:44:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:44:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:44:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:44:24 --> Total execution time: 0.0062
DEBUG - 2022-01-21 14:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:48:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 14:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 14:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 14:48:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 14:48:29 --> Total execution time: 0.0060
DEBUG - 2022-01-21 15:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 15:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 15:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 15:04:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 15:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 15:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 15:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 15:04:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 15:04:52 --> Total execution time: 0.0057
DEBUG - 2022-01-21 15:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 15:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 15:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 15:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 15:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 15:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 15:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 15:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 15:11:32 --> Total execution time: 0.0064
DEBUG - 2022-01-21 15:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 15:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 15:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 15:14:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 15:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 15:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 15:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 15:14:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 15:14:09 --> Total execution time: 0.0063
DEBUG - 2022-01-21 16:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:03:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:03:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:03:48 --> Total execution time: 0.0073
DEBUG - 2022-01-21 16:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:08:23 --> Total execution time: 0.0060
DEBUG - 2022-01-21 16:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:10:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:10:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:10:50 --> Total execution time: 0.0058
DEBUG - 2022-01-21 16:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:13:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:13:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:13:55 --> Total execution time: 0.0059
DEBUG - 2022-01-21 16:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:16:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:16:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:16:49 --> Total execution time: 0.0062
DEBUG - 2022-01-21 16:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:20:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:20:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:20:23 --> Total execution time: 0.0060
DEBUG - 2022-01-21 16:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:22:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:22:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:22:37 --> Total execution time: 0.0066
DEBUG - 2022-01-21 16:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:24:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:24:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:24:14 --> Total execution time: 0.0061
DEBUG - 2022-01-21 16:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:27:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:27:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:27:30 --> Total execution time: 0.0061
DEBUG - 2022-01-21 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:28:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:28:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:28:41 --> Total execution time: 0.0046
DEBUG - 2022-01-21 16:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:30:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:30:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:30:26 --> Total execution time: 0.0064
DEBUG - 2022-01-21 16:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:35:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:35:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:35:21 --> Total execution time: 0.0062
DEBUG - 2022-01-21 16:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:39:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:39:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:39:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:39:12 --> Total execution time: 0.0059
DEBUG - 2022-01-21 16:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:40:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:40:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:40:46 --> Total execution time: 0.0063
DEBUG - 2022-01-21 16:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:43:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:43:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:43:50 --> Total execution time: 0.0061
DEBUG - 2022-01-21 16:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:46:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:46:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:46:15 --> Total execution time: 0.0061
DEBUG - 2022-01-21 16:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:47:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:47:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:47:58 --> Total execution time: 0.0058
DEBUG - 2022-01-21 16:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:50:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:50:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:50:17 --> Total execution time: 0.0064
DEBUG - 2022-01-21 16:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:51:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:51:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:51:24 --> Total execution time: 0.0045
DEBUG - 2022-01-21 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:52:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:52:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:52:37 --> Total execution time: 0.0061
DEBUG - 2022-01-21 16:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:53:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:53:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-21 16:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-21 16:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-21 16:53:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-21 16:53:36 --> Total execution time: 0.0038
