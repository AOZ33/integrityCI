<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-23 03:50:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 03:50:10 --> No URI present. Default controller set.
DEBUG - 2021-11-23 03:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 03:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 03:50:10 --> Total execution time: 0.1003
DEBUG - 2021-11-23 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 03:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 03:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 03:50:14 --> Total execution time: 0.0609
DEBUG - 2021-11-23 03:50:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 03:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 03:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 03:50:17 --> Total execution time: 0.0360
DEBUG - 2021-11-23 03:50:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 03:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 03:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 03:50:24 --> Total execution time: 0.0789
DEBUG - 2021-11-23 03:51:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 03:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 03:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 03:51:42 --> Total execution time: 0.0287
DEBUG - 2021-11-23 04:02:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:02:35 --> Total execution time: 0.0308
DEBUG - 2021-11-23 04:02:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:02:44 --> Total execution time: 0.0387
DEBUG - 2021-11-23 04:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:05:48 --> Total execution time: 0.0417
DEBUG - 2021-11-23 04:07:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:07:52 --> Total execution time: 0.0283
DEBUG - 2021-11-23 04:11:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:11:10 --> Total execution time: 0.0406
DEBUG - 2021-11-23 04:18:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:18:57 --> Total execution time: 0.0422
DEBUG - 2021-11-23 04:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:20:19 --> Total execution time: 0.0507
DEBUG - 2021-11-23 04:21:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:21:38 --> Total execution time: 0.0274
DEBUG - 2021-11-23 04:24:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:24:30 --> Total execution time: 0.0296
DEBUG - 2021-11-23 04:24:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:24:31 --> Total execution time: 0.0494
DEBUG - 2021-11-23 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:24:55 --> Total execution time: 0.0416
DEBUG - 2021-11-23 04:25:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:25:26 --> Total execution time: 0.0443
DEBUG - 2021-11-23 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:26:26 --> Total execution time: 0.0265
DEBUG - 2021-11-23 04:27:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:27:08 --> Total execution time: 0.0461
DEBUG - 2021-11-23 04:28:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:28:21 --> Total execution time: 0.0463
DEBUG - 2021-11-23 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:29:15 --> Total execution time: 0.0377
DEBUG - 2021-11-23 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:29:39 --> Total execution time: 0.0488
DEBUG - 2021-11-23 04:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:34:24 --> Total execution time: 0.0375
DEBUG - 2021-11-23 04:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:34:41 --> Total execution time: 0.0445
DEBUG - 2021-11-23 04:36:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:36:08 --> Total execution time: 0.0425
DEBUG - 2021-11-23 04:36:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:36:30 --> Total execution time: 0.0385
DEBUG - 2021-11-23 04:37:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:37:13 --> Total execution time: 0.0277
DEBUG - 2021-11-23 04:37:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 04:37:34 --> Query error: Unknown column 'contact' in 'field list' - Invalid query: INSERT INTO `package` (`name`, `contact`, `id_package`) VALUES ('Farhan', '089187678098', '1')
DEBUG - 2021-11-23 04:38:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:38:49 --> Total execution time: 0.0480
DEBUG - 2021-11-23 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:38:50 --> Total execution time: 0.0461
DEBUG - 2021-11-23 04:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 04:38:56 --> Query error: Unknown column 'contact' in 'field list' - Invalid query: INSERT INTO `package` (`name`, `contact`, `id_package`) VALUES ('Farhan', '089187678098', '1')
DEBUG - 2021-11-23 04:44:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:44:05 --> Total execution time: 0.0375
DEBUG - 2021-11-23 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:44:06 --> Total execution time: 0.0494
DEBUG - 2021-11-23 04:44:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-23 04:44:30 --> 404 Page Not Found: Photograper/add_photograper
DEBUG - 2021-11-23 04:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:44:40 --> Total execution time: 0.0430
DEBUG - 2021-11-23 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:44:44 --> Total execution time: 0.0446
DEBUG - 2021-11-23 04:44:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:44:45 --> Total execution time: 0.0515
DEBUG - 2021-11-23 04:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 04:44:50 --> Query error: Unknown column 'id_Photograper' in 'field list' - Invalid query: INSERT INTO `photograper` (`name`, `contact`, `id_Photograper`) VALUES ('Farhan', '089187678098', NULL)
DEBUG - 2021-11-23 04:45:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:45:20 --> Total execution time: 0.0512
DEBUG - 2021-11-23 04:45:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:45:20 --> Total execution time: 0.0456
DEBUG - 2021-11-23 04:45:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 04:45:25 --> Query error: Unknown column 'id_photograper' in 'field list' - Invalid query: INSERT INTO `photograper` (`name`, `contact`, `id_photograper`) VALUES ('Farhan', '089187678098', NULL)
DEBUG - 2021-11-23 04:45:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:45:52 --> Total execution time: 0.0510
DEBUG - 2021-11-23 04:45:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:45:52 --> Total execution time: 0.0406
DEBUG - 2021-11-23 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 04:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 04:45:56 --> Total execution time: 0.0430
DEBUG - 2021-11-23 06:29:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:29:48 --> Total execution time: 0.0510
DEBUG - 2021-11-23 06:29:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:29:59 --> Total execution time: 0.0524
DEBUG - 2021-11-23 06:30:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:30:02 --> Total execution time: 0.0458
DEBUG - 2021-11-23 06:30:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:30:07 --> Total execution time: 0.0414
DEBUG - 2021-11-23 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:30:42 --> Total execution time: 0.0424
DEBUG - 2021-11-23 06:31:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:31:04 --> Total execution time: 0.0484
DEBUG - 2021-11-23 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:31:32 --> Total execution time: 0.0450
DEBUG - 2021-11-23 06:31:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:31:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-23 06:31:56 --> 404 Page Not Found: Videograper/add
DEBUG - 2021-11-23 06:33:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:33:10 --> Total execution time: 0.0519
DEBUG - 2021-11-23 06:33:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:33:11 --> Total execution time: 0.0269
DEBUG - 2021-11-23 06:33:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-23 06:33:21 --> 404 Page Not Found: Videograper/add
DEBUG - 2021-11-23 06:34:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:34:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-23 06:34:02 --> 404 Page Not Found: Videograper/add
DEBUG - 2021-11-23 06:34:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:34:03 --> Total execution time: 0.0399
DEBUG - 2021-11-23 06:34:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:34:04 --> Total execution time: 0.0459
DEBUG - 2021-11-23 06:34:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:34:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:34:15 --> Total execution time: 0.0278
DEBUG - 2021-11-23 06:34:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:34:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-23 06:34:50 --> 404 Page Not Found: Videograper/add
DEBUG - 2021-11-23 06:35:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:35:41 --> Total execution time: 0.0284
DEBUG - 2021-11-23 06:35:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:35:41 --> Total execution time: 0.0463
DEBUG - 2021-11-23 06:35:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:35:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-23 06:35:48 --> 404 Page Not Found: Videograper/add_videograper
DEBUG - 2021-11-23 06:41:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:41:22 --> Total execution time: 0.0284
DEBUG - 2021-11-23 06:42:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:42:12 --> Total execution time: 0.0394
DEBUG - 2021-11-23 06:42:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:42:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:42:20 --> Total execution time: 0.0411
DEBUG - 2021-11-23 06:47:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:47:11 --> Total execution time: 0.0308
DEBUG - 2021-11-23 06:47:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:47:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:47:35 --> Total execution time: 0.0406
DEBUG - 2021-11-23 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:50:05 --> Total execution time: 0.5129
DEBUG - 2021-11-23 06:50:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 06:50:15 --> Severity: error --> Exception: C:\xampp\htdocs\nesnu\application\models/Crew_model.php exists, but doesn't declare class Crew_model C:\xampp\htdocs\nesnu\system\core\Loader.php 340
DEBUG - 2021-11-23 06:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:50:40 --> Total execution time: 0.0270
DEBUG - 2021-11-23 06:50:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:50:41 --> Total execution time: 0.0409
DEBUG - 2021-11-23 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:50:47 --> Total execution time: 0.0438
DEBUG - 2021-11-23 06:51:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:51:48 --> Total execution time: 0.0457
DEBUG - 2021-11-23 06:51:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:51:49 --> Total execution time: 0.0513
DEBUG - 2021-11-23 06:51:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:51:50 --> Total execution time: 0.0690
DEBUG - 2021-11-23 06:55:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:55:54 --> Total execution time: 0.0471
DEBUG - 2021-11-23 06:56:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:56:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:56:33 --> Total execution time: 0.0419
DEBUG - 2021-11-23 06:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:57:05 --> Total execution time: 0.0373
DEBUG - 2021-11-23 06:57:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 06:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 06:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 06:57:56 --> Total execution time: 0.0519
DEBUG - 2021-11-23 07:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:01:41 --> Total execution time: 0.0481
DEBUG - 2021-11-23 07:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:02:24 --> Total execution time: 0.0613
DEBUG - 2021-11-23 07:02:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:02:26 --> Total execution time: 0.0509
DEBUG - 2021-11-23 07:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:20:38 --> Total execution time: 0.0305
DEBUG - 2021-11-23 07:22:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:22:02 --> Total execution time: 0.0378
DEBUG - 2021-11-23 07:22:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:22:23 --> Total execution time: 0.0421
DEBUG - 2021-11-23 07:27:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:27:43 --> Total execution time: 0.0500
DEBUG - 2021-11-23 07:28:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:28:56 --> Total execution time: 0.0466
DEBUG - 2021-11-23 07:29:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:29:53 --> Total execution time: 0.0464
DEBUG - 2021-11-23 07:30:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:30:51 --> Total execution time: 0.0503
DEBUG - 2021-11-23 07:38:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:38:39 --> Total execution time: 0.0295
DEBUG - 2021-11-23 07:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:38:59 --> Total execution time: 0.0492
DEBUG - 2021-11-23 07:39:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:39:04 --> Total execution time: 0.0271
DEBUG - 2021-11-23 07:40:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 07:40:30 --> Severity: error --> Exception: syntax error, unexpected end of file C:\xampp\htdocs\nesnu\application\views\package\index.php 413
DEBUG - 2021-11-23 07:40:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:40:46 --> Total execution time: 0.0464
DEBUG - 2021-11-23 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:41:09 --> Total execution time: 0.0409
DEBUG - 2021-11-23 07:41:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:41:57 --> Total execution time: 0.0445
DEBUG - 2021-11-23 07:42:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 07:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 07:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 07:42:16 --> Total execution time: 0.0374
DEBUG - 2021-11-23 09:24:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:24:01 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:24:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:24:01 --> Total execution time: 0.0579
DEBUG - 2021-11-23 09:24:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:24:57 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:24:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:24:57 --> Total execution time: 0.0397
DEBUG - 2021-11-23 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:24:58 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:24:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:24:58 --> Total execution time: 0.0522
DEBUG - 2021-11-23 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:24:58 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:24:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:24:58 --> Total execution time: 0.0479
DEBUG - 2021-11-23 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:24:58 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:24:58 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:24:58 --> Total execution time: 0.0443
DEBUG - 2021-11-23 09:25:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:25:35 --> Severity: Notice --> Undefined variable: join4table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:25:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:25:35 --> Total execution time: 0.0472
DEBUG - 2021-11-23 09:25:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:25:36 --> Severity: Notice --> Undefined variable: join4table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:25:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:25:36 --> Total execution time: 0.0396
DEBUG - 2021-11-23 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:26:14 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:26:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:26:14 --> Total execution time: 0.0415
DEBUG - 2021-11-23 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:26:14 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:26:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:26:14 --> Total execution time: 0.0490
DEBUG - 2021-11-23 09:26:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:26:14 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:26:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:26:14 --> Total execution time: 0.0306
DEBUG - 2021-11-23 09:35:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:35:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:35:00 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:35:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:35:00 --> Total execution time: 0.0493
DEBUG - 2021-11-23 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:35:01 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:35:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:35:01 --> Total execution time: 0.0283
DEBUG - 2021-11-23 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:35:01 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:35:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:35:01 --> Total execution time: 0.0407
DEBUG - 2021-11-23 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:35:01 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:35:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:35:01 --> Total execution time: 0.0478
DEBUG - 2021-11-23 09:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:35:01 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 281
ERROR - 2021-11-23 09:35:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 281
DEBUG - 2021-11-23 09:35:01 --> Total execution time: 0.0482
DEBUG - 2021-11-23 09:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:40:40 --> Severity: Notice --> Undefined index: id_package C:\xampp\htdocs\nesnu\application\views\package\index.php 286
ERROR - 2021-11-23 09:40:40 --> Severity: Notice --> Undefined index: id_package C:\xampp\htdocs\nesnu\application\views\package\index.php 286
DEBUG - 2021-11-23 09:40:40 --> Total execution time: 0.0541
DEBUG - 2021-11-23 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:40:41 --> Severity: Notice --> Undefined index: id_package C:\xampp\htdocs\nesnu\application\views\package\index.php 286
ERROR - 2021-11-23 09:40:41 --> Severity: Notice --> Undefined index: id_package C:\xampp\htdocs\nesnu\application\views\package\index.php 286
DEBUG - 2021-11-23 09:40:41 --> Total execution time: 0.0288
DEBUG - 2021-11-23 09:40:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:40:41 --> Severity: Notice --> Undefined index: id_package C:\xampp\htdocs\nesnu\application\views\package\index.php 286
ERROR - 2021-11-23 09:40:41 --> Severity: Notice --> Undefined index: id_package C:\xampp\htdocs\nesnu\application\views\package\index.php 286
DEBUG - 2021-11-23 09:40:41 --> Total execution time: 0.0480
DEBUG - 2021-11-23 09:52:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:52:16 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 291
ERROR - 2021-11-23 09:52:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 291
DEBUG - 2021-11-23 09:52:16 --> Total execution time: 0.0305
DEBUG - 2021-11-23 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:54:14 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 291
ERROR - 2021-11-23 09:54:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 291
DEBUG - 2021-11-23 09:54:14 --> Total execution time: 0.0298
DEBUG - 2021-11-23 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:54:14 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 291
ERROR - 2021-11-23 09:54:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 291
DEBUG - 2021-11-23 09:54:14 --> Total execution time: 0.0285
DEBUG - 2021-11-23 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:54:14 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 291
ERROR - 2021-11-23 09:54:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 291
DEBUG - 2021-11-23 09:54:14 --> Total execution time: 0.0513
DEBUG - 2021-11-23 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:54:14 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 291
ERROR - 2021-11-23 09:54:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 291
DEBUG - 2021-11-23 09:54:14 --> Total execution time: 0.0303
DEBUG - 2021-11-23 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:54:15 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 291
ERROR - 2021-11-23 09:54:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 291
DEBUG - 2021-11-23 09:54:15 --> Total execution time: 0.0459
DEBUG - 2021-11-23 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:54:15 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 291
ERROR - 2021-11-23 09:54:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 291
DEBUG - 2021-11-23 09:54:15 --> Total execution time: 0.0431
DEBUG - 2021-11-23 09:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 09:55:03 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 287
ERROR - 2021-11-23 09:55:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 287
DEBUG - 2021-11-23 09:55:03 --> Total execution time: 0.0390
DEBUG - 2021-11-23 09:56:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 09:56:54 --> Total execution time: 0.0402
DEBUG - 2021-11-23 09:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 09:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 09:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-23 09:58:44 --> Total execution time: 0.0398
DEBUG - 2021-11-23 10:00:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 10:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 10:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 10:00:27 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 239
ERROR - 2021-11-23 10:00:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 239
ERROR - 2021-11-23 10:00:27 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 330
ERROR - 2021-11-23 10:00:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 330
DEBUG - 2021-11-23 10:00:27 --> Total execution time: 0.0512
DEBUG - 2021-11-23 10:01:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 10:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 10:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 10:01:25 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 232
ERROR - 2021-11-23 10:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 232
ERROR - 2021-11-23 10:01:25 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 330
ERROR - 2021-11-23 10:01:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 330
DEBUG - 2021-11-23 10:01:25 --> Total execution time: 0.0487
DEBUG - 2021-11-23 10:01:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 10:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 10:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 10:01:57 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 243
ERROR - 2021-11-23 10:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 243
ERROR - 2021-11-23 10:01:57 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 330
ERROR - 2021-11-23 10:01:57 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 330
DEBUG - 2021-11-23 10:01:57 --> Total execution time: 0.0324
DEBUG - 2021-11-23 10:12:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-23 10:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-23 10:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-23 10:12:11 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 243
ERROR - 2021-11-23 10:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 243
ERROR - 2021-11-23 10:12:11 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 330
ERROR - 2021-11-23 10:12:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 330
DEBUG - 2021-11-23 10:12:11 --> Total execution time: 0.0545
