<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-12 07:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-12 07:32:58 --> No URI present. Default controller set.
DEBUG - 2022-04-12 07:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-12 07:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-12 07:32:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-12 07:32:58 --> Total execution time: 0.0682
DEBUG - 2022-04-12 09:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-12 09:50:47 --> No URI present. Default controller set.
DEBUG - 2022-04-12 09:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-12 09:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-12 09:50:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-12 09:50:47 --> Total execution time: 0.0405
DEBUG - 2022-04-12 17:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-12 17:32:41 --> No URI present. Default controller set.
DEBUG - 2022-04-12 17:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-12 17:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-12 17:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-12 17:32:41 --> Total execution time: 0.0404
DEBUG - 2022-04-12 17:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-12 17:32:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-12 17:32:42 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-12 17:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-12 17:32:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-12 17:32:42 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-12 17:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-12 17:32:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-12 17:32:42 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-12 17:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-12 17:32:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-12 17:32:42 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-12 17:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-12 17:32:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-12 17:32:42 --> 404 Page Not Found: Assets/https:
