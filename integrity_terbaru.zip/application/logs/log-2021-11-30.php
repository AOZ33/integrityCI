<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-30 04:38:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:38:27 --> No URI present. Default controller set.
DEBUG - 2021-11-30 04:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:38:27 --> Total execution time: 0.4431
DEBUG - 2021-11-30 04:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:38:29 --> Total execution time: 0.0879
DEBUG - 2021-11-30 04:38:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:38:45 --> Total execution time: 0.1021
DEBUG - 2021-11-30 04:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:38:57 --> Total execution time: 0.0536
DEBUG - 2021-11-30 04:38:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:38:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 04:38:58 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 04:38:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 04:38:58 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 04:38:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 04:38:58 --> Total execution time: 0.1208
DEBUG - 2021-11-30 04:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:38:59 --> Total execution time: 0.0492
DEBUG - 2021-11-30 04:39:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:39:00 --> Total execution time: 0.0481
DEBUG - 2021-11-30 04:39:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 04:39:01 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 04:39:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 04:39:01 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 04:39:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 04:39:01 --> Total execution time: 0.0546
DEBUG - 2021-11-30 04:39:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:39:05 --> Total execution time: 0.0287
DEBUG - 2021-11-30 04:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:39:06 --> Total execution time: 0.0273
DEBUG - 2021-11-30 04:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:39:32 --> Total execution time: 0.0439
DEBUG - 2021-11-30 04:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:39:34 --> Total execution time: 0.0398
DEBUG - 2021-11-30 04:39:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:39:59 --> Total execution time: 0.0469
DEBUG - 2021-11-30 04:44:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:44:18 --> No URI present. Default controller set.
DEBUG - 2021-11-30 04:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:44:18 --> Total execution time: 0.0336
DEBUG - 2021-11-30 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:44:20 --> Total execution time: 0.0387
DEBUG - 2021-11-30 04:44:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 04:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 04:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 04:44:21 --> Total execution time: 0.0276
DEBUG - 2021-11-30 05:22:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:22:31 --> Total execution time: 0.0551
DEBUG - 2021-11-30 05:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 05:22:50 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1471
ERROR - 2021-11-30 05:22:50 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `detail`, `more`, `price`, `date`, `place`) VALUES ('Reza', 'After ', 'Paket 1', Array, 'Box', 'dasdasdasd', 'Rp. 12.332.424', '2021-11-17', 'Braga')
DEBUG - 2021-11-30 05:23:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 05:23:23 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1471
ERROR - 2021-11-30 05:23:23 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `detail`, `more`, `price`, `date`, `place`) VALUES ('Reza', 'After ', 'Paket 1', Array, 'Box', 'dasdasdasd', 'Rp. 12.332.424', '2021-11-17', 'Braga')
DEBUG - 2021-11-30 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:23:25 --> Total execution time: 0.0477
DEBUG - 2021-11-30 05:26:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:26:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-30 05:26:25 --> Severity: error --> Exception: Unclosed '{' on line 5 C:\xampp\htdocs\nesnu\application\controllers\appointment.php 49
DEBUG - 2021-11-30 05:26:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-30 05:26:26 --> Severity: error --> Exception: Unclosed '{' on line 5 C:\xampp\htdocs\nesnu\application\controllers\appointment.php 49
DEBUG - 2021-11-30 05:26:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-30 05:26:27 --> Severity: error --> Exception: Unclosed '{' on line 5 C:\xampp\htdocs\nesnu\application\controllers\appointment.php 49
DEBUG - 2021-11-30 05:26:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:26:56 --> Total execution time: 0.0372
DEBUG - 2021-11-30 05:27:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:27:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:27:09 --> Total execution time: 0.0395
DEBUG - 2021-11-30 05:36:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:36:43 --> Total execution time: 0.0514
DEBUG - 2021-11-30 05:38:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:38:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:38:13 --> Total execution time: 0.0288
DEBUG - 2021-11-30 05:39:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:39:49 --> Total execution time: 0.0294
DEBUG - 2021-11-30 05:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 05:40:01 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1471
ERROR - 2021-11-30 05:40:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES ('Prewedding, Pegajian & Siraman, Akad & Resepsi', Array)' at line 1 - Invalid query: INSERT INTO `appointment` (`description`, 0) VALUES ('Prewedding, Pegajian & Siraman, Akad & Resepsi', Array)
DEBUG - 2021-11-30 05:40:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:40:05 --> Total execution time: 0.0688
DEBUG - 2021-11-30 05:40:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 05:40:08 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1471
ERROR - 2021-11-30 05:40:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '0) VALUES ('Prewedding, Pegajian & Siraman, Akad & Resepsi', Array)' at line 1 - Invalid query: INSERT INTO `appointment` (`description`, 0) VALUES ('Prewedding, Pegajian & Siraman, Akad & Resepsi', Array)
DEBUG - 2021-11-30 05:40:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:40:10 --> Total execution time: 0.0387
DEBUG - 2021-11-30 05:47:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:47:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:47:30 --> Total execution time: 0.0375
DEBUG - 2021-11-30 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:48:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:48:16 --> Total execution time: 0.0424
DEBUG - 2021-11-30 05:50:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:50:53 --> Total execution time: 0.0513
DEBUG - 2021-11-30 05:51:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:51:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:51:08 --> Total execution time: 0.0282
DEBUG - 2021-11-30 05:55:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:55:45 --> Total execution time: 0.0525
DEBUG - 2021-11-30 05:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:56:05 --> Total execution time: 0.0397
DEBUG - 2021-11-30 05:56:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:56:18 --> Total execution time: 0.0488
DEBUG - 2021-11-30 05:57:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:57:11 --> Total execution time: 0.0512
DEBUG - 2021-11-30 05:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:57:26 --> Total execution time: 0.0512
DEBUG - 2021-11-30 05:57:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:57:36 --> Total execution time: 0.0530
DEBUG - 2021-11-30 05:57:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:57:37 --> Total execution time: 0.0385
DEBUG - 2021-11-30 05:57:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:57:38 --> Total execution time: 0.0633
DEBUG - 2021-11-30 05:57:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:57:38 --> Total execution time: 0.0416
DEBUG - 2021-11-30 05:57:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 05:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 05:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 05:57:52 --> Total execution time: 0.0388
DEBUG - 2021-11-30 06:03:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:03:54 --> Total execution time: 0.0308
DEBUG - 2021-11-30 06:04:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:04:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:04:30 --> Total execution time: 0.0468
DEBUG - 2021-11-30 06:04:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:04:44 --> Total execution time: 0.0481
DEBUG - 2021-11-30 06:04:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:04:50 --> Total execution time: 0.0429
DEBUG - 2021-11-30 06:05:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:05:18 --> Total execution time: 0.0405
DEBUG - 2021-11-30 06:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:05:19 --> Total execution time: 0.0473
DEBUG - 2021-11-30 06:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:05:33 --> Total execution time: 0.0416
DEBUG - 2021-11-30 06:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:06:04 --> Total execution time: 0.0514
DEBUG - 2021-11-30 06:06:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:06:12 --> Total execution time: 0.0412
DEBUG - 2021-11-30 06:06:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:06:13 --> Total execution time: 0.0394
DEBUG - 2021-11-30 06:06:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:06:22 --> Total execution time: 0.0466
DEBUG - 2021-11-30 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:30:59 --> Total execution time: 0.0524
DEBUG - 2021-11-30 06:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:33:12 --> Total execution time: 0.0319
DEBUG - 2021-11-30 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:33:47 --> Total execution time: 0.0430
DEBUG - 2021-11-30 06:33:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:33:48 --> Total execution time: 0.0286
DEBUG - 2021-11-30 06:34:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:34:35 --> Total execution time: 0.0554
DEBUG - 2021-11-30 06:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:35:10 --> Total execution time: 0.0415
DEBUG - 2021-11-30 06:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:35:39 --> Total execution time: 0.0417
DEBUG - 2021-11-30 06:35:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:35:47 --> Total execution time: 0.0404
DEBUG - 2021-11-30 06:35:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:35:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-30 06:35:53 --> 404 Page Not Found: Appointment/hapus_data
DEBUG - 2021-11-30 06:35:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:35:55 --> Total execution time: 0.0523
DEBUG - 2021-11-30 06:36:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 06:36:03 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 06:36:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 06:36:03 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 06:36:03 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 06:36:03 --> Total execution time: 0.0491
DEBUG - 2021-11-30 06:36:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 06:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 06:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 06:36:05 --> Total execution time: 0.0498
DEBUG - 2021-11-30 07:39:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:39:17 --> Total execution time: 0.0564
DEBUG - 2021-11-30 07:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:39:37 --> Total execution time: 0.0455
DEBUG - 2021-11-30 07:39:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:39:57 --> Total execution time: 0.0487
DEBUG - 2021-11-30 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:40:07 --> Total execution time: 0.0292
DEBUG - 2021-11-30 07:41:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:41:02 --> Total execution time: 0.0500
DEBUG - 2021-11-30 07:41:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:41:43 --> Total execution time: 0.0310
DEBUG - 2021-11-30 07:42:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:42:37 --> Total execution time: 0.0324
DEBUG - 2021-11-30 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:44:31 --> Total execution time: 0.0505
DEBUG - 2021-11-30 07:45:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:45:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:45:01 --> Total execution time: 0.0456
DEBUG - 2021-11-30 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:45:17 --> Total execution time: 0.0487
DEBUG - 2021-11-30 07:45:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:45:26 --> Total execution time: 0.0411
DEBUG - 2021-11-30 07:45:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:45:27 --> Total execution time: 0.0528
DEBUG - 2021-11-30 07:45:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:45:36 --> Total execution time: 0.0532
DEBUG - 2021-11-30 07:45:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:45:44 --> Total execution time: 0.0372
DEBUG - 2021-11-30 07:45:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:45:51 --> Total execution time: 0.0468
DEBUG - 2021-11-30 07:45:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:45:57 --> Total execution time: 0.0425
DEBUG - 2021-11-30 07:48:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:48:02 --> Total execution time: 0.0291
DEBUG - 2021-11-30 07:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:48:14 --> Total execution time: 0.0292
DEBUG - 2021-11-30 07:48:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:48:15 --> Total execution time: 0.0282
DEBUG - 2021-11-30 07:48:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:48:25 --> Total execution time: 0.0520
DEBUG - 2021-11-30 07:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:49:16 --> Total execution time: 0.0463
DEBUG - 2021-11-30 07:49:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:49:51 --> Total execution time: 0.0533
DEBUG - 2021-11-30 07:49:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:49:51 --> Total execution time: 0.0448
DEBUG - 2021-11-30 07:49:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:49:55 --> Total execution time: 0.0472
DEBUG - 2021-11-30 07:50:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:50:17 --> Total execution time: 0.0494
DEBUG - 2021-11-30 07:50:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:50:34 --> Total execution time: 0.0528
DEBUG - 2021-11-30 07:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:50:45 --> Total execution time: 0.0615
DEBUG - 2021-11-30 07:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:50:56 --> Total execution time: 0.0501
DEBUG - 2021-11-30 07:51:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:51:28 --> Total execution time: 0.0483
DEBUG - 2021-11-30 07:51:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:51:35 --> Total execution time: 0.0396
DEBUG - 2021-11-30 07:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:52:41 --> Total execution time: 0.0452
DEBUG - 2021-11-30 07:52:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:52:52 --> Total execution time: 0.0478
DEBUG - 2021-11-30 07:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:53:32 --> Total execution time: 0.0512
DEBUG - 2021-11-30 07:53:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:53:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:53:58 --> Total execution time: 0.0516
DEBUG - 2021-11-30 07:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:54:19 --> Total execution time: 0.0392
DEBUG - 2021-11-30 07:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:55:04 --> Total execution time: 0.0524
DEBUG - 2021-11-30 07:56:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:56:09 --> Total execution time: 0.0464
DEBUG - 2021-11-30 07:56:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:56:41 --> Total execution time: 0.0456
DEBUG - 2021-11-30 07:56:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 07:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 07:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 07:56:54 --> Total execution time: 0.0447
DEBUG - 2021-11-30 08:10:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:10:14 --> Total execution time: 0.0481
DEBUG - 2021-11-30 08:10:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:10:53 --> Total execution time: 0.0446
DEBUG - 2021-11-30 08:11:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:02 --> Total execution time: 0.0469
DEBUG - 2021-11-30 08:11:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:02 --> Total execution time: 0.0522
DEBUG - 2021-11-30 08:11:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:15 --> Total execution time: 0.0277
DEBUG - 2021-11-30 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:22 --> Total execution time: 0.0438
DEBUG - 2021-11-30 08:11:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:23 --> Total execution time: 0.0412
DEBUG - 2021-11-30 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:29 --> Total execution time: 0.0448
DEBUG - 2021-11-30 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:29 --> Total execution time: 0.0413
DEBUG - 2021-11-30 08:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:29 --> Total execution time: 0.0278
DEBUG - 2021-11-30 08:11:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:30 --> Total execution time: 0.0387
DEBUG - 2021-11-30 08:11:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:39 --> Total execution time: 0.0394
DEBUG - 2021-11-30 08:11:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:11:40 --> Total execution time: 0.0446
DEBUG - 2021-11-30 08:12:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:12:08 --> Total execution time: 0.0729
DEBUG - 2021-11-30 08:12:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:12:31 --> Total execution time: 0.0423
DEBUG - 2021-11-30 08:12:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:12:55 --> Total execution time: 0.0461
DEBUG - 2021-11-30 08:13:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:13:23 --> Total execution time: 0.0518
DEBUG - 2021-11-30 08:13:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:13:33 --> Total execution time: 0.0523
DEBUG - 2021-11-30 08:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:19:16 --> Total execution time: 0.0499
DEBUG - 2021-11-30 08:23:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:23:01 --> Total execution time: 0.0280
DEBUG - 2021-11-30 08:23:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:23:43 --> Total execution time: 0.0530
DEBUG - 2021-11-30 08:24:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:24:11 --> Total execution time: 0.0494
DEBUG - 2021-11-30 08:24:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:24:26 --> Total execution time: 0.0469
DEBUG - 2021-11-30 08:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:24:43 --> Total execution time: 0.0383
DEBUG - 2021-11-30 08:24:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:24:58 --> Total execution time: 0.0522
DEBUG - 2021-11-30 08:25:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:25:18 --> Total execution time: 0.0440
DEBUG - 2021-11-30 08:25:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:25:34 --> Total execution time: 0.0467
DEBUG - 2021-11-30 08:26:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:26:33 --> Total execution time: 0.0481
DEBUG - 2021-11-30 08:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:26:40 --> Total execution time: 0.0459
DEBUG - 2021-11-30 08:26:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:26:41 --> Total execution time: 0.0438
DEBUG - 2021-11-30 08:26:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:26:41 --> Total execution time: 0.0439
DEBUG - 2021-11-30 08:26:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:26:50 --> Total execution time: 0.0432
DEBUG - 2021-11-30 08:27:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:27:20 --> Total execution time: 0.0382
DEBUG - 2021-11-30 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:27:32 --> Total execution time: 0.0501
DEBUG - 2021-11-30 08:27:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:27:38 --> Total execution time: 0.0372
DEBUG - 2021-11-30 08:27:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:27:44 --> Total execution time: 0.0269
DEBUG - 2021-11-30 08:27:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:27:50 --> Total execution time: 0.0455
DEBUG - 2021-11-30 08:28:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:28:39 --> Total execution time: 0.0411
DEBUG - 2021-11-30 08:28:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:28:52 --> Total execution time: 0.0441
DEBUG - 2021-11-30 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:29:10 --> Total execution time: 0.0368
DEBUG - 2021-11-30 08:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:29:18 --> Total execution time: 0.0634
DEBUG - 2021-11-30 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:29:29 --> Total execution time: 0.0301
DEBUG - 2021-11-30 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:29:29 --> Total execution time: 0.0469
DEBUG - 2021-11-30 08:29:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:29:29 --> Total execution time: 0.0446
DEBUG - 2021-11-30 08:29:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:29:42 --> Total execution time: 0.0428
DEBUG - 2021-11-30 08:36:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:36:04 --> Total execution time: 0.0402
DEBUG - 2021-11-30 08:42:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:42:18 --> Total execution time: 0.0511
DEBUG - 2021-11-30 08:42:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:42:44 --> Total execution time: 0.0481
DEBUG - 2021-11-30 08:42:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:42:58 --> Total execution time: 0.0525
DEBUG - 2021-11-30 08:44:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:44:37 --> Total execution time: 0.0440
DEBUG - 2021-11-30 08:44:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:44:51 --> Total execution time: 0.0465
DEBUG - 2021-11-30 08:45:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:45:22 --> Total execution time: 0.0381
DEBUG - 2021-11-30 08:45:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:45:29 --> Total execution time: 0.0524
DEBUG - 2021-11-30 08:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:46:13 --> Total execution time: 0.0477
DEBUG - 2021-11-30 08:46:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:46:40 --> Total execution time: 0.0417
DEBUG - 2021-11-30 08:47:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:47:02 --> Total execution time: 0.0526
DEBUG - 2021-11-30 08:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:56:40 --> Total execution time: 0.0427
DEBUG - 2021-11-30 08:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-30 08:56:44 --> 404 Page Not Found: Appointment/hapus_data
DEBUG - 2021-11-30 08:56:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:56:47 --> Total execution time: 0.0464
DEBUG - 2021-11-30 08:57:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:57:08 --> Total execution time: 0.0392
DEBUG - 2021-11-30 08:57:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 08:57:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 08:57:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 08:57:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 08:57:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 08:57:09 --> Total execution time: 0.0480
DEBUG - 2021-11-30 08:57:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 08:57:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 08:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 08:57:13 --> Total execution time: 0.0403
DEBUG - 2021-11-30 09:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:01:44 --> Total execution time: 0.0439
DEBUG - 2021-11-30 09:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:01:49 --> Total execution time: 0.0505
DEBUG - 2021-11-30 09:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:03:06 --> Total execution time: 0.0419
DEBUG - 2021-11-30 09:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:05:49 --> Total execution time: 0.0477
DEBUG - 2021-11-30 09:05:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:05:59 --> Total execution time: 0.0400
DEBUG - 2021-11-30 09:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:06:01 --> Total execution time: 0.0445
DEBUG - 2021-11-30 09:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:06:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:06:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:06:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:06:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:06:04 --> Total execution time: 0.0412
DEBUG - 2021-11-30 09:06:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:06:10 --> Total execution time: 0.0288
DEBUG - 2021-11-30 09:08:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:08:37 --> Total execution time: 0.0401
DEBUG - 2021-11-30 09:08:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:08:43 --> Total execution time: 0.0414
DEBUG - 2021-11-30 09:08:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:08:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:08:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:08:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:08:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:08:46 --> Total execution time: 0.0537
DEBUG - 2021-11-30 09:08:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:08:47 --> Total execution time: 0.0414
DEBUG - 2021-11-30 09:12:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:12:31 --> Total execution time: 0.0523
DEBUG - 2021-11-30 09:12:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:12:32 --> Total execution time: 0.0446
DEBUG - 2021-11-30 09:14:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:14:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:14:22 --> Total execution time: 0.0571
DEBUG - 2021-11-30 09:15:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:15:22 --> Total execution time: 0.0404
DEBUG - 2021-11-30 09:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:15:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:15:36 --> Total execution time: 0.0440
DEBUG - 2021-11-30 09:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:15:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:15:38 --> Total execution time: 0.0652
DEBUG - 2021-11-30 09:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:15:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:15:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:15:39 --> Total execution time: 0.0411
DEBUG - 2021-11-30 09:15:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:15:47 --> Total execution time: 0.0374
DEBUG - 2021-11-30 09:16:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:16:52 --> Total execution time: 0.0278
DEBUG - 2021-11-30 09:16:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:16:53 --> Total execution time: 0.0467
DEBUG - 2021-11-30 09:17:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:17:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:17:17 --> Total execution time: 0.0487
DEBUG - 2021-11-30 09:17:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:17:18 --> Total execution time: 0.0399
DEBUG - 2021-11-30 09:17:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:17:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:17:18 --> Total execution time: 0.0550
DEBUG - 2021-11-30 09:17:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:17:19 --> Total execution time: 0.0490
DEBUG - 2021-11-30 09:17:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:17:20 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:20 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:17:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:17:20 --> Total execution time: 0.0523
DEBUG - 2021-11-30 09:18:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:18:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:18:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:18:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:18:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:18:04 --> Total execution time: 0.0538
DEBUG - 2021-11-30 09:18:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:18:05 --> Total execution time: 0.0479
DEBUG - 2021-11-30 09:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:18:50 --> Total execution time: 0.0526
DEBUG - 2021-11-30 09:18:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:18:51 --> Total execution time: 0.0454
DEBUG - 2021-11-30 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:18:52 --> Total execution time: 0.0483
DEBUG - 2021-11-30 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:18:52 --> Total execution time: 0.0528
DEBUG - 2021-11-30 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:18:52 --> Total execution time: 0.0383
DEBUG - 2021-11-30 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:18:52 --> Total execution time: 0.0404
DEBUG - 2021-11-30 09:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:18:53 --> Total execution time: 0.0384
DEBUG - 2021-11-30 09:19:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:19:15 --> Total execution time: 0.0471
DEBUG - 2021-11-30 09:20:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:20:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:20:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:20:09 --> Total execution time: 0.0447
DEBUG - 2021-11-30 09:20:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:20:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-30 09:20:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-30 09:20:10 --> Total execution time: 0.0438
DEBUG - 2021-11-30 09:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:20:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:20:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:20:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:20:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:20:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:20:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-11-30 09:20:35 --> Total execution time: 0.0504
DEBUG - 2021-11-30 09:20:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:20:39 --> Total execution time: 0.0515
DEBUG - 2021-11-30 09:20:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:20:40 --> Total execution time: 0.0457
DEBUG - 2021-11-30 09:21:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:21:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-30 09:21:24 --> 404 Page Not Found: Appointment/hapus_data
DEBUG - 2021-11-30 09:21:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:21:55 --> Total execution time: 0.0284
DEBUG - 2021-11-30 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:21:56 --> Total execution time: 0.0474
DEBUG - 2021-11-30 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:21:58 --> Total execution time: 0.0402
DEBUG - 2021-11-30 09:22:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:22:00 --> Total execution time: 0.0378
DEBUG - 2021-11-30 09:25:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:25:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:25:43 --> Total execution time: 0.0415
DEBUG - 2021-11-30 09:27:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:27:33 --> Total execution time: 0.0464
DEBUG - 2021-11-30 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:27:39 --> Total execution time: 0.0287
DEBUG - 2021-11-30 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:29:02 --> Total execution time: 0.0443
DEBUG - 2021-11-30 09:29:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:29:56 --> Total execution time: 0.0520
DEBUG - 2021-11-30 09:30:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:30:00 --> Total execution time: 0.0419
DEBUG - 2021-11-30 09:30:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:30:03 --> Total execution time: 0.0410
DEBUG - 2021-11-30 09:30:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:30:19 --> Total execution time: 0.0439
DEBUG - 2021-11-30 09:33:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:33:22 --> Total execution time: 0.0419
DEBUG - 2021-11-30 09:34:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:34:14 --> Total execution time: 0.0499
DEBUG - 2021-11-30 09:34:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:34:14 --> Total execution time: 0.0483
DEBUG - 2021-11-30 09:34:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:34:57 --> Total execution time: 0.0424
DEBUG - 2021-11-30 09:35:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:35:54 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
DEBUG - 2021-11-30 09:35:54 --> Total execution time: 0.0343
DEBUG - 2021-11-30 09:36:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:36:25 --> Severity: Warning --> Undefined variable $tambahan C:\xampp\htdocs\nesnu\application\views\data\index.php 171
DEBUG - 2021-11-30 09:36:25 --> Total execution time: 0.0528
DEBUG - 2021-11-30 09:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
ERROR - 2021-11-30 09:37:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 171
DEBUG - 2021-11-30 09:37:59 --> Total execution time: 0.0577
DEBUG - 2021-11-30 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:40:29 --> Total execution time: 0.0314
DEBUG - 2021-11-30 09:41:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 09:41:33 --> Total execution time: 0.0382
DEBUG - 2021-11-30 09:41:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:41:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:41:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:41:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:41:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:41:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 09:41:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-11-30 09:41:56 --> Total execution time: 0.0481
DEBUG - 2021-11-30 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 09:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 09:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 09:48:35 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 37
ERROR - 2021-11-30 09:48:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 37
DEBUG - 2021-11-30 09:48:35 --> Total execution time: 0.0318
DEBUG - 2021-11-30 10:05:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 10:05:15 --> Severity: Warning --> Undefined property: Appointment::$Client_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 17
ERROR - 2021-11-30 10:05:15 --> Severity: error --> Exception: Call to a member function getAllClientById() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 17
DEBUG - 2021-11-30 10:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 10:05:20 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:20 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:20 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-11-30 10:05:20 --> Total execution time: 0.0315
DEBUG - 2021-11-30 10:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 10:05:21 --> Severity: Warning --> Undefined property: Appointment::$Client_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 17
ERROR - 2021-11-30 10:05:21 --> Severity: error --> Exception: Call to a member function getAllClientById() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 17
DEBUG - 2021-11-30 10:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 10:05:38 --> Total execution time: 0.0485
DEBUG - 2021-11-30 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 10:05:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-11-30 10:05:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-11-30 10:05:48 --> Total execution time: 0.0491
DEBUG - 2021-11-30 10:06:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 10:06:29 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:06:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:06:29 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:06:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:06:29 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:06:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-11-30 10:06:29 --> Total execution time: 0.0462
DEBUG - 2021-11-30 10:13:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 10:13:51 --> Total execution time: 0.0502
DEBUG - 2021-11-30 10:13:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 10:13:52 --> Total execution time: 0.0429
DEBUG - 2021-11-30 10:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 10:13:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-11-30 10:13:54 --> Total execution time: 0.0400
DEBUG - 2021-11-30 10:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 10:13:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:13:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-11-30 10:13:55 --> Total execution time: 0.0512
DEBUG - 2021-11-30 10:13:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 10:13:56 --> Total execution time: 0.0416
DEBUG - 2021-11-30 10:14:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-30 10:14:00 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:14:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:14:00 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:14:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:14:00 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-11-30 10:14:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-11-30 10:14:00 --> Total execution time: 0.0566
DEBUG - 2021-11-30 10:14:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-30 10:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-30 10:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-30 10:14:02 --> Total execution time: 0.0452
