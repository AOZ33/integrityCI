<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-06 19:36:50 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-06 19:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-06 19:36:50 --> No URI present. Default controller set.
DEBUG - 2022-03-06 19:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-06 19:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-06 19:36:50 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-06 19:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-06 19:36:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-06 19:36:50 --> Total execution time: 0.0306
DEBUG - 2022-03-06 19:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-06 19:36:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-06 19:36:50 --> 404 Page Not Found: Assets/https:
