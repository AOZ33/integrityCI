<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-08 15:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 15:55:44 --> No URI present. Default controller set.
DEBUG - 2022-05-08 15:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 15:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-08 15:55:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-08 15:55:44 --> Total execution time: 0.0510
DEBUG - 2022-05-08 16:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-08 16:36:25 --> No URI present. Default controller set.
DEBUG - 2022-05-08 16:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-08 16:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-08 16:36:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-08 16:36:25 --> Total execution time: 0.0442
