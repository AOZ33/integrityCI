<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-08 09:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:34:22 --> No URI present. Default controller set.
DEBUG - 2022-02-08 09:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:34:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:34:22 --> Total execution time: 0.0304
DEBUG - 2022-02-08 09:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:34:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-08 09:34:22 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-08 09:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:34:22 --> No URI present. Default controller set.
DEBUG - 2022-02-08 09:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:34:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:34:22 --> Total execution time: 0.0033
DEBUG - 2022-02-08 09:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:52:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:52:04 --> Total execution time: 0.0057
DEBUG - 2022-02-08 09:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:52:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-08 09:52:10 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 164070208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-08 09:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:54:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:54:19 --> Total execution time: 40.7754
DEBUG - 2022-02-08 09:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:54:21 --> No URI present. Default controller set.
DEBUG - 2022-02-08 09:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:54:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:54:21 --> Total execution time: 0.0039
DEBUG - 2022-02-08 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-08 09:54:22 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-08 09:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:54:22 --> No URI present. Default controller set.
DEBUG - 2022-02-08 09:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:54:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:54:22 --> Total execution time: 0.0032
DEBUG - 2022-02-08 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:54:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:54:29 --> Total execution time: 0.0033
DEBUG - 2022-02-08 09:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:54:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-08 09:54:37 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 164070208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-08 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 09:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 09:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 09:55:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 09:55:14 --> Total execution time: 5.8498
DEBUG - 2022-02-08 10:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 10:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 10:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 10:28:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 10:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 10:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 10:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 10:28:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 10:28:54 --> Total execution time: 0.0063
DEBUG - 2022-02-08 10:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 10:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 10:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 10:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 10:38:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 10:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 10:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 10:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 10:38:28 --> Total execution time: 0.0059
DEBUG - 2022-02-08 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 10:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 10:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 10:46:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 10:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 10:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 10:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 10:46:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 10:46:28 --> Total execution time: 0.0058
DEBUG - 2022-02-08 10:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 10:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 10:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 10:54:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 10:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 10:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 10:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 10:54:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 10:54:36 --> Total execution time: 0.0060
DEBUG - 2022-02-08 11:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:05:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:05:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:05:40 --> Total execution time: 0.0064
DEBUG - 2022-02-08 11:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:09:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:09:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:09:59 --> Total execution time: 0.0053
DEBUG - 2022-02-08 11:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:14:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:14:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:14:27 --> Total execution time: 0.0061
DEBUG - 2022-02-08 11:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:15:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:15:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:15:40 --> Total execution time: 0.0048
DEBUG - 2022-02-08 11:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:18:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:18:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:18:07 --> Total execution time: 0.0048
DEBUG - 2022-02-08 11:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:21:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:21:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:21:44 --> Total execution time: 0.0059
DEBUG - 2022-02-08 11:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:29:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:29:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:29:37 --> Total execution time: 0.0054
DEBUG - 2022-02-08 11:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:32:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:32:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:32:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:32:08 --> Total execution time: 0.0048
DEBUG - 2022-02-08 11:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:34:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:34:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:34:56 --> Total execution time: 0.0045
DEBUG - 2022-02-08 11:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:38:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:38:12 --> Total execution time: 0.0055
DEBUG - 2022-02-08 11:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:43:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:43:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:43:44 --> Total execution time: 0.0058
DEBUG - 2022-02-08 11:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:46:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:46:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:46:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:46:32 --> Total execution time: 0.0065
DEBUG - 2022-02-08 11:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:58:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:58:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 11:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 11:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 11:58:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 11:58:11 --> Total execution time: 0.0064
DEBUG - 2022-02-08 12:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:03:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:03:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:03:24 --> Total execution time: 0.0060
DEBUG - 2022-02-08 12:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:06:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:06:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:06:22 --> Total execution time: 0.0044
DEBUG - 2022-02-08 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:07:18 --> No URI present. Default controller set.
DEBUG - 2022-02-08 12:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:07:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:07:18 --> Total execution time: 0.0045
DEBUG - 2022-02-08 12:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:07:18 --> No URI present. Default controller set.
DEBUG - 2022-02-08 12:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:07:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:07:18 --> Total execution time: 0.0038
DEBUG - 2022-02-08 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:07:19 --> No URI present. Default controller set.
DEBUG - 2022-02-08 12:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:07:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:07:19 --> Total execution time: 0.0035
DEBUG - 2022-02-08 12:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:07:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-08 12:07:19 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-02-08 12:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:11:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:11:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:11:23 --> Total execution time: 0.0058
DEBUG - 2022-02-08 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:14:18 --> No URI present. Default controller set.
DEBUG - 2022-02-08 12:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:14:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:14:18 --> Total execution time: 0.0308
DEBUG - 2022-02-08 12:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:14:18 --> No URI present. Default controller set.
DEBUG - 2022-02-08 12:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:14:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:14:18 --> Total execution time: 0.0039
DEBUG - 2022-02-08 12:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:14:19 --> No URI present. Default controller set.
DEBUG - 2022-02-08 12:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 12:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 12:14:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 12:14:19 --> Total execution time: 0.0035
DEBUG - 2022-02-08 12:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 12:14:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-08 12:14:19 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-02-08 13:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:28:24 --> Total execution time: 0.0073
DEBUG - 2022-02-08 13:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:30:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:30:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:30:04 --> Total execution time: 0.0050
DEBUG - 2022-02-08 13:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:33:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:33:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:33:15 --> Total execution time: 0.0051
DEBUG - 2022-02-08 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:36:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:36:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:36:47 --> Total execution time: 0.0054
DEBUG - 2022-02-08 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:41:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:41:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:41:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:41:45 --> Total execution time: 0.0058
DEBUG - 2022-02-08 13:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:48:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:48:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:48:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:48:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:48:09 --> Total execution time: 0.0060
DEBUG - 2022-02-08 13:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:56:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:56:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:56:31 --> Total execution time: 0.0057
DEBUG - 2022-02-08 13:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:59:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 13:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 13:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 13:59:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 13:59:57 --> Total execution time: 0.0053
DEBUG - 2022-02-08 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:05:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:05:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:05:08 --> Total execution time: 0.0045
DEBUG - 2022-02-08 14:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:09:47 --> No URI present. Default controller set.
DEBUG - 2022-02-08 14:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:09:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:09:47 --> Total execution time: 0.0301
DEBUG - 2022-02-08 14:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:22:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:22:38 --> Total execution time: 0.0060
DEBUG - 2022-02-08 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:27:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:27:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:27:41 --> Total execution time: 0.0046
DEBUG - 2022-02-08 14:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:28:37 --> No URI present. Default controller set.
DEBUG - 2022-02-08 14:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:28:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:28:37 --> Total execution time: 0.0045
DEBUG - 2022-02-08 14:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:41:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:41:19 --> Total execution time: 0.0056
DEBUG - 2022-02-08 14:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:43:53 --> Total execution time: 0.0038
DEBUG - 2022-02-08 14:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:47:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:47:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:47:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:47:54 --> Total execution time: 0.0049
DEBUG - 2022-02-08 14:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:59:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 14:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 14:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 14:59:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 14:59:25 --> Total execution time: 0.0064
DEBUG - 2022-02-08 15:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:07:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:07:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:07:14 --> Total execution time: 0.0060
DEBUG - 2022-02-08 15:12:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:12:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:12:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:12:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:12:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:12:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:12:58 --> Total execution time: 0.0058
DEBUG - 2022-02-08 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:19:13 --> Total execution time: 0.0059
DEBUG - 2022-02-08 15:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:23:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:23:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:23:45 --> Total execution time: 0.0059
DEBUG - 2022-02-08 15:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:30:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:30:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:30:01 --> Total execution time: 0.0053
DEBUG - 2022-02-08 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:49:59 --> Total execution time: 0.0066
DEBUG - 2022-02-08 15:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:54:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:54:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:54:54 --> Total execution time: 0.0061
DEBUG - 2022-02-08 15:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:58:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 15:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 15:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 15:58:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 15:58:31 --> Total execution time: 0.0050
DEBUG - 2022-02-08 16:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:03:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:03:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:03:31 --> Total execution time: 0.0055
DEBUG - 2022-02-08 16:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:30:56 --> Total execution time: 0.0060
DEBUG - 2022-02-08 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:35:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:35:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:35:26 --> Total execution time: 0.0051
DEBUG - 2022-02-08 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:41:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:41:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:41:05 --> Total execution time: 0.0058
DEBUG - 2022-02-08 16:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:43:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:43:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:43:09 --> Total execution time: 0.0054
DEBUG - 2022-02-08 16:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:49:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:49:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:49:10 --> Total execution time: 0.0055
DEBUG - 2022-02-08 16:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:52:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 16:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 16:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 16:52:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 16:52:33 --> Total execution time: 0.0059
DEBUG - 2022-02-08 17:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:04:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:04:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:04:40 --> Total execution time: 0.0063
DEBUG - 2022-02-08 17:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:08:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:08:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:08:22 --> Total execution time: 0.0047
DEBUG - 2022-02-08 17:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:17:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:17:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:17:20 --> Total execution time: 0.0055
DEBUG - 2022-02-08 17:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:22:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:22:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:22:41 --> Total execution time: 0.0062
DEBUG - 2022-02-08 17:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:26:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-08 17:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-08 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-08 17:26:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-08 17:26:31 --> Total execution time: 0.0051
