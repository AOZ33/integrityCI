<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-23 00:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 00:34:18 --> No URI present. Default controller set.
DEBUG - 2022-02-23 00:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 00:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 00:34:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 00:34:18 --> Total execution time: 0.0326
DEBUG - 2022-02-23 02:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 02:21:56 --> No URI present. Default controller set.
DEBUG - 2022-02-23 02:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 02:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 02:21:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 02:21:56 --> Total execution time: 0.0303
DEBUG - 2022-02-23 09:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 09:23:20 --> No URI present. Default controller set.
DEBUG - 2022-02-23 09:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 09:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 09:23:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 09:23:20 --> Total execution time: 0.0302
DEBUG - 2022-02-23 09:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 09:23:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-23 09:23:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-23 09:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 09:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 09:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 09:38:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 09:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 09:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 09:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 09:38:30 --> Total execution time: 0.0056
DEBUG - 2022-02-23 09:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 09:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 09:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 09:53:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-23 09:53:05 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-23 09:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 09:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 09:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 09:53:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 09:53:06 --> Total execution time: 0.0043
DEBUG - 2022-02-23 10:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:03:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:03:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:03:20 --> Total execution time: 0.0060
DEBUG - 2022-02-23 10:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:07:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:07:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:07:42 --> Total execution time: 0.0074
DEBUG - 2022-02-23 10:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:37:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:37:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:37:16 --> Total execution time: 0.0066
DEBUG - 2022-02-23 10:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:44:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:44:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:44:03 --> Total execution time: 0.0057
DEBUG - 2022-02-23 10:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:53:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 10:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 10:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 10:53:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 10:53:38 --> Total execution time: 0.0061
DEBUG - 2022-02-23 11:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:05:21 --> Total execution time: 0.0065
DEBUG - 2022-02-23 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:11:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:11:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:11:09 --> Total execution time: 0.0065
DEBUG - 2022-02-23 11:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:16:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:16:59 --> Total execution time: 0.0068
DEBUG - 2022-02-23 11:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:24:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:24:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:24:33 --> Total execution time: 0.0066
DEBUG - 2022-02-23 11:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:31:13 --> Total execution time: 0.0059
DEBUG - 2022-02-23 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:39:08 --> Total execution time: 0.0070
DEBUG - 2022-02-23 11:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:44:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:44:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:44:38 --> Total execution time: 0.0062
DEBUG - 2022-02-23 11:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:52:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 11:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 11:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 11:52:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 11:52:29 --> Total execution time: 0.0067
DEBUG - 2022-02-23 12:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:20:30 --> No URI present. Default controller set.
DEBUG - 2022-02-23 12:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 12:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 12:20:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 12:20:30 --> Total execution time: 0.0312
DEBUG - 2022-02-23 12:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:20:30 --> No URI present. Default controller set.
DEBUG - 2022-02-23 12:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 12:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 12:20:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 12:20:30 --> Total execution time: 0.0032
DEBUG - 2022-02-23 12:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:20:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-23 12:20:31 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-23 12:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 12:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 12:20:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 12:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 12:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 12:20:51 --> Total execution time: 0.0044
DEBUG - 2022-02-23 12:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 12:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 12:20:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-23 12:20:57 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-23 12:23:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 12:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 12:23:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 12:23:44 --> Total execution time: 0.0325
DEBUG - 2022-02-23 12:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 12:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 12:59:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 12:59:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 12:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 12:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 12:59:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 12:59:08 --> Total execution time: 0.0068
DEBUG - 2022-02-23 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:22:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:22:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:22:45 --> Total execution time: 0.0066
DEBUG - 2022-02-23 13:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:25:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:25:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:25:34 --> Total execution time: 0.0046
DEBUG - 2022-02-23 13:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:29:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:29:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:29:52 --> Total execution time: 0.0062
DEBUG - 2022-02-23 13:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:40:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:40:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:40:22 --> Total execution time: 0.0071
DEBUG - 2022-02-23 13:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:48:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:48:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:48:13 --> Total execution time: 0.0058
DEBUG - 2022-02-23 13:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:50:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:50:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:50:50 --> Total execution time: 0.0055
DEBUG - 2022-02-23 13:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:53:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 13:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 13:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 13:53:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 13:53:17 --> Total execution time: 0.0056
DEBUG - 2022-02-23 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:01:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:01:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:01:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:01:43 --> Total execution time: 0.0059
DEBUG - 2022-02-23 14:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:06:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:06:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:06:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:06:16 --> Total execution time: 0.0054
DEBUG - 2022-02-23 14:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:12:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:12:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:12:07 --> Total execution time: 0.0061
DEBUG - 2022-02-23 14:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:18:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:18:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:18:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:18:34 --> Total execution time: 0.0054
DEBUG - 2022-02-23 14:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:27:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:27:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:27:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:27:18 --> Total execution time: 0.0064
DEBUG - 2022-02-23 14:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:34:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:34:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:34:12 --> Total execution time: 0.0065
DEBUG - 2022-02-23 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:45:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:45:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:45:38 --> Total execution time: 0.0059
DEBUG - 2022-02-23 14:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:51:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:51:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:51:45 --> Total execution time: 0.0054
DEBUG - 2022-02-23 14:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:56:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 14:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 14:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 14:56:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 14:56:40 --> Total execution time: 0.0063
DEBUG - 2022-02-23 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:09:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:09:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:09:56 --> Total execution time: 0.0062
DEBUG - 2022-02-23 15:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:11:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:11:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:11:48 --> Total execution time: 0.0057
DEBUG - 2022-02-23 15:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:16:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:16:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:16:24 --> Total execution time: 0.0061
DEBUG - 2022-02-23 15:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:22:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:22:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:22:53 --> Total execution time: 0.0065
DEBUG - 2022-02-23 15:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:28:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:28:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:28:16 --> Total execution time: 0.0062
DEBUG - 2022-02-23 15:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:31:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:31:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:31:31 --> Total execution time: 0.0049
DEBUG - 2022-02-23 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:34:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:34:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:34:18 --> Total execution time: 0.0044
DEBUG - 2022-02-23 15:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:40:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:40:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:40:31 --> Total execution time: 0.0063
DEBUG - 2022-02-23 15:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:46:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:46:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:46:06 --> Total execution time: 0.0061
DEBUG - 2022-02-23 15:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 15:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 15:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 15:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 15:50:59 --> Total execution time: 0.0061
DEBUG - 2022-02-23 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-23 17:31:49 --> No URI present. Default controller set.
DEBUG - 2022-02-23 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-23 17:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-23 17:31:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-23 17:31:49 --> Total execution time: 0.0309
