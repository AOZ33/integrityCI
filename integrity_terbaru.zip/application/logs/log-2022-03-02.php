<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-02 09:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:37:52 --> No URI present. Default controller set.
DEBUG - 2022-03-02 09:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:37:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:37:52 --> Total execution time: 0.0317
DEBUG - 2022-03-02 09:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-02 09:37:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-02 09:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:37:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:37:55 --> Total execution time: 0.0057
DEBUG - 2022-03-02 09:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:37:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:37:57 --> Total execution time: 0.0129
DEBUG - 2022-03-02 09:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:38:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:38:29 --> Total execution time: 0.0055
DEBUG - 2022-03-02 09:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:40:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:40:34 --> Total execution time: 0.0368
DEBUG - 2022-03-02 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:40:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:40:59 --> Total execution time: 0.0052
DEBUG - 2022-03-02 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:25 --> Total execution time: 0.0341
DEBUG - 2022-03-02 09:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:51:26 --> Total execution time: 0.0106
DEBUG - 2022-03-02 09:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:51:31 --> Total execution time: 0.0055
DEBUG - 2022-03-02 09:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:34 --> Total execution time: 0.0047
DEBUG - 2022-03-02 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:41 --> Total execution time: 0.0048
DEBUG - 2022-03-02 09:51:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:51:44 --> Total execution time: 0.0049
DEBUG - 2022-03-02 09:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:48 --> Total execution time: 0.0042
DEBUG - 2022-03-02 09:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:51 --> Total execution time: 0.0047
DEBUG - 2022-03-02 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:51:57 --> Total execution time: 0.0037
DEBUG - 2022-03-02 09:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:52:01 --> Total execution time: 0.0065
DEBUG - 2022-03-02 09:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:05 --> Total execution time: 0.0034
DEBUG - 2022-03-02 09:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 09:52:07 --> Total execution time: 0.0052
DEBUG - 2022-03-02 09:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:08 --> Total execution time: 0.0037
DEBUG - 2022-03-02 09:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:10 --> Total execution time: 0.0043
DEBUG - 2022-03-02 09:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:13 --> Total execution time: 0.0048
DEBUG - 2022-03-02 09:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:14 --> Total execution time: 0.0044
DEBUG - 2022-03-02 09:52:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:16 --> Total execution time: 0.0043
DEBUG - 2022-03-02 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:18 --> Total execution time: 0.0034
DEBUG - 2022-03-02 09:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 09:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 09:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 09:52:20 --> Total execution time: 0.0046
DEBUG - 2022-03-02 10:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:03:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:03:12 --> Total execution time: 0.0405
DEBUG - 2022-03-02 10:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:03:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:03:13 --> Total execution time: 0.0042
DEBUG - 2022-03-02 10:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:09:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:09:58 --> Total execution time: 0.0430
DEBUG - 2022-03-02 10:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:09:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:09:59 --> Total execution time: 0.0044
DEBUG - 2022-03-02 10:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:10:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:10:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:10:13 --> Total execution time: 0.0043
DEBUG - 2022-03-02 10:10:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:10:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:10:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:10:19 --> Total execution time: 0.0074
DEBUG - 2022-03-02 10:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:10:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:10:23 --> Total execution time: 0.0117
DEBUG - 2022-03-02 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:10:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:10:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:10:31 --> Total execution time: 0.0109
DEBUG - 2022-03-02 10:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:10:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:10:36 --> Total execution time: 0.0044
DEBUG - 2022-03-02 10:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:11:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 10:11:13 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-03-02 10:11:13 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Farhan', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-03-02 10:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:11:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:11:13 --> Total execution time: 0.0036
DEBUG - 2022-03-02 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:11:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:11:24 --> Total execution time: 0.0043
DEBUG - 2022-03-02 10:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:11:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:11:27 --> Total execution time: 0.0095
DEBUG - 2022-03-02 10:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:11:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:11:30 --> Total execution time: 0.0101
DEBUG - 2022-03-02 10:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:11:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:11:36 --> Total execution time: 0.0055
DEBUG - 2022-03-02 10:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:12:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:12:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:12:03 --> Total execution time: 0.0098
DEBUG - 2022-03-02 10:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:12:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:12:24 --> Total execution time: 0.0052
DEBUG - 2022-03-02 10:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:16:53 --> No URI present. Default controller set.
DEBUG - 2022-03-02 10:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:16:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:16:53 --> Total execution time: 0.0310
DEBUG - 2022-03-02 10:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:16:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-02 10:16:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-02 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:16:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:16:59 --> Total execution time: 0.0041
DEBUG - 2022-03-02 10:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:04 --> Total execution time: 0.0104
DEBUG - 2022-03-02 10:17:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:08 --> Total execution time: 0.0043
DEBUG - 2022-03-02 10:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:10 --> Total execution time: 0.0046
DEBUG - 2022-03-02 10:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:14 --> Total execution time: 0.0070
DEBUG - 2022-03-02 10:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:16 --> Total execution time: 0.0055
DEBUG - 2022-03-02 10:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:18 --> Total execution time: 0.0049
DEBUG - 2022-03-02 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:20 --> Total execution time: 0.0050
DEBUG - 2022-03-02 10:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:22 --> Total execution time: 0.0049
DEBUG - 2022-03-02 10:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:24 --> Total execution time: 0.0047
DEBUG - 2022-03-02 10:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:25 --> Total execution time: 0.0048
DEBUG - 2022-03-02 10:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:27 --> Total execution time: 0.0056
DEBUG - 2022-03-02 10:17:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:29 --> Total execution time: 0.0050
DEBUG - 2022-03-02 10:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:30 --> Total execution time: 0.0051
DEBUG - 2022-03-02 10:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:31 --> Total execution time: 0.0084
DEBUG - 2022-03-02 10:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:38 --> Total execution time: 0.0045
DEBUG - 2022-03-02 10:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:39 --> Total execution time: 0.0037
DEBUG - 2022-03-02 10:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:41 --> Total execution time: 0.0087
DEBUG - 2022-03-02 10:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:44 --> Total execution time: 0.0098
DEBUG - 2022-03-02 10:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:46 --> Total execution time: 0.0070
DEBUG - 2022-03-02 10:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:47 --> Total execution time: 0.0100
DEBUG - 2022-03-02 10:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:50 --> Total execution time: 0.0087
DEBUG - 2022-03-02 10:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:17:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:17:52 --> Total execution time: 0.0055
DEBUG - 2022-03-02 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:18:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:18:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:18:15 --> Total execution time: 0.0094
DEBUG - 2022-03-02 10:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:18:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:18:56 --> Total execution time: 0.0073
DEBUG - 2022-03-02 10:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:18:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:18:58 --> Total execution time: 0.0036
DEBUG - 2022-03-02 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:20:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:20:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:20:31 --> Total execution time: 0.0050
DEBUG - 2022-03-02 10:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:20:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:20:36 --> Total execution time: 0.0126
DEBUG - 2022-03-02 10:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:20:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:20:49 --> Total execution time: 0.0128
DEBUG - 2022-03-02 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:21:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:21:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:21:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:21:05 --> Total execution time: 0.0106
DEBUG - 2022-03-02 10:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:21:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:21:15 --> Total execution time: 0.0040
DEBUG - 2022-03-02 10:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:22:02 --> Total execution time: 0.0054
DEBUG - 2022-03-02 10:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:22:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:22:05 --> Total execution time: 0.0084
DEBUG - 2022-03-02 10:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:22:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:22:10 --> Total execution time: 0.0043
DEBUG - 2022-03-02 10:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:24:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:24:51 --> Total execution time: 0.0338
DEBUG - 2022-03-02 10:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 10:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 10:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 10:45:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 10:45:53 --> Total execution time: 0.0409
DEBUG - 2022-03-02 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:09 --> Total execution time: 0.0338
DEBUG - 2022-03-02 11:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:10 --> Total execution time: 0.0142
DEBUG - 2022-03-02 11:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:12 --> Total execution time: 0.0065
DEBUG - 2022-03-02 11:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:33 --> Total execution time: 0.0053
DEBUG - 2022-03-02 11:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:39 --> Total execution time: 0.0038
DEBUG - 2022-03-02 11:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:42 --> Total execution time: 0.0075
DEBUG - 2022-03-02 11:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:46 --> Total execution time: 0.0089
DEBUG - 2022-03-02 11:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:06:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:06:47 --> Total execution time: 0.0100
DEBUG - 2022-03-02 11:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:11:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:11:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:11:21 --> Total execution time: 0.0519
DEBUG - 2022-03-02 11:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:12:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:12:33 --> Total execution time: 0.0424
DEBUG - 2022-03-02 11:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:12:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:12:34 --> Total execution time: 0.0129
DEBUG - 2022-03-02 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:12:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:12:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:12:36 --> Total execution time: 0.0114
DEBUG - 2022-03-02 11:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:15:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:15:03 --> Total execution time: 0.0413
DEBUG - 2022-03-02 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:15:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:15:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:15:06 --> Total execution time: 0.0100
DEBUG - 2022-03-02 11:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:27:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:27:41 --> Total execution time: 0.0455
DEBUG - 2022-03-02 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:27:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:27:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:27:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:27:54 --> Total execution time: 0.0100
DEBUG - 2022-03-02 11:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:33:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:33:59 --> Total execution time: 0.0387
DEBUG - 2022-03-02 11:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:34:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:34:02 --> Total execution time: 0.0050
DEBUG - 2022-03-02 11:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:37:08 --> Severity: error --> Exception: syntax error, unexpected '$photo_g' (T_VARIABLE) /home/dunr4521/public_html/integrity/application/views/data/index.php 141
DEBUG - 2022-03-02 11:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:37:12 --> Severity: error --> Exception: syntax error, unexpected '$photo_g' (T_VARIABLE) /home/dunr4521/public_html/integrity/application/views/data/index.php 141
DEBUG - 2022-03-02 11:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:16 --> No URI present. Default controller set.
DEBUG - 2022-03-02 11:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:37:16 --> Total execution time: 0.0045
DEBUG - 2022-03-02 11:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-02 11:37:16 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-02 11:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:16 --> No URI present. Default controller set.
DEBUG - 2022-03-02 11:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:37:16 --> Total execution time: 0.0037
DEBUG - 2022-03-02 11:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:19 --> Total execution time: 0.0052
DEBUG - 2022-03-02 11:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:37:21 --> Severity: error --> Exception: syntax error, unexpected '$photo_g' (T_VARIABLE) /home/dunr4521/public_html/integrity/application/views/data/index.php 141
DEBUG - 2022-03-02 11:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:49 --> No URI present. Default controller set.
DEBUG - 2022-03-02 11:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:37:49 --> Total execution time: 0.0044
DEBUG - 2022-03-02 11:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-02 11:37:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-02 11:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:51 --> Total execution time: 0.0034
DEBUG - 2022-03-02 11:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:37:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:37:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:37:53 --> Total execution time: 0.0134
DEBUG - 2022-03-02 11:38:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:38:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 285
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 11:38:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 11:38:57 --> Total execution time: 0.0130
DEBUG - 2022-03-02 11:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:40:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:40:06 --> Total execution time: 0.0078
DEBUG - 2022-03-02 11:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:40:07 --> Total execution time: 0.0048
DEBUG - 2022-03-02 11:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 11:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 11:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 11:40:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 11:40:08 --> Total execution time: 0.0047
DEBUG - 2022-03-02 12:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:08:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:08:05 --> Total execution time: 0.0350
DEBUG - 2022-03-02 12:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:14:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:14:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:14:45 --> Total execution time: 0.0055
DEBUG - 2022-03-02 12:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:46:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:46:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:46:04 --> Total execution time: 0.0068
DEBUG - 2022-03-02 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:52:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:52:34 --> Total execution time: 0.0399
DEBUG - 2022-03-02 12:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:52:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:52:35 --> Total execution time: 0.0050
DEBUG - 2022-03-02 12:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:52:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:52:43 --> Total execution time: 0.0120
DEBUG - 2022-03-02 12:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:58:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:58:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 12:58:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-02 12:58:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-02 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:58:17 --> No URI present. Default controller set.
DEBUG - 2022-03-02 12:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:58:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:58:17 --> Total execution time: 0.0044
DEBUG - 2022-03-02 12:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:58:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-02 12:58:17 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-02 12:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:58:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:58:22 --> Total execution time: 0.0044
DEBUG - 2022-03-02 12:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 12:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 12:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 12:58:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 12:58:24 --> Total execution time: 0.0070
DEBUG - 2022-03-02 13:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 13:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 13:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 13:28:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 13:28:36 --> Total execution time: 0.0349
DEBUG - 2022-03-02 13:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 13:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 13:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 13:37:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 13:37:08 --> Total execution time: 0.0465
DEBUG - 2022-03-02 13:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 13:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 13:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 13:44:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 13:44:40 --> Total execution time: 0.0347
DEBUG - 2022-03-02 14:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:00:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:00:53 --> Total execution time: 0.0445
DEBUG - 2022-03-02 14:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:06:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:06:43 --> Total execution time: 0.0438
DEBUG - 2022-03-02 14:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:08:23 --> Total execution time: 0.0352
DEBUG - 2022-03-02 14:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:08:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:08:25 --> Total execution time: 0.0068
DEBUG - 2022-03-02 14:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:08:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:08:30 --> Total execution time: 0.0089
DEBUG - 2022-03-02 14:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:08:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:08:32 --> Total execution time: 0.0093
DEBUG - 2022-03-02 14:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:09:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:09:39 --> Total execution time: 0.0089
DEBUG - 2022-03-02 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:10:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:10:04 --> Total execution time: 0.0080
DEBUG - 2022-03-02 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:10:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:10:04 --> Total execution time: 0.0053
DEBUG - 2022-03-02 14:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:10:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:10:05 --> Total execution time: 0.0046
DEBUG - 2022-03-02 14:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:15:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:15:48 --> Total execution time: 0.0330
DEBUG - 2022-03-02 14:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:26:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:26:28 --> Total execution time: 0.0399
DEBUG - 2022-03-02 14:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:26:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:26:36 --> Total execution time: 0.0107
DEBUG - 2022-03-02 14:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:26:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:26:37 --> Total execution time: 0.0042
DEBUG - 2022-03-02 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:28:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:28:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:28:03 --> Total execution time: 0.0053
DEBUG - 2022-03-02 14:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:28:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:28:06 --> Total execution time: 0.0145
DEBUG - 2022-03-02 14:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:28:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:28:09 --> Total execution time: 0.0065
DEBUG - 2022-03-02 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:28:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:28:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:28:23 --> Total execution time: 0.0075
DEBUG - 2022-03-02 14:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 14:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 14:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 14:28:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 14:28:35 --> Total execution time: 0.0051
DEBUG - 2022-03-02 15:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:01:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:01:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:01:25 --> Total execution time: 0.0077
DEBUG - 2022-03-02 15:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:06:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:06:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:06:45 --> Total execution time: 0.0069
DEBUG - 2022-03-02 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:10:58 --> Total execution time: 0.0397
DEBUG - 2022-03-02 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:10:58 --> Total execution time: 0.0046
DEBUG - 2022-03-02 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:12:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:12:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-02 15:12:15 --> Total execution time: 0.0040
DEBUG - 2022-03-02 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:12:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-02 15:12:15 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-02 15:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:29:54 --> Total execution time: 0.0341
DEBUG - 2022-03-02 15:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:29:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:29:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, string given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 15:29:55 --> Total execution time: 0.0145
DEBUG - 2022-03-02 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:31:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 15:31:14 --> Total execution time: 0.0412
DEBUG - 2022-03-02 15:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 15:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 15:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 15:31:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-02 15:31:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-02 15:31:16 --> Total execution time: 0.0101
DEBUG - 2022-03-02 16:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 16:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 16:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 16:11:28 --> Total execution time: 0.0338
DEBUG - 2022-03-02 16:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-02 16:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-02 16:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-02 16:11:30 --> Total execution time: 0.0046
