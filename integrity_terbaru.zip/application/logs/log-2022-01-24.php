<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-24 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:02 --> No URI present. Default controller set.
DEBUG - 2022-01-24 09:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:12:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 09:12:02 --> Total execution time: 0.0307
DEBUG - 2022-01-24 09:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-24 09:12:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-24 09:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:12:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 09:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:12:14 --> Total execution time: 0.0062
DEBUG - 2022-01-24 09:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:27 --> No URI present. Default controller set.
DEBUG - 2022-01-24 09:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:12:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 09:12:27 --> Total execution time: 0.0049
DEBUG - 2022-01-24 09:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-24 09:12:27 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-24 09:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:12:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 09:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:12:31 --> Total execution time: 0.0038
DEBUG - 2022-01-24 09:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:12:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-24 09:12:38 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 110611576 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-24 09:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:13:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 09:13:10 --> Total execution time: 0.0056
DEBUG - 2022-01-24 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 09:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 09:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 09:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 09:49:27 --> Total execution time: 0.0070
DEBUG - 2022-01-24 10:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:18:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:18:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:18:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:18:07 --> Total execution time: 0.0063
DEBUG - 2022-01-24 10:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:48:56 --> Total execution time: 0.0066
DEBUG - 2022-01-24 10:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:52:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:52:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:52:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:52:35 --> Total execution time: 0.0066
DEBUG - 2022-01-24 10:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:55:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:55:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:55:04 --> Total execution time: 0.0064
DEBUG - 2022-01-24 10:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:58:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 10:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 10:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 10:58:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 10:58:06 --> Total execution time: 0.0057
DEBUG - 2022-01-24 11:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:28:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:28:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:28:43 --> Total execution time: 0.0062
DEBUG - 2022-01-24 11:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:32:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:32:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:32:29 --> Total execution time: 0.0063
DEBUG - 2022-01-24 11:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:36:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:36:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:36:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:36:56 --> Total execution time: 0.0062
DEBUG - 2022-01-24 11:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:41:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:41:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:41:48 --> Total execution time: 0.0063
DEBUG - 2022-01-24 11:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:44:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:44:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:44:21 --> Total execution time: 0.0062
DEBUG - 2022-01-24 11:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:49:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:49:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:49:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:49:36 --> Total execution time: 0.0057
DEBUG - 2022-01-24 11:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:56:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 11:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 11:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 11:56:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 11:56:57 --> Total execution time: 0.0064
DEBUG - 2022-01-24 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 12:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 12:03:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 12:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 12:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 12:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 12:03:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 12:03:37 --> Total execution time: 0.0060
DEBUG - 2022-01-24 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 12:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 12:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 12:07:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 12:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 12:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 12:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 12:07:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 12:07:40 --> Total execution time: 0.0055
DEBUG - 2022-01-24 12:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 12:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 12:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 12:29:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 12:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 12:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 12:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 12:29:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 12:29:04 --> Total execution time: 0.0066
DEBUG - 2022-01-24 12:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 12:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 12:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 12:33:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 12:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 12:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 12:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 12:33:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 12:33:06 --> Total execution time: 0.0059
DEBUG - 2022-01-24 13:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:28:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:28:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:28:35 --> Total execution time: 0.0070
DEBUG - 2022-01-24 13:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:33:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:33:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:33:45 --> Total execution time: 0.0066
DEBUG - 2022-01-24 13:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:37:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:37:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:37:49 --> Total execution time: 0.0061
DEBUG - 2022-01-24 13:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:43:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:43:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:43:13 --> Total execution time: 0.0073
DEBUG - 2022-01-24 13:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:51:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:51:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:51:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:51:02 --> Total execution time: 0.0071
DEBUG - 2022-01-24 13:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:53:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:53:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:53:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:53:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:53:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:53:39 --> Total execution time: 0.0053
DEBUG - 2022-01-24 13:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:58:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 13:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 13:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 13:58:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 13:58:58 --> Total execution time: 0.0058
DEBUG - 2022-01-24 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:04:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:04:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:04:17 --> Total execution time: 0.0060
DEBUG - 2022-01-24 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:05:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:05:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:05:57 --> Total execution time: 0.0053
DEBUG - 2022-01-24 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:10:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:10:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:10:53 --> Total execution time: 0.0061
DEBUG - 2022-01-24 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:17:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:17:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:17:43 --> Total execution time: 0.0066
DEBUG - 2022-01-24 14:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:23:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:23:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:23:23 --> Total execution time: 0.0063
DEBUG - 2022-01-24 14:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:27:44 --> Total execution time: 0.0064
DEBUG - 2022-01-24 14:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:30:56 --> Total execution time: 0.0064
DEBUG - 2022-01-24 14:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:35:35 --> Total execution time: 0.0063
DEBUG - 2022-01-24 14:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:40:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:40:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:40:25 --> Total execution time: 0.0059
DEBUG - 2022-01-24 14:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:44:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:44:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:44:33 --> Total execution time: 0.0065
DEBUG - 2022-01-24 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:52:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:52:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:52:10 --> Total execution time: 0.0069
DEBUG - 2022-01-24 14:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:55:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:55:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:55:27 --> Total execution time: 0.0050
DEBUG - 2022-01-24 14:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:59:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 14:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 14:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 14:59:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 14:59:23 --> Total execution time: 0.0055
DEBUG - 2022-01-24 15:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:05:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:05:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:05:06 --> Total execution time: 0.0063
DEBUG - 2022-01-24 15:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:10:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:10:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:10:42 --> Total execution time: 0.0059
DEBUG - 2022-01-24 15:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:15:19 --> Total execution time: 0.0062
DEBUG - 2022-01-24 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:18:38 --> Total execution time: 0.0061
DEBUG - 2022-01-24 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:25:03 --> Total execution time: 0.0066
DEBUG - 2022-01-24 15:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:27:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:27:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:27:54 --> Total execution time: 0.0054
DEBUG - 2022-01-24 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:31:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:31:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:31:48 --> Total execution time: 0.0061
DEBUG - 2022-01-24 15:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:50:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:50:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:50:43 --> Total execution time: 0.0058
DEBUG - 2022-01-24 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:54:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 15:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 15:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 15:54:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 15:54:44 --> Total execution time: 0.0065
DEBUG - 2022-01-24 16:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:05:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:05:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:05:10 --> Total execution time: 0.0060
DEBUG - 2022-01-24 16:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:09:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:09:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:09:23 --> Total execution time: 0.0062
DEBUG - 2022-01-24 16:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:15:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:15:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:15:47 --> Total execution time: 0.0063
DEBUG - 2022-01-24 16:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:20:01 --> Total execution time: 0.0071
DEBUG - 2022-01-24 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:23:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:23:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:23:55 --> Total execution time: 0.0064
DEBUG - 2022-01-24 16:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:25:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:25:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:25:39 --> Total execution time: 0.0058
DEBUG - 2022-01-24 16:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:31:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:31:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:31:59 --> Total execution time: 0.0065
DEBUG - 2022-01-24 16:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:36:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:36:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:36:40 --> Total execution time: 0.0061
DEBUG - 2022-01-24 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:42:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:42:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:42:34 --> Total execution time: 0.0068
DEBUG - 2022-01-24 16:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:44:14 --> Total execution time: 0.0050
DEBUG - 2022-01-24 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 16:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 16:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 16:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 16:58:25 --> Total execution time: 0.0062
DEBUG - 2022-01-24 17:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 17:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 17:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 17:01:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 17:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 17:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 17:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 17:01:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 17:01:34 --> Total execution time: 0.0056
DEBUG - 2022-01-24 17:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 17:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 17:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 17:05:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 17:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-24 17:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-24 17:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-24 17:05:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-24 17:05:55 --> Total execution time: 0.0047
