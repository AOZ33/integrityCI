<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-09-15 09:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:12 --> No URI present. Default controller set.
DEBUG - 2022-09-15 09:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:54:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:54:12 --> Total execution time: 0.1762
DEBUG - 2022-09-15 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:54:16 --> Total execution time: 0.0978
DEBUG - 2022-09-15 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-15 09:54:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-09-15 09:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-15 09:54:16 --> 404 Page Not Found: Auth/css
DEBUG - 2022-09-15 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-15 09:54:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-09-15 09:54:16 --> UTF-8 Support Enabled
ERROR - 2022-09-15 09:54:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-09-15 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-15 09:54:16 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-09-15 09:54:16 --> 404 Page Not Found: Auth/js
DEBUG - 2022-09-15 09:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:54:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:54:50 --> Total execution time: 0.1082
DEBUG - 2022-09-15 09:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:54:53 --> Total execution time: 0.0873
DEBUG - 2022-09-15 09:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:54:54 --> No URI present. Default controller set.
DEBUG - 2022-09-15 09:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:54:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:54:54 --> Total execution time: 0.0838
DEBUG - 2022-09-15 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:00 --> Total execution time: 0.1588
DEBUG - 2022-09-15 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:16 --> Total execution time: 0.1129
DEBUG - 2022-09-15 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:20 --> Total execution time: 0.0847
DEBUG - 2022-09-15 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-15 09:55:20 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-09-15 09:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:20 --> UTF-8 Support Enabled
ERROR - 2022-09-15 09:55:20 --> 404 Page Not Found: Auth/js
ERROR - 2022-09-15 09:55:20 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-09-15 09:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-15 09:55:20 --> 404 Page Not Found: Auth/css
DEBUG - 2022-09-15 09:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-15 09:55:20 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-09-15 09:55:20 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-09-15 09:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:32 --> Total execution time: 0.1166
DEBUG - 2022-09-15 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:42 --> Total execution time: 0.0910
DEBUG - 2022-09-15 09:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:55:50 --> Total execution time: 0.1046
DEBUG - 2022-09-15 09:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-09-15 09:56:04 --> 404 Page Not Found: User/editrole
DEBUG - 2022-09-15 09:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:06 --> Total execution time: 0.1066
DEBUG - 2022-09-15 09:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:07 --> Total execution time: 0.1141
DEBUG - 2022-09-15 09:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:56:15 --> Total execution time: 0.1338
DEBUG - 2022-09-15 09:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:22 --> Total execution time: 0.1071
DEBUG - 2022-09-15 09:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:26 --> Total execution time: 0.1141
DEBUG - 2022-09-15 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:29 --> Total execution time: 0.1222
DEBUG - 2022-09-15 09:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:31 --> Total execution time: 0.1173
DEBUG - 2022-09-15 09:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:38 --> Total execution time: 0.1573
DEBUG - 2022-09-15 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:41 --> Total execution time: 0.1550
DEBUG - 2022-09-15 09:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:44 --> Total execution time: 0.1678
DEBUG - 2022-09-15 09:56:46 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:46 --> Total execution time: 0.1218
DEBUG - 2022-09-15 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:48 --> Total execution time: 0.1174
DEBUG - 2022-09-15 09:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:55 --> Total execution time: 0.1997
DEBUG - 2022-09-15 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:56:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:56:57 --> Total execution time: 0.1601
DEBUG - 2022-09-15 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:57:22 --> Total execution time: 0.1085
DEBUG - 2022-09-15 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:57:30 --> Total execution time: 0.1093
DEBUG - 2022-09-15 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:57:44 --> Total execution time: 0.1039
DEBUG - 2022-09-15 09:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 09:57:51 --> Total execution time: 0.1168
DEBUG - 2022-09-15 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:58:01 --> Total execution time: 0.1347
DEBUG - 2022-09-15 09:58:07 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:58:08 --> Total execution time: 0.1357
DEBUG - 2022-09-15 09:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:58:13 --> Total execution time: 0.1537
DEBUG - 2022-09-15 09:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 09:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 09:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 09:58:18 --> Total execution time: 0.1152
DEBUG - 2022-09-15 10:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 10:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 10:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 10:07:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 10:07:09 --> Total execution time: 0.1730
DEBUG - 2022-09-15 10:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 10:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 10:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 10:07:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 10:07:28 --> Total execution time: 0.1644
DEBUG - 2022-09-15 10:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 10:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 10:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 10:07:32 --> Total execution time: 0.1056
DEBUG - 2022-09-15 10:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 10:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 10:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 10:07:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 10:07:34 --> Total execution time: 0.1326
DEBUG - 2022-09-15 10:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 10:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 10:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 10:07:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 10:07:48 --> Total execution time: 0.1695
DEBUG - 2022-09-15 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-09-15 10:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-09-15 10:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-09-15 10:10:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-09-15 10:10:59 --> Total execution time: 0.1358
