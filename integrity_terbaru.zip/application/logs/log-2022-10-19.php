<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-10-19 03:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:17:22 --> No URI present. Default controller set.
DEBUG - 2022-10-19 03:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:17:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:17:22 --> Total execution time: 0.1796
DEBUG - 2022-10-19 03:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:18:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:18:29 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:18:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:18:29 --> Total execution time: 0.0998
DEBUG - 2022-10-19 03:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:18:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:18:37 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:18:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:18:37 --> Total execution time: 0.2898
DEBUG - 2022-10-19 03:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:18:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:18:54 --> Total execution time: 0.1647
DEBUG - 2022-10-19 03:18:56 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:18:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:18:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:18:56 --> Total execution time: 0.1711
DEBUG - 2022-10-19 03:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:18:58 --> Total execution time: 0.1153
DEBUG - 2022-10-19 03:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:18:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:18:59 --> Total execution time: 0.1737
DEBUG - 2022-10-19 03:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:19:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:19:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:19:02 --> Total execution time: 0.1277
DEBUG - 2022-10-19 03:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:19:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:19:19 --> Total execution time: 0.1217
DEBUG - 2022-10-19 03:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 03:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 03:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 03:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 03:19:27 --> Total execution time: 0.1123
DEBUG - 2022-10-19 17:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:38:41 --> No URI present. Default controller set.
DEBUG - 2022-10-19 17:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:38:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:38:41 --> Total execution time: 0.1430
DEBUG - 2022-10-19 17:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:38:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:38:49 --> Total execution time: 0.1088
DEBUG - 2022-10-19 17:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:39:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:39:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:39:16 --> Total execution time: 0.0862
DEBUG - 2022-10-19 17:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:40:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:40:32 --> Total execution time: 0.1003
DEBUG - 2022-10-19 17:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:47:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:47:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:47:27 --> Total execution time: 0.0919
DEBUG - 2022-10-19 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:47:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:47:52 --> Total execution time: 0.0920
DEBUG - 2022-10-19 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-19 17:47:52 --> 404 Page Not Found: Auth/css
DEBUG - 2022-10-19 17:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:47:52 --> UTF-8 Support Enabled
ERROR - 2022-10-19 17:47:52 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-10-19 17:47:52 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-10-19 17:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-19 17:47:52 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-10-19 17:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-19 17:47:52 --> 404 Page Not Found: Auth/js
ERROR - 2022-10-19 17:47:52 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-10-19 17:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:47:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:47:57 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:47:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:47:57 --> Total execution time: 0.1016
DEBUG - 2022-10-19 17:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:48:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:48:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:48:16 --> Total execution time: 0.1054
DEBUG - 2022-10-19 17:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:48:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:48:24 --> Total execution time: 0.1124
DEBUG - 2022-10-19 17:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 17:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 17:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 17:48:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 17:48:26 --> Total execution time: 0.2480
DEBUG - 2022-10-19 18:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:02:28 --> Total execution time: 0.1221
DEBUG - 2022-10-19 18:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:02:39 --> Total execution time: 0.1547
DEBUG - 2022-10-19 18:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:02:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:02:46 --> Total execution time: 0.1912
DEBUG - 2022-10-19 18:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:03:30 --> Total execution time: 0.1293
DEBUG - 2022-10-19 18:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:15:24 --> Total execution time: 0.1064
DEBUG - 2022-10-19 18:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:18:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:18:18 --> Total execution time: 0.1354
DEBUG - 2022-10-19 18:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:26:00 --> Total execution time: 0.1108
DEBUG - 2022-10-19 18:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:26:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:26:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:26:16 --> Total execution time: 0.0877
DEBUG - 2022-10-19 18:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:26:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:26:18 --> Total execution time: 0.1236
DEBUG - 2022-10-19 18:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-19 18:26:18 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-10-19 18:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-19 18:26:18 --> 404 Page Not Found: Auth/css
DEBUG - 2022-10-19 18:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-10-19 18:26:18 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-10-19 18:26:18 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-10-19 18:26:18 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-10-19 18:26:18 --> 404 Page Not Found: Auth/js
DEBUG - 2022-10-19 18:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:28:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:28:50 --> Total execution time: 0.1043
DEBUG - 2022-10-19 18:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:30:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:30:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:30:48 --> Total execution time: 0.0880
DEBUG - 2022-10-19 18:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:30:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:30:55 --> Total execution time: 0.1155
DEBUG - 2022-10-19 18:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:31:52 --> Total execution time: 0.1009
DEBUG - 2022-10-19 18:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:31:53 --> Total execution time: 0.2083
DEBUG - 2022-10-19 18:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:52:49 --> Total execution time: 0.1119
DEBUG - 2022-10-19 18:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-10-19 18:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-19 18:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-19 18:52:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-19 18:52:52 --> Total execution time: 0.1138
