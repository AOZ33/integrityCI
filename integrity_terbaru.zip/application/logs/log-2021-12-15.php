<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-15 03:58:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:21 --> No URI present. Default controller set.
DEBUG - 2021-12-15 03:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:21 --> Total execution time: 0.0846
DEBUG - 2021-12-15 03:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:23 --> Total execution time: 0.0688
DEBUG - 2021-12-15 03:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:25 --> Total execution time: 0.0454
DEBUG - 2021-12-15 03:58:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:26 --> Total execution time: 0.0401
DEBUG - 2021-12-15 03:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:27 --> Total execution time: 0.0379
DEBUG - 2021-12-15 03:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:31 --> Total execution time: 0.0258
DEBUG - 2021-12-15 03:58:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:33 --> Total execution time: 0.0409
DEBUG - 2021-12-15 03:58:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 03:58:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 03:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 03:58:34 --> Total execution time: 0.0528
DEBUG - 2021-12-15 04:09:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:09:17 --> Total execution time: 0.0329
DEBUG - 2021-12-15 04:09:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:09:18 --> Total execution time: 0.0494
DEBUG - 2021-12-15 04:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:09:19 --> Total execution time: 0.0363
DEBUG - 2021-12-15 04:09:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:09:20 --> Total execution time: 0.0468
DEBUG - 2021-12-15 04:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:10:28 --> Total execution time: 0.0511
DEBUG - 2021-12-15 04:10:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:10:29 --> Total execution time: 0.0284
DEBUG - 2021-12-15 04:11:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:11:10 --> Total execution time: 0.0503
DEBUG - 2021-12-15 04:13:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:13:09 --> Total execution time: 0.0409
DEBUG - 2021-12-15 04:13:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:14:00 --> Total execution time: 0.0427
DEBUG - 2021-12-15 04:14:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:14:09 --> Total execution time: 0.0464
DEBUG - 2021-12-15 04:14:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:14:17 --> Total execution time: 0.0500
DEBUG - 2021-12-15 04:32:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:32:48 --> Total execution time: 0.0526
DEBUG - 2021-12-15 04:36:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:36:27 --> Total execution time: 0.0513
DEBUG - 2021-12-15 04:38:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:38:12 --> Total execution time: 0.0534
DEBUG - 2021-12-15 04:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:38:23 --> Severity: Warning --> Undefined property: Data::$Spk_model C:\xampp\htdocs\nesnu\application\controllers\data.php 107
ERROR - 2021-12-15 04:38:23 --> Severity: error --> Exception: Call to a member function spk_prewed() on null C:\xampp\htdocs\nesnu\application\controllers\data.php 107
DEBUG - 2021-12-15 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:38:50 --> Total execution time: 0.0289
DEBUG - 2021-12-15 04:38:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:38:52 --> Total execution time: 0.0491
DEBUG - 2021-12-15 04:39:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:39:05 --> Severity: Warning --> Undefined property: Wedding::$Wedding_model C:\xampp\htdocs\nesnu\application\controllers\wedding.php 42
ERROR - 2021-12-15 04:39:05 --> Severity: error --> Exception: Call to a member function spk_prewed() on null C:\xampp\htdocs\nesnu\application\controllers\wedding.php 42
DEBUG - 2021-12-15 04:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:39:46 --> Total execution time: 0.0522
DEBUG - 2021-12-15 04:39:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:39:48 --> Total execution time: 0.0415
DEBUG - 2021-12-15 04:39:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:39:55 --> Severity: error --> Exception: Call to undefined method Wedding_model::spk_prewed() C:\xampp\htdocs\nesnu\application\controllers\wedding.php 46
DEBUG - 2021-12-15 04:40:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:40:15 --> Total execution time: 0.0286
DEBUG - 2021-12-15 04:40:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:40:16 --> Total execution time: 0.0294
DEBUG - 2021-12-15 04:40:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:40:25 --> Severity: error --> Exception: Too few arguments to function Wedding_model::spk_wedding(), 0 passed in C:\xampp\htdocs\nesnu\application\controllers\wedding.php on line 46 and exactly 2 expected C:\xampp\htdocs\nesnu\application\models\Wedding_model.php 10
DEBUG - 2021-12-15 04:43:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:43:33 --> Total execution time: 0.0403
DEBUG - 2021-12-15 04:43:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:43:34 --> Total execution time: 0.0394
DEBUG - 2021-12-15 04:47:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:47:09 --> Severity: error --> Exception: Too few arguments to function Wedding_model::spk_wedding(), 0 passed in C:\xampp\htdocs\nesnu\application\controllers\wedding.php on line 45 and exactly 1 expected C:\xampp\htdocs\nesnu\application\models\Wedding_model.php 11
DEBUG - 2021-12-15 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:48:41 --> Total execution time: 0.0480
DEBUG - 2021-12-15 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:48:53 --> Total execution time: 0.0616
DEBUG - 2021-12-15 04:49:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:49:43 --> Total execution time: 0.0401
DEBUG - 2021-12-15 04:49:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:49:53 --> Query error: Column 'phone' cannot be null - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Wia & Irvan', NULL, NULL, NULL, NULL, 'Lamaran', 'Acara 20x30cm', 'Acara 20x30cm', NULL)
DEBUG - 2021-12-15 04:53:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:53:59 --> Total execution time: 0.0549
DEBUG - 2021-12-15 04:54:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:54:00 --> Total execution time: 0.0511
DEBUG - 2021-12-15 04:54:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:54:54 --> Total execution time: 0.0430
DEBUG - 2021-12-15 04:55:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:55:13 --> Query error: Column 'phone' cannot be null - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Wia & Irvan', NULL, NULL, NULL, NULL, 'Lamaran', 'Acara 25x30cm', 'Acara 25x30cm', 'asdasdas')
DEBUG - 2021-12-15 04:57:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:57:24 --> Total execution time: 0.0291
DEBUG - 2021-12-15 04:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:57:30 --> Total execution time: 0.0390
DEBUG - 2021-12-15 04:57:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:57:46 --> Query error: Column 'name' cannot be null - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES (NULL, NULL, NULL, NULL, NULL, 'Lamaran', 'Acara 20x30cm', 'Acara 20x30cm', 'hjfghffgh')
DEBUG - 2021-12-15 04:58:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:58:07 --> Total execution time: 0.0318
DEBUG - 2021-12-15 04:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:58:09 --> Total execution time: 0.0296
DEBUG - 2021-12-15 04:58:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:58:17 --> Query error: Column 'phone' cannot be null - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Ani & Sutadi', NULL, NULL, NULL, NULL, ',Lamaran,Prewedding', 'Acara 20x30cm', 'Acara 20x30cm', 'asdasd')
DEBUG - 2021-12-15 04:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:58:44 --> Total execution time: 0.0292
DEBUG - 2021-12-15 04:58:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 04:58:46 --> Total execution time: 0.0437
DEBUG - 2021-12-15 04:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 04:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 04:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 04:59:17 --> Query error: Column 'place_p' cannot be null - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Wia & Irvan', '081321268444', '2015-01-11', NULL, '00:00:00', 'Lamaran', 'Acara 20x30cm', 'Acara 20x30cm', 'dasDASD')
DEBUG - 2021-12-15 05:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 05:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 05:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 05:01:07 --> Total execution time: 0.0335
DEBUG - 2021-12-15 06:30:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:30:10 --> Total execution time: 0.0506
DEBUG - 2021-12-15 06:30:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:30:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:30:23 --> Total execution time: 0.0460
DEBUG - 2021-12-15 06:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:35:01 --> Total execution time: 0.0424
DEBUG - 2021-12-15 06:35:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:35:46 --> Total execution time: 0.0563
DEBUG - 2021-12-15 06:36:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:36:34 --> Total execution time: 0.0401
DEBUG - 2021-12-15 06:41:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 06:41:17 --> Severity: error --> Exception: Too few arguments to function Wedding_model::spk_wedding(), 0 passed in C:\xampp\htdocs\nesnu\application\controllers\wedding.php on line 45 and exactly 1 expected C:\xampp\htdocs\nesnu\application\models\Wedding_model.php 11
DEBUG - 2021-12-15 06:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:44:50 --> Total execution time: 0.0443
DEBUG - 2021-12-15 06:44:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:44:53 --> Total execution time: 0.0433
DEBUG - 2021-12-15 06:45:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 06:45:03 --> Severity: error --> Exception: Too few arguments to function Wedding_model::spk_wedding(), 0 passed in C:\xampp\htdocs\nesnu\application\controllers\wedding.php on line 45 and exactly 1 expected C:\xampp\htdocs\nesnu\application\models\Wedding_model.php 11
DEBUG - 2021-12-15 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:46:07 --> Total execution time: 0.0292
DEBUG - 2021-12-15 06:46:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:46:07 --> Total execution time: 0.0302
DEBUG - 2021-12-15 06:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:46:19 --> Total execution time: 0.0301
DEBUG - 2021-12-15 06:48:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:48:24 --> Total execution time: 0.0404
DEBUG - 2021-12-15 06:48:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:48:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:48:34 --> Total execution time: 0.0462
DEBUG - 2021-12-15 06:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 06:48:44 --> Query error: Unknown column 'phone' in 'field list' - Invalid query: INSERT INTO `wedding` (`name`, `phone`, `date_w`, `w_akad`, `w_resepsi`, `place_w`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Dita. A & Yudi', '089624009667', '2015-02-01', '00:00:00', '00:00:00', '', 'aRI', 'riri', 'aji', 'asdasdasd')
DEBUG - 2021-12-15 06:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:49:29 --> Total execution time: 0.0292
DEBUG - 2021-12-15 06:49:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:49:31 --> Total execution time: 0.0457
DEBUG - 2021-12-15 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:49:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:49:44 --> Total execution time: 0.0454
DEBUG - 2021-12-15 06:51:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:51:56 --> Total execution time: 0.0465
DEBUG - 2021-12-15 06:53:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:53:29 --> Total execution time: 0.0382
DEBUG - 2021-12-15 06:53:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:53:30 --> Total execution time: 0.0478
DEBUG - 2021-12-15 06:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:53:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-15 06:53:31 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-15 06:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:53:33 --> Total execution time: 0.0427
DEBUG - 2021-12-15 06:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:53:34 --> Total execution time: 0.0505
DEBUG - 2021-12-15 06:54:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:54:06 --> Total execution time: 0.0434
DEBUG - 2021-12-15 06:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:54:07 --> Total execution time: 0.0408
DEBUG - 2021-12-15 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:54:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:54:42 --> Total execution time: 0.0463
DEBUG - 2021-12-15 06:54:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:54:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:54:53 --> Total execution time: 0.0430
DEBUG - 2021-12-15 06:55:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:55:37 --> Total execution time: 0.0424
DEBUG - 2021-12-15 06:55:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:55:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:55:46 --> Total execution time: 0.0444
DEBUG - 2021-12-15 06:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:56:02 --> Total execution time: 0.0445
DEBUG - 2021-12-15 06:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 06:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 06:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 06:56:13 --> Total execution time: 0.0507
DEBUG - 2021-12-15 07:06:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:06:07 --> Total execution time: 0.0491
DEBUG - 2021-12-15 07:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:10:15 --> Total execution time: 0.0467
DEBUG - 2021-12-15 07:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:11:09 --> Total execution time: 0.0452
DEBUG - 2021-12-15 07:11:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:11:26 --> Total execution time: 0.0289
DEBUG - 2021-12-15 07:11:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:11:56 --> Total execution time: 0.0288
DEBUG - 2021-12-15 07:12:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:12:11 --> Total execution time: 0.0295
DEBUG - 2021-12-15 07:12:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:12:17 --> Total execution time: 0.0388
DEBUG - 2021-12-15 07:13:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:13:46 --> Total execution time: 0.0530
DEBUG - 2021-12-15 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:14:31 --> Total execution time: 0.0297
DEBUG - 2021-12-15 07:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:28:03 --> Total execution time: 0.5222
DEBUG - 2021-12-15 07:28:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:28:10 --> Total execution time: 0.0452
DEBUG - 2021-12-15 07:30:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 1010
ERROR - 2021-12-15 07:30:05 --> Severity: Warning --> Undefined variable $date_s C:\xampp\htdocs\nesnu\application\views\data\index.php 1017
DEBUG - 2021-12-15 07:30:05 --> Total execution time: 0.0702
DEBUG - 2021-12-15 07:30:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:30:23 --> Total execution time: 0.0445
DEBUG - 2021-12-15 07:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:31:15 --> Total execution time: 0.0476
DEBUG - 2021-12-15 07:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:31:32 --> Total execution time: 0.0435
DEBUG - 2021-12-15 07:32:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:32:03 --> Total execution time: 0.0460
DEBUG - 2021-12-15 07:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:33:12 --> Total execution time: 0.0540
DEBUG - 2021-12-15 07:33:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:33:44 --> Total execution time: 0.0458
DEBUG - 2021-12-15 07:33:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:33:53 --> Total execution time: 0.0469
DEBUG - 2021-12-15 07:34:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:34:31 --> Total execution time: 0.0470
DEBUG - 2021-12-15 07:34:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:34:59 --> Total execution time: 0.0541
DEBUG - 2021-12-15 07:38:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:38:46 --> Total execution time: 0.0598
DEBUG - 2021-12-15 07:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:40:40 --> Total execution time: 0.0479
DEBUG - 2021-12-15 07:47:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:47:49 --> Total execution time: 0.0298
DEBUG - 2021-12-15 07:48:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:48:24 --> Total execution time: 0.0419
DEBUG - 2021-12-15 07:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:49:04 --> Total execution time: 0.0516
DEBUG - 2021-12-15 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:49:12 --> Total execution time: 0.0527
DEBUG - 2021-12-15 07:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:49:29 --> Total execution time: 0.0278
DEBUG - 2021-12-15 07:49:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:49:52 --> Total execution time: 0.0433
DEBUG - 2021-12-15 07:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:50:05 --> Total execution time: 0.0534
DEBUG - 2021-12-15 07:50:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:50:26 --> Total execution time: 0.0307
DEBUG - 2021-12-15 07:50:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:50:35 --> Total execution time: 0.0396
DEBUG - 2021-12-15 07:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:50:37 --> Total execution time: 0.0473
DEBUG - 2021-12-15 07:50:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 07:50:56 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\spk.php 107
DEBUG - 2021-12-15 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:51:01 --> Total execution time: 0.0545
DEBUG - 2021-12-15 07:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:58:31 --> Total execution time: 0.0310
DEBUG - 2021-12-15 07:58:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 07:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 07:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 07:58:40 --> Total execution time: 0.0420
DEBUG - 2021-12-15 08:00:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 08:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 08:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 08:00:36 --> Total execution time: 0.0296
DEBUG - 2021-12-15 08:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 08:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 08:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 08:01:06 --> Total execution time: 0.0293
DEBUG - 2021-12-15 08:01:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 08:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 08:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-15 08:01:21 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\spk.php 107
DEBUG - 2021-12-15 08:06:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 08:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 08:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 08:06:33 --> Total execution time: 0.0527
DEBUG - 2021-12-15 08:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 08:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 08:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 08:06:34 --> Total execution time: 0.0435
DEBUG - 2021-12-15 08:08:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 08:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 08:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 08:08:41 --> Total execution time: 0.0483
DEBUG - 2021-12-15 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 08:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 08:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 08:08:55 --> Total execution time: 0.0302
DEBUG - 2021-12-15 08:09:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-15 08:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-15 08:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-15 08:09:05 --> Total execution time: 0.0301
