<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-08-09 04:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:17:54 --> Total execution time: 0.1555
DEBUG - 2022-08-09 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:17:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:17:58 --> Total execution time: 0.1369
DEBUG - 2022-08-09 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:17:58 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:17:58 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:17:58 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:17:58 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:17:58 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:17:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:17:58 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:18:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:18:01 --> Total execution time: 0.0979
DEBUG - 2022-08-09 04:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:18:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:18:02 --> Total execution time: 0.1330
DEBUG - 2022-08-09 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:18:03 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:18:03 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:26:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:26:35 --> Total execution time: 0.1330
DEBUG - 2022-08-09 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:26:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:26:37 --> Total execution time: 0.1042
DEBUG - 2022-08-09 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:26:37 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:26:37 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:26:37 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:26:37 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:26:37 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:26:37 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:26:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:26:37 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:27:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:27:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:27:29 --> Total execution time: 0.0978
DEBUG - 2022-08-09 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:27:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:27:30 --> Total execution time: 0.0866
DEBUG - 2022-08-09 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:30 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:27:30 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:30 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:27:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:27:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:27:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:27:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:27:30 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:27:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:27:32 --> Total execution time: 0.1251
DEBUG - 2022-08-09 04:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:27:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:27:33 --> Total execution time: 0.0912
DEBUG - 2022-08-09 04:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:27:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:27:45 --> Total execution time: 0.1191
DEBUG - 2022-08-09 04:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:28:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:28:14 --> Total execution time: 0.1013
DEBUG - 2022-08-09 04:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:31:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:31:06 --> Total execution time: 0.1138
DEBUG - 2022-08-09 04:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:31:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:31:07 --> Total execution time: 0.1147
DEBUG - 2022-08-09 04:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:31:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:31:19 --> Total execution time: 0.1057
DEBUG - 2022-08-09 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:31:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:31:40 --> Total execution time: 0.1158
DEBUG - 2022-08-09 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:31:40 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:31:40 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:31:40 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:31:40 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:31:40 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:31:40 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:31:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:31:43 --> Total execution time: 0.1364
DEBUG - 2022-08-09 04:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:32:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:32:28 --> Total execution time: 0.1002
DEBUG - 2022-08-09 04:32:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:32:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:32:29 --> Total execution time: 0.1128
DEBUG - 2022-08-09 04:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:33:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:33:09 --> Total execution time: 0.0921
DEBUG - 2022-08-09 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:33:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:33:10 --> Total execution time: 0.0944
DEBUG - 2022-08-09 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:33:10 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:33:10 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:33:10 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:33:10 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 04:33:10 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:33:10 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:33:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:33:12 --> Total execution time: 0.1187
DEBUG - 2022-08-09 04:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:33:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:33:55 --> Total execution time: 0.0900
DEBUG - 2022-08-09 04:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:33:55 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:33:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:33:57 --> Total execution time: 0.0989
DEBUG - 2022-08-09 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:33:57 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:33:57 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 04:33:57 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:33:57 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:33:57 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:33:57 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:34:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:34:00 --> Total execution time: 0.1056
DEBUG - 2022-08-09 04:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:35:29 --> Total execution time: 0.0980
DEBUG - 2022-08-09 04:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:35:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:35:29 --> Total execution time: 0.0974
DEBUG - 2022-08-09 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:35:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:35:32 --> Total execution time: 0.1126
DEBUG - 2022-08-09 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:32 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:35:32 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:35:32 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:35:32 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:35:32 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 04:35:32 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:35:32 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:35:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:35:50 --> Total execution time: 0.0913
DEBUG - 2022-08-09 04:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:50 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:35:50 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:35:50 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:35:50 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:35:50 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:35:50 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:35:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:35:50 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:35:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:35:53 --> Total execution time: 0.1181
DEBUG - 2022-08-09 04:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:36:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:36:40 --> Total execution time: 0.1424
DEBUG - 2022-08-09 04:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:36:40 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:36:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:36:43 --> Total execution time: 0.1137
DEBUG - 2022-08-09 04:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:36:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:36:44 --> Total execution time: 0.0998
DEBUG - 2022-08-09 04:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:36:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:36:44 --> Total execution time: 0.0875
DEBUG - 2022-08-09 04:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:36:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:36:46 --> Total execution time: 0.1089
DEBUG - 2022-08-09 04:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:36:46 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:36:46 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:36:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:36:46 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 04:36:46 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:36:46 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:36:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:36:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:36:48 --> Total execution time: 0.1653
DEBUG - 2022-08-09 04:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:36:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:36:53 --> Total execution time: 0.1040
DEBUG - 2022-08-09 04:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:38:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:38:47 --> Total execution time: 0.1129
DEBUG - 2022-08-09 04:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:38:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:38:49 --> Total execution time: 0.1116
DEBUG - 2022-08-09 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:38:50 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:38:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:38:50 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:38:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:38:50 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:38:50 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:38:50 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:38:50 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:38:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:38:52 --> Total execution time: 0.1147
DEBUG - 2022-08-09 04:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:40:03 --> Total execution time: 0.1101
DEBUG - 2022-08-09 04:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:40:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:40:04 --> Total execution time: 0.1096
DEBUG - 2022-08-09 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:40:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:40:06 --> Total execution time: 0.1207
DEBUG - 2022-08-09 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:40:06 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:40:06 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:40:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:40:06 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:40:06 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:40:06 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:40:06 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:40:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:40:08 --> Total execution time: 0.1156
DEBUG - 2022-08-09 04:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:40:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:40:10 --> Total execution time: 0.1040
DEBUG - 2022-08-09 04:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:40:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:40:10 --> Total execution time: 0.1075
DEBUG - 2022-08-09 04:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:40:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:40:55 --> Total execution time: 0.1330
DEBUG - 2022-08-09 04:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:40:56 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:40:56 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:40:56 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 04:40:56 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:40:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:40:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:40:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:41:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:41:58 --> Total execution time: 0.1018
DEBUG - 2022-08-09 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:41:58 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:41:58 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:41:58 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:41:58 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:41:58 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:41:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:41:58 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:41:58 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:42:02 --> Total execution time: 0.1231
DEBUG - 2022-08-09 04:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:42:09 --> Total execution time: 0.1137
DEBUG - 2022-08-09 04:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:42:22 --> Total execution time: 0.1168
DEBUG - 2022-08-09 04:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:42:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:42:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:42:22 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:42:22 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:42:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:42:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:42:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:42:29 --> Total execution time: 0.1145
DEBUG - 2022-08-09 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:42:29 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:42:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:42:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:42:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:42:29 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:42:29 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 04:42:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:43:07 --> Total execution time: 0.1162
DEBUG - 2022-08-09 04:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:07 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:43:07 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:43:07 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:43:07 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:43:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:43:07 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:43:08 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:43:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:43:08 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:43:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:43:11 --> Total execution time: 0.1139
DEBUG - 2022-08-09 04:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:43:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:43:12 --> Total execution time: 0.1055
DEBUG - 2022-08-09 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:43:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:43:25 --> Total execution time: 0.1085
DEBUG - 2022-08-09 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:25 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:43:25 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:43:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:43:25 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:43:25 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:43:25 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:43:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:43:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:43:28 --> Total execution time: 0.1287
DEBUG - 2022-08-09 04:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:43:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:43:29 --> Total execution time: 0.1113
DEBUG - 2022-08-09 04:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:43:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:43:29 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:43:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:44:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:44:13 --> Total execution time: 0.1270
DEBUG - 2022-08-09 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:44:13 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:44:13 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:44:13 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:44:13 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:44:13 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:44:13 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:44:14 --> Total execution time: 0.1186
DEBUG - 2022-08-09 04:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:45:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:45:50 --> Total execution time: 0.1251
DEBUG - 2022-08-09 04:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:45:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:45:51 --> Total execution time: 0.0889
DEBUG - 2022-08-09 04:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:45:55 --> Total execution time: 0.1080
DEBUG - 2022-08-09 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:45:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:45:56 --> Total execution time: 0.1174
DEBUG - 2022-08-09 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:56 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:45:56 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:45:56 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:45:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:45:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:45:56 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:45:56 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:45:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:45:58 --> Total execution time: 0.1122
DEBUG - 2022-08-09 04:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:46:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:46:30 --> Total execution time: 0.0870
DEBUG - 2022-08-09 04:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:46:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:46:31 --> Total execution time: 0.0978
DEBUG - 2022-08-09 04:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:46:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:46:33 --> Total execution time: 0.1166
DEBUG - 2022-08-09 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:46:34 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:46:34 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:46:34 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:46:34 --> UTF-8 Support Enabled
ERROR - 2022-08-09 04:46:34 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:46:34 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:46:34 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:46:34 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:46:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:46:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:46:35 --> Total execution time: 0.1251
DEBUG - 2022-08-09 04:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:47:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:47:24 --> Total execution time: 0.1405
DEBUG - 2022-08-09 04:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:47:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:47:36 --> Total execution time: 0.1023
DEBUG - 2022-08-09 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:48:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:48:39 --> Total execution time: 0.0939
DEBUG - 2022-08-09 04:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:48:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:48:40 --> Total execution time: 0.1096
DEBUG - 2022-08-09 04:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:48:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:48:41 --> Total execution time: 0.1047
DEBUG - 2022-08-09 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:48:41 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:48:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:48:41 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:48:41 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:48:41 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:48:41 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:48:41 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:48:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:48:42 --> Total execution time: 0.1115
DEBUG - 2022-08-09 04:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:48:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:48:58 --> Total execution time: 0.1041
DEBUG - 2022-08-09 04:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:48:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:48:59 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:49:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:49:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:49:00 --> Total execution time: 0.1088
DEBUG - 2022-08-09 04:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:49:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:49:02 --> Total execution time: 0.1059
DEBUG - 2022-08-09 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:49:02 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:49:02 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 04:49:02 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:49:02 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:49:02 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:49:02 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:49:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:49:03 --> Total execution time: 0.1324
DEBUG - 2022-08-09 04:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:49:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:49:12 --> Total execution time: 0.1138
DEBUG - 2022-08-09 04:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:49:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:49:13 --> Total execution time: 0.1115
DEBUG - 2022-08-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:52:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:52:27 --> Total execution time: 0.1514
DEBUG - 2022-08-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:52:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:52:27 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:52:27 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:52:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:52:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:52:27 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 04:52:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:52:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:52:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:52:29 --> Total execution time: 0.1446
DEBUG - 2022-08-09 04:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:52:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:52:32 --> Total execution time: 0.1049
DEBUG - 2022-08-09 04:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:52:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:52:33 --> Total execution time: 0.1168
DEBUG - 2022-08-09 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:52:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:52:42 --> Total execution time: 0.1540
DEBUG - 2022-08-09 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:52:42 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:52:42 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:52:42 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 04:52:42 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 04:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 04:52:42 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 04:52:42 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 04:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 04:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 04:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 04:52:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 04:52:43 --> Total execution time: 0.1136
DEBUG - 2022-08-09 05:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:16:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:16:35 --> Total execution time: 0.1171
DEBUG - 2022-08-09 05:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:17:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:17:10 --> Total execution time: 0.1060
DEBUG - 2022-08-09 05:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:17:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:17:11 --> Total execution time: 0.1020
DEBUG - 2022-08-09 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:17:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:17:13 --> Total execution time: 0.1107
DEBUG - 2022-08-09 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:17:13 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:17:13 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:17:13 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:17:13 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:17:13 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:17:13 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:17:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:17:15 --> Total execution time: 0.1435
DEBUG - 2022-08-09 05:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:17:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:17:31 --> Total execution time: 0.1076
DEBUG - 2022-08-09 05:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:17:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:17:32 --> Total execution time: 0.0939
DEBUG - 2022-08-09 05:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:19:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:19:11 --> Total execution time: 0.1184
DEBUG - 2022-08-09 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:19:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:19:14 --> Total execution time: 0.1695
DEBUG - 2022-08-09 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:19:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:19:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:19:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:19:14 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 05:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:19:14 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 05:19:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:19:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:19:16 --> Total execution time: 0.1487
DEBUG - 2022-08-09 05:19:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:19:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:19:33 --> Total execution time: 0.1393
DEBUG - 2022-08-09 05:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:20:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:20:07 --> Total execution time: 0.1188
DEBUG - 2022-08-09 05:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:20:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:20:08 --> Total execution time: 0.1050
DEBUG - 2022-08-09 05:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:20:10 --> Total execution time: 0.1283
DEBUG - 2022-08-09 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:20:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:20:23 --> Total execution time: 0.1158
DEBUG - 2022-08-09 05:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:21:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:21:10 --> Total execution time: 0.1223
DEBUG - 2022-08-09 05:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:21:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:21:12 --> Total execution time: 0.1102
DEBUG - 2022-08-09 05:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:21:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:21:13 --> Total execution time: 0.1361
DEBUG - 2022-08-09 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:21:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:21:14 --> Total execution time: 0.1033
DEBUG - 2022-08-09 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:21:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:21:14 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 05:21:14 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 05:21:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:21:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:21:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:21:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:21:16 --> Total execution time: 0.1634
DEBUG - 2022-08-09 05:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:21:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:21:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:21:29 --> Total execution time: 0.0892
DEBUG - 2022-08-09 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:03 --> Total execution time: 0.1185
DEBUG - 2022-08-09 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:22:03 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:22:03 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 05:22:03 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:22:03 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:22:03 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:22:03 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 05:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:05 --> Total execution time: 0.1044
DEBUG - 2022-08-09 05:22:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:12 --> Total execution time: 0.2286
DEBUG - 2022-08-09 05:22:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:15 --> Total execution time: 0.1587
DEBUG - 2022-08-09 05:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:22 --> Total execution time: 0.1087
DEBUG - 2022-08-09 05:22:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:24 --> Total execution time: 0.1130
DEBUG - 2022-08-09 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:22:25 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:22:25 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:22:25 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 05:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:22:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:22:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:22:25 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 05:22:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:26 --> Total execution time: 0.1392
DEBUG - 2022-08-09 05:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:22:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:22:38 --> Total execution time: 0.1098
DEBUG - 2022-08-09 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:23:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:23:01 --> Total execution time: 0.1086
DEBUG - 2022-08-09 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:01 --> UTF-8 Support Enabled
ERROR - 2022-08-09 05:23:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:23:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:23:01 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:23:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:23:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:23:01 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 05:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:23:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:23:03 --> Total execution time: 0.1453
DEBUG - 2022-08-09 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:23:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:23:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:23:14 --> Total execution time: 0.1095
DEBUG - 2022-08-09 05:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:14 --> Total execution time: 0.1078
DEBUG - 2022-08-09 05:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:56:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:56:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:56:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:56:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:56:14 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 05:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:56:14 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 05:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:16 --> Total execution time: 0.1159
DEBUG - 2022-08-09 05:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:19 --> Total execution time: 0.1009
DEBUG - 2022-08-09 05:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:19 --> Total execution time: 0.0926
DEBUG - 2022-08-09 05:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:36 --> Total execution time: 0.1057
DEBUG - 2022-08-09 05:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:37 --> Total execution time: 0.1207
DEBUG - 2022-08-09 05:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:38 --> Total execution time: 0.1057
DEBUG - 2022-08-09 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:56:39 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 05:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:56:39 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:56:39 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:56:39 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:56:39 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:56:39 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 05:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:40 --> Total execution time: 0.1754
DEBUG - 2022-08-09 05:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:41 --> Total execution time: 0.1276
DEBUG - 2022-08-09 05:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:56:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:56:42 --> Total execution time: 0.1085
DEBUG - 2022-08-09 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:59:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:59:09 --> Total execution time: 0.1167
DEBUG - 2022-08-09 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 05:59:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 05:59:10 --> Total execution time: 0.1150
DEBUG - 2022-08-09 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 05:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:59:10 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 05:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 05:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:59:10 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:59:10 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 05:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 05:59:10 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:59:10 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 05:59:10 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:00:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:00:41 --> Total execution time: 0.1111
DEBUG - 2022-08-09 06:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:00:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:00:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:00:49 --> Total execution time: 0.1044
DEBUG - 2022-08-09 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:00:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:00:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:00:55 --> Total execution time: 0.1805
DEBUG - 2022-08-09 06:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:00:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:00:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:00:58 --> Total execution time: 0.1347
DEBUG - 2022-08-09 06:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:01:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:01:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:01:28 --> Total execution time: 0.1146
DEBUG - 2022-08-09 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:01:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:01:29 --> Total execution time: 0.1239
DEBUG - 2022-08-09 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:01:29 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:01:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:29 --> UTF-8 Support Enabled
ERROR - 2022-08-09 06:01:29 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:01:29 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:01:29 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:01:29 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 06:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:01:31 --> Total execution time: 0.1560
DEBUG - 2022-08-09 06:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:01:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:01:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:01:40 --> Total execution time: 0.1002
DEBUG - 2022-08-09 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:02:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:02:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:02:20 --> Total execution time: 0.1337
DEBUG - 2022-08-09 06:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:02:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:02:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:02:22 --> Total execution time: 0.1253
DEBUG - 2022-08-09 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:02:28 --> Total execution time: 0.0944
DEBUG - 2022-08-09 06:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:08 --> Total execution time: 0.1079
DEBUG - 2022-08-09 06:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:14 --> Total execution time: 0.0965
DEBUG - 2022-08-09 06:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:20 --> Total execution time: 0.1767
DEBUG - 2022-08-09 06:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:22 --> Total execution time: 0.0987
DEBUG - 2022-08-09 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:23 --> Total execution time: 0.1101
DEBUG - 2022-08-09 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:20:23 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:20:23 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:20:23 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:20:23 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 06:20:23 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 06:20:23 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:25 --> Total execution time: 0.1433
DEBUG - 2022-08-09 06:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:41 --> Total execution time: 0.0941
DEBUG - 2022-08-09 06:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:20:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:20:56 --> Total execution time: 0.1047
DEBUG - 2022-08-09 06:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:21:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:21:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:21:02 --> Total execution time: 0.1819
DEBUG - 2022-08-09 06:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:21:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:21:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:21:04 --> Total execution time: 0.1243
DEBUG - 2022-08-09 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:22:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:22:59 --> Total execution time: 0.1497
DEBUG - 2022-08-09 06:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:23:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:23:01 --> Total execution time: 0.1193
DEBUG - 2022-08-09 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:23:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:23:01 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 06:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:23:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:23:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:23:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:23:01 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:23:02 --> Total execution time: 0.1690
DEBUG - 2022-08-09 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:23:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:23:17 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `user` SET `password` = '$2y$10$tPWT6SdiR4tBONrgCBcTyO2KVnQepal0TvLcKNfvXIE4xmzPti0x6', `role_id` = 2, `is_active` = 1, `date_created` = 1660018997
WHERE `email` = Array
DEBUG - 2022-08-09 06:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:23:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:23:17 --> Total execution time: 0.0919
DEBUG - 2022-08-09 06:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:23:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:23:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:23:32 --> Total execution time: 0.1141
DEBUG - 2022-08-09 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:26:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:26:22 --> Total execution time: 0.1248
DEBUG - 2022-08-09 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:22 --> UTF-8 Support Enabled
ERROR - 2022-08-09 06:26:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:26:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:26:22 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:26:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:26:22 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:26:22 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 06:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:26:22 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:26:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:26:24 --> Total execution time: 0.1379
DEBUG - 2022-08-09 06:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:26:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:26:34 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `user` SET `password` = '$2y$10$fMlQqLbn8BxCO8TQRLQaGuSgYj/B/vXGzluArZexuZwyAdS6mCA.e', `role_id` = 2, `is_active` = 1, `date_created` = 1660019194
WHERE `email` = Array
DEBUG - 2022-08-09 06:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:26:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:26:34 --> Total execution time: 0.1451
DEBUG - 2022-08-09 06:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:28:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:28:51 --> Total execution time: 0.1048
DEBUG - 2022-08-09 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:28:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:28:52 --> Total execution time: 0.1036
DEBUG - 2022-08-09 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:28:52 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 06:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:28:52 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:28:52 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 06:28:52 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:28:52 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:28:52 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:28:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:28:53 --> Total execution time: 0.1599
DEBUG - 2022-08-09 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:29:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:29:05 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `user` SET `password` = '$2y$10$FCcS5YxoFgTeNo.Rdw3b0eWWlcXMNKJDQTFRh.gnwAsvNhNgVxLje', `role_id` = 2, `is_active` = 1, `date_created` = 1660019345
WHERE `email` = Array
DEBUG - 2022-08-09 06:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:29:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:29:05 --> Total execution time: 0.0869
DEBUG - 2022-08-09 06:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:30:16 --> Total execution time: 0.1388
DEBUG - 2022-08-09 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:30:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:30:17 --> Total execution time: 0.1039
DEBUG - 2022-08-09 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:30:17 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:30:17 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 06:30:17 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:30:17 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:30:17 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:30:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:30:17 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:30:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:30:22 --> Severity: error --> Exception: Too few arguments to function Auth::reset_password(), 0 passed in C:\xampp\htdocs\NESNUMOTO\integrity\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\NESNUMOTO\integrity\application\controllers\Auth.php 127
DEBUG - 2022-08-09 06:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:30:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:30:40 --> Total execution time: 0.1311
DEBUG - 2022-08-09 06:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:30:40 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:30:41 --> Total execution time: 0.1342
DEBUG - 2022-08-09 06:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:30:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:30:42 --> Total execution time: 0.0929
DEBUG - 2022-08-09 06:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:30:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:30:43 --> Total execution time: 0.0942
DEBUG - 2022-08-09 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:31:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:31:29 --> Total execution time: 0.1360
DEBUG - 2022-08-09 06:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:31:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:31:30 --> Total execution time: 0.1060
DEBUG - 2022-08-09 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:31:30 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 06:31:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:31:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:31:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:31:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:31:30 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 06:31:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:31:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:31:31 --> Total execution time: 0.1263
DEBUG - 2022-08-09 06:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:31:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:31:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:31:45 --> Total execution time: 0.1007
DEBUG - 2022-08-09 06:32:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:32:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:32:47 --> Total execution time: 0.1576
DEBUG - 2022-08-09 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:32:47 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:32:47 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:32:47 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 06:32:47 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:32:47 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:32:47 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:32:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:32:49 --> Total execution time: 0.1445
DEBUG - 2022-08-09 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:33:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:33:01 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `user` SET `password` = '$2y$10$xZ7RDCXgB8sZvHXSPbty5uLDSv2nR4fnCLyVPDlzygHGKut/rbc/O', `role_id` = 2, `is_active` = 1, `date_created` = 1660019581
WHERE `email` = Array
DEBUG - 2022-08-09 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:33:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:33:01 --> Total execution time: 0.1162
DEBUG - 2022-08-09 06:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:40:27 --> Total execution time: 0.1057
DEBUG - 2022-08-09 06:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:40:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:40:32 --> Total execution time: 0.1301
DEBUG - 2022-08-09 06:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:40:33 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:40:33 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:40:33 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:40:33 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:40:33 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 06:40:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:40:33 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:40:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:40:34 --> Severity: error --> Exception: Too few arguments to function Auth::change_password(), 0 passed in C:\xampp\htdocs\NESNUMOTO\integrity\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\NESNUMOTO\integrity\application\controllers\Auth.php 165
DEBUG - 2022-08-09 06:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:42:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:42:24 --> Total execution time: 0.1043
DEBUG - 2022-08-09 06:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:42:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:42:26 --> Total execution time: 0.1246
DEBUG - 2022-08-09 06:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:43:49 --> Total execution time: 0.1417
DEBUG - 2022-08-09 06:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:43:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:43:50 --> Total execution time: 0.1175
DEBUG - 2022-08-09 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:43:51 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:43:51 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:43:51 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:43:51 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 06:43:51 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:43:51 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:43:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:43:56 --> Total execution time: 0.1512
DEBUG - 2022-08-09 06:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:44:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:44:13 --> Severity: error --> Exception: Too few arguments to function Auth::change_password(), 0 passed in C:\xampp\htdocs\NESNUMOTO\integrity\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\NESNUMOTO\integrity\application\controllers\Auth.php 165
DEBUG - 2022-08-09 06:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:47:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:47:42 --> Total execution time: 0.0928
DEBUG - 2022-08-09 06:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:47:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:47:43 --> Total execution time: 0.1040
DEBUG - 2022-08-09 06:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:47:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:47:46 --> Total execution time: 0.1163
DEBUG - 2022-08-09 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:47:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:47:48 --> Total execution time: 0.1023
DEBUG - 2022-08-09 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:47:48 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:47:48 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:47:48 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 06:47:48 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 06:47:48 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:47:48 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:47:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:47:49 --> Total execution time: 0.1301
DEBUG - 2022-08-09 06:47:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:47:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:47:58 --> Severity: error --> Exception: Too few arguments to function Auth::change_password(), 0 passed in C:\xampp\htdocs\NESNUMOTO\integrity\system\core\CodeIgniter.php on line 532 and exactly 2 expected C:\xampp\htdocs\NESNUMOTO\integrity\application\controllers\Auth.php 165
DEBUG - 2022-08-09 06:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:48:56 --> Total execution time: 0.1380
DEBUG - 2022-08-09 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:48:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:48:57 --> Total execution time: 0.1164
DEBUG - 2022-08-09 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:48:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:48:58 --> Total execution time: 0.0953
DEBUG - 2022-08-09 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:49:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:49:09 --> Total execution time: 0.1143
DEBUG - 2022-08-09 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:49:09 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:49:09 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 06:49:09 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:49:09 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 06:49:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 06:49:09 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 06:49:09 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 06:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:49:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:49:12 --> Total execution time: 0.1071
DEBUG - 2022-08-09 06:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:49:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-09 06:49:21 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: UPDATE `user` SET `password` = '$2y$10$4vaKAzOy19868zGrTUM.nuep7/h97PZzAzTTDGBpIHq0FPZG4Jqca', `role_id` = 2, `is_active` = 1, `date_created` = 1660020561
WHERE `email` = Array
DEBUG - 2022-08-09 06:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:49:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:49:21 --> Total execution time: 0.1278
DEBUG - 2022-08-09 06:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:50:02 --> Total execution time: 0.1054
DEBUG - 2022-08-09 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 06:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 06:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 06:50:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 06:50:40 --> Total execution time: 0.1047
DEBUG - 2022-08-09 07:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:13:59 --> Total execution time: 0.1268
DEBUG - 2022-08-09 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:14:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:14:01 --> Total execution time: 0.0884
DEBUG - 2022-08-09 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:14:01 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:14:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:14:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:14:01 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:14:01 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:14:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:14:01 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 07:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:14:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:14:03 --> Total execution time: 0.1208
DEBUG - 2022-08-09 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:14:13 --> 404 Page Not Found: Password/index
DEBUG - 2022-08-09 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:14:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:14:36 --> Total execution time: 0.0939
DEBUG - 2022-08-09 07:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:15:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:15:04 --> 404 Page Not Found: Password/index
DEBUG - 2022-08-09 07:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:16:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:16:35 --> Total execution time: 0.1380
DEBUG - 2022-08-09 07:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:16:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:16:36 --> Total execution time: 0.1227
DEBUG - 2022-08-09 07:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:16:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:16:36 --> Total execution time: 0.1044
DEBUG - 2022-08-09 07:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:16:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:16:38 --> Total execution time: 0.1304
DEBUG - 2022-08-09 07:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:16:38 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:16:38 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:16:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:16:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:16:38 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 07:16:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:16:38 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:16:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:16:40 --> Total execution time: 0.1158
DEBUG - 2022-08-09 07:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:16:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:16:48 --> 404 Page Not Found: Password/index
DEBUG - 2022-08-09 07:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:17:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:17:48 --> Total execution time: 0.1076
DEBUG - 2022-08-09 07:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:17:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:17:55 --> Total execution time: 0.1013
DEBUG - 2022-08-09 07:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:17:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:17:56 --> Total execution time: 0.1133
DEBUG - 2022-08-09 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:17:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:17:57 --> Total execution time: 0.1368
DEBUG - 2022-08-09 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:17:57 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:17:57 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:17:57 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:17:57 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:17:57 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 07:17:57 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:17:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:17:59 --> Total execution time: 0.1032
DEBUG - 2022-08-09 07:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:18:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:18:42 --> Total execution time: 0.1203
DEBUG - 2022-08-09 07:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:18:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:18:42 --> Total execution time: 0.1102
DEBUG - 2022-08-09 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:18:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:18:44 --> Total execution time: 0.1284
DEBUG - 2022-08-09 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:18:44 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:18:44 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:18:44 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:18:44 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:18:44 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:18:44 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:18:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:18:47 --> Total execution time: 0.1294
DEBUG - 2022-08-09 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:18:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:18:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:18:59 --> Total execution time: 0.0907
DEBUG - 2022-08-09 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:20:59 --> Total execution time: 0.1379
DEBUG - 2022-08-09 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:20:59 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:20:59 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:20:59 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:20:59 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:20:59 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:20:59 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 07:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:01 --> Total execution time: 0.0935
DEBUG - 2022-08-09 07:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:10 --> Total execution time: 0.1286
DEBUG - 2022-08-09 07:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:26 --> Total execution time: 0.0954
DEBUG - 2022-08-09 07:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:32 --> Total execution time: 0.1995
DEBUG - 2022-08-09 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:21:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:21:34 --> Total execution time: 0.1026
DEBUG - 2022-08-09 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:22:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:22:16 --> Total execution time: 0.1357
DEBUG - 2022-08-09 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:22:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:22:16 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 07:22:16 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:22:16 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:22:16 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 07:22:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:22:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:22:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:22:19 --> Total execution time: 0.1305
DEBUG - 2022-08-09 07:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:22:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:22:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:22:36 --> Total execution time: 0.1018
DEBUG - 2022-08-09 07:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:23:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:23:14 --> Total execution time: 0.0963
DEBUG - 2022-08-09 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:23:15 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:23:15 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:23:15 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:23:15 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 07:23:15 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:23:15 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:23:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:23:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:23:17 --> Total execution time: 0.1547
DEBUG - 2022-08-09 07:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:23:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:23:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:23:25 --> Total execution time: 0.1174
DEBUG - 2022-08-09 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:23:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:23:33 --> Total execution time: 0.1331
DEBUG - 2022-08-09 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:23:33 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:33 --> UTF-8 Support Enabled
ERROR - 2022-08-09 07:23:33 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 07:23:33 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:23:33 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:23:33 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:23:33 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:23:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:23:36 --> Total execution time: 0.1194
DEBUG - 2022-08-09 07:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:23:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:23:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:23:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:23:53 --> Total execution time: 0.1043
DEBUG - 2022-08-09 07:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:24:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:24:08 --> Total execution time: 0.1090
DEBUG - 2022-08-09 07:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:24:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:24:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:24:11 --> Total execution time: 0.1024
DEBUG - 2022-08-09 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:24:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:24:13 --> Total execution time: 0.1294
DEBUG - 2022-08-09 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:24:13 --> UTF-8 Support Enabled
ERROR - 2022-08-09 07:24:13 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:24:13 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:24:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:24:13 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 07:24:13 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:24:13 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:24:13 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:25:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:25:37 --> Total execution time: 0.1019
DEBUG - 2022-08-09 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:25:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:25:48 --> Total execution time: 0.1092
DEBUG - 2022-08-09 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:25:48 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:25:48 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 07:25:48 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 07:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:25:48 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:25:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:25:49 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:25:49 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:26:10 --> Total execution time: 0.1136
DEBUG - 2022-08-09 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:26:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:26:11 --> Total execution time: 0.1040
DEBUG - 2022-08-09 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:26:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:26:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:26:11 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 07:26:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:26:11 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:26:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:26:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:26:30 --> Total execution time: 0.1372
DEBUG - 2022-08-09 07:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:33:16 --> Total execution time: 0.1346
DEBUG - 2022-08-09 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:34:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:34:35 --> Total execution time: 0.1094
DEBUG - 2022-08-09 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:34:35 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:34:35 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:34:35 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:34:35 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:34:35 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:34:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:34:35 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:34:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:34:36 --> Total execution time: 0.1148
DEBUG - 2022-08-09 07:34:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:34:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:34:38 --> Total execution time: 0.1573
DEBUG - 2022-08-09 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:34:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:34:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:34:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:34:38 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:34:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:34:38 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 07:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:34:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:34:44 --> Total execution time: 0.1366
DEBUG - 2022-08-09 07:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:34:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:34:47 --> Total execution time: 0.1085
DEBUG - 2022-08-09 07:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:34:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:34:50 --> Total execution time: 0.1043
DEBUG - 2022-08-09 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:34:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:34:51 --> Total execution time: 0.1093
DEBUG - 2022-08-09 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:34:51 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:51 --> UTF-8 Support Enabled
ERROR - 2022-08-09 07:34:51 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:34:51 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:34:51 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:34:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:34:51 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:34:51 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:02 --> Total execution time: 0.1046
DEBUG - 2022-08-09 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:05 --> Total execution time: 0.1012
DEBUG - 2022-08-09 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:05 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:05 --> UTF-8 Support Enabled
ERROR - 2022-08-09 07:35:05 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:05 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:35:05 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 07:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:05 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:35:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:05 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:06 --> Total execution time: 0.1168
DEBUG - 2022-08-09 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:08 --> Total execution time: 0.1079
DEBUG - 2022-08-09 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:08 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:35:08 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:35:08 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 07:35:08 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:35:08 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:08 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:35:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:08 --> Total execution time: 0.1020
DEBUG - 2022-08-09 07:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:26 --> Total execution time: 0.0968
DEBUG - 2022-08-09 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:27 --> Total execution time: 0.1124
DEBUG - 2022-08-09 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:27 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:35:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:28 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:28 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:35:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:35:28 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:35:28 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 07:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:31 --> Total execution time: 0.1212
DEBUG - 2022-08-09 07:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:34 --> Total execution time: 0.1015
DEBUG - 2022-08-09 07:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:35:35 --> Total execution time: 0.1416
DEBUG - 2022-08-09 07:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:48:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:48:11 --> Total execution time: 0.1080
DEBUG - 2022-08-09 07:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:48:12 --> UTF-8 Support Enabled
ERROR - 2022-08-09 07:48:12 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:48:12 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:48:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:48:12 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 07:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:48:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 07:48:12 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 07:48:12 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 07:48:12 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 07:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:49:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:49:10 --> Total execution time: 0.1119
DEBUG - 2022-08-09 07:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:49:27 --> Total execution time: 0.0909
DEBUG - 2022-08-09 07:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 07:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 07:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 07:49:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 07:49:28 --> Total execution time: 0.0907
DEBUG - 2022-08-09 08:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:19:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:19:20 --> Total execution time: 0.1543
DEBUG - 2022-08-09 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:19:21 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:19:21 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:19:21 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:19:21 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:19:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:19:21 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:19:21 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:19:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:19:22 --> Total execution time: 0.1272
DEBUG - 2022-08-09 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:29:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:29:56 --> Total execution time: 0.0992
DEBUG - 2022-08-09 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:29:56 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:29:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:29:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:29:56 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:29:56 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 08:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:29:56 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:29:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:29:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:30:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:30:05 --> Total execution time: 0.1130
DEBUG - 2022-08-09 08:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:30:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:30:06 --> Total execution time: 0.1008
DEBUG - 2022-08-09 08:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:30:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:30:29 --> Total execution time: 0.0880
DEBUG - 2022-08-09 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:30:30 --> Total execution time: 0.1000
DEBUG - 2022-08-09 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:30 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:30:30 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:30:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:30:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:30:30 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:30:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:30:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:30:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:30:33 --> Total execution time: 0.1259
DEBUG - 2022-08-09 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:30:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:30:39 --> Total execution time: 0.1401
DEBUG - 2022-08-09 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:30:40 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:30:40 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:30:40 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:30:40 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:30:40 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:30:40 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:30:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:30:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:30:44 --> Total execution time: 0.1138
DEBUG - 2022-08-09 08:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:31:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:31:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:31:38 --> Total execution time: 0.0983
DEBUG - 2022-08-09 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:31:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:31:40 --> Total execution time: 0.0847
DEBUG - 2022-08-09 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:40 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:31:40 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:31:40 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:40 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:31:40 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 08:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:31:40 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:31:40 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:31:40 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:31:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:31:43 --> Total execution time: 0.1093
DEBUG - 2022-08-09 08:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:32:39 --> Total execution time: 0.0998
DEBUG - 2022-08-09 08:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:32:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:32:40 --> Total execution time: 0.0969
DEBUG - 2022-08-09 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:32:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:32:53 --> Total execution time: 0.1056
DEBUG - 2022-08-09 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:32:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:32:53 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:32:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:32:53 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:32:53 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:32:53 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:32:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:32:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:32:56 --> Total execution time: 0.1127
DEBUG - 2022-08-09 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:32:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:32:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:32:57 --> Total execution time: 0.0828
DEBUG - 2022-08-09 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:32:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:32:59 --> Total execution time: 0.0886
DEBUG - 2022-08-09 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:32:59 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:32:59 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:32:59 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:32:59 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:32:59 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:32:59 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:33:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:33:21 --> Total execution time: 0.0976
DEBUG - 2022-08-09 08:34:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:34:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:34:13 --> Total execution time: 0.0963
DEBUG - 2022-08-09 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:34:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:34:14 --> Total execution time: 0.0871
DEBUG - 2022-08-09 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:34:14 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:14 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:34:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:34:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:34:14 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:34:14 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:34:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:34:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:34:14 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:34:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:34:17 --> Total execution time: 0.0975
DEBUG - 2022-08-09 08:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:34:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:34:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:34:24 --> Total execution time: 0.0919
DEBUG - 2022-08-09 08:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:34:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:34:27 --> Total execution time: 0.1115
DEBUG - 2022-08-09 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:27 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:34:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:34:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:34:27 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:34:27 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:34:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:34:27 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:34:27 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 08:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:34:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:34:28 --> Total execution time: 0.1062
DEBUG - 2022-08-09 08:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:35:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:35:53 --> Total execution time: 0.0928
DEBUG - 2022-08-09 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:36 --> Total execution time: 0.0858
DEBUG - 2022-08-09 08:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:40 --> Total execution time: 0.0939
DEBUG - 2022-08-09 08:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:47 --> Total execution time: 0.3006
DEBUG - 2022-08-09 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:50 --> Total execution time: 0.1384
DEBUG - 2022-08-09 08:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:52 --> Total execution time: 0.0966
DEBUG - 2022-08-09 08:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:36:52 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 08:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:36:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:53 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:36:53 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:36:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:36:53 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:36:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:36:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:36:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:36:55 --> Total execution time: 0.1104
DEBUG - 2022-08-09 08:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:38:12 --> Total execution time: 0.1152
DEBUG - 2022-08-09 08:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:38:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:38:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:38:15 --> Total execution time: 0.0848
DEBUG - 2022-08-09 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:38:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:38:16 --> Total execution time: 0.0907
DEBUG - 2022-08-09 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:38:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:38:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:38:16 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:38:16 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 08:38:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:38:16 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:38:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:38:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:38:18 --> Total execution time: 0.1012
DEBUG - 2022-08-09 08:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:38:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:38:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:38:22 --> Total execution time: 0.0903
DEBUG - 2022-08-09 08:38:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:38:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:38:23 --> Total execution time: 0.1097
DEBUG - 2022-08-09 08:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:47:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:47:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:47:45 --> Total execution time: 0.1567
DEBUG - 2022-08-09 08:47:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:47:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:47:47 --> Total execution time: 0.1241
DEBUG - 2022-08-09 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:47:47 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:47:47 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:47:47 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:47:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:47:47 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:47:47 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:47:47 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:47:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:47:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:48:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:48:21 --> Total execution time: 0.0830
DEBUG - 2022-08-09 08:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:48:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:48:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:48:30 --> Total execution time: 0.1238
DEBUG - 2022-08-09 08:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:49:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:49:01 --> Total execution time: 0.0990
DEBUG - 2022-08-09 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:49:02 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:49:02 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:49:02 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:49:02 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:49:02 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:49:02 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:49:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:49:23 --> Total execution time: 0.0887
DEBUG - 2022-08-09 08:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:49:27 --> Total execution time: 0.0916
DEBUG - 2022-08-09 08:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:49:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:49:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:49:34 --> Total execution time: 0.0882
DEBUG - 2022-08-09 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:49:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:49:41 --> Total execution time: 0.1152
DEBUG - 2022-08-09 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:49:41 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:49:41 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:49:41 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:49:41 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:49:41 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:49:41 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:49:45 --> Total execution time: 0.0882
DEBUG - 2022-08-09 08:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:50:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:50:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:50:17 --> Total execution time: 0.1609
DEBUG - 2022-08-09 08:50:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:50:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:50:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:50:39 --> Total execution time: 0.1064
DEBUG - 2022-08-09 08:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:50:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:50:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:50:54 --> Total execution time: 0.1019
DEBUG - 2022-08-09 08:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:51:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:51:00 --> Total execution time: 0.0861
DEBUG - 2022-08-09 08:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:51:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:51:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:51:16 --> Total execution time: 0.1036
DEBUG - 2022-08-09 08:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:52:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:52:30 --> Total execution time: 0.0960
DEBUG - 2022-08-09 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:52:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:52:32 --> Total execution time: 0.1189
DEBUG - 2022-08-09 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:52:32 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:52:32 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:52:32 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:52:32 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:52:32 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:52:32 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:52:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:52:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:52:34 --> Total execution time: 0.0998
DEBUG - 2022-08-09 08:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:52:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:52:51 --> Total execution time: 0.0906
DEBUG - 2022-08-09 08:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:53:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:53:04 --> Total execution time: 0.0975
DEBUG - 2022-08-09 08:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:53:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:53:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:53:11 --> Total execution time: 0.0978
DEBUG - 2022-08-09 08:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:54:20 --> Total execution time: 0.0922
DEBUG - 2022-08-09 08:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:54:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:54:22 --> Total execution time: 0.0925
DEBUG - 2022-08-09 08:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:54:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:54:25 --> Total execution time: 0.1152
DEBUG - 2022-08-09 08:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:25 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:54:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:54:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:54:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:54:25 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:54:25 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 08:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:54:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:54:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:54:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:54:32 --> Total execution time: 0.0898
DEBUG - 2022-08-09 08:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:54:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:54:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:54:52 --> Total execution time: 0.0890
DEBUG - 2022-08-09 08:55:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:55:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:55:20 --> Total execution time: 0.0868
DEBUG - 2022-08-09 08:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:55:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:55:21 --> Total execution time: 0.1045
DEBUG - 2022-08-09 08:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:55:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:55:22 --> Total execution time: 0.1194
DEBUG - 2022-08-09 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:55:23 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:55:23 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:55:23 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:55:23 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:55:23 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:55:23 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:55:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:55:25 --> Total execution time: 0.1504
DEBUG - 2022-08-09 08:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:55:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:55:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:55:37 --> Total execution time: 0.1080
DEBUG - 2022-08-09 08:55:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:55:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:55:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:55:46 --> Total execution time: 0.0918
DEBUG - 2022-08-09 08:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:56:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:57:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:57:03 --> Total execution time: 0.0856
DEBUG - 2022-08-09 08:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:57:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:57:50 --> Total execution time: 0.0913
DEBUG - 2022-08-09 08:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:57:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:57:50 --> Total execution time: 0.0873
DEBUG - 2022-08-09 08:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:57:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:57:53 --> Total execution time: 0.1124
DEBUG - 2022-08-09 08:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:58:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:58:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:58:00 --> Total execution time: 0.0848
DEBUG - 2022-08-09 08:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:58:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:58:06 --> Total execution time: 0.1230
DEBUG - 2022-08-09 08:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:58:06 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:06 --> UTF-8 Support Enabled
ERROR - 2022-08-09 08:58:06 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 08:58:06 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:58:06 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:58:06 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:58:06 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:58:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:58:08 --> Total execution time: 0.0916
DEBUG - 2022-08-09 08:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:59:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:59:02 --> Total execution time: 0.1168
DEBUG - 2022-08-09 08:59:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:59:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:59:04 --> Total execution time: 0.0934
DEBUG - 2022-08-09 08:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:59:04 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:59:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:59:05 --> Total execution time: 0.1856
DEBUG - 2022-08-09 08:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:59:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:59:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:59:13 --> Total execution time: 0.0914
DEBUG - 2022-08-09 08:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:59:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:59:44 --> Total execution time: 0.1092
DEBUG - 2022-08-09 08:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:59:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:59:45 --> Total execution time: 0.0923
DEBUG - 2022-08-09 08:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:59:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:59:46 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 08:59:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:59:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 08:59:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 08:59:46 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 08:59:46 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 08:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 08:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 08:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 08:59:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 08:59:47 --> Total execution time: 0.1453
DEBUG - 2022-08-09 09:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:00:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:00:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:00:01 --> Total execution time: 0.0908
DEBUG - 2022-08-09 09:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:00:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:00:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:00:07 --> Total execution time: 0.1350
DEBUG - 2022-08-09 09:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:00:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:00:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:00:14 --> Total execution time: 0.1509
DEBUG - 2022-08-09 09:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:00:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:00:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:00:16 --> Total execution time: 0.0917
DEBUG - 2022-08-09 09:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:01:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:01:00 --> Total execution time: 0.1894
DEBUG - 2022-08-09 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:01:00 --> UTF-8 Support Enabled
ERROR - 2022-08-09 09:01:00 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:01:00 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:01:00 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:01:00 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:01:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:01:00 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:01:00 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:05:35 --> Total execution time: 0.1385
DEBUG - 2022-08-09 09:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:05:41 --> Total execution time: 0.1562
DEBUG - 2022-08-09 09:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:05:44 --> Total execution time: 0.1301
DEBUG - 2022-08-09 09:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:50 --> Total execution time: 0.0998
DEBUG - 2022-08-09 09:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:05:53 --> Total execution time: 0.0895
DEBUG - 2022-08-09 09:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:05:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:05:55 --> Total execution time: 0.1205
DEBUG - 2022-08-09 09:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:22 --> Total execution time: 0.1017
DEBUG - 2022-08-09 09:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:23 --> Total execution time: 0.1113
DEBUG - 2022-08-09 09:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:24 --> Total execution time: 0.0977
DEBUG - 2022-08-09 09:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:27 --> Total execution time: 0.0959
DEBUG - 2022-08-09 09:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:30 --> Total execution time: 0.1068
DEBUG - 2022-08-09 09:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:32 --> Total execution time: 0.1004
DEBUG - 2022-08-09 09:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:33 --> Total execution time: 0.1004
DEBUG - 2022-08-09 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:34 --> Total execution time: 0.1382
DEBUG - 2022-08-09 09:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:37 --> Total execution time: 0.0825
DEBUG - 2022-08-09 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:38 --> Total execution time: 0.1018
DEBUG - 2022-08-09 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:07:38 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:07:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:07:38 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:07:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:07:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:07:38 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:42 --> Total execution time: 0.1050
DEBUG - 2022-08-09 09:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:07:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:07:59 --> Total execution time: 0.0970
DEBUG - 2022-08-09 09:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:08:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:08:01 --> Total execution time: 0.1220
DEBUG - 2022-08-09 09:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:08:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:08:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:08:02 --> Total execution time: 0.0848
DEBUG - 2022-08-09 09:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:08:03 --> Total execution time: 0.0921
DEBUG - 2022-08-09 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:29 --> Total execution time: 0.1043
DEBUG - 2022-08-09 09:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:30 --> Total execution time: 0.0844
DEBUG - 2022-08-09 09:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:31 --> Total execution time: 0.0895
DEBUG - 2022-08-09 09:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:10:32 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:10:32 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:10:32 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:10:32 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:10:32 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:10:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:10:32 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:34 --> Total execution time: 0.1282
DEBUG - 2022-08-09 09:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:44 --> Total execution time: 0.1749
DEBUG - 2022-08-09 09:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:50 --> Total execution time: 0.0857
DEBUG - 2022-08-09 09:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:53 --> Total execution time: 0.0921
DEBUG - 2022-08-09 09:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:53 --> UTF-8 Support Enabled
ERROR - 2022-08-09 09:10:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:10:53 --> UTF-8 Support Enabled
ERROR - 2022-08-09 09:10:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:10:53 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:10:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:10:53 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 09:10:53 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:10:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:10:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:10:56 --> Total execution time: 0.1320
DEBUG - 2022-08-09 09:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:12 --> Total execution time: 0.1146
DEBUG - 2022-08-09 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:30 --> Total execution time: 0.1303
DEBUG - 2022-08-09 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:11:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:11:30 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:11:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:11:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:11:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:11:30 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 09:11:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:31 --> Total execution time: 0.1123
DEBUG - 2022-08-09 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:32 --> Total execution time: 0.0919
DEBUG - 2022-08-09 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:53 --> Total execution time: 0.1025
DEBUG - 2022-08-09 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:53 --> UTF-8 Support Enabled
ERROR - 2022-08-09 09:11:53 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:11:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:11:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:11:53 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:11:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:11:53 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 09:11:53 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:56 --> Total execution time: 0.1195
DEBUG - 2022-08-09 09:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:11:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:11:57 --> Total execution time: 0.0958
DEBUG - 2022-08-09 09:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:12:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:12:37 --> Total execution time: 0.0994
DEBUG - 2022-08-09 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:12:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:12:38 --> Total execution time: 0.0839
DEBUG - 2022-08-09 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:12:38 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 09:12:38 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:12:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:12:38 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 09:12:38 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:12:38 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:12:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:12:41 --> Total execution time: 0.0898
DEBUG - 2022-08-09 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:12:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:12:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:12:43 --> Total execution time: 0.1070
DEBUG - 2022-08-09 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:12:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:12:49 --> Total execution time: 0.0888
DEBUG - 2022-08-09 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:12:49 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:12:49 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:12:49 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:12:49 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:12:49 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:12:49 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:13:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:13:46 --> Total execution time: 0.1128
DEBUG - 2022-08-09 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:46 --> UTF-8 Support Enabled
ERROR - 2022-08-09 09:13:46 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 09:13:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:13:46 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:13:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:13:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:13:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:13:46 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:13:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:13:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:13:48 --> Total execution time: 0.0991
DEBUG - 2022-08-09 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:14:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:14:17 --> Total execution time: 0.1200
DEBUG - 2022-08-09 09:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:17:54 --> Total execution time: 0.1019
DEBUG - 2022-08-09 09:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:17:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:17:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:17:59 --> Total execution time: 0.0872
DEBUG - 2022-08-09 09:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:18:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:18:03 --> Total execution time: 0.1113
DEBUG - 2022-08-09 09:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:18:03 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:04 --> UTF-8 Support Enabled
ERROR - 2022-08-09 09:18:04 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:18:04 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:18:04 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:18:04 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-09 09:18:04 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:18:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:18:06 --> Total execution time: 0.0964
DEBUG - 2022-08-09 09:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:18:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:18:33 --> Total execution time: 0.1732
DEBUG - 2022-08-09 09:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:18:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:18:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:18:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:18:40 --> Total execution time: 0.1065
DEBUG - 2022-08-09 09:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:18:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:18:41 --> Total execution time: 0.0937
DEBUG - 2022-08-09 09:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:18:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:18:50 --> Total execution time: 0.1078
DEBUG - 2022-08-09 09:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:24:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:24:47 --> Total execution time: 0.1089
DEBUG - 2022-08-09 09:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:24:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:24:48 --> Total execution time: 0.0853
DEBUG - 2022-08-09 09:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:24:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:24:49 --> Total execution time: 0.0913
DEBUG - 2022-08-09 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:24:50 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:24:50 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:24:50 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:24:50 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:24:50 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:24:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:24:50 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:24:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:24:52 --> Total execution time: 0.1024
DEBUG - 2022-08-09 09:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:24:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:24:52 --> Total execution time: 0.1048
DEBUG - 2022-08-09 09:24:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:24:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:24:57 --> Total execution time: 0.0856
DEBUG - 2022-08-09 09:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:24:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:24:59 --> Total execution time: 0.1178
DEBUG - 2022-08-09 09:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:25:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:25:00 --> Total execution time: 0.0897
DEBUG - 2022-08-09 09:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:25:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:25:01 --> Total execution time: 0.0915
DEBUG - 2022-08-09 09:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:25:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:25:05 --> Total execution time: 0.1255
DEBUG - 2022-08-09 09:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:25:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:25:08 --> Total execution time: 0.1114
DEBUG - 2022-08-09 09:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:25:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:25:10 --> Total execution time: 0.0971
DEBUG - 2022-08-09 09:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:25:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:25:10 --> Total execution time: 0.1095
DEBUG - 2022-08-09 09:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:25:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:25:52 --> Total execution time: 0.1160
DEBUG - 2022-08-09 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:25:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:25:54 --> Total execution time: 0.0889
DEBUG - 2022-08-09 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:25:54 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:25:54 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:25:54 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-09 09:25:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:25:54 --> UTF-8 Support Enabled
ERROR - 2022-08-09 09:25:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:25:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:27:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:27:26 --> Total execution time: 0.0884
DEBUG - 2022-08-09 09:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:27:44 --> Total execution time: 0.1024
DEBUG - 2022-08-09 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:27:44 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:27:44 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-09 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:27:44 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-09 09:27:44 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:27:44 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-09 09:27:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-09 09:27:44 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-09 09:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:27:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:27:46 --> Total execution time: 0.1322
DEBUG - 2022-08-09 09:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:27:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-09 09:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-09 09:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-09 09:27:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-09 09:27:55 --> Total execution time: 0.0905
