<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-13 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:20:19 --> No URI present. Default controller set.
DEBUG - 2022-01-13 09:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:20:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:20:19 --> Total execution time: 0.0301
DEBUG - 2022-01-13 09:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:20:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-13 09:20:19 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-13 09:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:22:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:22:29 --> Total execution time: 0.0060
DEBUG - 2022-01-13 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:37:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:37:00 --> Total execution time: 0.1631
DEBUG - 2022-01-13 09:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:38:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:38:31 --> Total execution time: 0.0319
DEBUG - 2022-01-13 09:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:38:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:38:33 --> Total execution time: 0.0038
DEBUG - 2022-01-13 09:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:38:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:38:35 --> Total execution time: 0.0035
DEBUG - 2022-01-13 09:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:38:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:38:37 --> Total execution time: 0.0037
DEBUG - 2022-01-13 09:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:44:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:44:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:44:53 --> Total execution time: 0.0063
DEBUG - 2022-01-13 09:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:57:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 09:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 09:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 09:57:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 09:57:27 --> Total execution time: 0.0060
DEBUG - 2022-01-13 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:03:49 --> Total execution time: 0.0055
DEBUG - 2022-01-13 10:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:06:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:06:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:06:57 --> Total execution time: 0.0049
DEBUG - 2022-01-13 10:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:14:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:14:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:14:46 --> Total execution time: 0.0077
DEBUG - 2022-01-13 10:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:22:03 --> Total execution time: 0.0064
DEBUG - 2022-01-13 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:24:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:25:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:25:00 --> Total execution time: 0.0053
DEBUG - 2022-01-13 10:31:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:31:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:31:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:31:37 --> Total execution time: 0.0064
DEBUG - 2022-01-13 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:34:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:34:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:34:20 --> Total execution time: 0.0050
DEBUG - 2022-01-13 10:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:44:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:44:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:44:06 --> Total execution time: 0.0066
DEBUG - 2022-01-13 10:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:47:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:47:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:47:06 --> Total execution time: 0.0050
DEBUG - 2022-01-13 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:57:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 10:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 10:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 10:57:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 10:57:26 --> Total execution time: 0.0066
DEBUG - 2022-01-13 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:14:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:14:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:14:37 --> Total execution time: 0.0064
DEBUG - 2022-01-13 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:17:54 --> No URI present. Default controller set.
DEBUG - 2022-01-13 11:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:17:54 --> Total execution time: 0.0314
DEBUG - 2022-01-13 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-13 11:17:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-13 11:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-13 11:17:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-01-13 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:19:00 --> Total execution time: 0.0058
DEBUG - 2022-01-13 11:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:26:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:26:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:26:09 --> Total execution time: 0.0056
DEBUG - 2022-01-13 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:30:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:30:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:30:58 --> Total execution time: 0.0057
DEBUG - 2022-01-13 11:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:31:44 --> No URI present. Default controller set.
DEBUG - 2022-01-13 11:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:31:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:31:44 --> Total execution time: 0.0067
DEBUG - 2022-01-13 11:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:31:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-13 11:31:44 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-13 11:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:37:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:37:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:37:52 --> Total execution time: 0.0055
DEBUG - 2022-01-13 11:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:40:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:40:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:40:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:40:42 --> Total execution time: 0.0047
DEBUG - 2022-01-13 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:45:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:45:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:45:05 --> Total execution time: 0.0059
DEBUG - 2022-01-13 11:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:51:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:51:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:51:25 --> Total execution time: 0.0063
DEBUG - 2022-01-13 11:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 11:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 11:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 11:51:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 11:51:29 --> Total execution time: 0.1507
DEBUG - 2022-01-13 13:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:22:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:22:22 --> Total execution time: 0.0434
DEBUG - 2022-01-13 13:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:27:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:27:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:27:00 --> Total execution time: 0.0054
DEBUG - 2022-01-13 13:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:31:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:31:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:31:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:31:38 --> Total execution time: 0.0068
DEBUG - 2022-01-13 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:44:20 --> Total execution time: 0.0067
DEBUG - 2022-01-13 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:48:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:48:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:48:11 --> Total execution time: 0.0068
DEBUG - 2022-01-13 13:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:52:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:52:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:52:00 --> Total execution time: 0.0062
DEBUG - 2022-01-13 13:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:55:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:55:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:55:14 --> Total execution time: 0.0062
DEBUG - 2022-01-13 13:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:58:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:58:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:58:10 --> Total execution time: 0.0061
DEBUG - 2022-01-13 13:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:59:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 13:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 13:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 13:59:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 13:59:45 --> Total execution time: 0.0048
DEBUG - 2022-01-13 14:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:02:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:02:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:02:46 --> Total execution time: 0.0051
DEBUG - 2022-01-13 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:05:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:05:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:05:08 --> Total execution time: 0.0059
DEBUG - 2022-01-13 14:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:06:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:06:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:06:54 --> Total execution time: 0.0046
DEBUG - 2022-01-13 14:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:10:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:10:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:10:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:10:20 --> Total execution time: 0.0069
DEBUG - 2022-01-13 14:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:10:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:10:24 --> Total execution time: 0.1864
DEBUG - 2022-01-13 14:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:20:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:20:26 --> Total execution time: 0.0346
DEBUG - 2022-01-13 14:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:26:10 --> Total execution time: 0.0061
DEBUG - 2022-01-13 14:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:27:33 --> No URI present. Default controller set.
DEBUG - 2022-01-13 14:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:27:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:27:33 --> Total execution time: 0.0304
DEBUG - 2022-01-13 14:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:27:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-13 14:27:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-13 14:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:27:33 --> No URI present. Default controller set.
DEBUG - 2022-01-13 14:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:27:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:27:33 --> Total execution time: 0.0030
DEBUG - 2022-01-13 14:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:27:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:27:42 --> Total execution time: 0.0050
DEBUG - 2022-01-13 14:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:27:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:27:46 --> Total execution time: 0.2003
DEBUG - 2022-01-13 14:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:28:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:28:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:28:46 --> Total execution time: 0.0043
DEBUG - 2022-01-13 14:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:32:43 --> Total execution time: 0.0346
DEBUG - 2022-01-13 14:39:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:39:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:39:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:39:11 --> Total execution time: 0.0061
DEBUG - 2022-01-13 14:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:42:09 --> Total execution time: 0.0057
DEBUG - 2022-01-13 14:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:48:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:48:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:48:14 --> Total execution time: 0.0067
DEBUG - 2022-01-13 14:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:57:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:57:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:57:00 --> Total execution time: 0.0063
DEBUG - 2022-01-13 14:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:59:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 14:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 14:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 14:59:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 14:59:38 --> Total execution time: 0.0049
DEBUG - 2022-01-13 15:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:02:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:02:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:02:51 --> Total execution time: 0.0056
DEBUG - 2022-01-13 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:02:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:02:57 --> Total execution time: 0.1408
DEBUG - 2022-01-13 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:03:49 --> Total execution time: 0.0058
DEBUG - 2022-01-13 15:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:07:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:07:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:07:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:07:43 --> Total execution time: 0.0050
DEBUG - 2022-01-13 15:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:11:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:11:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:11:51 --> Total execution time: 0.0058
DEBUG - 2022-01-13 15:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:16:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:16:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:16:03 --> Total execution time: 0.0062
DEBUG - 2022-01-13 15:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:18:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:18:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:18:06 --> Total execution time: 0.0055
DEBUG - 2022-01-13 15:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:22:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:22:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:22:59 --> Total execution time: 0.0056
DEBUG - 2022-01-13 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:28:25 --> Total execution time: 0.0062
DEBUG - 2022-01-13 15:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:30:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:30:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:30:52 --> Total execution time: 0.0059
DEBUG - 2022-01-13 15:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:36:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 15:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 15:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 15:36:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 15:36:18 --> Total execution time: 0.0062
DEBUG - 2022-01-13 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:15:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:15:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:15:25 --> Total execution time: 0.0067
DEBUG - 2022-01-13 16:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:19:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:19:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:19:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:19:55 --> Total execution time: 0.0060
DEBUG - 2022-01-13 16:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:22:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:22:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:22:25 --> Total execution time: 0.0055
DEBUG - 2022-01-13 16:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:27:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:27:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:27:21 --> Total execution time: 0.0057
DEBUG - 2022-01-13 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:31:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:31:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:31:37 --> Total execution time: 0.0055
DEBUG - 2022-01-13 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:33:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:33:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:33:45 --> Total execution time: 0.0051
DEBUG - 2022-01-13 16:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:38:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:38:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:38:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:38:16 --> Total execution time: 0.0067
DEBUG - 2022-01-13 16:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:42:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:42:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:42:16 --> Total execution time: 0.0056
DEBUG - 2022-01-13 16:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:44:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:44:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:44:07 --> Total execution time: 0.0057
DEBUG - 2022-01-13 16:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:48:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:48:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:48:02 --> Total execution time: 0.0060
DEBUG - 2022-01-13 16:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:52:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:52:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:52:32 --> Total execution time: 0.0058
DEBUG - 2022-01-13 16:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:55:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:55:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:55:38 --> Total execution time: 0.0048
DEBUG - 2022-01-13 16:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-13 16:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-13 16:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-13 16:55:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-13 16:55:41 --> Total execution time: 0.1453
