<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-19 14:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 14:47:07 --> No URI present. Default controller set.
DEBUG - 2022-03-19 14:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 14:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-19 14:47:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 14:47:07 --> Total execution time: 0.0340
DEBUG - 2022-03-19 18:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-19 18:45:17 --> No URI present. Default controller set.
DEBUG - 2022-03-19 18:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-19 18:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-19 18:45:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-19 18:45:17 --> Total execution time: 0.0296
