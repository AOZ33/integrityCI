<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-26 15:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:10 --> No URI present. Default controller set.
DEBUG - 2022-03-26 15:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:43:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:43:10 --> Total execution time: 0.0314
DEBUG - 2022-03-26 15:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:10 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-26 15:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:10 --> 404 Page Not Found: Js/jquery.min.js
ERROR - 2022-03-26 15:43:10 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-26 15:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:10 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-26 15:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:11 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-26 15:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:11 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-26 15:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:11 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-26 15:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:11 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-26 15:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:11 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-26 15:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:43:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:43:17 --> Total execution time: 0.0054
DEBUG - 2022-03-26 15:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:43:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:43:17 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-26 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:44:13 --> Total execution time: 0.0043
DEBUG - 2022-03-26 15:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:44:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 15:44:13 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-26 15:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:44:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:44:17 --> Total execution time: 0.0135
DEBUG - 2022-03-26 15:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:44:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:44:19 --> Total execution time: 0.0043
DEBUG - 2022-03-26 15:44:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:44:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:44:21 --> Total execution time: 0.0057
DEBUG - 2022-03-26 15:44:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:44:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:44:39 --> Total execution time: 0.0167
DEBUG - 2022-03-26 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 15:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 15:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 15:49:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 15:49:30 --> Total execution time: 0.0330
DEBUG - 2022-03-26 16:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:01:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:01:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:01:59 --> Total execution time: 0.0055
DEBUG - 2022-03-26 16:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:06:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:06:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:06:21 --> Total execution time: 0.0061
DEBUG - 2022-03-26 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:32 --> No URI present. Default controller set.
DEBUG - 2022-03-26 16:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:44:32 --> Total execution time: 0.0307
DEBUG - 2022-03-26 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-26 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:32 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-26 16:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:32 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-26 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:33 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-03-26 16:44:33 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-26 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:33 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-26 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:33 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-26 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:33 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-26 16:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:33 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-26 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:44:37 --> Total execution time: 0.0049
DEBUG - 2022-03-26 16:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-26 16:44:38 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-26 16:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:44:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:44:40 --> Total execution time: 0.0117
DEBUG - 2022-03-26 16:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:44:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:44:50 --> Total execution time: 0.0135
DEBUG - 2022-03-26 16:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:45:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:45:08 --> Total execution time: 0.0146
DEBUG - 2022-03-26 16:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:45:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:45:13 --> Total execution time: 0.0136
DEBUG - 2022-03-26 16:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-26 16:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-26 16:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-26 16:45:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-26 16:45:25 --> Total execution time: 0.0151
