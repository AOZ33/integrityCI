<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-27 09:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 09:30:31 --> No URI present. Default controller set.
DEBUG - 2022-01-27 09:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 09:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 09:30:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 09:30:31 --> Total execution time: 0.0308
DEBUG - 2022-01-27 09:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 09:30:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-27 09:30:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-27 09:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 09:30:33 --> No URI present. Default controller set.
DEBUG - 2022-01-27 09:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 09:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 09:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 09:30:33 --> Total execution time: 0.0035
DEBUG - 2022-01-27 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 09:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 09:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 09:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 09:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 09:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 09:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 09:30:42 --> Total execution time: 0.0067
DEBUG - 2022-01-27 09:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 09:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 09:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 09:33:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-27 09:33:27 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 130160480 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-01-27 09:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 09:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 09:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 09:33:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 09:33:30 --> Total execution time: 0.0043
DEBUG - 2022-01-27 10:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:16:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:16:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:16:29 --> Total execution time: 0.0070
DEBUG - 2022-01-27 10:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:24:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:24:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:24:37 --> Total execution time: 0.0063
DEBUG - 2022-01-27 10:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:27:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:27:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:27:15 --> Total execution time: 0.0049
DEBUG - 2022-01-27 10:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:36:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:36:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:36:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:36:22 --> Total execution time: 0.0061
DEBUG - 2022-01-27 10:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:42:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:42:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:42:01 --> Total execution time: 0.0067
DEBUG - 2022-01-27 10:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:51:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:51:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:51:28 --> Total execution time: 0.0068
DEBUG - 2022-01-27 10:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:58:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 10:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 10:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 10:58:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 10:58:33 --> Total execution time: 0.0057
DEBUG - 2022-01-27 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:07:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:07:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:07:16 --> Total execution time: 0.0064
DEBUG - 2022-01-27 11:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:14:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:14:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:14:48 --> Total execution time: 0.0067
DEBUG - 2022-01-27 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:19:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:19:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:19:52 --> Total execution time: 0.0069
DEBUG - 2022-01-27 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:27:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:27:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:27:54 --> Total execution time: 0.0064
DEBUG - 2022-01-27 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:41:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:41:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:41:17 --> Total execution time: 0.0062
DEBUG - 2022-01-27 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 11:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 11:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 11:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 11:58:56 --> Total execution time: 0.0057
DEBUG - 2022-01-27 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 13:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 13:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 13:09:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-27 13:09:52 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 131741648 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-01-27 13:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 13:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 13:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 13:25:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 13:25:01 --> Total execution time: 0.0370
DEBUG - 2022-01-27 14:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:28:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:28:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:28:15 --> Total execution time: 0.0070
DEBUG - 2022-01-27 14:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:36:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:36:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:36:39 --> Total execution time: 0.0073
DEBUG - 2022-01-27 14:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:43:35 --> Total execution time: 0.0061
DEBUG - 2022-01-27 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:51:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:51:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:51:51 --> Total execution time: 0.0056
DEBUG - 2022-01-27 14:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:55:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 14:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 14:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 14:55:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 14:55:23 --> Total execution time: 0.0060
DEBUG - 2022-01-27 15:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:01:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:01:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:01:37 --> Total execution time: 0.0061
DEBUG - 2022-01-27 15:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:07:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:07:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:07:16 --> Total execution time: 0.0054
DEBUG - 2022-01-27 15:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:11:01 --> Total execution time: 0.0062
DEBUG - 2022-01-27 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:16:14 --> Total execution time: 0.0056
DEBUG - 2022-01-27 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:18:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:18:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:18:16 --> Total execution time: 0.0065
DEBUG - 2022-01-27 15:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:25:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:25:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:25:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:25:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:25:49 --> Total execution time: 0.0064
DEBUG - 2022-01-27 15:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 15:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 15:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 15:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 15:32:41 --> Total execution time: 0.0069
DEBUG - 2022-01-27 16:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:06:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:06:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:06:51 --> Total execution time: 0.0070
DEBUG - 2022-01-27 16:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:10:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:10:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:10:00 --> Total execution time: 0.0057
DEBUG - 2022-01-27 16:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:15:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:15:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:15:29 --> Total execution time: 0.0069
DEBUG - 2022-01-27 16:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:25:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:25:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:25:17 --> Total execution time: 0.0061
DEBUG - 2022-01-27 16:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:30:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:30:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:30:04 --> Total execution time: 0.0059
DEBUG - 2022-01-27 16:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:32:42 --> Total execution time: 0.0046
DEBUG - 2022-01-27 16:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:45:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:45:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:45:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:45:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:45:10 --> Total execution time: 0.0063
DEBUG - 2022-01-27 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:52:55 --> Total execution time: 0.0060
DEBUG - 2022-01-27 16:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:58:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 16:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 16:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 16:58:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 16:58:58 --> Total execution time: 0.0067
DEBUG - 2022-01-27 17:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 17:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 17:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 17:04:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 17:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-27 17:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-27 17:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-27 17:04:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-27 17:04:27 --> Total execution time: 0.0060
