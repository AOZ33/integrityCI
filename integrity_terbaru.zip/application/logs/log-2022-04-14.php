<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-14 02:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 02:57:43 --> No URI present. Default controller set.
DEBUG - 2022-04-14 02:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 02:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 02:57:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 02:57:43 --> Total execution time: 0.0612
DEBUG - 2022-04-14 02:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 02:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 02:57:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-14 02:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 02:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 02:57:43 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-14 02:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 02:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 02:57:43 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-14 02:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 02:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 02:57:43 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-14 02:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 02:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 02:57:43 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-14 02:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 02:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 02:57:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-14 03:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 03:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 03:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 03:09:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 03:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 03:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 03:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 03:09:43 --> Total execution time: 0.0045
DEBUG - 2022-04-14 03:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 03:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 03:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 03:09:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 03:09:53 --> Total execution time: 0.0132
DEBUG - 2022-04-14 05:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:35:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-14 05:35:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-04-14 05:35:45 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-04-14 05:36:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:36:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-14 05:36:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-04-14 05:36:50 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-04-14 05:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-14 05:36:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-04-14 05:36:51 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-04-14 05:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:57 --> No URI present. Default controller set.
DEBUG - 2022-04-14 05:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:36:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:36:57 --> Total execution time: 0.0039
DEBUG - 2022-04-14 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:36:58 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-14 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:36:58 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-14 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:36:58 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-14 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:36:58 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-14 05:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:36:58 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-14 05:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:58 --> No URI present. Default controller set.
DEBUG - 2022-04-14 05:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:36:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:36:58 --> Total execution time: 0.0021
DEBUG - 2022-04-14 05:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:36:59 --> Total execution time: 0.0029
DEBUG - 2022-04-14 05:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:37:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:37:01 --> Total execution time: 0.0143
DEBUG - 2022-04-14 05:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:38:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:38:06 --> Total execution time: 0.0123
DEBUG - 2022-04-14 05:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:38:35 --> 404 Page Not Found: Data/techmeet
DEBUG - 2022-04-14 05:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:38:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:38:39 --> Total execution time: 0.0082
DEBUG - 2022-04-14 05:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:47:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:47:13 --> Total execution time: 0.0497
DEBUG - 2022-04-14 05:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:47:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:47:16 --> 404 Page Not Found: Data/techmeet
DEBUG - 2022-04-14 05:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:47:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:47:20 --> Total execution time: 0.0075
DEBUG - 2022-04-14 05:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:49:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:49:09 --> Total execution time: 0.0514
DEBUG - 2022-04-14 05:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:49:11 --> 404 Page Not Found: Data/techmeet
DEBUG - 2022-04-14 05:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:49:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:49:13 --> Total execution time: 0.0056
DEBUG - 2022-04-14 05:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:50:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:50:04 --> Total execution time: 0.0079
DEBUG - 2022-04-14 05:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:50:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:50:09 --> Total execution time: 0.0037
DEBUG - 2022-04-14 05:50:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:50:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:50:14 --> Total execution time: 0.0066
DEBUG - 2022-04-14 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:50:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:50:16 --> 404 Page Not Found: Data/techmeet
DEBUG - 2022-04-14 05:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:50:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:50:26 --> Total execution time: 0.0089
DEBUG - 2022-04-14 05:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:50:28 --> Total execution time: 0.0029
DEBUG - 2022-04-14 05:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:50:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:50:30 --> Total execution time: 0.0053
DEBUG - 2022-04-14 05:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:50:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-14 05:50:32 --> 404 Page Not Found: Data/techmeet
DEBUG - 2022-04-14 05:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-14 05:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-14 05:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-14 05:53:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-14 05:53:59 --> Total execution time: 0.0413
