<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-07 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 09:54:07 --> No URI present. Default controller set.
DEBUG - 2022-01-07 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 09:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 09:54:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 09:54:07 --> Total execution time: 0.0315
DEBUG - 2022-01-07 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 09:54:14 --> No URI present. Default controller set.
DEBUG - 2022-01-07 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 09:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 09:54:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 09:54:14 --> Total execution time: 0.0034
DEBUG - 2022-01-07 09:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 09:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-07 09:54:15 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-07 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 09:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 09:54:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 09:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 09:54:29 --> Total execution time: 0.0060
DEBUG - 2022-01-07 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 09:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 09:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 09:54:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 09:54:31 --> Total execution time: 0.0844
DEBUG - 2022-01-07 10:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:07:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:07:11 --> Total execution time: 0.0333
DEBUG - 2022-01-07 10:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:11:54 --> Total execution time: 0.0060
DEBUG - 2022-01-07 10:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:15:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:15:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:15:59 --> Total execution time: 0.0061
DEBUG - 2022-01-07 10:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:17:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:17:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:17:33 --> Total execution time: 0.0056
DEBUG - 2022-01-07 10:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:20:57 --> Total execution time: 0.0058
DEBUG - 2022-01-07 10:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:29:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:29:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:29:24 --> Total execution time: 0.0059
DEBUG - 2022-01-07 10:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:31:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:31:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:31:37 --> Total execution time: 0.0055
DEBUG - 2022-01-07 10:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:35:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:35:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:35:56 --> Total execution time: 0.0059
DEBUG - 2022-01-07 10:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:39:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:39:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:39:56 --> Total execution time: 0.0060
DEBUG - 2022-01-07 10:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:44:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:44:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:44:26 --> Total execution time: 0.0066
DEBUG - 2022-01-07 10:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:46:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:46:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:46:50 --> Total execution time: 0.0066
DEBUG - 2022-01-07 10:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:50:58 --> Total execution time: 0.0063
DEBUG - 2022-01-07 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:55:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:55:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:55:33 --> Total execution time: 0.0059
DEBUG - 2022-01-07 10:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:58:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:58:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:58:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:58:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:58:49 --> Total execution time: 0.0059
DEBUG - 2022-01-07 10:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:59:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 10:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 10:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 10:59:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 10:59:59 --> Total execution time: 0.0036
DEBUG - 2022-01-07 11:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 11:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 11:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 11:09:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 11:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 11:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 11:09:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:09:09 --> Total execution time: 0.0075
DEBUG - 2022-01-07 11:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 11:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 11:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 11:13:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 11:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 11:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 11:13:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:13:54 --> Total execution time: 0.0059
DEBUG - 2022-01-07 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 11:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 11:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 11:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 11:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 11:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 11:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:17:53 --> Total execution time: 0.0062
DEBUG - 2022-01-07 11:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 11:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 11:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 11:23:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 11:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 11:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 11:23:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 11:23:01 --> Total execution time: 0.0065
DEBUG - 2022-01-07 13:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 13:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 13:53:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 13:53:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 13:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 13:53:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-07 13:53:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-07 13:53:05 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-07 13:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 13:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 13:53:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-07 13:53:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-07 13:53:17 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-07 13:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:53:24 --> No URI present. Default controller set.
DEBUG - 2022-01-07 13:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 13:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 13:53:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 13:53:24 --> Total execution time: 0.0040
DEBUG - 2022-01-07 13:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-07 13:53:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-07 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 13:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 13:53:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 13:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 13:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 13:53:31 --> Total execution time: 0.0061
DEBUG - 2022-01-07 13:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 13:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 13:53:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 13:53:35 --> Total execution time: 0.1144
DEBUG - 2022-01-07 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 13:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 13:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 13:54:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 13:54:40 --> Total execution time: 0.0051
DEBUG - 2022-01-07 14:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:03:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:03:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:03:37 --> Total execution time: 0.0060
DEBUG - 2022-01-07 14:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:04:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:04:23 --> Total execution time: 0.0857
DEBUG - 2022-01-07 14:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:04:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:04:57 --> Total execution time: 0.0050
DEBUG - 2022-01-07 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:11:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:11:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:11:56 --> Total execution time: 0.0059
DEBUG - 2022-01-07 14:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:13:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:13:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:13:36 --> Total execution time: 0.0071
DEBUG - 2022-01-07 14:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:17:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:17:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:17:05 --> Total execution time: 0.0060
DEBUG - 2022-01-07 14:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:20:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:20:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:20:53 --> Total execution time: 0.0059
DEBUG - 2022-01-07 14:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:23:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:23:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:23:30 --> Total execution time: 0.0157
DEBUG - 2022-01-07 14:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:25:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:25:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:25:29 --> Total execution time: 0.0050
DEBUG - 2022-01-07 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:28:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-07 14:28:58 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-07 14:28:58 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Rini Sulviani & Imam Santosa', 'Imam Santosa & Rini Sulviani', 'Pengsir Only 4 jt', NULL, '', '', '', '', '', '', '', '', '2-3m', '1 menit', '', 'Komp. Cigadung Greenland K48A', '082113764901', 'imamsantosaharta@gmail.com', '', 'Rp. 4.000.000', '', '', 'Rp. 4.000.000', '', '', '', '', '', '', '', '', '2021-03-11', '09:00', 'Jl. Abadi II No. 2 Gegerkalong', '', '', '', '', '', '', '', '', '', '', '', '2021-03-05', '', '', '', '', '', '')
DEBUG - 2022-01-07 14:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:28:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:28:58 --> Total execution time: 0.0046
DEBUG - 2022-01-07 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:30:16 --> Total execution time: 0.0055
DEBUG - 2022-01-07 14:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:34:58 --> Total execution time: 0.0057
DEBUG - 2022-01-07 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:39:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:39:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:39:30 --> Total execution time: 0.0053
DEBUG - 2022-01-07 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:42:02 --> Total execution time: 0.0046
DEBUG - 2022-01-07 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:44:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:44:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:44:46 --> Total execution time: 0.0047
DEBUG - 2022-01-07 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:47:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:47:26 --> Total execution time: 0.0061
DEBUG - 2022-01-07 14:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:48:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:48:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:48:47 --> Total execution time: 0.0047
DEBUG - 2022-01-07 14:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:53:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 14:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 14:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 14:53:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 14:53:10 --> Total execution time: 0.0061
DEBUG - 2022-01-07 15:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:00:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:00:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:00:48 --> Total execution time: 0.0062
DEBUG - 2022-01-07 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:02:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:02:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:02:27 --> Total execution time: 0.0049
DEBUG - 2022-01-07 15:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:07:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:07:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:07:50 --> Total execution time: 0.0056
DEBUG - 2022-01-07 15:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:10:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:10:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:10:54 --> Total execution time: 0.0059
DEBUG - 2022-01-07 15:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:13:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:13:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:13:56 --> Total execution time: 0.0049
DEBUG - 2022-01-07 15:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:14:00 --> Total execution time: 0.1524
DEBUG - 2022-01-07 15:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:18:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:18:10 --> Total execution time: 0.0339
DEBUG - 2022-01-07 15:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:18:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:18:11 --> Total execution time: 0.0039
DEBUG - 2022-01-07 15:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:20:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:20:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:20:15 --> Total execution time: 0.0060
DEBUG - 2022-01-07 15:20:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:20:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:20:18 --> Total execution time: 0.1038
DEBUG - 2022-01-07 15:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:23:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:23:00 --> Total execution time: 0.0342
DEBUG - 2022-01-07 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:26:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:26:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:26:56 --> Total execution time: 0.0057
DEBUG - 2022-01-07 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:38:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:38:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:38:13 --> Total execution time: 0.0062
DEBUG - 2022-01-07 15:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:41:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:41:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:41:41 --> Total execution time: 0.0055
DEBUG - 2022-01-07 15:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:44:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:44:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:44:06 --> Total execution time: 0.0055
DEBUG - 2022-01-07 15:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:47:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:47:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:47:03 --> Total execution time: 0.0052
DEBUG - 2022-01-07 15:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:51:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:51:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:51:38 --> Total execution time: 0.0064
DEBUG - 2022-01-07 15:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:54:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:54:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:54:33 --> Total execution time: 0.0060
DEBUG - 2022-01-07 15:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:59:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 15:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 15:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 15:59:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 15:59:22 --> Total execution time: 0.0060
DEBUG - 2022-01-07 16:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:04:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:04:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:04:20 --> Total execution time: 0.0063
DEBUG - 2022-01-07 16:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:07:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:07:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:07:49 --> Total execution time: 0.0056
DEBUG - 2022-01-07 16:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:09:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:09:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:09:11 --> Total execution time: 0.0051
DEBUG - 2022-01-07 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:10:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:10:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:10:33 --> Total execution time: 0.0054
DEBUG - 2022-01-07 16:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:12:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:12:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:12:18 --> Total execution time: 0.0050
DEBUG - 2022-01-07 16:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:14:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:14:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:14:21 --> Total execution time: 0.0048
DEBUG - 2022-01-07 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:15:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:15:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:15:28 --> Total execution time: 0.0044
DEBUG - 2022-01-07 16:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:18:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:18:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:18:33 --> Total execution time: 0.0063
DEBUG - 2022-01-07 16:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:18:38 --> Total execution time: 0.1090
DEBUG - 2022-01-07 16:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:18:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:18:59 --> Total execution time: 0.1094
DEBUG - 2022-01-07 16:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:19:00 --> Total execution time: 0.0950
DEBUG - 2022-01-07 16:19:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:19:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:19:34 --> Total execution time: 0.0054
DEBUG - 2022-01-07 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:22:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:22:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:22:16 --> Total execution time: 0.0057
DEBUG - 2022-01-07 16:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:27:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:27:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:27:42 --> Total execution time: 0.0060
DEBUG - 2022-01-07 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:31:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:31:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:31:37 --> Total execution time: 0.0057
DEBUG - 2022-01-07 16:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:32:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:32:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:32:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:32:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:32:55 --> Total execution time: 0.0054
DEBUG - 2022-01-07 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:33:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:33:31 --> Total execution time: 0.1251
DEBUG - 2022-01-07 16:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:34:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:34:36 --> Total execution time: 0.0059
DEBUG - 2022-01-07 16:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:36:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:36:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:36:20 --> Total execution time: 0.0049
DEBUG - 2022-01-07 16:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:40:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:40:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:40:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:40:08 --> Total execution time: 0.0064
DEBUG - 2022-01-07 16:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:43:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:43:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:43:00 --> Total execution time: 0.0048
DEBUG - 2022-01-07 16:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:45:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:45:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:45:57 --> Total execution time: 0.0057
DEBUG - 2022-01-07 16:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:48:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:48:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:48:52 --> Total execution time: 0.0062
DEBUG - 2022-01-07 16:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:48:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:48:57 --> Total execution time: 0.1435
DEBUG - 2022-01-07 16:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:57:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:57:44 --> Total execution time: 0.0342
DEBUG - 2022-01-07 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 16:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 16:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 16:58:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 16:58:44 --> Total execution time: 0.1122
DEBUG - 2022-01-07 21:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 21:37:21 --> No URI present. Default controller set.
DEBUG - 2022-01-07 21:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 21:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 21:37:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 21:37:21 --> Total execution time: 0.0310
DEBUG - 2022-01-07 21:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-07 21:37:21 --> No URI present. Default controller set.
DEBUG - 2022-01-07 21:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-07 21:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-07 21:37:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-07 21:37:21 --> Total execution time: 0.0042
