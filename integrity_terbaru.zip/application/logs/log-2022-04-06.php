<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> No URI present. Default controller set.
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 07:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-06 07:25:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-06 07:25:08 --> Total execution time: 0.0480
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 07:25:08 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 07:25:08 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 07:25:08 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 07:25:08 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 07:25:08 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 07:25:08 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> No URI present. Default controller set.
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 07:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-06 07:25:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-06 07:25:08 --> Total execution time: 0.0020
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 07:25:08 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-06 07:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 07:25:08 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-06 07:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 07:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-06 07:25:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-06 07:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 07:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-06 07:25:18 --> Total execution time: 0.0050
DEBUG - 2022-04-06 07:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 07:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-06 07:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-06 07:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-06 07:25:21 --> Total execution time: 0.0200
DEBUG - 2022-04-06 16:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-06 16:46:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-06 16:46:59 --> 404 Page Not Found: Wp-loginphp/index
