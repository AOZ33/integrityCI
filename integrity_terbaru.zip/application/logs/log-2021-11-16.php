<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-16 09:27:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:27:02 --> Total execution time: 0.0485
DEBUG - 2021-11-16 09:27:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:27:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:27:08 --> Total execution time: 0.0423
DEBUG - 2021-11-16 09:32:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:32:17 --> Total execution time: 0.0428
DEBUG - 2021-11-16 09:33:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:33:11 --> Total execution time: 0.0451
DEBUG - 2021-11-16 09:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:34:34 --> Total execution time: 0.0304
DEBUG - 2021-11-16 09:37:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:37:34 --> Total execution time: 0.0478
DEBUG - 2021-11-16 09:39:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:39:18 --> Total execution time: 0.0316
DEBUG - 2021-11-16 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:40:29 --> Total execution time: 0.0418
DEBUG - 2021-11-16 09:43:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:43:21 --> Total execution time: 0.0443
DEBUG - 2021-11-16 09:43:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:43:59 --> Total execution time: 0.0863
DEBUG - 2021-11-16 09:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Undefined variable: dt C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-16 09:49:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
DEBUG - 2021-11-16 09:49:24 --> Total execution time: 0.1423
DEBUG - 2021-11-16 09:50:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-16 09:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-16 09:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-16 09:50:08 --> Total execution time: 0.0471
