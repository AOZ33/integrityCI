<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-11 00:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:12 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:08:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:08:12 --> Total execution time: 0.0488
DEBUG - 2022-06-11 00:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:28 --> 404 Page Not Found: Git/config
DEBUG - 2022-06-11 00:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:45 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:08:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:08:45 --> Total execution time: 0.0016
DEBUG - 2022-06-11 00:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:46 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:08:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:08:46 --> Total execution time: 0.0014
DEBUG - 2022-06-11 00:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:49 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-06-11 00:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:49 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-06-11 00:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:49 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-06-11 00:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-06-11 00:08:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-06-11 00:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:50 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-06-11 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:51 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-06-11 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:51 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-06-11 00:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 00:08:51 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-06-11 00:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:10:46 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:10:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:10:47 --> Total execution time: 0.0361
DEBUG - 2022-06-11 00:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:12:29 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:12:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:12:29 --> Total execution time: 0.0463
DEBUG - 2022-06-11 00:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:12:47 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:12:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:12:47 --> Total execution time: 0.0022
DEBUG - 2022-06-11 00:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:14:48 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:14:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:14:48 --> Total execution time: 0.0347
DEBUG - 2022-06-11 00:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:16:49 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:16:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:16:49 --> Total execution time: 0.0358
DEBUG - 2022-06-11 00:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 00:17:18 --> No URI present. Default controller set.
DEBUG - 2022-06-11 00:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 00:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 00:17:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 00:17:18 --> Total execution time: 0.0028
DEBUG - 2022-06-11 02:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 02:11:50 --> No URI present. Default controller set.
DEBUG - 2022-06-11 02:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 02:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 02:11:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 02:11:50 --> Total execution time: 0.0391
DEBUG - 2022-06-11 02:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 02:11:50 --> No URI present. Default controller set.
DEBUG - 2022-06-11 02:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 02:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 02:11:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 02:11:50 --> Total execution time: 0.0023
DEBUG - 2022-06-11 10:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:42 --> No URI present. Default controller set.
DEBUG - 2022-06-11 10:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 10:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 10:36:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 10:36:42 --> Total execution time: 0.0384
DEBUG - 2022-06-11 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:43 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-06-11 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:43 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-06-11 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 10:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:43 --> 404 Page Not Found: Assets/https:
ERROR - 2022-06-11 10:36:43 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-06-11 10:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:43 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-06-11 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:43 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-11 10:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 10:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 10:36:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 10:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 10:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 10:36:59 --> Total execution time: 0.0014
DEBUG - 2022-06-11 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-06-11 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:59 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-06-11 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 10:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:59 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-06-11 10:36:59 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-06-11 10:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:36:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 10:36:59 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-06-11 10:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 10:37:05 --> No URI present. Default controller set.
DEBUG - 2022-06-11 10:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 10:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 10:37:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 10:37:05 --> Total execution time: 0.0020
DEBUG - 2022-06-11 12:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:38 --> No URI present. Default controller set.
DEBUG - 2022-06-11 12:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 12:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 12:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 12:41:38 --> Total execution time: 0.0372
DEBUG - 2022-06-11 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:39 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-06-11 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:39 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-06-11 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:39 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-06-11 12:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:39 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-06-11 12:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:39 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-06-11 12:41:40 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:40 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-06-11 12:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:41 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-06-11 12:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:41 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-06-11 12:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 12:41:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 12:41:41 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-06-11 13:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 13:43:50 --> No URI present. Default controller set.
DEBUG - 2022-06-11 13:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 13:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 13:43:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 13:43:50 --> Total execution time: 0.0368
DEBUG - 2022-06-11 13:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 13:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 13:43:50 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-06-11 13:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 13:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 13:43:50 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-06-11 13:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 13:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 13:43:50 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-06-11 13:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 13:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 13:43:50 --> UTF-8 Support Enabled
ERROR - 2022-06-11 13:43:50 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-06-11 13:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 13:43:50 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-06-11 13:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 13:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-11 13:43:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-06-11 21:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-06-11 21:48:04 --> No URI present. Default controller set.
DEBUG - 2022-06-11 21:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-11 21:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-11 21:48:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-11 21:48:04 --> Total execution time: 0.0540
