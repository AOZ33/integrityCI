<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-18 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:26 --> No URI present. Default controller set.
DEBUG - 2022-04-18 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 02:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 02:49:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 02:49:26 --> Total execution time: 0.0527
DEBUG - 2022-04-18 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 02:49:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-18 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 02:49:26 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-18 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 02:49:26 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-18 02:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 02:49:26 --> UTF-8 Support Enabled
ERROR - 2022-04-18 02:49:26 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-18 02:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 02:49:26 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-18 02:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 02:49:27 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-18 02:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 02:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 02:49:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 02:49:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 02:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 02:49:28 --> Total execution time: 0.0113
DEBUG - 2022-04-18 02:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 02:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 02:49:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 02:49:42 --> Total execution time: 0.0331
DEBUG - 2022-04-18 02:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 02:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 02:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 02:49:45 --> Total execution time: 0.0257
DEBUG - 2022-04-18 02:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 02:49:46 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-18 02:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 02:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 02:49:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 02:49:55 --> Total execution time: 0.0078
DEBUG - 2022-04-18 02:50:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 02:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 02:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 02:50:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 02:50:06 --> Total execution time: 0.0044
DEBUG - 2022-04-18 03:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 03:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 03:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 03:43:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 03:43:39 --> Total execution time: 0.0408
DEBUG - 2022-04-18 03:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 03:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 03:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 03:44:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 03:44:23 --> Total execution time: 0.0028
DEBUG - 2022-04-18 03:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 03:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 03:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 03:45:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 03:45:11 --> Total execution time: 0.0041
DEBUG - 2022-04-18 03:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 03:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 03:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 03:46:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 03:46:40 --> Total execution time: 0.0052
DEBUG - 2022-04-18 03:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 03:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 03:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 03:49:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 03:49:07 --> Total execution time: 0.0518
DEBUG - 2022-04-18 03:49:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 03:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 03:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 03:49:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 03:49:53 --> Total execution time: 0.0040
DEBUG - 2022-04-18 03:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 03:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 03:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 03:54:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 03:54:06 --> Total execution time: 0.0042
DEBUG - 2022-04-18 03:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 03:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 03:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 03:59:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 03:59:13 --> Total execution time: 0.0395
DEBUG - 2022-04-18 04:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:02:28 --> Total execution time: 0.0051
DEBUG - 2022-04-18 04:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:02:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:02:58 --> Total execution time: 0.0043
DEBUG - 2022-04-18 04:04:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:04:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:04:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:04:09 --> Total execution time: 0.0026
DEBUG - 2022-04-18 04:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:07:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:07:37 --> Total execution time: 0.0047
DEBUG - 2022-04-18 04:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:08:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:08:27 --> Total execution time: 0.0039
DEBUG - 2022-04-18 04:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:09:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:09:28 --> Total execution time: 0.0039
DEBUG - 2022-04-18 04:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:18:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:18:57 --> Total execution time: 0.0420
DEBUG - 2022-04-18 04:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:24:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:24:49 --> Total execution time: 0.0403
DEBUG - 2022-04-18 04:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:39:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:39:00 --> Total execution time: 0.0469
DEBUG - 2022-04-18 04:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:40:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:40:29 --> Total execution time: 0.0038
DEBUG - 2022-04-18 04:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:41:29 --> Total execution time: 0.0045
DEBUG - 2022-04-18 04:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:43:15 --> Total execution time: 0.0050
DEBUG - 2022-04-18 04:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:44:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:44:30 --> Total execution time: 0.0047
DEBUG - 2022-04-18 04:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:45:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:45:36 --> Total execution time: 0.0404
DEBUG - 2022-04-18 04:47:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:47:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:47:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:47:39 --> Total execution time: 0.0432
DEBUG - 2022-04-18 04:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:48:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:48:49 --> Total execution time: 0.0034
DEBUG - 2022-04-18 04:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:48:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:48:50 --> Total execution time: 0.0024
DEBUG - 2022-04-18 04:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:48:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:48:51 --> Total execution time: 0.0025
DEBUG - 2022-04-18 04:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:49:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:49:13 --> Total execution time: 0.0051
DEBUG - 2022-04-18 04:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 04:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 04:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 04:54:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 04:54:07 --> Total execution time: 0.0460
DEBUG - 2022-04-18 05:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:07:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:07:13 --> Total execution time: 0.0413
DEBUG - 2022-04-18 05:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:07:29 --> Total execution time: 0.0035
DEBUG - 2022-04-18 05:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:07:29 --> Total execution time: 0.0024
DEBUG - 2022-04-18 05:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:08:23 --> Total execution time: 0.0049
DEBUG - 2022-04-18 05:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:08:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:08:54 --> Total execution time: 0.0041
DEBUG - 2022-04-18 05:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:09:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:09:43 --> Total execution time: 0.0029
DEBUG - 2022-04-18 05:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:24:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:24:58 --> Total execution time: 0.0443
DEBUG - 2022-04-18 05:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:26:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:26:54 --> Total execution time: 0.0409
DEBUG - 2022-04-18 05:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:28:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:28:27 --> Total execution time: 0.0417
DEBUG - 2022-04-18 05:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:44:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:44:02 --> Total execution time: 0.0546
DEBUG - 2022-04-18 05:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:51:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:51:45 --> Total execution time: 0.0443
DEBUG - 2022-04-18 05:57:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 05:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 05:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 05:57:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 05:57:03 --> Total execution time: 0.0479
DEBUG - 2022-04-18 06:05:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:05:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:05:02 --> Total execution time: 0.0551
DEBUG - 2022-04-18 06:05:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:05:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:05:03 --> Total execution time: 0.0103
DEBUG - 2022-04-18 06:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:07:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:07:40 --> Total execution time: 0.0080
DEBUG - 2022-04-18 06:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:07:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:07:44 --> Total execution time: 0.0023
DEBUG - 2022-04-18 06:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:09:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:09:40 --> Total execution time: 0.0579
DEBUG - 2022-04-18 06:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:09:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:09:44 --> Total execution time: 0.0030
DEBUG - 2022-04-18 06:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:10:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:10:46 --> Total execution time: 0.0032
DEBUG - 2022-04-18 06:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:10:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:10:50 --> Total execution time: 0.0064
DEBUG - 2022-04-18 06:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:10:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:10:53 --> Total execution time: 0.0031
DEBUG - 2022-04-18 06:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:18:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:18:53 --> Total execution time: 0.0413
DEBUG - 2022-04-18 06:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:20:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:20:11 --> Total execution time: 0.0036
DEBUG - 2022-04-18 06:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:20:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:20:46 --> Total execution time: 0.0025
DEBUG - 2022-04-18 06:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:23:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:23:31 --> Total execution time: 0.0412
DEBUG - 2022-04-18 06:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:52:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:52:06 --> Total execution time: 0.0505
DEBUG - 2022-04-18 06:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:52:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:52:32 --> Total execution time: 0.0047
DEBUG - 2022-04-18 06:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:52:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:52:37 --> Total execution time: 0.0024
DEBUG - 2022-04-18 06:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:53:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 06:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 06:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 06:53:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 06:53:26 --> Total execution time: 0.0066
DEBUG - 2022-04-18 07:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:01:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 07:01:55 --> Total execution time: 0.0440
DEBUG - 2022-04-18 07:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:02:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 07:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:02:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 07:02:09 --> Total execution time: 0.0106
DEBUG - 2022-04-18 07:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:50:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 07:50:54 --> Total execution time: 0.0679
DEBUG - 2022-04-18 07:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:50:59 --> Total execution time: 0.0060
DEBUG - 2022-04-18 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 07:51:01 --> 404 Page Not Found: Techmeet/index
DEBUG - 2022-04-18 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:51:03 --> Total execution time: 0.0033
DEBUG - 2022-04-18 07:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:52:49 --> Total execution time: 0.0023
DEBUG - 2022-04-18 07:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:52:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 07:52:50 --> Total execution time: 0.0087
DEBUG - 2022-04-18 07:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:52:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 07:52:52 --> 404 Page Not Found: Techmeet/index
DEBUG - 2022-04-18 07:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 07:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 07:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 07:55:56 --> Total execution time: 0.0444
DEBUG - 2022-04-18 08:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 08:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 08:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 08:00:01 --> Total execution time: 0.0084
DEBUG - 2022-04-18 08:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 08:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 08:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 08:00:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 08:00:04 --> Total execution time: 0.0101
DEBUG - 2022-04-18 08:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 08:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 08:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 08:00:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 08:00:07 --> Total execution time: 0.0029
DEBUG - 2022-04-18 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 08:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 08:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 08:00:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 08:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 08:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 08:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 08:00:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-18 08:00:09 --> Total execution time: 0.0085
DEBUG - 2022-04-18 08:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 08:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 08:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 08:00:11 --> Total execution time: 0.0032
DEBUG - 2022-04-18 08:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 08:00:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-18 08:00:19 --> 404 Page Not Found: Techmeet/detail_techmeet
DEBUG - 2022-04-18 08:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-18 08:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-18 08:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-18 08:00:20 --> Total execution time: 0.0040
