<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-07 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:28 --> No URI present. Default controller set.
DEBUG - 2022-04-07 02:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:37:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:37:28 --> Total execution time: 0.0422
DEBUG - 2022-04-07 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 02:37:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-07 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 02:37:28 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-07 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 02:37:28 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-04-07 02:37:28 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-07 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 02:37:28 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-07 02:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 02:37:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-07 02:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:37:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:37:29 --> Total execution time: 0.0047
DEBUG - 2022-04-07 02:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:37:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:37:40 --> Total execution time: 0.0138
DEBUG - 2022-04-07 02:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:39:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:39:15 --> Total execution time: 0.0046
DEBUG - 2022-04-07 02:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:47:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:47:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:47:09 --> Total execution time: 0.0042
DEBUG - 2022-04-07 02:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:51:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:51:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:51:38 --> Total execution time: 0.0039
DEBUG - 2022-04-07 02:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:53:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:53:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:53:57 --> Total execution time: 0.0026
DEBUG - 2022-04-07 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 02:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 02:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 02:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 02:56:20 --> Total execution time: 0.0039
DEBUG - 2022-04-07 03:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:00:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:00:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:00:44 --> Total execution time: 0.0022
DEBUG - 2022-04-07 03:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:03:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:03:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:03:17 --> Total execution time: 0.0040
DEBUG - 2022-04-07 03:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:12:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:12:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:12:04 --> Total execution time: 0.0041
DEBUG - 2022-04-07 03:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:14:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:14:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:14:03 --> Total execution time: 0.0040
DEBUG - 2022-04-07 03:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:15:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:15:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:15:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:15:23 --> Total execution time: 0.0020
DEBUG - 2022-04-07 03:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:18:19 --> Total execution time: 0.0040
DEBUG - 2022-04-07 03:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:21:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:21:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:21:15 --> Total execution time: 0.0022
DEBUG - 2022-04-07 03:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:21:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:21:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:21:41 --> Total execution time: 0.0022
DEBUG - 2022-04-07 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:27:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:27:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:27:42 --> Total execution time: 0.0039
DEBUG - 2022-04-07 03:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:28:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:28:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:28:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:28:17 --> Total execution time: 0.0022
DEBUG - 2022-04-07 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:30:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:30:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:30:23 --> Total execution time: 0.0043
DEBUG - 2022-04-07 03:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:35:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:35:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:35:18 --> Total execution time: 0.0038
DEBUG - 2022-04-07 03:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:37:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:37:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:37:26 --> Total execution time: 0.0020
DEBUG - 2022-04-07 03:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:41:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:41:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:41:27 --> Total execution time: 0.0025
DEBUG - 2022-04-07 03:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:43:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:43:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:43:45 --> Total execution time: 0.0039
DEBUG - 2022-04-07 03:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:47:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:47:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:47:00 --> Total execution time: 0.0019
DEBUG - 2022-04-07 03:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:55:01 --> Total execution time: 0.0045
DEBUG - 2022-04-07 03:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:58:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:58:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:58:02 --> Total execution time: 0.0041
DEBUG - 2022-04-07 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:59:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 03:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 03:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 03:59:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 03:59:29 --> Total execution time: 0.0023
DEBUG - 2022-04-07 04:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:00:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:00:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:00:37 --> Total execution time: 0.0041
DEBUG - 2022-04-07 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:01:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:01:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:01:46 --> Total execution time: 0.0024
DEBUG - 2022-04-07 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:04:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:04:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:04:29 --> Total execution time: 0.0023
DEBUG - 2022-04-07 04:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:07:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:07:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:07:26 --> Total execution time: 0.0045
DEBUG - 2022-04-07 04:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:15:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:15:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:15:05 --> Total execution time: 0.0042
DEBUG - 2022-04-07 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:17:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:17:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:17:00 --> Total execution time: 0.0019
DEBUG - 2022-04-07 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:20:59 --> Total execution time: 0.0040
DEBUG - 2022-04-07 04:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:30:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:30:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:30:09 --> Total execution time: 0.0087
DEBUG - 2022-04-07 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:33:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:33:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:33:57 --> Total execution time: 0.0038
DEBUG - 2022-04-07 04:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:52:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:52:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:52:30 --> Total execution time: 0.0044
DEBUG - 2022-04-07 04:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:56:18 --> Total execution time: 0.0037
DEBUG - 2022-04-07 04:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:58:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:58:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:58:42 --> Total execution time: 0.0040
DEBUG - 2022-04-07 04:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:59:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 04:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 04:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 04:59:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 04:59:56 --> Total execution time: 0.0020
DEBUG - 2022-04-07 05:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:07:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:07:55 --> Total execution time: 0.0467
DEBUG - 2022-04-07 05:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:07:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:07:59 --> Total execution time: 0.0093
DEBUG - 2022-04-07 05:08:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:08:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:08:05 --> Total execution time: 0.0029
DEBUG - 2022-04-07 05:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:13:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:13:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:13:27 --> Total execution time: 0.0042
DEBUG - 2022-04-07 05:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:16:14 --> Total execution time: 0.0040
DEBUG - 2022-04-07 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:17:54 --> Total execution time: 0.0022
DEBUG - 2022-04-07 05:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:22:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:22:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:22:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:22:45 --> Total execution time: 0.0045
DEBUG - 2022-04-07 05:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:28:33 --> Total execution time: 0.0053
DEBUG - 2022-04-07 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:30:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:30:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:30:46 --> Total execution time: 0.0040
DEBUG - 2022-04-07 05:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:33:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:33:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:33:36 --> Total execution time: 0.0038
DEBUG - 2022-04-07 05:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:37:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:37:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:37:26 --> Total execution time: 0.0041
DEBUG - 2022-04-07 05:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:41:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:41:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:41:07 --> Total execution time: 0.0040
DEBUG - 2022-04-07 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:41:47 --> No URI present. Default controller set.
DEBUG - 2022-04-07 05:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:41:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:41:47 --> Total execution time: 0.0022
DEBUG - 2022-04-07 05:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:46:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:46:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:46:11 --> Total execution time: 0.0042
DEBUG - 2022-04-07 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:48:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:48:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:48:32 --> Total execution time: 0.0041
DEBUG - 2022-04-07 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:58:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 05:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 05:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 05:58:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 05:58:12 --> Total execution time: 0.0039
DEBUG - 2022-04-07 06:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:03:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:03:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:03:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:03:06 --> Total execution time: 0.0041
DEBUG - 2022-04-07 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:09:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:09:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:09:23 --> Total execution time: 0.0041
DEBUG - 2022-04-07 06:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:14:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:14:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:14:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:14:37 --> Total execution time: 0.0042
DEBUG - 2022-04-07 06:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:15:20 --> Total execution time: 0.0019
DEBUG - 2022-04-07 06:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:17:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:17:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:17:46 --> Total execution time: 0.0040
DEBUG - 2022-04-07 06:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:19:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:19:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:19:29 --> Total execution time: 0.0045
DEBUG - 2022-04-07 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:20:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:20:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:20:31 --> Total execution time: 0.0028
DEBUG - 2022-04-07 06:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:22:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:22:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:22:37 --> Total execution time: 0.0041
DEBUG - 2022-04-07 06:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:24:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:24:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:24:26 --> Total execution time: 0.0042
DEBUG - 2022-04-07 06:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:26:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:26:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:26:31 --> Total execution time: 0.0039
DEBUG - 2022-04-07 06:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:30:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:30:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:30:48 --> Total execution time: 0.0046
DEBUG - 2022-04-07 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:33:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:33:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:33:17 --> Total execution time: 0.0023
DEBUG - 2022-04-07 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:30 --> No URI present. Default controller set.
DEBUG - 2022-04-07 06:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:35:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:35:30 --> Total execution time: 0.0036
DEBUG - 2022-04-07 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:35:30 --> UTF-8 Support Enabled
ERROR - 2022-04-07 06:35:30 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-07 06:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:35:30 --> 404 Page Not Found: Js/main.js
ERROR - 2022-04-07 06:35:30 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-07 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:35:30 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-07 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:35:30 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-07 06:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:35:30 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-07 06:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:30 --> No URI present. Default controller set.
DEBUG - 2022-04-07 06:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:35:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:35:30 --> Total execution time: 0.0021
DEBUG - 2022-04-07 06:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:35:31 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-07 06:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:40 --> No URI present. Default controller set.
DEBUG - 2022-04-07 06:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:35:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:35:40 --> Total execution time: 0.0020
DEBUG - 2022-04-07 06:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:35:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:35:46 --> Total execution time: 0.0040
DEBUG - 2022-04-07 06:36:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:36:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:36:02 --> Total execution time: 0.0143
DEBUG - 2022-04-07 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:20 --> No URI present. Default controller set.
DEBUG - 2022-04-07 06:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:36:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:36:20 --> Total execution time: 0.0022
DEBUG - 2022-04-07 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:36:20 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-07 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:36:20 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-07 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:36:20 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-07 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:36:20 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-07 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:36:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-07 06:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:36:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-07 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:36:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:36:37 --> Total execution time: 0.0020
DEBUG - 2022-04-07 06:36:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:36:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-07 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:36:48 --> Total execution time: 0.0039
DEBUG - 2022-04-07 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-07 06:36:48 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-07 06:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:36:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:36:51 --> Total execution time: 0.0050
DEBUG - 2022-04-07 06:37:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:37:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:37:09 --> Total execution time: 0.0135
DEBUG - 2022-04-07 06:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:37:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:37:17 --> Total execution time: 0.0062
DEBUG - 2022-04-07 06:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:37:33 --> Total execution time: 0.0140
DEBUG - 2022-04-07 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:38:12 --> Total execution time: 0.0046
DEBUG - 2022-04-07 06:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:38:17 --> Total execution time: 0.0058
DEBUG - 2022-04-07 06:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:38:24 --> Total execution time: 0.0059
DEBUG - 2022-04-07 06:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:38:39 --> Total execution time: 0.0061
DEBUG - 2022-04-07 06:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:41:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:41:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:41:56 --> Total execution time: 0.0026
DEBUG - 2022-04-07 06:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:43:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:43:47 --> Total execution time: 0.0100
DEBUG - 2022-04-07 06:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:44:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:44:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:44:00 --> Total execution time: 0.0027
DEBUG - 2022-04-07 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:45:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:45:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:45:00 --> Total execution time: 0.0025
DEBUG - 2022-04-07 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:45:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:45:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:45:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:45:45 --> Total execution time: 0.0024
DEBUG - 2022-04-07 06:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:47:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:47:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:47:24 --> Total execution time: 0.0057
DEBUG - 2022-04-07 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:48:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:48:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:48:58 --> Total execution time: 0.0044
DEBUG - 2022-04-07 06:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:51:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:51:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:51:00 --> Total execution time: 0.0055
DEBUG - 2022-04-07 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:53:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:53:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:53:19 --> Total execution time: 0.0040
DEBUG - 2022-04-07 06:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:56:39 --> Total execution time: 0.0040
DEBUG - 2022-04-07 06:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 06:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 06:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 06:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 06:58:56 --> Total execution time: 0.0040
DEBUG - 2022-04-07 07:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:02:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:02:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:02:32 --> Total execution time: 0.0051
DEBUG - 2022-04-07 07:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:03:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:03:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:03:27 --> Total execution time: 0.0028
DEBUG - 2022-04-07 07:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:05:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:05:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:05:11 --> Total execution time: 0.0042
DEBUG - 2022-04-07 07:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:08:23 --> Total execution time: 0.0048
DEBUG - 2022-04-07 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:09:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:09:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:09:45 --> Total execution time: 0.0039
DEBUG - 2022-04-07 07:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:11:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:11:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:11:44 --> Total execution time: 0.0041
DEBUG - 2022-04-07 07:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:14:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:14:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:14:09 --> Total execution time: 0.0043
DEBUG - 2022-04-07 07:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:16:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:16:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:16:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:16:37 --> Total execution time: 0.0026
DEBUG - 2022-04-07 07:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:17:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:17:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:17:36 --> Total execution time: 0.0024
DEBUG - 2022-04-07 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:19:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:19:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:19:18 --> Total execution time: 0.0044
DEBUG - 2022-04-07 07:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:21:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:21:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:21:10 --> Total execution time: 0.0042
DEBUG - 2022-04-07 07:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:22:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:22:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:22:57 --> Total execution time: 0.0039
DEBUG - 2022-04-07 07:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:25:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:25:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:25:34 --> Total execution time: 0.0049
DEBUG - 2022-04-07 07:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:27:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:27:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:27:08 --> Total execution time: 0.0054
DEBUG - 2022-04-07 07:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:28:24 --> Total execution time: 0.0040
DEBUG - 2022-04-07 07:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:31:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:31:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:31:16 --> Total execution time: 0.0055
DEBUG - 2022-04-07 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:34:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:34:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:34:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:34:17 --> Total execution time: 0.0055
DEBUG - 2022-04-07 07:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:37:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:37:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:37:35 --> Total execution time: 0.0043
DEBUG - 2022-04-07 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:42:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:42:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:42:14 --> Total execution time: 0.0042
DEBUG - 2022-04-07 07:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:43:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:43:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:43:56 --> Total execution time: 0.0044
DEBUG - 2022-04-07 07:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:51:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:51:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:51:55 --> Total execution time: 0.0042
DEBUG - 2022-04-07 07:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:54:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:54:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:54:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:54:29 --> Total execution time: 0.0043
DEBUG - 2022-04-07 07:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:56:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:56:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:56:33 --> Total execution time: 0.0045
DEBUG - 2022-04-07 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:58:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:58:16 --> Total execution time: 0.0041
DEBUG - 2022-04-07 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:59:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 07:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 07:59:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 07:59:50 --> Total execution time: 0.0038
DEBUG - 2022-04-07 08:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:00:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:00:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:00:21 --> Total execution time: 0.0025
DEBUG - 2022-04-07 08:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:03:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:03:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:03:00 --> Total execution time: 0.0043
DEBUG - 2022-04-07 08:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:05:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:05:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:05:38 --> Total execution time: 0.0043
DEBUG - 2022-04-07 08:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:07:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:07:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:07:36 --> Total execution time: 0.0046
DEBUG - 2022-04-07 08:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:10:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:10:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:10:10 --> Total execution time: 0.0046
DEBUG - 2022-04-07 08:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:25:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:25:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:25:26 --> Total execution time: 0.0050
DEBUG - 2022-04-07 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:27:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:27:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:27:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:27:32 --> Total execution time: 0.0044
DEBUG - 2022-04-07 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:30:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:30:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:30:20 --> Total execution time: 0.0041
DEBUG - 2022-04-07 08:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:33:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:33:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:33:58 --> Total execution time: 0.0041
DEBUG - 2022-04-07 08:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:35:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:35:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:35:27 --> Total execution time: 0.0040
DEBUG - 2022-04-07 08:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:37:33 --> Total execution time: 0.0024
DEBUG - 2022-04-07 08:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 08:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 08:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 08:38:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 08:38:07 --> Total execution time: 0.0185
DEBUG - 2022-04-07 14:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 14:10:16 --> No URI present. Default controller set.
DEBUG - 2022-04-07 14:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 14:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 14:10:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 14:10:16 --> Total execution time: 0.0388
DEBUG - 2022-04-07 14:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-07 14:10:17 --> No URI present. Default controller set.
DEBUG - 2022-04-07 14:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-07 14:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-07 14:10:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-07 14:10:17 --> Total execution time: 0.0014
