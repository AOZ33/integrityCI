<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-10 07:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:50:50 --> No URI present. Default controller set.
DEBUG - 2022-03-10 07:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 07:50:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 07:50:50 --> Total execution time: 0.0304
DEBUG - 2022-03-10 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:50:51 --> No URI present. Default controller set.
DEBUG - 2022-03-10 07:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 07:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 07:50:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 07:50:51 --> Total execution time: 0.0030
DEBUG - 2022-03-10 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:50:51 --> No URI present. Default controller set.
DEBUG - 2022-03-10 07:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 07:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 07:50:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 07:50:51 --> Total execution time: 0.0030
DEBUG - 2022-03-10 07:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-10 07:50:52 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-03-10 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:54:51 --> No URI present. Default controller set.
DEBUG - 2022-03-10 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 07:54:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 07:54:51 --> Total execution time: 0.0301
DEBUG - 2022-03-10 07:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:54:52 --> No URI present. Default controller set.
DEBUG - 2022-03-10 07:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 07:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 07:54:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 07:54:52 --> Total execution time: 0.0034
DEBUG - 2022-03-10 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:54:53 --> No URI present. Default controller set.
DEBUG - 2022-03-10 07:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 07:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 07:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 07:54:53 --> Total execution time: 0.0032
DEBUG - 2022-03-10 07:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:54:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-10 07:54:53 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-03-10 07:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 07:56:36 --> No URI present. Default controller set.
DEBUG - 2022-03-10 07:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 07:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 07:56:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 07:56:36 --> Total execution time: 0.0310
DEBUG - 2022-03-10 08:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 08:02:30 --> No URI present. Default controller set.
DEBUG - 2022-03-10 08:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 08:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 08:02:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 08:02:30 --> Total execution time: 0.0299
DEBUG - 2022-03-10 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:39:47 --> No URI present. Default controller set.
DEBUG - 2022-03-10 09:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:39:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 09:39:47 --> Total execution time: 0.0309
DEBUG - 2022-03-10 09:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:39:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-10 09:39:47 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-10 09:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:39:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 09:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:39:51 --> Total execution time: 0.0062
DEBUG - 2022-03-10 09:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:49:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-10 09:49:12 --> Severity: error --> Exception: Call to a member function hitungJumlahAsset() on null /home/dunr4521/public_html/integrity/application/controllers/Data.php 81
DEBUG - 2022-03-10 09:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:49:19 --> Total execution time: 0.0055
DEBUG - 2022-03-10 09:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:49:21 --> Total execution time: 0.0057
DEBUG - 2022-03-10 09:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:49:23 --> Total execution time: 0.0044
DEBUG - 2022-03-10 09:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:49:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-10 09:49:23 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-10 09:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:49:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-10 09:49:25 --> Severity: error --> Exception: Call to a member function hitungJumlahAsset() on null /home/dunr4521/public_html/integrity/application/controllers/Data.php 81
DEBUG - 2022-03-10 09:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:49:59 --> Total execution time: 0.0053
DEBUG - 2022-03-10 09:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:51:22 --> Total execution time: 0.0322
DEBUG - 2022-03-10 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:51:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-10 09:51:23 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-10 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:51:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 09:51:24 --> Total execution time: 0.0104
DEBUG - 2022-03-10 09:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 09:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 09:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 09:51:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 09:51:27 --> Total execution time: 0.0047
DEBUG - 2022-03-10 10:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 10:17:54 --> No URI present. Default controller set.
DEBUG - 2022-03-10 10:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 10:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 10:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 10:17:54 --> Total execution time: 0.0299
DEBUG - 2022-03-10 11:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:12:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:12:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:12:08 --> Total execution time: 0.0083
DEBUG - 2022-03-10 11:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:14:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:14:26 --> Total execution time: 0.0403
DEBUG - 2022-03-10 11:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:14:35 --> Total execution time: 0.0095
DEBUG - 2022-03-10 11:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:15:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:15:00 --> Total execution time: 0.0166
DEBUG - 2022-03-10 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:15:06 --> Total execution time: 0.0147
DEBUG - 2022-03-10 11:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:15:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:15:08 --> Total execution time: 0.0044
DEBUG - 2022-03-10 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:21:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:21:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:21:12 --> Total execution time: 0.0076
DEBUG - 2022-03-10 11:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:21:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:21:17 --> Total execution time: 0.0170
DEBUG - 2022-03-10 11:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:21:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:21:21 --> Total execution time: 0.0085
DEBUG - 2022-03-10 11:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:21:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:21:24 --> Total execution time: 0.0097
DEBUG - 2022-03-10 11:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 11:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 11:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 11:21:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 11:21:28 --> Total execution time: 0.0038
DEBUG - 2022-03-10 12:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 12:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 12:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 12:23:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 12:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 12:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 12:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 12:23:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 12:23:11 --> Total execution time: 0.0069
DEBUG - 2022-03-10 12:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 12:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 12:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 12:28:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 12:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 12:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 12:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 12:28:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 12:28:26 --> Total execution time: 0.0065
DEBUG - 2022-03-10 12:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 12:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 12:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 12:35:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 12:35:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 12:35:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 12:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 12:35:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 12:35:31 --> Total execution time: 0.0058
DEBUG - 2022-03-10 13:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:15:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:15:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:15:21 --> Total execution time: 0.0067
DEBUG - 2022-03-10 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:17:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:17:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:17:59 --> Total execution time: 0.0043
DEBUG - 2022-03-10 13:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:25:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:25:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:25:02 --> Total execution time: 0.0054
DEBUG - 2022-03-10 13:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:42:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:42:56 --> Total execution time: 0.0424
DEBUG - 2022-03-10 13:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:01 --> Total execution time: 0.0136
DEBUG - 2022-03-10 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:07 --> Total execution time: 0.0109
DEBUG - 2022-03-10 13:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:18 --> Total execution time: 0.0123
DEBUG - 2022-03-10 13:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:20 --> Total execution time: 0.0069
DEBUG - 2022-03-10 13:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:20 --> Total execution time: 0.0057
DEBUG - 2022-03-10 13:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:24 --> Total execution time: 0.0060
DEBUG - 2022-03-10 13:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:39 --> Total execution time: 0.0142
DEBUG - 2022-03-10 13:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:42 --> Total execution time: 0.0111
DEBUG - 2022-03-10 13:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:43:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:43:50 --> Total execution time: 0.0138
DEBUG - 2022-03-10 13:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:44:20 --> Total execution time: 0.0168
DEBUG - 2022-03-10 13:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:44:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:44:35 --> Total execution time: 0.0135
DEBUG - 2022-03-10 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:44:37 --> Total execution time: 0.0072
DEBUG - 2022-03-10 13:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:44:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:44:42 --> Total execution time: 0.0070
DEBUG - 2022-03-10 13:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:44:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:44:49 --> Total execution time: 0.0060
DEBUG - 2022-03-10 13:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:45:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:45:53 --> Total execution time: 0.0056
DEBUG - 2022-03-10 13:59:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:59:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:59:47 --> Total execution time: 0.0447
DEBUG - 2022-03-10 13:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 13:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 13:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 13:59:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 13:59:51 --> Total execution time: 0.0061
DEBUG - 2022-03-10 14:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:02:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:02:01 --> Total execution time: 0.0320
DEBUG - 2022-03-10 14:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:02:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:02:13 --> Total execution time: 0.0112
DEBUG - 2022-03-10 14:02:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:02:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:02:27 --> Total execution time: 0.0148
DEBUG - 2022-03-10 14:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:02:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:02:37 --> Total execution time: 0.0122
DEBUG - 2022-03-10 14:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:04:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:04:08 --> Total execution time: 0.0435
DEBUG - 2022-03-10 14:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:04:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:04:13 --> Total execution time: 0.0108
DEBUG - 2022-03-10 14:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:04:31 --> Total execution time: 0.0135
DEBUG - 2022-03-10 14:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:04:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:04:34 --> Total execution time: 0.0106
DEBUG - 2022-03-10 14:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:04:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:04:53 --> Total execution time: 0.0137
DEBUG - 2022-03-10 14:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:04:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:04:58 --> Total execution time: 0.0068
DEBUG - 2022-03-10 14:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:05:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:05:10 --> Total execution time: 0.0152
DEBUG - 2022-03-10 14:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:05:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:05:30 --> Total execution time: 0.0138
DEBUG - 2022-03-10 14:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:05:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:05:32 --> Total execution time: 0.0077
DEBUG - 2022-03-10 14:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:05:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:05:34 --> Total execution time: 0.0042
DEBUG - 2022-03-10 14:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:39:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 14:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 14:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 14:39:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 14:39:46 --> Total execution time: 0.0073
DEBUG - 2022-03-10 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 15:06:42 --> No URI present. Default controller set.
DEBUG - 2022-03-10 15:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 15:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 15:06:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 15:06:42 --> Total execution time: 0.0316
DEBUG - 2022-03-10 15:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 15:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 15:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 15:09:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 15:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-10 15:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-10 15:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-10 15:09:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-10 15:09:41 --> Total execution time: 0.0069
