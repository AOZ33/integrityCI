<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-25 09:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:13:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-25 09:13:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-25 09:13:24 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-25 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:29 --> No URI present. Default controller set.
DEBUG - 2022-03-25 09:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:13:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:13:29 --> Total execution time: 0.0033
DEBUG - 2022-03-25 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-25 09:13:29 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-25 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:13:29 --> UTF-8 Support Enabled
ERROR - 2022-03-25 09:13:29 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-25 09:13:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-25 09:13:29 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-25 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-25 09:13:29 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-25 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-25 09:13:29 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-25 09:13:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:29 --> No URI present. Default controller set.
DEBUG - 2022-03-25 09:13:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:13:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:13:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:13:29 --> Total execution time: 0.0034
DEBUG - 2022-03-25 09:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:13:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:13:32 --> Total execution time: 0.0061
DEBUG - 2022-03-25 09:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:21:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:21:47 --> Total execution time: 0.0418
DEBUG - 2022-03-25 09:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:21:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:21:55 --> Total execution time: 0.0062
DEBUG - 2022-03-25 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:24:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:24:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:24:09 --> Total execution time: 0.0041
DEBUG - 2022-03-25 09:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:28:42 --> Total execution time: 0.0064
DEBUG - 2022-03-25 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:33:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:33:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:33:44 --> Total execution time: 0.0056
DEBUG - 2022-03-25 09:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:40:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:40:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:40:16 --> Total execution time: 0.0060
DEBUG - 2022-03-25 09:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:43:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:43:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:43:52 --> Total execution time: 0.0064
DEBUG - 2022-03-25 09:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:47:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:47:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:47:15 --> Total execution time: 0.0055
DEBUG - 2022-03-25 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:57:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 09:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 09:57:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 09:57:12 --> Total execution time: 0.0064
DEBUG - 2022-03-25 10:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:01:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:01:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:01:15 --> Total execution time: 0.0067
DEBUG - 2022-03-25 10:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:07:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:07:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:07:58 --> Total execution time: 0.0062
DEBUG - 2022-03-25 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:22:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:22:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:22:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:22:57 --> Total execution time: 0.0074
DEBUG - 2022-03-25 10:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:28:25 --> Total execution time: 0.0063
DEBUG - 2022-03-25 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:32:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:32:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:32:47 --> Total execution time: 0.0062
DEBUG - 2022-03-25 10:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:37:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:37:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:37:13 --> Total execution time: 0.0062
DEBUG - 2022-03-25 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:47:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:47:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:47:23 --> Total execution time: 0.0062
DEBUG - 2022-03-25 10:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:50:59 --> Total execution time: 0.0056
DEBUG - 2022-03-25 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 10:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 10:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 10:57:35 --> Total execution time: 0.0065
DEBUG - 2022-03-25 11:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:06:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:06:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:06:10 --> Total execution time: 0.0069
DEBUG - 2022-03-25 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:09:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:09:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:09:16 --> Total execution time: 0.0048
DEBUG - 2022-03-25 11:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:11:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:11:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:11:45 --> Total execution time: 0.0046
DEBUG - 2022-03-25 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:22:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:22:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:22:51 --> Total execution time: 0.0071
DEBUG - 2022-03-25 11:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:25:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:25:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:25:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:25:12 --> Total execution time: 0.0050
DEBUG - 2022-03-25 11:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:28:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:28:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:28:29 --> Total execution time: 0.0063
DEBUG - 2022-03-25 11:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:40:28 --> Total execution time: 0.0059
DEBUG - 2022-03-25 11:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:41:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 11:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 11:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 11:41:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 11:41:52 --> Total execution time: 0.0039
DEBUG - 2022-03-25 12:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 12:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 12:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 12:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 12:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 12:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 12:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:50:59 --> Total execution time: 0.0063
DEBUG - 2022-03-25 12:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 12:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 12:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 12:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 12:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 12:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 12:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:53:40 --> Total execution time: 0.0038
DEBUG - 2022-03-25 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 12:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 12:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 12:55:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 12:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 12:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 12:55:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:55:58 --> Total execution time: 0.0043
DEBUG - 2022-03-25 12:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 12:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 12:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 12:59:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 12:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 12:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 12:59:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 12:59:39 --> Total execution time: 0.0045
DEBUG - 2022-03-25 13:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 13:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 13:02:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 13:02:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 13:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 13:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 13:02:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 13:02:12 --> Total execution time: 0.0050
DEBUG - 2022-03-25 13:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 13:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 13:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 13:04:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 13:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 13:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 13:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 13:04:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 13:04:23 --> Total execution time: 0.0047
DEBUG - 2022-03-25 13:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 13:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 13:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 13:06:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 13:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 13:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 13:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 13:06:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 13:06:26 --> Total execution time: 0.0037
DEBUG - 2022-03-25 13:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 13:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 13:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 13:11:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 13:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 13:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 13:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 13:11:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 13:11:23 --> Total execution time: 0.0064
DEBUG - 2022-03-25 14:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:16:58 --> Total execution time: 0.0074
DEBUG - 2022-03-25 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:32:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:32:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:32:37 --> Total execution time: 0.0066
DEBUG - 2022-03-25 14:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:35:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:35:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:35:51 --> Total execution time: 0.0053
DEBUG - 2022-03-25 14:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:37:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:37:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:37:39 --> Total execution time: 0.0052
DEBUG - 2022-03-25 14:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:39:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:39:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:39:44 --> Total execution time: 0.0037
DEBUG - 2022-03-25 14:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:43:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:43:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:43:10 --> Total execution time: 0.0049
DEBUG - 2022-03-25 14:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:45:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:45:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:45:23 --> Total execution time: 0.0036
DEBUG - 2022-03-25 14:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:47:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:47:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:47:30 --> Total execution time: 0.0045
DEBUG - 2022-03-25 14:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:49:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:49:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:49:12 --> Total execution time: 0.0039
DEBUG - 2022-03-25 14:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:52:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:52:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:52:24 --> Total execution time: 0.0051
DEBUG - 2022-03-25 14:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:54:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:54:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:54:44 --> Total execution time: 0.0051
DEBUG - 2022-03-25 14:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:56:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:56:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:56:56 --> Total execution time: 0.0048
DEBUG - 2022-03-25 14:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:58:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 14:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 14:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 14:58:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 14:58:53 --> Total execution time: 0.0035
DEBUG - 2022-03-25 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:00:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:00:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:00:54 --> Total execution time: 0.0058
DEBUG - 2022-03-25 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:03:49 --> Total execution time: 0.0040
DEBUG - 2022-03-25 15:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:06:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:06:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:06:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:06:34 --> Total execution time: 0.0051
DEBUG - 2022-03-25 15:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:08:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:08:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:08:32 --> Total execution time: 0.0039
DEBUG - 2022-03-25 15:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:10:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:10:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:10:08 --> Total execution time: 0.0039
DEBUG - 2022-03-25 15:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:12:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:12:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:12:12 --> Total execution time: 0.0050
DEBUG - 2022-03-25 15:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:13:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:13:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:13:55 --> Total execution time: 0.0051
DEBUG - 2022-03-25 15:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:21:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:21:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:21:10 --> Total execution time: 0.0073
DEBUG - 2022-03-25 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:24:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:24:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:24:02 --> Total execution time: 0.0048
DEBUG - 2022-03-25 15:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:26:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:26:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:26:09 --> Total execution time: 0.0045
DEBUG - 2022-03-25 15:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:28:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:28:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:28:38 --> Total execution time: 0.0051
DEBUG - 2022-03-25 15:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:32:34 --> Total execution time: 0.0047
DEBUG - 2022-03-25 15:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:34:58 --> Total execution time: 0.0052
DEBUG - 2022-03-25 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:37:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:37:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:37:27 --> Total execution time: 0.0058
DEBUG - 2022-03-25 15:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:40:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:40:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:40:21 --> Total execution time: 0.0046
DEBUG - 2022-03-25 15:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:43:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:43:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:43:22 --> Total execution time: 0.0064
DEBUG - 2022-03-25 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:46:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:46:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:46:04 --> Total execution time: 0.0055
DEBUG - 2022-03-25 15:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:48:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:48:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:48:32 --> Total execution time: 0.0033
DEBUG - 2022-03-25 15:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:50:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:50:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:50:19 --> Total execution time: 0.0044
DEBUG - 2022-03-25 15:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:51:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:51:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:51:33 --> Total execution time: 0.0049
DEBUG - 2022-03-25 15:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:52:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:52:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:52:21 --> Total execution time: 0.0039
DEBUG - 2022-03-25 15:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:54:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 15:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 15:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 15:54:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 15:54:24 --> Total execution time: 0.0047
DEBUG - 2022-03-25 16:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:20:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:20:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:20:03 --> Total execution time: 0.0071
DEBUG - 2022-03-25 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:22:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:22:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:22:16 --> Total execution time: 0.0039
DEBUG - 2022-03-25 16:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:24:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:24:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:24:49 --> Total execution time: 0.0046
DEBUG - 2022-03-25 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:24:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:24:56 --> Total execution time: 0.0113
DEBUG - 2022-03-25 16:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:25:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:25:06 --> Total execution time: 0.0160
DEBUG - 2022-03-25 16:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:25:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:25:18 --> Total execution time: 0.0150
DEBUG - 2022-03-25 16:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:25:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:25:33 --> Total execution time: 0.0091
DEBUG - 2022-03-25 16:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:25:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:25:39 --> Total execution time: 0.0056
DEBUG - 2022-03-25 16:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:25:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:25:51 --> Total execution time: 0.0162
DEBUG - 2022-03-25 16:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:26:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:26:02 --> Total execution time: 0.0151
DEBUG - 2022-03-25 16:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:26:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:26:09 --> Total execution time: 0.0037
DEBUG - 2022-03-25 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:26:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:26:15 --> Total execution time: 0.0043
DEBUG - 2022-03-25 16:26:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:26:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:26:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:26:21 --> Total execution time: 0.0153
DEBUG - 2022-03-25 16:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:26:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:26:22 --> Total execution time: 0.0037
DEBUG - 2022-03-25 16:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:27:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:27:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:27:46 --> Total execution time: 0.0054
DEBUG - 2022-03-25 16:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:30:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:30:16 --> Total execution time: 0.0050
DEBUG - 2022-03-25 16:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:33:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:33:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:33:51 --> Total execution time: 0.0048
DEBUG - 2022-03-25 16:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:35:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:35:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:35:40 --> Total execution time: 0.0050
DEBUG - 2022-03-25 16:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:36:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:36:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:36:57 --> Total execution time: 0.0053
DEBUG - 2022-03-25 16:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:39:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:39:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:39:38 --> Total execution time: 0.0048
DEBUG - 2022-03-25 16:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:42:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:42:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:42:57 --> Total execution time: 0.0062
DEBUG - 2022-03-25 16:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:46:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:46:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:46:31 --> Total execution time: 0.0054
DEBUG - 2022-03-25 16:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:46:37 --> Total execution time: 0.0193
DEBUG - 2022-03-25 16:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-25 16:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-25 16:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-25 16:46:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-25 16:46:38 --> Total execution time: 0.0096
