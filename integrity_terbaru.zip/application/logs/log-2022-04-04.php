<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-04 07:48:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:48:18 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:48:40 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:48:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:48:42 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:48:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 07:48:59 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=525873 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:48:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:48:59 --> Unable to connect to the database
DEBUG - 2022-04-04 07:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:48:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:48:59 --> Total execution time: 41.5183
DEBUG - 2022-04-04 07:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:49:08 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 07:49:22 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570845 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:49:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:49:22 --> Unable to connect to the database
DEBUG - 2022-04-04 07:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:49:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:49:22 --> Total execution time: 41.5011
ERROR - 2022-04-04 07:49:23 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570846 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:49:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:49:23 --> Unable to connect to the database
DEBUG - 2022-04-04 07:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:49:23 --> Total execution time: 41.3034
ERROR - 2022-04-04 07:49:50 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570856 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:49:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:49:50 --> Unable to connect to the database
DEBUG - 2022-04-04 07:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:49:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:49:50 --> Total execution time: 41.4340
DEBUG - 2022-04-04 07:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:49:56 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 07:50:37 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570894 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:50:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:50:37 --> Unable to connect to the database
DEBUG - 2022-04-04 07:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:50:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:50:37 --> Total execution time: 41.5211
DEBUG - 2022-04-04 07:50:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:50:42 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:51:00 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:51:23 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:51:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 07:51:23 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570933 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:51:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:51:23 --> Unable to connect to the database
DEBUG - 2022-04-04 07:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:51:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:51:23 --> Total execution time: 41.3496
DEBUG - 2022-04-04 07:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:51:24 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:51:30 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:51:38 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:51:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 07:51:41 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570941 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:51:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:51:41 --> Unable to connect to the database
DEBUG - 2022-04-04 07:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:51:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:51:41 --> Total execution time: 41.5431
DEBUG - 2022-04-04 07:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:51:42 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:51:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 07:52:05 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570958 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:05 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:05 --> Unable to connect to the database
DEBUG - 2022-04-04 07:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:52:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:52:05 --> Total execution time: 41.5674
ERROR - 2022-04-04 07:52:06 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570959 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:06 --> Unable to connect to the database
DEBUG - 2022-04-04 07:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:52:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:52:06 --> Total execution time: 41.5746
ERROR - 2022-04-04 07:52:11 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570975 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:11 --> Unable to connect to the database
DEBUG - 2022-04-04 07:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:52:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:52:11 --> Total execution time: 41.5935
ERROR - 2022-04-04 07:52:19 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570976 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:19 --> Unable to connect to the database
DEBUG - 2022-04-04 07:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:52:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:52:19 --> Total execution time: 41.2848
ERROR - 2022-04-04 07:52:23 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=570941 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:52:23 --> Unable to connect to the database
DEBUG - 2022-04-04 07:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:52:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:52:23 --> Total execution time: 41.4641
DEBUG - 2022-04-04 07:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:52:40 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:52:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 07:53:21 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=571015 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:53:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:53:21 --> Unable to connect to the database
DEBUG - 2022-04-04 07:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:53:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:53:21 --> Total execution time: 41.4217
DEBUG - 2022-04-04 07:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:53:59 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:54:18 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:54:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:54:18 --> Total execution time: 0.0025
DEBUG - 2022-04-04 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:54:20 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:54:20 --> Total execution time: 0.0020
ERROR - 2022-04-04 07:54:41 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=571269 /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:54:41 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/nsnmt.com/integrity/system/database/drivers/mysqli/mysqli_driver.php 203
ERROR - 2022-04-04 07:54:41 --> Unable to connect to the database
DEBUG - 2022-04-04 07:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:54:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:54:41 --> Total execution time: 41.5339
DEBUG - 2022-04-04 07:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:55:15 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:55:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:55:15 --> Total execution time: 0.0021
DEBUG - 2022-04-04 07:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:55:26 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:55:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:55:26 --> Total execution time: 0.0021
DEBUG - 2022-04-04 07:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:56:07 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:56:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:56:07 --> Total execution time: 0.0021
DEBUG - 2022-04-04 07:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:56:13 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:56:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:56:13 --> Total execution time: 0.0021
DEBUG - 2022-04-04 07:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:56:17 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:56:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:56:17 --> Total execution time: 0.0022
DEBUG - 2022-04-04 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:56:32 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:56:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:56:32 --> Total execution time: 0.0023
DEBUG - 2022-04-04 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:56:35 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:56:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:56:35 --> Total execution time: 0.0014
DEBUG - 2022-04-04 07:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:56:36 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:56:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:56:36 --> Total execution time: 0.0019
DEBUG - 2022-04-04 07:56:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:56:57 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:56:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:56:57 --> Total execution time: 0.0020
DEBUG - 2022-04-04 07:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:57:09 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:57:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:57:09 --> Total execution time: 0.0022
DEBUG - 2022-04-04 07:57:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:57:12 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:57:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:57:12 --> Total execution time: 0.0020
DEBUG - 2022-04-04 07:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:57:27 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:57:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:57:27 --> Total execution time: 0.0023
DEBUG - 2022-04-04 07:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:57:56 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:57:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:57:56 --> Total execution time: 0.0021
DEBUG - 2022-04-04 07:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:58:52 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:58:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:58:52 --> Total execution time: 0.0020
DEBUG - 2022-04-04 07:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:59:35 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:59:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:59:35 --> Total execution time: 0.0025
DEBUG - 2022-04-04 07:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 07:59:38 --> No URI present. Default controller set.
DEBUG - 2022-04-04 07:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 07:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 07:59:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 07:59:38 --> Total execution time: 0.0022
DEBUG - 2022-04-04 08:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:02:46 --> No URI present. Default controller set.
DEBUG - 2022-04-04 08:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:02:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:02:46 --> Total execution time: 0.0390
DEBUG - 2022-04-04 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:04 --> 404 Page Not Found: 404html/index
DEBUG - 2022-04-04 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-04 08:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:13 --> No URI present. Default controller set.
DEBUG - 2022-04-04 08:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:03:13 --> Total execution time: 0.0022
DEBUG - 2022-04-04 08:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-04 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:16 --> No URI present. Default controller set.
DEBUG - 2022-04-04 08:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:03:16 --> Total execution time: 0.0026
DEBUG - 2022-04-04 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:16 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-04 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:16 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-04 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:16 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-04 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:16 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-04 08:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:16 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-04 08:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-04 08:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:28 --> Total execution time: 0.0068
DEBUG - 2022-04-04 08:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:34 --> Total execution time: 0.0041
DEBUG - 2022-04-04 08:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:34 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-04 08:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:42 --> Total execution time: 0.0020
DEBUG - 2022-04-04 08:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:03:49 --> Total execution time: 0.0145
DEBUG - 2022-04-04 08:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:03:58 --> Total execution time: 0.0031
DEBUG - 2022-04-04 08:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:03:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:03:58 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-04 08:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:04:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:04:01 --> Total execution time: 0.0087
DEBUG - 2022-04-04 08:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:04:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:04:29 --> Total execution time: 0.0078
DEBUG - 2022-04-04 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:04:31 --> Total execution time: 0.0032
DEBUG - 2022-04-04 08:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:04:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:04:40 --> Total execution time: 0.0075
DEBUG - 2022-04-04 08:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:04:45 --> Total execution time: 0.0079
DEBUG - 2022-04-04 08:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:04:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:04:49 --> Total execution time: 0.0054
DEBUG - 2022-04-04 08:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:04:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:04:52 --> Total execution time: 0.0045
DEBUG - 2022-04-04 08:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:05:45 --> No URI present. Default controller set.
DEBUG - 2022-04-04 08:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:05:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:05:45 --> Total execution time: 0.0024
DEBUG - 2022-04-04 08:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:05:46 --> No URI present. Default controller set.
DEBUG - 2022-04-04 08:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:05:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:05:46 --> Total execution time: 0.0014
DEBUG - 2022-04-04 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:05:48 --> No URI present. Default controller set.
DEBUG - 2022-04-04 08:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:05:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:05:48 --> Total execution time: 0.0013
DEBUG - 2022-04-04 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:05:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-04 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:05:48 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-04 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:05:48 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-04 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:05:48 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-04 08:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 08:05:48 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-04 08:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:07:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:07:50 --> Total execution time: 0.0451
DEBUG - 2022-04-04 08:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:07:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:07:54 --> Total execution time: 0.0077
DEBUG - 2022-04-04 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:08:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:08:45 --> Total execution time: 0.0079
DEBUG - 2022-04-04 08:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:08:52 --> Total execution time: 0.0068
DEBUG - 2022-04-04 08:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:08:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:08:57 --> Total execution time: 0.0077
DEBUG - 2022-04-04 08:09:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:09:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:09:42 --> Total execution time: 0.0083
DEBUG - 2022-04-04 08:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:15:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:15:39 --> Total execution time: 0.0444
DEBUG - 2022-04-04 08:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:16:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:16:43 --> Total execution time: 0.0446
DEBUG - 2022-04-04 08:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:16:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:16:46 --> Total execution time: 0.0128
DEBUG - 2022-04-04 08:33:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:33:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:33:45 --> Total execution time: 0.0527
DEBUG - 2022-04-04 08:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:33:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:33:53 --> Total execution time: 0.0064
DEBUG - 2022-04-04 08:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:39:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:39:44 --> Total execution time: 0.0381
DEBUG - 2022-04-04 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:41:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:41:21 --> Total execution time: 0.0443
DEBUG - 2022-04-04 08:41:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:41:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:41:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:41:26 --> Total execution time: 0.0150
DEBUG - 2022-04-04 08:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:41:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:41:27 --> Total execution time: 0.0029
DEBUG - 2022-04-04 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:44:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:44:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:44:12 --> Total execution time: 0.0041
DEBUG - 2022-04-04 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:49:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:49:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:49:43 --> Total execution time: 0.0038
DEBUG - 2022-04-04 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:55:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:55:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:55:40 --> Total execution time: 0.0038
DEBUG - 2022-04-04 08:57:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:57:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:57:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:57:01 --> Total execution time: 0.0049
DEBUG - 2022-04-04 08:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:59:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 08:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 08:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 08:59:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 08:59:58 --> Total execution time: 0.0040
DEBUG - 2022-04-04 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:03:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:03:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:03:36 --> Total execution time: 0.0038
DEBUG - 2022-04-04 09:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:07:12 --> Total execution time: 0.0039
DEBUG - 2022-04-04 09:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:09:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:09:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:09:22 --> Total execution time: 0.0040
DEBUG - 2022-04-04 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:11:32 --> Total execution time: 0.0041
DEBUG - 2022-04-04 09:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:13:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:13:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:13:13 --> Total execution time: 0.0039
DEBUG - 2022-04-04 09:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:15:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:15:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:15:16 --> Total execution time: 0.0052
DEBUG - 2022-04-04 09:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:16:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:16:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:16:46 --> Total execution time: 0.0039
DEBUG - 2022-04-04 09:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:26 --> No URI present. Default controller set.
DEBUG - 2022-04-04 09:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:18:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:18:26 --> Total execution time: 0.0344
DEBUG - 2022-04-04 09:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 09:18:27 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-04 09:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 09:18:27 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-04 09:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 09:18:27 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-04 09:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 09:18:27 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-04 09:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-04 09:18:27 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-04 09:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:18:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:18:32 --> Total execution time: 0.0029
DEBUG - 2022-04-04 09:18:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:18:36 --> Total execution time: 0.0076
DEBUG - 2022-04-04 09:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:18:38 --> Total execution time: 0.0049
DEBUG - 2022-04-04 09:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:19:05 --> Total execution time: 0.0060
DEBUG - 2022-04-04 09:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:19:08 --> Total execution time: 0.0039
DEBUG - 2022-04-04 09:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:19:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:19:21 --> Total execution time: 0.0138
DEBUG - 2022-04-04 09:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:19:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:19:23 --> Total execution time: 0.0038
DEBUG - 2022-04-04 09:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:43:23 --> No URI present. Default controller set.
DEBUG - 2022-04-04 09:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:43:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:43:23 --> Total execution time: 0.0357
DEBUG - 2022-04-04 09:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:43:24 --> No URI present. Default controller set.
DEBUG - 2022-04-04 09:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:43:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:43:24 --> Total execution time: 0.0020
DEBUG - 2022-04-04 09:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:43:49 --> No URI present. Default controller set.
DEBUG - 2022-04-04 09:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:43:49 --> Total execution time: 0.0016
DEBUG - 2022-04-04 09:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 09:43:53 --> No URI present. Default controller set.
DEBUG - 2022-04-04 09:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 09:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 09:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 09:43:53 --> Total execution time: 0.0015
DEBUG - 2022-04-04 18:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-04 18:58:40 --> No URI present. Default controller set.
DEBUG - 2022-04-04 18:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-04 18:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-04 18:58:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-04 18:58:40 --> Total execution time: 0.0339
