<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-01 03:49:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:49:14 --> No URI present. Default controller set.
DEBUG - 2021-12-01 03:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 03:49:14 --> Total execution time: 0.0894
DEBUG - 2021-12-01 03:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 03:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 03:49:15 --> Total execution time: 0.0690
DEBUG - 2021-12-01 03:55:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 03:55:33 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:55:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:55:33 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:55:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:55:33 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:55:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 03:55:33 --> Total execution time: 0.0633
DEBUG - 2021-12-01 03:55:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 03:55:40 --> Total execution time: 0.0452
DEBUG - 2021-12-01 03:55:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 03:55:42 --> Total execution time: 0.0379
DEBUG - 2021-12-01 03:55:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 03:55:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 03:55:53 --> Total execution time: 0.0449
DEBUG - 2021-12-01 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 03:56:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 03:56:16 --> Total execution time: 0.0440
DEBUG - 2021-12-01 03:56:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 03:56:19 --> Total execution time: 0.0425
DEBUG - 2021-12-01 03:56:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 03:56:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 03:56:40 --> Total execution time: 0.0320
DEBUG - 2021-12-01 03:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 03:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 03:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 03:56:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 03:56:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 03:56:59 --> Total execution time: 0.0522
DEBUG - 2021-12-01 04:08:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:08:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:08:49 --> Total execution time: 0.0392
DEBUG - 2021-12-01 04:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:08:50 --> Total execution time: 0.0402
DEBUG - 2021-12-01 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:08:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:08:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:08:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:08:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:08:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:08:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:08:54 --> Total execution time: 0.0549
DEBUG - 2021-12-01 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:08:55 --> Total execution time: 0.0526
DEBUG - 2021-12-01 04:09:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:09:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:09:09 --> Total execution time: 0.0439
DEBUG - 2021-12-01 04:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:09:11 --> Total execution time: 0.0378
DEBUG - 2021-12-01 04:09:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:09:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:09:17 --> Total execution time: 0.0523
DEBUG - 2021-12-01 04:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:09:19 --> Total execution time: 0.0437
DEBUG - 2021-12-01 04:09:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:09:29 --> Total execution time: 0.0475
DEBUG - 2021-12-01 04:09:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:09:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:09:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:09:32 --> Total execution time: 0.0439
DEBUG - 2021-12-01 04:09:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:09:32 --> Total execution time: 0.0420
DEBUG - 2021-12-01 04:10:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:10:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:10:46 --> Total execution time: 0.0482
DEBUG - 2021-12-01 04:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:10:47 --> Total execution time: 0.0509
DEBUG - 2021-12-01 04:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:10:47 --> Total execution time: 0.0370
DEBUG - 2021-12-01 04:10:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:10:48 --> Total execution time: 0.0456
DEBUG - 2021-12-01 04:10:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:10:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:10:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:10:49 --> Total execution time: 0.0506
DEBUG - 2021-12-01 04:10:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:10:49 --> Total execution time: 0.0274
DEBUG - 2021-12-01 04:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:11:29 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:11:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:11:29 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:11:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:11:29 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:11:29 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:11:29 --> Total execution time: 0.0554
DEBUG - 2021-12-01 04:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:11:29 --> Total execution time: 0.0391
DEBUG - 2021-12-01 04:12:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:12:34 --> Total execution time: 0.0384
DEBUG - 2021-12-01 04:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:12:35 --> Total execution time: 0.0480
DEBUG - 2021-12-01 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:13:17 --> Total execution time: 0.0432
DEBUG - 2021-12-01 04:13:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:13:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:18 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:32 --> No URI present. Default controller set.
DEBUG - 2021-12-01 04:14:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:32 --> Total execution time: 0.0305
DEBUG - 2021-12-01 04:14:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:33 --> Total execution time: 0.0479
DEBUG - 2021-12-01 04:14:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:34 --> Total execution time: 0.0621
DEBUG - 2021-12-01 04:14:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:14:35 --> Total execution time: 0.0509
DEBUG - 2021-12-01 04:14:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:35 --> Total execution time: 0.0271
DEBUG - 2021-12-01 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:14:36 --> Total execution time: 0.0420
DEBUG - 2021-12-01 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:36 --> Total execution time: 0.0459
DEBUG - 2021-12-01 04:14:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:14:37 --> Total execution time: 0.0437
DEBUG - 2021-12-01 04:14:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:37 --> Total execution time: 0.0469
DEBUG - 2021-12-01 04:14:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:14:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:14:39 --> Total execution time: 0.0476
DEBUG - 2021-12-01 04:14:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:39 --> Total execution time: 0.0510
DEBUG - 2021-12-01 04:14:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:42 --> Total execution time: 0.0506
DEBUG - 2021-12-01 04:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:14:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:53 --> No URI present. Default controller set.
DEBUG - 2021-12-01 04:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:53 --> Total execution time: 0.0453
DEBUG - 2021-12-01 04:14:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:14:54 --> No URI present. Default controller set.
DEBUG - 2021-12-01 04:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:14:54 --> Total execution time: 0.0264
DEBUG - 2021-12-01 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:06 --> Total execution time: 0.0385
DEBUG - 2021-12-01 04:17:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:08 --> Total execution time: 0.0429
DEBUG - 2021-12-01 04:17:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:09 --> Total execution time: 0.0265
DEBUG - 2021-12-01 04:17:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:10 --> Total execution time: 0.0434
DEBUG - 2021-12-01 04:17:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:11 --> Total execution time: 0.0376
DEBUG - 2021-12-01 04:17:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:12 --> Total execution time: 0.0420
DEBUG - 2021-12-01 04:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:13 --> Total execution time: 0.0448
DEBUG - 2021-12-01 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:14 --> Total execution time: 0.0266
DEBUG - 2021-12-01 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:17:14 --> Total execution time: 0.0526
DEBUG - 2021-12-01 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:14 --> Total execution time: 0.0433
DEBUG - 2021-12-01 04:17:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:14 --> Total execution time: 0.0462
DEBUG - 2021-12-01 04:17:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:15 --> Total execution time: 0.0427
DEBUG - 2021-12-01 04:17:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:16 --> Total execution time: 0.0505
DEBUG - 2021-12-01 04:17:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:29 --> Total execution time: 0.0245
DEBUG - 2021-12-01 04:17:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:30 --> Total execution time: 0.0397
DEBUG - 2021-12-01 04:17:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:36 --> Total execution time: 0.0482
DEBUG - 2021-12-01 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:39 --> Total execution time: 0.0416
DEBUG - 2021-12-01 04:17:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:40 --> Total execution time: 0.0400
DEBUG - 2021-12-01 04:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:41 --> Total execution time: 0.0538
DEBUG - 2021-12-01 04:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:17:41 --> Total execution time: 0.0320
DEBUG - 2021-12-01 04:17:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:42 --> Total execution time: 0.0397
DEBUG - 2021-12-01 04:17:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:42 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:42 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:42 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:17:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:17:42 --> Total execution time: 0.0424
DEBUG - 2021-12-01 04:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:43 --> Total execution time: 0.0473
DEBUG - 2021-12-01 04:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:43 --> Total execution time: 0.0355
DEBUG - 2021-12-01 04:17:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:17:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:17:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:17:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:17:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:17:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:17:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-01 04:17:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:51 --> Total execution time: 0.0440
DEBUG - 2021-12-01 04:17:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:52 --> Total execution time: 0.0397
DEBUG - 2021-12-01 04:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:55 --> Total execution time: 0.0245
DEBUG - 2021-12-01 04:17:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:56 --> Total execution time: 0.0373
DEBUG - 2021-12-01 04:17:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:17:58 --> Total execution time: 0.0243
DEBUG - 2021-12-01 04:18:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:03 --> Total execution time: 0.0376
DEBUG - 2021-12-01 04:18:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:05 --> Total execution time: 0.0475
DEBUG - 2021-12-01 04:18:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:07 --> Total execution time: 0.0424
DEBUG - 2021-12-01 04:18:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:09 --> Total execution time: 0.0412
DEBUG - 2021-12-01 04:18:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:38 --> Total execution time: 0.0463
DEBUG - 2021-12-01 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:39 --> Total execution time: 0.0420
DEBUG - 2021-12-01 04:18:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:40 --> Total execution time: 0.0473
DEBUG - 2021-12-01 04:18:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:42 --> Total execution time: 0.0498
DEBUG - 2021-12-01 04:18:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:49 --> Total execution time: 0.0445
DEBUG - 2021-12-01 04:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:50 --> Total execution time: 0.0421
DEBUG - 2021-12-01 04:18:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:51 --> Total execution time: 0.0243
DEBUG - 2021-12-01 04:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:18:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:18:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:18:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:18:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:18:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:18:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:18:52 --> Total execution time: 0.0308
DEBUG - 2021-12-01 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:53 --> Total execution time: 0.0419
DEBUG - 2021-12-01 04:18:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:18:54 --> Total execution time: 0.0392
DEBUG - 2021-12-01 04:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:20:34 --> Total execution time: 0.0493
DEBUG - 2021-12-01 04:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:20:35 --> Total execution time: 0.0362
DEBUG - 2021-12-01 04:21:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:21:49 --> Total execution time: 0.0362
DEBUG - 2021-12-01 04:21:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:21:52 --> Total execution time: 0.0409
DEBUG - 2021-12-01 04:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:21:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:21:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:21:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:21:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:21:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:21:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:21:53 --> Total execution time: 0.0421
DEBUG - 2021-12-01 04:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:21:54 --> Total execution time: 0.0384
DEBUG - 2021-12-01 04:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:21:54 --> Total execution time: 0.0363
DEBUG - 2021-12-01 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:23:13 --> Total execution time: 0.0453
DEBUG - 2021-12-01 04:23:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:23:13 --> Total execution time: 0.0372
DEBUG - 2021-12-01 04:23:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:23:14 --> Total execution time: 0.0392
DEBUG - 2021-12-01 04:26:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:26:28 --> Total execution time: 0.0429
DEBUG - 2021-12-01 04:26:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:26:29 --> Total execution time: 0.0489
DEBUG - 2021-12-01 04:26:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:26:37 --> Total execution time: 0.0448
DEBUG - 2021-12-01 04:27:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:27:20 --> Total execution time: 0.0420
DEBUG - 2021-12-01 04:27:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:27:34 --> Total execution time: 0.0478
DEBUG - 2021-12-01 04:27:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:27:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:27:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:27:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:27:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:27:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:27:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:27:36 --> Total execution time: 0.0469
DEBUG - 2021-12-01 04:29:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:29:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:29:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:29:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:29:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:29:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:29:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:29:14 --> Total execution time: 0.0536
DEBUG - 2021-12-01 04:29:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:29:16 --> Total execution time: 0.0320
DEBUG - 2021-12-01 04:42:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:42:31 --> Severity: error --> Exception: Unable to locate the model you have specified: Fullcalendar_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-01 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:44:26 --> Severity: error --> Exception: Unable to locate the model you have specified: Fullcalendar_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-01 04:44:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:44:27 --> Severity: error --> Exception: Unable to locate the model you have specified: Fullcalendar_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-01 04:44:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:44:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:44:28 --> Total execution time: 0.0551
DEBUG - 2021-12-01 04:44:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:44:29 --> Severity: error --> Exception: Unable to locate the model you have specified: Fullcalendar_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-01 04:44:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:44:48 --> Severity: error --> Exception: Unable to locate the model you have specified: Fullcalendar_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-01 04:44:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:44:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:44:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:44:49 --> Total execution time: 0.0589
DEBUG - 2021-12-01 04:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:44:50 --> Severity: error --> Exception: Unable to locate the model you have specified: Fullcalendar_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-01 04:45:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:45:41 --> Severity: error --> Exception: Unable to locate the model you have specified: Fullcalendar_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-01 04:45:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:45:42 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:42 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:42 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:42 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:45:42 --> Total execution time: 0.0406
DEBUG - 2021-12-01 04:45:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:45:43 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:43 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:43 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:45:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:45:43 --> Total execution time: 0.0455
DEBUG - 2021-12-01 04:45:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:45:44 --> Severity: error --> Exception: Unable to locate the model you have specified: Fullcalendar_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-01 04:46:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:46:01 --> Total execution time: 0.0478
DEBUG - 2021-12-01 04:46:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:46:03 --> Total execution time: 0.0423
DEBUG - 2021-12-01 04:46:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:46:04 --> Total execution time: 0.0383
DEBUG - 2021-12-01 04:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:46:13 --> Total execution time: 0.0436
DEBUG - 2021-12-01 04:46:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:46:14 --> Total execution time: 0.0500
DEBUG - 2021-12-01 04:46:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:46:15 --> Total execution time: 0.0397
DEBUG - 2021-12-01 04:46:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:46:59 --> Total execution time: 0.0430
DEBUG - 2021-12-01 04:48:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:30 --> Total execution time: 0.0514
DEBUG - 2021-12-01 04:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:31 --> Total execution time: 0.0474
DEBUG - 2021-12-01 04:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:31 --> Total execution time: 0.0492
DEBUG - 2021-12-01 04:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:32 --> Total execution time: 0.0435
DEBUG - 2021-12-01 04:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:36 --> Total execution time: 0.0245
DEBUG - 2021-12-01 04:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:36 --> Total execution time: 0.0260
DEBUG - 2021-12-01 04:48:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:38 --> Total execution time: 0.0420
DEBUG - 2021-12-01 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:39 --> Total execution time: 0.0469
DEBUG - 2021-12-01 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:39 --> Total execution time: 0.0458
DEBUG - 2021-12-01 04:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:39 --> Total execution time: 0.0392
DEBUG - 2021-12-01 04:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:48:40 --> Total execution time: 0.0452
DEBUG - 2021-12-01 04:54:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:54:01 --> 404 Page Not Found: User/index
DEBUG - 2021-12-01 04:54:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:54:05 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:05 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:05 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:54:05 --> Total execution time: 0.0452
DEBUG - 2021-12-01 04:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:54:07 --> 404 Page Not Found: User/index
DEBUG - 2021-12-01 04:54:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:54:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:54:59 --> 404 Page Not Found: User/index
DEBUG - 2021-12-01 04:54:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:54:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:54:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:54:59 --> Total execution time: 0.0548
DEBUG - 2021-12-01 04:55:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:55:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:55:00 --> 404 Page Not Found: FullCalendar/index
DEBUG - 2021-12-01 04:55:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:55:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:55:16 --> Total execution time: 0.0539
DEBUG - 2021-12-01 04:55:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:55:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:55:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:55:17 --> Total execution time: 0.0424
DEBUG - 2021-12-01 04:56:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:56:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:56:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:56:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:56:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:56:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:56:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:56:56 --> Total execution time: 0.0459
DEBUG - 2021-12-01 04:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:56:57 --> 404 Page Not Found: User/index
DEBUG - 2021-12-01 04:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:57:26 --> 404 Page Not Found: User/index
DEBUG - 2021-12-01 04:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:57:27 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:27 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:27 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:57:27 --> Total execution time: 0.0332
DEBUG - 2021-12-01 04:57:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:57:28 --> 404 Page Not Found: FullCaledar/index
DEBUG - 2021-12-01 04:57:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:57:36 --> 404 Page Not Found: FullCaledar/index
DEBUG - 2021-12-01 04:57:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:57:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:57:36 --> Total execution time: 0.0451
DEBUG - 2021-12-01 04:57:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:57:38 --> Total execution time: 0.0502
DEBUG - 2021-12-01 04:57:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:57:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:57:39 --> Total execution time: 0.0316
DEBUG - 2021-12-01 04:57:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:57:40 --> Total execution time: 0.0488
DEBUG - 2021-12-01 04:57:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:57:41 --> Total execution time: 0.0433
DEBUG - 2021-12-01 04:57:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:57:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:57:44 --> Total execution time: 0.0462
DEBUG - 2021-12-01 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:57:45 --> 404 Page Not Found: FullCaledar/index
DEBUG - 2021-12-01 04:57:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:57:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:57:47 --> Total execution time: 0.0481
DEBUG - 2021-12-01 04:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 04:57:48 --> Total execution time: 0.0488
DEBUG - 2021-12-01 04:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:57:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:57:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:57:48 --> Total execution time: 0.0499
DEBUG - 2021-12-01 04:57:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:57:49 --> 404 Page Not Found: FullCaledar/index
DEBUG - 2021-12-01 04:58:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:58:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:58:20 --> 404 Page Not Found: FullCaledar/index
DEBUG - 2021-12-01 04:58:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:58:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:58:21 --> Total execution time: 0.0327
DEBUG - 2021-12-01 04:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 04:58:22 --> 404 Page Not Found: FullCaledar/index
DEBUG - 2021-12-01 04:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 04:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 04:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 04:58:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 04:58:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 04:58:23 --> Total execution time: 0.0329
DEBUG - 2021-12-01 05:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 05:05:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 05:05:12 --> Total execution time: 0.0538
DEBUG - 2021-12-01 05:05:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:13 --> Total execution time: 0.0372
DEBUG - 2021-12-01 05:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:16 --> Total execution time: 0.0246
DEBUG - 2021-12-01 05:05:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:18 --> Total execution time: 0.0413
DEBUG - 2021-12-01 05:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:20 --> Total execution time: 0.0471
DEBUG - 2021-12-01 05:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:21 --> Total execution time: 0.0409
DEBUG - 2021-12-01 05:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 05:05:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:05:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 05:05:23 --> Total execution time: 0.0483
DEBUG - 2021-12-01 05:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:24 --> Total execution time: 0.0278
DEBUG - 2021-12-01 05:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:24 --> Total execution time: 0.0478
DEBUG - 2021-12-01 05:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:25 --> Total execution time: 0.0431
DEBUG - 2021-12-01 05:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:05:26 --> Total execution time: 0.0483
DEBUG - 2021-12-01 05:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:06:01 --> Total execution time: 0.0549
DEBUG - 2021-12-01 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:06:02 --> Total execution time: 0.0453
DEBUG - 2021-12-01 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:06:02 --> Total execution time: 0.0341
DEBUG - 2021-12-01 05:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:06:02 --> Total execution time: 0.0412
DEBUG - 2021-12-01 05:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:08:21 --> Total execution time: 0.0440
DEBUG - 2021-12-01 05:08:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:08:36 --> Total execution time: 0.0350
DEBUG - 2021-12-01 05:08:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:08:45 --> Total execution time: 0.0405
DEBUG - 2021-12-01 05:08:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 05:08:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 05:08:47 --> Total execution time: 0.0412
DEBUG - 2021-12-01 05:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:08:50 --> Total execution time: 0.0441
DEBUG - 2021-12-01 05:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 05:08:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:08:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 05:08:56 --> Total execution time: 0.0525
DEBUG - 2021-12-01 05:08:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:08:59 --> Total execution time: 0.0462
DEBUG - 2021-12-01 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 05:09:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 05:09:28 --> Total execution time: 0.0524
DEBUG - 2021-12-01 05:09:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:09:31 --> Total execution time: 0.0417
DEBUG - 2021-12-01 05:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 05:09:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 05:09:48 --> Total execution time: 0.0314
DEBUG - 2021-12-01 05:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:09:52 --> Total execution time: 0.0418
DEBUG - 2021-12-01 05:09:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 05:09:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:09:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 05:09:55 --> Total execution time: 0.0501
DEBUG - 2021-12-01 05:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:09:57 --> Total execution time: 0.0414
DEBUG - 2021-12-01 05:10:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 05:10:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:10:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:10:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:10:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:10:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 05:10:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 05:10:14 --> Total execution time: 0.0338
DEBUG - 2021-12-01 05:10:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 05:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 05:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 05:10:21 --> Total execution time: 0.0436
DEBUG - 2021-12-01 07:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:15 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:06:15 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:06:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:22 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:06:22 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:23 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:06:23 --> Total execution time: 0.0712
DEBUG - 2021-12-01 07:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:24 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:06:24 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:06:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:48 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:06:48 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:06:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:48 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:06:48 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:06:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:48 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:06:48 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:06:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:06:49 --> Total execution time: 0.0523
DEBUG - 2021-12-01 07:06:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:50 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:50 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:50 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:06:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:06:50 --> Total execution time: 0.0533
DEBUG - 2021-12-01 07:06:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:06:51 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:06:51 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:07:45 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:07:45 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:07:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:07:45 --> Total execution time: 0.0523
DEBUG - 2021-12-01 07:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:07:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:07:46 --> Total execution time: 0.0509
DEBUG - 2021-12-01 07:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:07:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:07:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:07:47 --> Total execution time: 0.0499
DEBUG - 2021-12-01 07:07:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:07:47 --> Severity: Warning --> Undefined variable $name_id C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:07:47 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:09:23 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:09:23 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:09:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:09:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:09:24 --> Total execution time: 0.0326
DEBUG - 2021-12-01 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:09:45 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:09:45 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:09:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:09:45 --> Total execution time: 0.0423
DEBUG - 2021-12-01 07:09:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:09:47 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:09:47 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:09:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:09:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:09:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:09:47 --> Total execution time: 0.0522
DEBUG - 2021-12-01 07:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:09:49 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:09:49 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:12:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:12:40 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:12:40 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:12:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:12:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:12:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:12:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:12:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:12:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:12:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:12:40 --> Total execution time: 0.0478
DEBUG - 2021-12-01 07:12:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:12:41 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:12:41 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:15:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:15:46 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:15:46 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:15:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:15:47 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:15:47 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:15:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:15:47 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:15:47 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:15:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:15:47 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:15:47 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:15:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:15:47 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:15:47 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:16:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:16:50 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:16:50 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:16:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:16:50 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:16:50 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:16:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:16:51 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:16:51 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:27:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:27:16 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:27:16 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:27:16 --> Total execution time: 0.0498
DEBUG - 2021-12-01 07:29:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:28 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:29:28 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:29:28 --> Total execution time: 0.0514
DEBUG - 2021-12-01 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:30 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:29:30 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:29:30 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 07:29:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 07:29:30 --> Total execution time: 0.0503
DEBUG - 2021-12-01 07:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:30 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:29:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:29:30 --> Total execution time: 0.0488
DEBUG - 2021-12-01 07:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:29:32 --> Total execution time: 0.0425
DEBUG - 2021-12-01 07:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:29:32 --> Total execution time: 0.0284
DEBUG - 2021-12-01 07:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:29:32 --> Total execution time: 0.0397
DEBUG - 2021-12-01 07:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:29:32 --> Total execution time: 0.0393
DEBUG - 2021-12-01 07:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:29:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:29:32 --> Total execution time: 0.0652
DEBUG - 2021-12-01 07:29:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:29:57 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:29:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:29:57 --> Total execution time: 0.0508
DEBUG - 2021-12-01 07:30:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:30:02 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:30:02 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:30:02 --> Total execution time: 0.0400
DEBUG - 2021-12-01 07:30:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:30:08 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 07:30:08 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 07:30:08 --> Total execution time: 0.0539
DEBUG - 2021-12-01 07:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:31:27 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 07:31:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 07:31:27 --> Total execution time: 0.0449
DEBUG - 2021-12-01 07:32:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:32:10 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 07:32:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 07:32:10 --> Total execution time: 0.0423
DEBUG - 2021-12-01 07:32:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:32:48 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 07:32:48 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 07:32:48 --> Total execution time: 0.0504
DEBUG - 2021-12-01 07:37:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:37:12 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 07:37:12 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 07:37:12 --> Total execution time: 0.0395
DEBUG - 2021-12-01 07:38:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:38:17 --> Severity: Warning --> Undefined variable $get_name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 07:38:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 07:38:17 --> Total execution time: 0.0511
DEBUG - 2021-12-01 07:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 07:53:31 --> Total execution time: 0.0540
DEBUG - 2021-12-01 07:58:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:58:35 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 07:58:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 07:58:35 --> Total execution time: 0.0518
DEBUG - 2021-12-01 07:59:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 07:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 07:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 07:59:47 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 07:59:47 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 07:59:47 --> Total execution time: 0.0482
DEBUG - 2021-12-01 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:00:10 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:00:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:00:10 --> Total execution time: 0.0419
DEBUG - 2021-12-01 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:00:10 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:00:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:00:10 --> Total execution time: 0.0481
DEBUG - 2021-12-01 08:00:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:00:10 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:00:10 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:00:10 --> Total execution time: 0.0479
DEBUG - 2021-12-01 08:00:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:00:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:00:27 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:00:27 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:00:27 --> Total execution time: 0.0295
DEBUG - 2021-12-01 08:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:04:32 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:04:32 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:04:32 --> Total execution time: 0.0480
DEBUG - 2021-12-01 08:12:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:12:59 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:12:59 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:13:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:06 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:06 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:06 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 08:13:06 --> Total execution time: 0.0460
DEBUG - 2021-12-01 08:13:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:08 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:13:08 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:13:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:15 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:15 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:15 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:15 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 08:13:15 --> Total execution time: 0.0520
DEBUG - 2021-12-01 08:13:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:16 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:13:16 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:13:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 08:13:17 --> Total execution time: 0.0490
DEBUG - 2021-12-01 08:13:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:44 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:13:44 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:46 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:13:46 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:46 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:13:46 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:13:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:13:46 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:13:46 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:14:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:14:11 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:14:11 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:14:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:14:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:14:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:14:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:14:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:14:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 08:14:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 08:14:12 --> Total execution time: 0.0468
DEBUG - 2021-12-01 08:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:14:13 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:14:13 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:14:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:14:26 --> Severity: Warning --> Undefined variable $client C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
ERROR - 2021-12-01 08:14:26 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 40
DEBUG - 2021-12-01 08:14:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 08:14:33 --> Total execution time: 0.0408
DEBUG - 2021-12-01 08:22:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 08:22:00 --> Total execution time: 0.0317
DEBUG - 2021-12-01 08:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 08:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 08:22:24 --> Total execution time: 0.0396
DEBUG - 2021-12-01 08:22:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 08:22:26 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
DEBUG - 2021-12-01 08:22:26 --> Total execution time: 0.0614
DEBUG - 2021-12-01 08:23:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 08:23:08 --> Total execution time: 0.0280
DEBUG - 2021-12-01 08:23:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:23:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 08:23:20 --> 404 Page Not Found: Data/edit_barang
DEBUG - 2021-12-01 08:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 08:23:22 --> Total execution time: 0.0508
DEBUG - 2021-12-01 08:23:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 08:23:28 --> Total execution time: 0.0276
DEBUG - 2021-12-01 08:35:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:35:03 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 08:35:03 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 08:35:03 --> Total execution time: 0.0415
DEBUG - 2021-12-01 08:35:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:35:57 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 08:35:57 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 08:35:57 --> Total execution time: 0.0315
DEBUG - 2021-12-01 08:36:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 08:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 08:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 08:36:00 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 08:36:00 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 08:36:00 --> Total execution time: 0.0422
DEBUG - 2021-12-01 09:42:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:42:51 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 09:42:51 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 09:42:51 --> Total execution time: 0.0597
DEBUG - 2021-12-01 09:42:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
DEBUG - 2021-12-01 09:42:52 --> Total execution time: 0.0572
DEBUG - 2021-12-01 09:42:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:54 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
DEBUG - 2021-12-01 09:42:54 --> Total execution time: 0.0537
DEBUG - 2021-12-01 09:42:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:42:56 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:42:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 57
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
ERROR - 2021-12-01 09:42:58 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\data\index.php 79
DEBUG - 2021-12-01 09:42:58 --> Total execution time: 0.0624
DEBUG - 2021-12-01 09:43:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:43:22 --> Total execution time: 0.0417
DEBUG - 2021-12-01 09:43:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:43:23 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:44:40 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:44:41 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:44:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:44:41 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:44:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:44:41 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:44:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:44:41 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:44:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:44:41 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:44:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:44:42 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:44:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:44:42 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 09:48:39 --> 404 Page Not Found: Data/edit
DEBUG - 2021-12-01 09:49:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:49:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 09:49:01 --> 404 Page Not Found: Data/edit
DEBUG - 2021-12-01 09:49:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:49:02 --> Total execution time: 0.0401
DEBUG - 2021-12-01 09:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 09:49:04 --> 404 Page Not Found: Data/edit
DEBUG - 2021-12-01 09:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:49:05 --> Total execution time: 0.0483
DEBUG - 2021-12-01 09:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:49:26 --> Total execution time: 0.0482
DEBUG - 2021-12-01 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:49:27 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 67
DEBUG - 2021-12-01 09:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:49:45 --> Total execution time: 0.0494
DEBUG - 2021-12-01 09:50:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:50:02 --> Total execution time: 0.0494
DEBUG - 2021-12-01 09:50:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:50:03 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 67
DEBUG - 2021-12-01 09:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:50:55 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 67
DEBUG - 2021-12-01 09:50:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:50:56 --> Total execution time: 0.0393
DEBUG - 2021-12-01 09:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 09:50:57 --> 404 Page Not Found: Appointment/edit_barang
DEBUG - 2021-12-01 09:51:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:51:03 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 66
DEBUG - 2021-12-01 09:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:51:18 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 66
DEBUG - 2021-12-01 09:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:51:18 --> Total execution time: 0.0282
DEBUG - 2021-12-01 09:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:51:19 --> Total execution time: 0.0442
DEBUG - 2021-12-01 09:51:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:51:20 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 66
DEBUG - 2021-12-01 09:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:51:25 --> Severity: Warning --> Undefined variable $appointment C:\xampp\htdocs\nesnu\application\controllers\appointment.php 71
ERROR - 2021-12-01 09:51:25 --> Severity: Warning --> Undefined variable $pilihan C:\xampp\htdocs\nesnu\application\controllers\appointment.php 72
ERROR - 2021-12-01 09:51:25 --> Severity: Warning --> Undefined variable $photo C:\xampp\htdocs\nesnu\application\controllers\appointment.php 74
ERROR - 2021-12-01 09:51:25 --> Severity: Warning --> Undefined variable $video C:\xampp\htdocs\nesnu\application\controllers\appointment.php 75
ERROR - 2021-12-01 09:51:25 --> Severity: Warning --> Undefined variable $edit C:\xampp\htdocs\nesnu\application\controllers\appointment.php 76
ERROR - 2021-12-01 09:51:25 --> Severity: Warning --> Undefined variable $crew C:\xampp\htdocs\nesnu\application\controllers\appointment.php 77
DEBUG - 2021-12-01 09:51:25 --> Total execution time: 0.0469
DEBUG - 2021-12-01 09:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:52:38 --> Total execution time: 0.0457
DEBUG - 2021-12-01 09:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:52:39 --> Total execution time: 0.0347
DEBUG - 2021-12-01 09:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:52:41 --> Total execution time: 0.0434
DEBUG - 2021-12-01 09:52:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:52:43 --> Total execution time: 0.0498
DEBUG - 2021-12-01 09:52:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:52:54 --> Total execution time: 0.0454
DEBUG - 2021-12-01 09:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:52:55 --> Total execution time: 0.0287
DEBUG - 2021-12-01 09:52:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:52:56 --> Total execution time: 0.0484
DEBUG - 2021-12-01 09:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:52:58 --> Total execution time: 0.0441
DEBUG - 2021-12-01 09:54:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:54:36 --> Total execution time: 0.0462
DEBUG - 2021-12-01 09:54:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:54:37 --> Total execution time: 0.0351
DEBUG - 2021-12-01 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:54:39 --> Total execution time: 0.0477
DEBUG - 2021-12-01 09:54:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:54:40 --> Severity: Warning --> Undefined variable $name C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
ERROR - 2021-12-01 09:54:40 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\appointment\index.php 39
DEBUG - 2021-12-01 09:54:40 --> Total execution time: 0.0299
DEBUG - 2021-12-01 09:55:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:55:14 --> Total execution time: 0.0436
DEBUG - 2021-12-01 09:55:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:55:41 --> Severity: Warning --> Undefined property: Appointment::$Client_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 39
ERROR - 2021-12-01 09:55:41 --> Severity: error --> Exception: Call to a member function getAllClient() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 39
DEBUG - 2021-12-01 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:05 --> Total execution time: 0.0281
DEBUG - 2021-12-01 09:56:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:06 --> Total execution time: 0.0378
DEBUG - 2021-12-01 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:28 --> Total execution time: 0.0406
DEBUG - 2021-12-01 09:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:44 --> Total execution time: 0.0459
DEBUG - 2021-12-01 09:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:48 --> Total execution time: 0.0420
DEBUG - 2021-12-01 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:49 --> Total execution time: 0.0423
DEBUG - 2021-12-01 09:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:51 --> Total execution time: 0.0426
DEBUG - 2021-12-01 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:52 --> Total execution time: 0.0404
DEBUG - 2021-12-01 09:56:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:53 --> Total execution time: 0.0503
DEBUG - 2021-12-01 09:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:55 --> Total execution time: 0.0286
DEBUG - 2021-12-01 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:57 --> Total execution time: 0.0433
DEBUG - 2021-12-01 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:58 --> Total execution time: 0.0528
DEBUG - 2021-12-01 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:56:59 --> Total execution time: 0.0496
DEBUG - 2021-12-01 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:57:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:57:01 --> Total execution time: 0.0539
DEBUG - 2021-12-01 09:57:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:57:02 --> Total execution time: 0.0440
DEBUG - 2021-12-01 09:57:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:57:04 --> Total execution time: 0.0421
DEBUG - 2021-12-01 09:57:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 09:57:29 --> Total execution time: 0.0503
DEBUG - 2021-12-01 09:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:57:30 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:59:01 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 09:59:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 09:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 09:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 09:59:02 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 10:00:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:01 --> Total execution time: 0.0616
DEBUG - 2021-12-01 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:04 --> Total execution time: 0.0442
DEBUG - 2021-12-01 10:00:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:07 --> Total execution time: 0.0439
DEBUG - 2021-12-01 10:00:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:08 --> Total execution time: 0.0440
DEBUG - 2021-12-01 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:09 --> Total execution time: 0.0443
DEBUG - 2021-12-01 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:10 --> Total execution time: 0.0449
DEBUG - 2021-12-01 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:22 --> Total execution time: 0.0384
DEBUG - 2021-12-01 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:22 --> Total execution time: 0.0437
DEBUG - 2021-12-01 10:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:23 --> Total execution time: 0.0585
DEBUG - 2021-12-01 10:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:23 --> Total execution time: 0.0289
DEBUG - 2021-12-01 10:00:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:24 --> Total execution time: 0.0462
DEBUG - 2021-12-01 10:00:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:24 --> Total execution time: 0.0447
DEBUG - 2021-12-01 10:00:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:25 --> Total execution time: 0.0464
DEBUG - 2021-12-01 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:26 --> Total execution time: 0.0450
DEBUG - 2021-12-01 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:26 --> Total execution time: 0.0440
DEBUG - 2021-12-01 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:28 --> Total execution time: 0.0432
DEBUG - 2021-12-01 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:00:28 --> Total execution time: 0.0417
DEBUG - 2021-12-01 10:03:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:14 --> Total execution time: 0.0484
DEBUG - 2021-12-01 10:03:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:15 --> Total execution time: 0.0365
DEBUG - 2021-12-01 10:03:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:16 --> Total execution time: 0.0432
DEBUG - 2021-12-01 10:03:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:23 --> Total execution time: 0.0457
DEBUG - 2021-12-01 10:03:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:23 --> Total execution time: 0.0455
DEBUG - 2021-12-01 10:03:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:24 --> Total execution time: 0.0413
DEBUG - 2021-12-01 10:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:26 --> Total execution time: 0.0532
DEBUG - 2021-12-01 10:03:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:27 --> Total execution time: 0.0440
DEBUG - 2021-12-01 10:03:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:31 --> Total execution time: 0.0447
DEBUG - 2021-12-01 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:33 --> Total execution time: 0.0282
DEBUG - 2021-12-01 10:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:33 --> Total execution time: 0.0377
DEBUG - 2021-12-01 10:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:34 --> Total execution time: 0.0431
DEBUG - 2021-12-01 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:35 --> Total execution time: 0.0454
DEBUG - 2021-12-01 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:37 --> Total execution time: 0.0430
DEBUG - 2021-12-01 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:38 --> Total execution time: 0.0273
DEBUG - 2021-12-01 10:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:03:57 --> Total execution time: 0.0379
DEBUG - 2021-12-01 10:03:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:03:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 10:03:59 --> 404 Page Not Found: Appointment/edit
DEBUG - 2021-12-01 10:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 10:04:08 --> 404 Page Not Found: Appointment/edit
DEBUG - 2021-12-01 10:04:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:10 --> Total execution time: 0.0482
DEBUG - 2021-12-01 10:04:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:12 --> Total execution time: 0.0437
DEBUG - 2021-12-01 10:04:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:13 --> Total execution time: 0.0430
DEBUG - 2021-12-01 10:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:14 --> Total execution time: 0.0445
DEBUG - 2021-12-01 10:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:14 --> Total execution time: 0.0445
DEBUG - 2021-12-01 10:04:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:43 --> Total execution time: 0.0440
DEBUG - 2021-12-01 10:04:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:46 --> Total execution time: 0.0460
DEBUG - 2021-12-01 10:04:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:04:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:04:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:04:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:04:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:04:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:04:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 10:04:48 --> Total execution time: 0.0322
DEBUG - 2021-12-01 10:04:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:50 --> Total execution time: 0.0422
DEBUG - 2021-12-01 10:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:54 --> Total execution time: 0.0281
DEBUG - 2021-12-01 10:04:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:04:56 --> Total execution time: 0.0524
DEBUG - 2021-12-01 10:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:05:39 --> Total execution time: 0.0404
DEBUG - 2021-12-01 10:05:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:05:40 --> Total execution time: 0.0278
DEBUG - 2021-12-01 10:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:06:15 --> Total execution time: 0.0508
DEBUG - 2021-12-01 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:06:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:06:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:06:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:06:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:06:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:06:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 10:06:17 --> Total execution time: 0.0518
DEBUG - 2021-12-01 10:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:06:24 --> Total execution time: 0.0417
DEBUG - 2021-12-01 10:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:06:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:06:26 --> Total execution time: 0.0569
DEBUG - 2021-12-01 10:07:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:07:13 --> Total execution time: 0.0301
DEBUG - 2021-12-01 10:10:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:10:27 --> Total execution time: 0.0432
DEBUG - 2021-12-01 10:11:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:11:21 --> Total execution time: 0.0552
DEBUG - 2021-12-01 10:11:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:11:38 --> Total execution time: 0.0540
DEBUG - 2021-12-01 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:11:52 --> Total execution time: 0.0501
DEBUG - 2021-12-01 10:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:12:00 --> Total execution time: 0.0469
DEBUG - 2021-12-01 10:13:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:13:14 --> Total execution time: 0.0555
DEBUG - 2021-12-01 10:13:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:13:34 --> Total execution time: 0.0427
DEBUG - 2021-12-01 10:15:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:15:04 --> Total execution time: 0.0295
DEBUG - 2021-12-01 10:17:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:17:20 --> Total execution time: 0.0444
DEBUG - 2021-12-01 10:17:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:17:31 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:31 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:31 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 10:17:31 --> Total execution time: 0.0337
DEBUG - 2021-12-01 10:17:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:17:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:17:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 10:17:37 --> Total execution time: 0.0486
DEBUG - 2021-12-01 10:17:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:17:40 --> Total execution time: 0.0523
DEBUG - 2021-12-01 10:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:18:06 --> Total execution time: 0.0411
DEBUG - 2021-12-01 10:20:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:20:01 --> Total execution time: 0.0431
DEBUG - 2021-12-01 10:20:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:20:11 --> Total execution time: 0.0508
DEBUG - 2021-12-01 10:20:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:20:54 --> Total execution time: 0.0457
DEBUG - 2021-12-01 10:22:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:22:17 --> Total execution time: 0.0473
DEBUG - 2021-12-01 10:22:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:22:30 --> Total execution time: 0.0397
DEBUG - 2021-12-01 10:23:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:23:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-01 10:23:02 --> 404 Page Not Found: Data/edit_barang
DEBUG - 2021-12-01 10:23:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:23:04 --> Total execution time: 0.0363
DEBUG - 2021-12-01 10:23:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:23:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:23:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 10:23:49 --> Total execution time: 0.0484
DEBUG - 2021-12-01 10:23:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:23:50 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:50 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:50 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 10:23:50 --> Total execution time: 0.0577
DEBUG - 2021-12-01 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:23:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:23:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 153
ERROR - 2021-12-01 10:23:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 153
DEBUG - 2021-12-01 10:23:54 --> Total execution time: 0.0492
DEBUG - 2021-12-01 10:23:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:24:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:24:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:24:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:24:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:24:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:24:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:24:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 10:24:12 --> Total execution time: 0.0552
DEBUG - 2021-12-01 10:24:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:24:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:24:53 --> Total execution time: 0.0315
DEBUG - 2021-12-01 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:24:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:24:59 --> Total execution time: 0.0543
DEBUG - 2021-12-01 10:26:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:26:37 --> Total execution time: 0.0304
DEBUG - 2021-12-01 10:27:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:27:28 --> Total execution time: 0.0460
DEBUG - 2021-12-01 10:28:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:28:22 --> Total execution time: 0.0480
DEBUG - 2021-12-01 10:30:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:30:06 --> Total execution time: 0.0382
DEBUG - 2021-12-01 10:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:30:41 --> Total execution time: 0.0527
DEBUG - 2021-12-01 10:31:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:31:06 --> Total execution time: 0.0475
DEBUG - 2021-12-01 10:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:31:45 --> Total execution time: 0.0297
DEBUG - 2021-12-01 10:32:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:32:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:32:28 --> Total execution time: 0.0284
DEBUG - 2021-12-01 10:32:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:32:30 --> Total execution time: 0.0421
DEBUG - 2021-12-01 10:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:32:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:32:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:32:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:32:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:32:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:32:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 10:32:32 --> Total execution time: 0.0505
DEBUG - 2021-12-01 10:32:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:32:33 --> Total execution time: 0.0478
DEBUG - 2021-12-01 10:33:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:33:39 --> Total execution time: 0.0387
DEBUG - 2021-12-01 10:33:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:33:43 --> Total execution time: 0.0521
DEBUG - 2021-12-01 10:34:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:34:06 --> Total execution time: 0.0417
DEBUG - 2021-12-01 10:35:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:35:11 --> Total execution time: 0.0379
DEBUG - 2021-12-01 10:35:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:35:37 --> Total execution time: 0.0383
DEBUG - 2021-12-01 10:35:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:35:47 --> Total execution time: 0.0458
DEBUG - 2021-12-01 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:35:58 --> Total execution time: 0.0513
DEBUG - 2021-12-01 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:36:45 --> Total execution time: 0.0526
DEBUG - 2021-12-01 10:36:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:36:54 --> Total execution time: 0.0277
DEBUG - 2021-12-01 10:37:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:37:24 --> Total execution time: 0.0524
DEBUG - 2021-12-01 10:37:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:37:37 --> Total execution time: 0.0525
DEBUG - 2021-12-01 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:38:10 --> Total execution time: 0.0398
DEBUG - 2021-12-01 10:38:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:38:47 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1519
ERROR - 2021-12-01 10:38:47 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1519
ERROR - 2021-12-01 10:38:47 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1519
ERROR - 2021-12-01 10:38:47 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1519
ERROR - 2021-12-01 10:38:47 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1519
ERROR - 2021-12-01 10:38:47 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1519
ERROR - 2021-12-01 10:38:47 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: UPDATE `appointment` SET `name` = 'Farhan & FItri', `name_a` = NULL, `package` = 'Paket 1', `description` = Array, `detail` = Array, `more` = 'Tambahan 1 Jam', `photograper` = Array, `videograper` = Array, `editor` = Array, `crew` = Array, `price` = 'Rp. 2.750.000', `date` = '2021-12-09', `place` = 'Braga'
WHERE `id` = '16'
ERROR - 2021-12-01 10:38:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\nesnu\system\core\Exceptions.php:271) C:\xampp\htdocs\nesnu\system\core\Common.php 570
DEBUG - 2021-12-01 10:40:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:40:07 --> Total execution time: 0.0538
DEBUG - 2021-12-01 10:40:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:40:08 --> Total execution time: 0.0381
DEBUG - 2021-12-01 10:40:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:40:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:40:50 --> Total execution time: 0.0284
DEBUG - 2021-12-01 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:41:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:41:50 --> Total execution time: 0.0270
DEBUG - 2021-12-01 10:47:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:47:49 --> Total execution time: 0.0324
DEBUG - 2021-12-01 10:47:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:47:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:47:57 --> Total execution time: 0.0507
DEBUG - 2021-12-01 10:48:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:48:01 --> Total execution time: 0.0456
DEBUG - 2021-12-01 10:48:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:48:05 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:05 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:05 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 10:48:05 --> Total execution time: 0.0712
DEBUG - 2021-12-01 10:48:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:48:11 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:11 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:11 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 10:48:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 10:48:11 --> Total execution time: 0.0450
DEBUG - 2021-12-01 10:48:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:48:13 --> Total execution time: 0.0466
DEBUG - 2021-12-01 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:48:27 --> Total execution time: 0.0480
DEBUG - 2021-12-01 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:49:06 --> Total execution time: 0.0377
DEBUG - 2021-12-01 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:49:07 --> Total execution time: 0.0389
DEBUG - 2021-12-01 10:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:49:17 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 10:49:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:49:19 --> Total execution time: 0.0545
DEBUG - 2021-12-01 10:49:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:49:22 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 10:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:49:24 --> Total execution time: 0.0504
DEBUG - 2021-12-01 10:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:49:28 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 10:49:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:49:30 --> Total execution time: 0.0282
DEBUG - 2021-12-01 10:50:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:50:12 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 10:50:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:50:16 --> Total execution time: 0.0457
DEBUG - 2021-12-01 10:50:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:50:17 --> Total execution time: 0.0470
DEBUG - 2021-12-01 10:50:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:50:47 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 34
DEBUG - 2021-12-01 10:51:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:51:28 --> Total execution time: 0.0492
DEBUG - 2021-12-01 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:51:31 --> Total execution time: 0.0366
DEBUG - 2021-12-01 10:51:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:51:32 --> Total execution time: 0.0436
DEBUG - 2021-12-01 10:51:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:51:34 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:51:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:51:36 --> Total execution time: 0.0523
DEBUG - 2021-12-01 10:51:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:51:53 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:52:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:52:17 --> Total execution time: 0.0452
DEBUG - 2021-12-01 10:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:52:38 --> Total execution time: 0.0410
DEBUG - 2021-12-01 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:53:13 --> Total execution time: 0.0477
DEBUG - 2021-12-01 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:53:33 --> Total execution time: 0.0412
DEBUG - 2021-12-01 10:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:53:33 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:53:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:53:43 --> Total execution time: 0.0458
DEBUG - 2021-12-01 10:53:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:53:45 --> Total execution time: 0.0444
DEBUG - 2021-12-01 10:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:53:46 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:53:53 --> Total execution time: 0.0527
DEBUG - 2021-12-01 10:53:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:53:54 --> Total execution time: 0.0506
DEBUG - 2021-12-01 10:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:53:55 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:54:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:54:01 --> Total execution time: 0.0479
DEBUG - 2021-12-01 10:54:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:54:02 --> Total execution time: 0.0469
DEBUG - 2021-12-01 10:54:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:54:08 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:54:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:54:10 --> Total execution time: 0.0532
DEBUG - 2021-12-01 10:54:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:54:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:54:29 --> Total execution time: 0.0417
DEBUG - 2021-12-01 10:54:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:54:32 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:54:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:54:39 --> Total execution time: 0.0488
DEBUG - 2021-12-01 10:54:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:54:44 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:54:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:54:56 --> Total execution time: 0.0499
DEBUG - 2021-12-01 10:55:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:55:05 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:55:06 --> Total execution time: 0.0516
DEBUG - 2021-12-01 10:55:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:55:19 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 30
DEBUG - 2021-12-01 10:55:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:55:25 --> Total execution time: 0.0391
DEBUG - 2021-12-01 10:55:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:55:40 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 30
DEBUG - 2021-12-01 10:55:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:55:44 --> Total execution time: 0.0508
DEBUG - 2021-12-01 10:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:56:49 --> Total execution time: 0.0425
DEBUG - 2021-12-01 10:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:56:50 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:56:55 --> Total execution time: 0.0507
DEBUG - 2021-12-01 10:57:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:57:44 --> Total execution time: 0.0504
DEBUG - 2021-12-01 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:57:45 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:57:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:57:47 --> Total execution time: 0.0282
DEBUG - 2021-12-01 10:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 10:57:48 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 10:57:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 10:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 10:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 10:57:51 --> Total execution time: 0.0456
DEBUG - 2021-12-01 11:00:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:00:55 --> Total execution time: 0.0447
DEBUG - 2021-12-01 11:01:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:01:23 --> Total execution time: 0.0391
DEBUG - 2021-12-01 11:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:01:41 --> Total execution time: 0.0467
DEBUG - 2021-12-01 11:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 11:01:51 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 11:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:01:53 --> Total execution time: 0.0279
DEBUG - 2021-12-01 11:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:02:00 --> Total execution time: 0.0457
DEBUG - 2021-12-01 11:02:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 11:02:09 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-01 11:02:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:02:16 --> Total execution time: 0.0436
DEBUG - 2021-12-01 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:08:05 --> Total execution time: 0.0512
DEBUG - 2021-12-01 11:08:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:08:07 --> Total execution time: 0.0475
DEBUG - 2021-12-01 11:08:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 11:08:08 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-01 11:08:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:08:10 --> Total execution time: 0.0396
DEBUG - 2021-12-01 11:10:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:10:39 --> Total execution time: 0.0467
DEBUG - 2021-12-01 11:11:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:11:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:11:40 --> Total execution time: 0.0395
DEBUG - 2021-12-01 11:11:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:11:42 --> Total execution time: 0.0445
DEBUG - 2021-12-01 11:14:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:14:11 --> Total execution time: 0.0425
DEBUG - 2021-12-01 11:14:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:14:12 --> Total execution time: 0.0507
DEBUG - 2021-12-01 11:14:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 11:14:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 11:14:14 --> Total execution time: 0.0494
DEBUG - 2021-12-01 11:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 11:14:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:14:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 11:14:18 --> Total execution time: 0.0329
DEBUG - 2021-12-01 11:14:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:14:19 --> Total execution time: 0.0283
DEBUG - 2021-12-01 11:16:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:16:47 --> Total execution time: 0.0382
DEBUG - 2021-12-01 11:16:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 11:16:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 11:16:47 --> Total execution time: 0.0454
DEBUG - 2021-12-01 11:16:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:16:48 --> Total execution time: 0.0449
DEBUG - 2021-12-01 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 11:16:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 11:16:49 --> Total execution time: 0.0319
DEBUG - 2021-12-01 11:16:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:16:49 --> Total execution time: 0.0449
DEBUG - 2021-12-01 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-01 11:16:51 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:51 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:51 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-01 11:16:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-01 11:16:51 --> Total execution time: 0.0535
DEBUG - 2021-12-01 11:16:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:16:51 --> Total execution time: 0.0468
DEBUG - 2021-12-01 11:17:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-01 11:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-01 11:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-01 11:17:05 --> Total execution time: 0.0442
