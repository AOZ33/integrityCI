<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-05 02:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:23:55 --> No URI present. Default controller set.
DEBUG - 2022-03-05 02:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 02:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 02:23:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 02:23:55 --> Total execution time: 0.0331
DEBUG - 2022-03-05 02:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:23:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 02:23:55 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 02:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:51:51 --> No URI present. Default controller set.
DEBUG - 2022-03-05 02:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 02:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 02:51:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 02:51:51 --> Total execution time: 0.0312
DEBUG - 2022-03-05 02:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:51:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 02:51:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 02:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:53:23 --> No URI present. Default controller set.
DEBUG - 2022-03-05 02:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 02:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 02:53:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 02:53:23 --> Total execution time: 0.0308
DEBUG - 2022-03-05 02:53:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 02:53:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 02:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 02:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 02:53:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 02:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 02:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 02:53:31 --> Total execution time: 0.0065
DEBUG - 2022-03-05 02:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:53:34 --> No URI present. Default controller set.
DEBUG - 2022-03-05 02:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 02:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 02:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 02:53:34 --> Total execution time: 0.0032
DEBUG - 2022-03-05 02:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 02:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 02:53:44 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:03:48 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:03:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:03:48 --> Total execution time: 0.0304
DEBUG - 2022-03-05 03:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:03:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:10:17 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:10:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:10:17 --> Total execution time: 0.0302
DEBUG - 2022-03-05 03:10:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:10:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:10:17 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:10:49 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:10:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:10:49 --> Total execution time: 0.0051
DEBUG - 2022-03-05 03:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:10:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:10:50 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:11:24 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:11:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:11:24 --> Total execution time: 0.0049
DEBUG - 2022-03-05 03:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:11:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:11:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:11:46 --> Total execution time: 0.0052
DEBUG - 2022-03-05 03:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:11:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:11:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:12:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:12:26 --> Total execution time: 0.0040
DEBUG - 2022-03-05 03:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:12:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:12:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:12:31 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:12:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:12:31 --> Total execution time: 0.0041
DEBUG - 2022-03-05 03:12:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:12:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:12:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:13:27 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:13:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:13:27 --> Total execution time: 0.0047
DEBUG - 2022-03-05 03:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:13:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:13:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:14:19 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:14:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:14:19 --> Total execution time: 0.0060
DEBUG - 2022-03-05 03:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:14:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:14:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:14:34 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:14:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:14:34 --> Total execution time: 0.0049
DEBUG - 2022-03-05 03:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:14:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:14:34 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:15:12 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:15:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:15:12 --> Total execution time: 0.0048
DEBUG - 2022-03-05 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:15:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:15:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:15:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:15:35 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:15:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:15:35 --> Total execution time: 0.0046
DEBUG - 2022-03-05 03:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:15:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:15:36 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:16:08 --> No URI present. Default controller set.
DEBUG - 2022-03-05 03:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:16:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:16:08 --> Total execution time: 0.0042
DEBUG - 2022-03-05 03:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:16:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 03:16:08 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 03:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:16:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:16:31 --> Total execution time: 0.0052
DEBUG - 2022-03-05 03:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:16:40 --> Total execution time: 0.0046
DEBUG - 2022-03-05 03:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:16:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:16:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-05 03:16:43 --> Total execution time: 0.0190
DEBUG - 2022-03-05 03:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:22:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:22:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-05 03:22:40 --> Total execution time: 0.0432
DEBUG - 2022-03-05 03:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:22:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 03:22:40 --> Total execution time: 0.0049
DEBUG - 2022-03-05 03:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 03:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 03:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 03:48:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 03:48:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 03:48:55 --> Total execution time: 0.0461
DEBUG - 2022-03-05 04:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:19:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:19:43 --> Total execution time: 0.0459
DEBUG - 2022-03-05 04:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:19:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:19:50 --> Unable to load the requested class: Dompdf_gen
DEBUG - 2022-03-05 04:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:19:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:19:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:19:57 --> Total execution time: 0.0091
DEBUG - 2022-03-05 04:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:20:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:20:42 --> Unable to load the requested class: Dompdf_gen
DEBUG - 2022-03-05 04:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:21:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:21:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:21:45 --> Total execution time: 0.0111
DEBUG - 2022-03-05 04:21:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:21:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:21:48 --> Unable to load the requested class: Dompdf_gen
DEBUG - 2022-03-05 04:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:22:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:35 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:22:35 --> Total execution time: 0.0111
DEBUG - 2022-03-05 04:22:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:22:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:22:38 --> Severity: error --> Exception: Call to a member function result() on array /home/dunr4521/public_html/integrity/application/controllers/Data.php 86
DEBUG - 2022-03-05 04:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:22:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:22:41 --> Severity: error --> Exception: Call to a member function result() on array /home/dunr4521/public_html/integrity/application/controllers/Data.php 86
DEBUG - 2022-03-05 04:22:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:22:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:22:43 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:22:43 --> Total execution time: 0.0101
DEBUG - 2022-03-05 04:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:22:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:22:55 --> Severity: error --> Exception: Call to a member function result() on array /home/dunr4521/public_html/integrity/application/controllers/Data.php 86
DEBUG - 2022-03-05 04:23:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:23:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:23:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:23:18 --> Total execution time: 0.0124
DEBUG - 2022-03-05 04:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:23:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:23:23 --> Severity: error --> Exception: Call to a member function result() on array /home/dunr4521/public_html/integrity/application/controllers/Data.php 86
DEBUG - 2022-03-05 04:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:24:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:24:18 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:24:18 --> Total execution time: 0.0107
DEBUG - 2022-03-05 04:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:25:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:25:00 --> Severity: error --> Exception: Call to a member function result() on array /home/dunr4521/public_html/integrity/application/controllers/Data.php 86
DEBUG - 2022-03-05 04:25:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:25:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:25:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:25:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:25:02 --> Total execution time: 0.0095
DEBUG - 2022-03-05 04:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:26:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:26:41 --> Total execution time: 0.0417
DEBUG - 2022-03-05 04:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:26:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:26:43 --> Severity: error --> Exception: Call to a member function result() on array /home/dunr4521/public_html/integrity/application/controllers/Data.php 86
DEBUG - 2022-03-05 04:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:26:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:26:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:26:45 --> Total execution time: 0.0092
DEBUG - 2022-03-05 04:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:27:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:27:45 --> Total execution time: 0.0116
DEBUG - 2022-03-05 04:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:27:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:27:47 --> Severity: error --> Exception: Call to a member function result() on array /home/dunr4521/public_html/integrity/application/controllers/Data.php 86
DEBUG - 2022-03-05 04:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:27:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:27:50 --> Total execution time: 0.0092
DEBUG - 2022-03-05 04:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:29:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:29:31 --> Severity: error --> Exception: Call to a member function result() on array /home/dunr4521/public_html/integrity/application/controllers/Data.php 86
DEBUG - 2022-03-05 04:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 04:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 04:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 04:29:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 04:29:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 04:29:34 --> Total execution time: 0.0173
DEBUG - 2022-03-05 05:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 05:22:02 --> No URI present. Default controller set.
DEBUG - 2022-03-05 05:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 05:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 05:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 05:22:02 --> Total execution time: 0.0301
DEBUG - 2022-03-05 05:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 05:22:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 05:22:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 08:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 08:20:17 --> No URI present. Default controller set.
DEBUG - 2022-03-05 08:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 08:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 08:20:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 08:20:17 --> Total execution time: 0.0299
DEBUG - 2022-03-05 08:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 08:20:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 08:20:17 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 13:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:03:20 --> No URI present. Default controller set.
DEBUG - 2022-03-05 13:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:03:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:03:20 --> Total execution time: 0.0300
DEBUG - 2022-03-05 13:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:03:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 13:03:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 13:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:03:21 --> No URI present. Default controller set.
DEBUG - 2022-03-05 13:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:03:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:03:21 --> Total execution time: 0.0039
DEBUG - 2022-03-05 13:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:03:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:03:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:03:30 --> Total execution time: 0.0051
DEBUG - 2022-03-05 13:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:03:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 13:03:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 13:03:38 --> Total execution time: 0.0160
DEBUG - 2022-03-05 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:04:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:04:10 --> Total execution time: 0.0057
DEBUG - 2022-03-05 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:12:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:12:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:12:14 --> Total execution time: 0.0061
DEBUG - 2022-03-05 13:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:17:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:17:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:17:23 --> Total execution time: 0.0071
DEBUG - 2022-03-05 13:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:21:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:21:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:21:04 --> Total execution time: 0.0059
DEBUG - 2022-03-05 13:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:23:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:23:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:23:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:23:37 --> Total execution time: 0.0053
DEBUG - 2022-03-05 13:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:27:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:27:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:27:43 --> Total execution time: 0.0061
DEBUG - 2022-03-05 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 13:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 13:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 13:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 13:33:02 --> Total execution time: 0.0059
DEBUG - 2022-03-05 14:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 14:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 14:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 14:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 14:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 14:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 14:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 14:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 14:24:46 --> Total execution time: 0.0080
DEBUG - 2022-03-05 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 15:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 15:32:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 15:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 15:32:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 15:32:01 --> Total execution time: 0.0068
DEBUG - 2022-03-05 15:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 15:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 15:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 15:37:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 15:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 15:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 15:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 15:37:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 15:37:11 --> Total execution time: 0.0060
DEBUG - 2022-03-05 16:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:04:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:04:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:04:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:04:33 --> Total execution time: 0.0060
DEBUG - 2022-03-05 16:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:07:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:07:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:07:54 --> Total execution time: 0.0048
DEBUG - 2022-03-05 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:23:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:23:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:23:39 --> Total execution time: 0.0063
DEBUG - 2022-03-05 16:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:39:33 --> No URI present. Default controller set.
DEBUG - 2022-03-05 16:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:39:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:39:33 --> Total execution time: 0.0307
DEBUG - 2022-03-05 16:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:39:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 16:39:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-05 16:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:39:34 --> No URI present. Default controller set.
DEBUG - 2022-03-05 16:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:39:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:39:34 --> Total execution time: 0.0030
DEBUG - 2022-03-05 16:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:39:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:39:50 --> Total execution time: 0.0044
DEBUG - 2022-03-05 16:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:39:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-05 16:39:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 332
DEBUG - 2022-03-05 16:39:56 --> Total execution time: 0.0148
DEBUG - 2022-03-05 16:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 16:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 16:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 16:40:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 16:40:02 --> Total execution time: 0.0041
DEBUG - 2022-03-05 18:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 18:19:00 --> No URI present. Default controller set.
DEBUG - 2022-03-05 18:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-05 18:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-05 18:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-05 18:19:00 --> Total execution time: 0.0310
DEBUG - 2022-03-05 18:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-05 18:19:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-05 18:19:00 --> 404 Page Not Found: Assets/https:
