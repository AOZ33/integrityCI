<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-03 09:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:05:01 --> No URI present. Default controller set.
DEBUG - 2022-02-03 09:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:05:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 09:05:01 --> Total execution time: 0.0315
DEBUG - 2022-02-03 09:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:05:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-03 09:05:01 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-03 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:13:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:13:56 --> Total execution time: 0.0055
DEBUG - 2022-02-03 09:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:14:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-03 09:14:19 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 148878296 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-03 09:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:14:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 09:14:21 --> Total execution time: 0.0040
DEBUG - 2022-02-03 09:52:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:52:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 09:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:52:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 09:52:33 --> Total execution time: 0.0070
DEBUG - 2022-02-03 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:58:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 09:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 09:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 09:58:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 09:58:59 --> Total execution time: 0.0059
DEBUG - 2022-02-03 10:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:01:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:01:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:01:59 --> Total execution time: 0.0048
DEBUG - 2022-02-03 10:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:20:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:20:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:20:11 --> Total execution time: 0.0059
DEBUG - 2022-02-03 10:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:31:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:31:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:31:05 --> Total execution time: 0.0060
DEBUG - 2022-02-03 10:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:37:33 --> Total execution time: 0.0063
DEBUG - 2022-02-03 10:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:49:45 --> Total execution time: 0.0055
DEBUG - 2022-02-03 10:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 10:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 10:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 10:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 10:54:20 --> Total execution time: 0.0062
DEBUG - 2022-02-03 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:00:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:00:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:00:14 --> Total execution time: 0.0059
DEBUG - 2022-02-03 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:03:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:03:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:03:23 --> Total execution time: 0.0055
DEBUG - 2022-02-03 11:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:09:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:09:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:09:06 --> Total execution time: 0.0061
DEBUG - 2022-02-03 11:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:12:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:12:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:12:31 --> Total execution time: 0.0058
DEBUG - 2022-02-03 11:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:14:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:14:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:14:45 --> Total execution time: 0.0052
DEBUG - 2022-02-03 11:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:25:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:25:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:25:18 --> Total execution time: 0.0056
DEBUG - 2022-02-03 11:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:30:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:30:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:30:59 --> Total execution time: 0.0068
DEBUG - 2022-02-03 11:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:34:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:34:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:34:41 --> Total execution time: 0.0064
DEBUG - 2022-02-03 11:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:40:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:40:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:40:32 --> Total execution time: 0.0064
DEBUG - 2022-02-03 11:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:42:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:42:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:42:04 --> Total execution time: 0.0045
DEBUG - 2022-02-03 11:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:44:57 --> Total execution time: 0.0053
DEBUG - 2022-02-03 11:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:53:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 11:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 11:53:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 11:53:20 --> Total execution time: 0.0059
DEBUG - 2022-02-03 12:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 12:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 12:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 12:25:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 12:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 12:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 12:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 12:25:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 12:25:07 --> Total execution time: 0.0067
DEBUG - 2022-02-03 12:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 12:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 12:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 12:28:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 12:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 12:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 12:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 12:28:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 12:28:10 --> Total execution time: 0.0052
DEBUG - 2022-02-03 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 12:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 12:31:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 12:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 12:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 12:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 12:31:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 12:31:28 --> Total execution time: 0.0058
DEBUG - 2022-02-03 13:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 13:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 13:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 13:18:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 13:18:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 13:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 13:18:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 13:18:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 13:18:59 --> Total execution time: 0.0070
DEBUG - 2022-02-03 13:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 13:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 13:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 13:25:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 13:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 13:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 13:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 13:25:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 13:25:52 --> Total execution time: 0.0059
DEBUG - 2022-02-03 14:01:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:01:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:01:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:01:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:01:45 --> Total execution time: 0.0066
DEBUG - 2022-02-03 14:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:09:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:09:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:09:29 --> Total execution time: 0.0061
DEBUG - 2022-02-03 14:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:17:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:17:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:17:28 --> Total execution time: 0.0062
DEBUG - 2022-02-03 14:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:20:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:20:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:20:57 --> Total execution time: 0.0057
DEBUG - 2022-02-03 14:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:32:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:32:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:32:00 --> Total execution time: 0.0063
DEBUG - 2022-02-03 14:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:38:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:38:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:38:22 --> Total execution time: 0.0058
DEBUG - 2022-02-03 14:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:43:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:43:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:43:19 --> Total execution time: 0.0075
DEBUG - 2022-02-03 14:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:52:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 14:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 14:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 14:52:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 14:52:14 --> Total execution time: 0.0061
DEBUG - 2022-02-03 15:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:14:35 --> Total execution time: 0.0066
DEBUG - 2022-02-03 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:18:38 --> Total execution time: 0.0062
DEBUG - 2022-02-03 15:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:22:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:22:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:22:42 --> Total execution time: 0.0059
DEBUG - 2022-02-03 15:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:32:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:32:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:32:06 --> Total execution time: 0.0058
DEBUG - 2022-02-03 15:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:39:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:39:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:39:34 --> Total execution time: 0.0055
DEBUG - 2022-02-03 15:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:43:07 --> Total execution time: 0.0057
DEBUG - 2022-02-03 15:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:57:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 15:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 15:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 15:57:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 15:57:25 --> Total execution time: 0.0061
DEBUG - 2022-02-03 16:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:01:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:01:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:01:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:01:23 --> Total execution time: 0.0058
DEBUG - 2022-02-03 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:11:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:11:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:11:19 --> Total execution time: 0.0057
DEBUG - 2022-02-03 16:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:36:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:36:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:36:15 --> Total execution time: 0.0061
DEBUG - 2022-02-03 16:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:47:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:47:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:47:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:47:19 --> Total execution time: 0.0053
DEBUG - 2022-02-03 16:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:49:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:49:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:49:42 --> Total execution time: 0.0044
DEBUG - 2022-02-03 16:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:51:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-03 16:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-03 16:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-03 16:51:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-03 16:51:18 --> Total execution time: 0.0051
