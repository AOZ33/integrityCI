<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-21 10:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:48 --> No URI present. Default controller set.
DEBUG - 2022-03-21 10:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:18:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:18:48 --> Total execution time: 0.0301
DEBUG - 2022-03-21 10:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-21 10:18:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-21 10:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-21 10:18:49 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-21 10:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-21 10:18:49 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-21 10:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-21 10:18:49 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-03-21 10:18:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-21 10:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:49 --> No URI present. Default controller set.
DEBUG - 2022-03-21 10:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:18:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:18:49 --> Total execution time: 0.0033
DEBUG - 2022-03-21 10:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:18:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:18:54 --> Total execution time: 0.0077
DEBUG - 2022-03-21 10:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:19:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:19:03 --> Total execution time: 0.0127
DEBUG - 2022-03-21 10:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:19:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:19:04 --> Total execution time: 0.0041
DEBUG - 2022-03-21 10:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:40:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:40:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:40:17 --> Total execution time: 0.0072
DEBUG - 2022-03-21 10:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:45:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:45:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:45:57 --> Total execution time: 0.0059
DEBUG - 2022-03-21 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:53:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 10:53:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 10:53:13 --> Total execution time: 0.0056
DEBUG - 2022-03-21 11:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:01:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:01:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:01:57 --> Total execution time: 0.0060
DEBUG - 2022-03-21 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:07:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:07:30 --> Total execution time: 0.0063
DEBUG - 2022-03-21 11:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:11:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:11:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:11:18 --> Total execution time: 0.0059
DEBUG - 2022-03-21 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:30:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:30:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:30:58 --> Total execution time: 0.0059
DEBUG - 2022-03-21 11:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:37:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:37:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:37:55 --> Total execution time: 0.0070
DEBUG - 2022-03-21 11:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:50:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:50:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:50:35 --> Total execution time: 0.0062
DEBUG - 2022-03-21 11:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:53:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:53:34 --> Total execution time: 0.0053
DEBUG - 2022-03-21 11:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:56:18 --> Total execution time: 0.0050
DEBUG - 2022-03-21 11:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:59:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:59:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 11:59:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 11:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 11:59:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 11:59:49 --> Total execution time: 0.0052
DEBUG - 2022-03-21 12:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 12:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 12:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 12:01:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 12:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 12:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 12:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 12:01:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 12:01:56 --> Total execution time: 0.0049
DEBUG - 2022-03-21 12:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 12:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 12:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 12:47:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 12:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 12:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 12:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 12:47:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 12:47:13 --> Total execution time: 0.0076
DEBUG - 2022-03-21 13:06:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:06:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:06:44 --> Total execution time: 0.0400
DEBUG - 2022-03-21 13:06:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:06:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:06:46 --> Total execution time: 0.0101
DEBUG - 2022-03-21 13:06:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:06:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:06:57 --> Total execution time: 0.0045
DEBUG - 2022-03-21 13:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:12:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:12:46 --> Total execution time: 0.0340
DEBUG - 2022-03-21 13:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:18:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:18:49 --> Total execution time: 0.0414
DEBUG - 2022-03-21 13:18:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:18:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:18:53 --> Total execution time: 0.0108
DEBUG - 2022-03-21 13:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:19:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:19:01 --> Total execution time: 0.0041
DEBUG - 2022-03-21 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:22:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:22:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:22:17 --> Total execution time: 0.0052
DEBUG - 2022-03-21 13:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:26:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:26:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:26:11 --> Total execution time: 0.0058
DEBUG - 2022-03-21 13:50:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:50:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:50:24 --> Total execution time: 0.0411
DEBUG - 2022-03-21 13:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:50:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:50:31 --> Total execution time: 0.0083
DEBUG - 2022-03-21 13:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:50:45 --> Total execution time: 0.0055
DEBUG - 2022-03-21 13:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:50:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:50:52 --> Total execution time: 0.0072
DEBUG - 2022-03-21 13:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:50:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:50:56 --> Total execution time: 0.0034
DEBUG - 2022-03-21 13:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:54:53 --> Total execution time: 0.0065
DEBUG - 2022-03-21 13:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:56:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 13:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 13:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 13:56:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 13:56:51 --> Total execution time: 0.0055
DEBUG - 2022-03-21 14:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:01:54 --> Total execution time: 0.0064
DEBUG - 2022-03-21 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:07:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:07:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:07:31 --> Total execution time: 0.0059
DEBUG - 2022-03-21 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:13:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:13:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:13:46 --> Total execution time: 0.0066
DEBUG - 2022-03-21 14:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:17:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:17:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:17:09 --> Total execution time: 0.0047
DEBUG - 2022-03-21 14:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:30:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 14:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 14:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 14:30:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 14:30:01 --> Total execution time: 0.0067
DEBUG - 2022-03-21 15:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:11:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:11:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:11:20 --> Total execution time: 0.0076
DEBUG - 2022-03-21 15:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:16:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:16:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:16:35 --> Total execution time: 0.0067
DEBUG - 2022-03-21 15:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:22:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:22:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:22:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:22:12 --> Total execution time: 0.0061
DEBUG - 2022-03-21 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:25:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:25:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:25:57 --> Total execution time: 0.0066
DEBUG - 2022-03-21 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:32:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:32:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:32:22 --> Total execution time: 0.0061
DEBUG - 2022-03-21 15:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:34:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:34:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:34:47 --> Total execution time: 0.0048
DEBUG - 2022-03-21 15:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:38:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:38:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:38:01 --> Total execution time: 0.0065
DEBUG - 2022-03-21 15:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:41:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:41:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:41:42 --> Total execution time: 0.0049
DEBUG - 2022-03-21 15:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:45:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:45:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:45:34 --> Total execution time: 0.0051
DEBUG - 2022-03-21 15:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:50:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:50:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:50:16 --> Total execution time: 0.0058
DEBUG - 2022-03-21 15:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:53:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:53:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:53:37 --> Total execution time: 0.0054
DEBUG - 2022-03-21 15:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:58:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 15:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 15:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 15:58:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 15:58:09 --> Total execution time: 0.0070
DEBUG - 2022-03-21 16:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:01:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:01:07 --> Total execution time: 0.0336
DEBUG - 2022-03-21 16:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:01:54 --> Total execution time: 0.0047
DEBUG - 2022-03-21 16:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:02:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:02:51 --> Total execution time: 0.0047
DEBUG - 2022-03-21 16:04:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:04:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:04:45 --> Total execution time: 0.0384
DEBUG - 2022-03-21 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:04:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:04:49 --> Total execution time: 0.0103
DEBUG - 2022-03-21 16:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:05:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:05:25 --> Total execution time: 0.0052
DEBUG - 2022-03-21 16:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:07:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:07:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:07:17 --> Total execution time: 0.0047
DEBUG - 2022-03-21 16:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:09:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:09:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:09:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:09:36 --> Total execution time: 0.0049
DEBUG - 2022-03-21 16:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:13:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:13:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:13:36 --> Total execution time: 0.0047
DEBUG - 2022-03-21 16:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:15:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:15:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:15:30 --> Total execution time: 0.0048
DEBUG - 2022-03-21 16:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:18:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:18:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:18:30 --> Total execution time: 0.0066
DEBUG - 2022-03-21 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:21:00 --> Total execution time: 0.0036
DEBUG - 2022-03-21 16:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:23:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:23:41 --> Total execution time: 0.0049
DEBUG - 2022-03-21 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:26:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:26:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:26:05 --> Total execution time: 0.0050
DEBUG - 2022-03-21 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:28:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:28:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:28:26 --> Total execution time: 0.0053
DEBUG - 2022-03-21 16:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:29:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:29:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:29:43 --> Total execution time: 0.0045
DEBUG - 2022-03-21 16:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-21 16:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-21 16:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-21 16:29:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-21 16:29:46 --> Total execution time: 0.0126
