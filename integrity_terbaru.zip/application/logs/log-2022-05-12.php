<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-12 03:09:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:07 --> No URI present. Default controller set.
DEBUG - 2022-05-12 03:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:09:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 03:09:07 --> Total execution time: 0.0499
DEBUG - 2022-05-12 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 03:09:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-12 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 03:09:10 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-12 03:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 03:09:10 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-12 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 03:09:10 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-12 03:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 03:09:10 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-12 03:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 03:09:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-12 03:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:09:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 03:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:09:14 --> Total execution time: 0.0050
DEBUG - 2022-05-12 03:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:44:38 --> Total execution time: 0.0431
DEBUG - 2022-05-12 03:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:44:40 --> Total execution time: 0.0022
DEBUG - 2022-05-12 03:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:44:50 --> Total execution time: 0.0038
DEBUG - 2022-05-12 03:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:45:04 --> Total execution time: 0.0079
DEBUG - 2022-05-12 03:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:49:06 --> Total execution time: 0.0437
DEBUG - 2022-05-12 03:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:57:07 --> Total execution time: 0.0473
DEBUG - 2022-05-12 03:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 03:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 03:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 03:59:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 03:59:21 --> Total execution time: 0.0056
DEBUG - 2022-05-12 04:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:11:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:11:59 --> Total execution time: 0.0430
DEBUG - 2022-05-12 04:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:12:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:12:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:12:06 --> Total execution time: 0.0029
DEBUG - 2022-05-12 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:12:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:12:16 --> Total execution time: 0.0026
DEBUG - 2022-05-12 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:12:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-12 04:12:33 --> The upload path does not appear to be valid.
DEBUG - 2022-05-12 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:12:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:12:33 --> Total execution time: 0.0022
DEBUG - 2022-05-12 04:13:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:13:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:13:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:13:50 --> Total execution time: 0.0040
DEBUG - 2022-05-12 04:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:13:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:13:52 --> Total execution time: 0.0021
DEBUG - 2022-05-12 04:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:14:31 --> Total execution time: 0.0026
DEBUG - 2022-05-12 04:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 04:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 04:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 04:15:19 --> Total execution time: 0.0045
DEBUG - 2022-05-12 04:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 04:15:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 04:15:21 --> 404 Page Not Found: Profile/edit
DEBUG - 2022-05-12 05:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:30:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:30:39 --> Total execution time: 0.0466
DEBUG - 2022-05-12 05:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:30:41 --> Total execution time: 0.0063
DEBUG - 2022-05-12 05:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:31:47 --> Total execution time: 0.0038
DEBUG - 2022-05-12 05:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:44:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:44:25 --> Total execution time: 0.0618
DEBUG - 2022-05-12 05:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:44:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:44:29 --> Total execution time: 0.0126
DEBUG - 2022-05-12 05:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:44:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:44:53 --> Total execution time: 0.0077
DEBUG - 2022-05-12 05:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:44:56 --> Total execution time: 0.0197
DEBUG - 2022-05-12 05:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:54:11 --> Total execution time: 0.0501
DEBUG - 2022-05-12 05:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-12 05:54:24 --> Query error: Duplicate entry ',Apid,Dion' for key 'photograper' - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Heny', '', '', '', '-', ',Apid,Dion', ',Davi', '', '')
DEBUG - 2022-05-12 05:54:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:54:24 --> Total execution time: 0.0080
DEBUG - 2022-05-12 05:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:28 --> Total execution time: 0.0041
DEBUG - 2022-05-12 05:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:30 --> Total execution time: 0.0023
DEBUG - 2022-05-12 05:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:34 --> Total execution time: 0.0029
DEBUG - 2022-05-12 05:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:34 --> Total execution time: 0.0465
DEBUG - 2022-05-12 05:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:37 --> Total execution time: 0.0014
DEBUG - 2022-05-12 05:54:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:37 --> Total execution time: 0.0467
DEBUG - 2022-05-12 05:54:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:38 --> Total execution time: 0.0036
DEBUG - 2022-05-12 05:54:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:40 --> Total execution time: 0.0029
DEBUG - 2022-05-12 05:54:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:43 --> Total execution time: 0.0064
DEBUG - 2022-05-12 05:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:44 --> Total execution time: 0.0051
DEBUG - 2022-05-12 05:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:46 --> Total execution time: 0.0055
DEBUG - 2022-05-12 05:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:48 --> Total execution time: 0.0056
DEBUG - 2022-05-12 05:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:50 --> Total execution time: 0.0043
DEBUG - 2022-05-12 05:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:52 --> Total execution time: 0.0032
DEBUG - 2022-05-12 05:54:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:54:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:54:55 --> Total execution time: 0.0070
DEBUG - 2022-05-12 05:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-12 05:55:15 --> Query error: Duplicate entry ',Apid,Dion' for key 'photograper' - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Heny', '', '2022-05-03', '', '-', ',Apid,Dion', ',Memeng', ',Kewong', '')
DEBUG - 2022-05-12 05:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:55:15 --> Total execution time: 0.0067
DEBUG - 2022-05-12 05:55:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:18 --> Total execution time: 0.0025
DEBUG - 2022-05-12 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:22 --> Total execution time: 0.0025
DEBUG - 2022-05-12 05:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:24 --> Total execution time: 0.0038
DEBUG - 2022-05-12 05:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:25 --> Total execution time: 0.0025
DEBUG - 2022-05-12 05:55:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:27 --> Total execution time: 0.0028
DEBUG - 2022-05-12 05:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:55:30 --> Total execution time: 0.0085
DEBUG - 2022-05-12 05:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-12 05:55:48 --> Query error: Duplicate entry ',Apid,Dion' for key 'photograper' - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Hapsari Wulandari & Widyana Kukuh Pradipta', '085720208858', '2022-05-13', 'sadsad', '-', ',Apid,Dion', ',Zaki', '', 'asdasd')
DEBUG - 2022-05-12 05:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:55:48 --> Total execution time: 0.0069
DEBUG - 2022-05-12 05:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:50 --> Total execution time: 0.0025
DEBUG - 2022-05-12 05:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:53 --> Total execution time: 0.0029
DEBUG - 2022-05-12 05:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:55:55 --> Total execution time: 0.0026
DEBUG - 2022-05-12 05:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:56:23 --> Total execution time: 0.0030
DEBUG - 2022-05-12 05:56:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:56:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:56:28 --> Total execution time: 0.0075
DEBUG - 2022-05-12 05:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:56:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:56:41 --> Total execution time: 0.0066
DEBUG - 2022-05-12 05:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:56:44 --> Total execution time: 0.0030
DEBUG - 2022-05-12 05:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:56:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:56:47 --> Total execution time: 0.0058
DEBUG - 2022-05-12 05:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-12 05:57:14 --> Query error: Duplicate entry ',Dion' for key 'photograper' - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date`, `place_p`, `w_prewed`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Heny', '132312312', '2022-05-12', 'sdasdsad', '-', ',Dion', ',Memeng', '', 'sadasdas')
DEBUG - 2022-05-12 05:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:57:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:57:14 --> Total execution time: 0.0056
DEBUG - 2022-05-12 05:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:57:16 --> Total execution time: 0.0032
DEBUG - 2022-05-12 05:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:58:58 --> Total execution time: 0.0033
DEBUG - 2022-05-12 05:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:59:00 --> Total execution time: 0.0067
DEBUG - 2022-05-12 05:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:59:10 --> Total execution time: 0.0074
DEBUG - 2022-05-12 05:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:12 --> Total execution time: 0.0033
DEBUG - 2022-05-12 05:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:28 --> Total execution time: 0.0031
DEBUG - 2022-05-12 05:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:59:39 --> Total execution time: 0.0051
DEBUG - 2022-05-12 05:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 05:59:48 --> Total execution time: 0.0075
DEBUG - 2022-05-12 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:50 --> Total execution time: 0.0056
DEBUG - 2022-05-12 05:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:54 --> Total execution time: 0.0061
DEBUG - 2022-05-12 05:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 05:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 05:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 05:59:57 --> Total execution time: 0.0041
DEBUG - 2022-05-12 06:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:00:07 --> Total execution time: 0.0047
DEBUG - 2022-05-12 06:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:00:09 --> Total execution time: 0.0039
DEBUG - 2022-05-12 06:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:00:12 --> Total execution time: 0.0033
DEBUG - 2022-05-12 06:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:06:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 06:06:48 --> Total execution time: 0.0478
DEBUG - 2022-05-12 06:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:49:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 06:49:26 --> Total execution time: 0.0146
DEBUG - 2022-05-12 06:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:49:29 --> Total execution time: 0.0053
DEBUG - 2022-05-12 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 06:49:59 --> Total execution time: 0.0084
DEBUG - 2022-05-12 06:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:50:19 --> Total execution time: 0.0038
DEBUG - 2022-05-12 06:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:50:28 --> Total execution time: 0.0035
DEBUG - 2022-05-12 06:51:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 06:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 06:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 06:51:29 --> Total execution time: 0.0027
DEBUG - 2022-05-12 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:00:02 --> Total execution time: 0.0446
DEBUG - 2022-05-12 07:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:01:29 --> Total execution time: 0.0546
DEBUG - 2022-05-12 07:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:09:43 --> Total execution time: 0.0497
DEBUG - 2022-05-12 07:09:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:09:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:09:45 --> Total execution time: 0.0044
DEBUG - 2022-05-12 07:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:19:42 --> Total execution time: 0.0485
DEBUG - 2022-05-12 07:34:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:34:16 --> Total execution time: 0.0633
DEBUG - 2022-05-12 07:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:38:09 --> Total execution time: 0.0039
DEBUG - 2022-05-12 07:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:38:42 --> Total execution time: 0.0062
DEBUG - 2022-05-12 07:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:38:50 --> Total execution time: 0.0063
DEBUG - 2022-05-12 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:45:48 --> Total execution time: 0.0609
DEBUG - 2022-05-12 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:49:18 --> No URI present. Default controller set.
DEBUG - 2022-05-12 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 07:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 07:49:18 --> Total execution time: 0.0172
DEBUG - 2022-05-12 07:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:49:20 --> No URI present. Default controller set.
DEBUG - 2022-05-12 07:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:49:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 07:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:49:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 07:49:20 --> Total execution time: 0.0078
DEBUG - 2022-05-12 07:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 07:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 07:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 07:49:25 --> Total execution time: 0.0045
DEBUG - 2022-05-12 08:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:10:55 --> Total execution time: 0.0488
DEBUG - 2022-05-12 08:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:10:56 --> Total execution time: 0.0029
DEBUG - 2022-05-12 08:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:10:59 --> Total execution time: 0.0050
DEBUG - 2022-05-12 08:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:11:12 --> Total execution time: 0.0035
DEBUG - 2022-05-12 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-12 08:11:18 --> Severity: error --> Exception: Call to a member function detail_prewed() on null /home/nsnmt.com/integrity/application/controllers/Personal.php 11
DEBUG - 2022-05-12 08:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:12:24 --> Total execution time: 0.0053
DEBUG - 2022-05-12 08:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:13:34 --> Total execution time: 0.0510
DEBUG - 2022-05-12 08:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:13:52 --> Total execution time: 0.0033
DEBUG - 2022-05-12 08:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:13:56 --> Total execution time: 0.0037
DEBUG - 2022-05-12 08:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:14:06 --> Total execution time: 0.0026
DEBUG - 2022-05-12 08:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:15:29 --> Total execution time: 0.0037
DEBUG - 2022-05-12 08:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:15:33 --> Total execution time: 0.0036
DEBUG - 2022-05-12 08:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:15:34 --> Total execution time: 0.0030
DEBUG - 2022-05-12 08:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:15:43 --> Total execution time: 0.0034
DEBUG - 2022-05-12 08:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:15:45 --> Total execution time: 0.0030
DEBUG - 2022-05-12 08:30:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:30:10 --> Total execution time: 0.0557
DEBUG - 2022-05-12 08:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:30:13 --> Total execution time: 0.0059
DEBUG - 2022-05-12 08:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:30:15 --> Total execution time: 0.0028
DEBUG - 2022-05-12 08:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:30:17 --> Total execution time: 0.0033
DEBUG - 2022-05-12 08:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:30:19 --> Total execution time: 0.0060
DEBUG - 2022-05-12 08:30:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:30:22 --> Total execution time: 0.0037
DEBUG - 2022-05-12 08:30:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:30:23 --> Total execution time: 0.0023
DEBUG - 2022-05-12 08:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:30:58 --> Total execution time: 0.0031
DEBUG - 2022-05-12 08:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:31:16 --> Total execution time: 0.0029
DEBUG - 2022-05-12 08:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:31:43 --> Total execution time: 0.0034
DEBUG - 2022-05-12 08:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:31:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 08:31:46 --> 404 Page Not Found: Personal/videograper
DEBUG - 2022-05-12 08:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:31:55 --> Total execution time: 0.0030
DEBUG - 2022-05-12 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:33:05 --> Total execution time: 0.0068
DEBUG - 2022-05-12 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:33:06 --> Total execution time: 0.0049
DEBUG - 2022-05-12 08:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:33:08 --> Total execution time: 0.0033
DEBUG - 2022-05-12 08:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:33:10 --> Total execution time: 0.0080
DEBUG - 2022-05-12 08:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:33:21 --> Total execution time: 0.0059
DEBUG - 2022-05-12 08:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:33:40 --> Total execution time: 0.0026
DEBUG - 2022-05-12 08:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:00 --> Total execution time: 0.0042
DEBUG - 2022-05-12 08:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:01 --> Total execution time: 0.1071
DEBUG - 2022-05-12 08:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:03 --> Total execution time: 0.0037
DEBUG - 2022-05-12 08:34:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 08:34:08 --> Total execution time: 0.0079
DEBUG - 2022-05-12 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 08:34:18 --> Total execution time: 0.0058
DEBUG - 2022-05-12 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:21 --> Total execution time: 0.0044
DEBUG - 2022-05-12 08:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:25 --> Total execution time: 0.0040
DEBUG - 2022-05-12 08:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:40 --> Total execution time: 0.0028
DEBUG - 2022-05-12 08:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:42 --> Total execution time: 0.0029
DEBUG - 2022-05-12 08:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:34:58 --> Total execution time: 0.0035
DEBUG - 2022-05-12 08:36:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 08:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 08:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 08:36:13 --> Total execution time: 0.0040
DEBUG - 2022-05-12 13:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:11 --> No URI present. Default controller set.
DEBUG - 2022-05-12 13:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:54:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:54:11 --> Total execution time: 0.0383
DEBUG - 2022-05-12 13:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-12 13:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:12 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-12 13:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:12 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-12 13:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:12 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-12 13:54:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:12 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-12 13:54:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-12 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:54:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:54:23 --> Total execution time: 0.0035
DEBUG - 2022-05-12 13:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:54:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:54:25 --> Total execution time: 0.0017
DEBUG - 2022-05-12 13:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:26 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-12 13:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:26 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-12 13:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-12 13:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:54:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:54:28 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-12 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:55:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:55:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:55:59 --> Total execution time: 0.0020
DEBUG - 2022-05-12 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:55:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-12 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:55:59 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-12 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:55:59 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-12 13:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:55:59 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-12 13:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:55:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:55:59 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-12 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:38 --> No URI present. Default controller set.
DEBUG - 2022-05-12 13:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:56:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:56:38 --> Total execution time: 0.0027
DEBUG - 2022-05-12 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:56:38 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-12 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:56:38 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-12 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:56:38 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-12 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:56:38 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-12 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-12 13:56:38 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-12 13:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:56:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:56:45 --> Total execution time: 0.0027
DEBUG - 2022-05-12 13:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:56:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:56:47 --> Total execution time: 0.0152
DEBUG - 2022-05-12 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-12 13:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-12 13:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-12 13:56:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-12 13:56:48 --> Total execution time: 0.0054
