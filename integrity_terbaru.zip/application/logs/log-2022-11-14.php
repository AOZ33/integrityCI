<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-14 01:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 01:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 01:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 01:25:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 01:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 01:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 01:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 01:25:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 01:25:58 --> Total execution time: 0.0920
DEBUG - 2022-11-14 13:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 13:20:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 13:20:30 --> Total execution time: 0.1762
DEBUG - 2022-11-14 13:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 13:20:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 13:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 13:20:48 --> Total execution time: 0.1157
DEBUG - 2022-11-14 13:35:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 13:35:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 13:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 13:35:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 13:35:05 --> Total execution time: 0.1645
DEBUG - 2022-11-14 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 14:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 14:32:39 --> Total execution time: 0.1734
DEBUG - 2022-11-14 14:56:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 14:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 14:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 14:56:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 14:56:54 --> Total execution time: 0.2110
DEBUG - 2022-11-14 15:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 15:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 15:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 15:05:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 15:05:34 --> Total execution time: 0.1834
DEBUG - 2022-11-14 16:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:00:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 16:00:12 --> Total execution time: 0.1476
DEBUG - 2022-11-14 16:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:08:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 16:08:12 --> Total execution time: 0.1313
DEBUG - 2022-11-14 16:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:08:29 --> Total execution time: 0.1534
DEBUG - 2022-11-14 16:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:08:54 --> Total execution time: 0.1109
DEBUG - 2022-11-14 16:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:08:58 --> Total execution time: 0.1113
DEBUG - 2022-11-14 16:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:09:01 --> Total execution time: 0.1091
DEBUG - 2022-11-14 16:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:09:02 --> Total execution time: 0.1238
DEBUG - 2022-11-14 16:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:09:24 --> Total execution time: 0.1305
DEBUG - 2022-11-14 16:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:09:53 --> Total execution time: 0.1377
DEBUG - 2022-11-14 16:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:10:10 --> Total execution time: 0.1445
DEBUG - 2022-11-14 16:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:10:30 --> Total execution time: 0.1893
DEBUG - 2022-11-14 16:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:10:48 --> Total execution time: 0.1742
DEBUG - 2022-11-14 16:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:11:01 --> Total execution time: 0.1235
DEBUG - 2022-11-14 16:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:11:21 --> Total execution time: 0.1271
DEBUG - 2022-11-14 16:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:11:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 16:11:23 --> Total execution time: 0.1637
DEBUG - 2022-11-14 16:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:42:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 16:42:12 --> Total execution time: 0.2140
DEBUG - 2022-11-14 16:43:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:43:13 --> Total execution time: 0.1614
DEBUG - 2022-11-14 16:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:44:46 --> Total execution time: 0.1410
DEBUG - 2022-11-14 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:45:32 --> Total execution time: 0.1404
DEBUG - 2022-11-14 16:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 16:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 16:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 16:59:24 --> Total execution time: 0.1794
DEBUG - 2022-11-14 17:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:00:03 --> Total execution time: 0.1849
DEBUG - 2022-11-14 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:00:43 --> Total execution time: 0.1664
DEBUG - 2022-11-14 17:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:01:27 --> Total execution time: 0.1520
DEBUG - 2022-11-14 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:02:06 --> Total execution time: 0.1753
DEBUG - 2022-11-14 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:03:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 17:03:00 --> Total execution time: 0.1712
DEBUG - 2022-11-14 17:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:33:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-14 17:33:27 --> Total execution time: 0.1935
DEBUG - 2022-11-14 17:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:39:50 --> Total execution time: 0.1903
DEBUG - 2022-11-14 17:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:45:40 --> Total execution time: 0.1592
DEBUG - 2022-11-14 17:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:47:31 --> Total execution time: 0.1131
DEBUG - 2022-11-14 17:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:47:33 --> Total execution time: 0.1542
DEBUG - 2022-11-14 17:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 17:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 17:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 17:59:13 --> Total execution time: 0.1435
DEBUG - 2022-11-14 18:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 18:02:06 --> Total execution time: 0.1403
DEBUG - 2022-11-14 18:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 18:14:52 --> Total execution time: 0.1269
DEBUG - 2022-11-14 18:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 18:30:06 --> Total execution time: 0.1401
DEBUG - 2022-11-14 18:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 18:48:53 --> Total execution time: 0.1653
DEBUG - 2022-11-14 18:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 18:59:25 --> Total execution time: 0.1458
DEBUG - 2022-11-14 18:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 18:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 18:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 18:59:27 --> Total execution time: 0.1463
DEBUG - 2022-11-14 19:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:05:34 --> Total execution time: 0.2932
DEBUG - 2022-11-14 19:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:07:30 --> Total execution time: 0.1270
DEBUG - 2022-11-14 19:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:10:58 --> Total execution time: 0.1836
DEBUG - 2022-11-14 19:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:11:03 --> Total execution time: 0.1610
DEBUG - 2022-11-14 19:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:13:15 --> Total execution time: 0.1406
DEBUG - 2022-11-14 19:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:14:18 --> Total execution time: 0.1589
DEBUG - 2022-11-14 19:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:14:31 --> Total execution time: 0.1213
DEBUG - 2022-11-14 19:14:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:14:33 --> Total execution time: 0.1336
DEBUG - 2022-11-14 19:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:14:43 --> Total execution time: 0.1169
DEBUG - 2022-11-14 19:14:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:14:46 --> Total execution time: 0.1959
DEBUG - 2022-11-14 19:14:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:14:51 --> Total execution time: 0.1261
DEBUG - 2022-11-14 19:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:14:54 --> Total execution time: 0.1650
DEBUG - 2022-11-14 19:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:25:00 --> Total execution time: 0.1843
DEBUG - 2022-11-14 19:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:26:05 --> Total execution time: 0.1641
DEBUG - 2022-11-14 19:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:36:09 --> Total execution time: 0.1559
DEBUG - 2022-11-14 19:39:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:39:25 --> Total execution time: 0.1530
DEBUG - 2022-11-14 19:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:46:28 --> Total execution time: 0.1386
DEBUG - 2022-11-14 19:46:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:46:31 --> Total execution time: 0.1500
DEBUG - 2022-11-14 19:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:46:33 --> Total execution time: 0.1488
DEBUG - 2022-11-14 19:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:49:58 --> Total execution time: 0.2966
DEBUG - 2022-11-14 19:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:55:31 --> Total execution time: 0.1499
DEBUG - 2022-11-14 19:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:55:53 --> Total execution time: 0.1616
DEBUG - 2022-11-14 19:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 19:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 19:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 19:55:54 --> Total execution time: 0.1237
DEBUG - 2022-11-14 20:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 20:03:08 --> Total execution time: 0.1996
DEBUG - 2022-11-14 20:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 20:07:24 --> Total execution time: 0.1217
DEBUG - 2022-11-14 20:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-14 20:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-14 20:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-14 20:08:19 --> Total execution time: 0.1323
