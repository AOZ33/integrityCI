<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-11 09:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 09:10:26 --> No URI present. Default controller set.
DEBUG - 2022-02-11 09:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 09:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 09:10:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 09:10:26 --> Total execution time: 0.0312
DEBUG - 2022-02-11 09:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 09:10:27 --> No URI present. Default controller set.
DEBUG - 2022-02-11 09:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 09:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 09:10:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 09:10:27 --> Total execution time: 0.0032
DEBUG - 2022-02-11 09:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 09:10:27 --> No URI present. Default controller set.
DEBUG - 2022-02-11 09:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 09:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 09:10:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 09:10:27 --> Total execution time: 0.0038
DEBUG - 2022-02-11 09:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 09:10:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 09:10:28 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-02-11 09:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 09:36:39 --> No URI present. Default controller set.
DEBUG - 2022-02-11 09:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 09:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 09:36:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 09:36:39 --> Total execution time: 0.0303
DEBUG - 2022-02-11 09:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 09:36:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 09:36:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 09:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 09:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 09:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 09:55:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 09:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 09:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 09:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 09:55:03 --> Total execution time: 0.0068
DEBUG - 2022-02-11 10:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:11:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 10:11:20 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 180474576 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:11:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:11:24 --> Total execution time: 0.0040
DEBUG - 2022-02-11 10:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:17:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:17:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:17:15 --> Total execution time: 0.0061
DEBUG - 2022-02-11 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:19:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:19:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:19:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:19:24 --> Total execution time: 0.0050
DEBUG - 2022-02-11 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:28:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:28:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:28:14 --> Total execution time: 0.0060
DEBUG - 2022-02-11 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:33:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:33:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:33:17 --> Total execution time: 0.0067
DEBUG - 2022-02-11 10:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:37:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:37:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:37:59 --> Total execution time: 0.0055
DEBUG - 2022-02-11 10:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:43:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:43:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:43:42 --> Total execution time: 0.0057
DEBUG - 2022-02-11 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:51:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 10:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 10:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 10:51:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 10:51:30 --> Total execution time: 0.0056
DEBUG - 2022-02-11 11:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:02:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:02:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:02:10 --> Total execution time: 0.0066
DEBUG - 2022-02-11 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:06:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:06:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:06:08 --> Total execution time: 0.0050
DEBUG - 2022-02-11 11:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:07:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:07:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:07:58 --> Total execution time: 0.0051
DEBUG - 2022-02-11 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:18:31 --> Total execution time: 0.0058
DEBUG - 2022-02-11 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:28:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 11:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 11:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 11:28:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 11:28:07 --> Total execution time: 0.0059
DEBUG - 2022-02-11 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:30:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 13:30:42 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-11 13:30:42 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-11 13:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:30:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 13:30:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-11 13:30:59 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-11 13:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:32:39 --> No URI present. Default controller set.
DEBUG - 2022-02-11 13:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:32:39 --> Total execution time: 0.0318
DEBUG - 2022-02-11 13:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 13:32:39 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 13:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:32:40 --> No URI present. Default controller set.
DEBUG - 2022-02-11 13:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:32:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:32:40 --> Total execution time: 0.0035
DEBUG - 2022-02-11 13:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:36:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:36:30 --> Total execution time: 0.0059
DEBUG - 2022-02-11 13:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:42:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 13:42:01 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182055064 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 13:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:42:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:42:04 --> Total execution time: 0.0042
DEBUG - 2022-02-11 13:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:46:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:46:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:46:14 --> Total execution time: 0.0059
DEBUG - 2022-02-11 13:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:52:51 --> Total execution time: 0.0058
DEBUG - 2022-02-11 13:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:54:03 --> No URI present. Default controller set.
DEBUG - 2022-02-11 13:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:54:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:54:03 --> Total execution time: 0.0309
DEBUG - 2022-02-11 13:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 13:54:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 13:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:55:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:55:23 --> Total execution time: 0.0053
DEBUG - 2022-02-11 13:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:55:38 --> Total execution time: 0.0067
DEBUG - 2022-02-11 13:55:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:55:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:55:46 --> Total execution time: 0.0043
DEBUG - 2022-02-11 13:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:55:47 --> Total execution time: 0.0036
DEBUG - 2022-02-11 13:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:55:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 13:55:56 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182297848 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 13:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:56:13 --> Total execution time: 0.0034
DEBUG - 2022-02-11 13:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:56:20 --> Total execution time: 0.0051
DEBUG - 2022-02-11 13:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:56:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:56:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:56:50 --> Total execution time: 0.0043
DEBUG - 2022-02-11 13:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:57:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 13:57:10 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182419336 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 13:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:58:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 13:58:00 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182419336 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 13:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:58:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 13:58:04 --> Total execution time: 0.0036
DEBUG - 2022-02-11 13:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 13:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 13:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 13:59:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 13:59:30 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182419336 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 14:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:05:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:05:59 --> Total execution time: 0.0347
DEBUG - 2022-02-11 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:06:54 --> Total execution time: 0.0066
DEBUG - 2022-02-11 14:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:06:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:06:56 --> Total execution time: 0.0038
DEBUG - 2022-02-11 14:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:06:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 14:06:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 14:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:07:06 --> Total execution time: 0.0047
DEBUG - 2022-02-11 14:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:07:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:07:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:07:28 --> Total execution time: 0.0035
DEBUG - 2022-02-11 14:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 14:07:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:07:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:07:47 --> Total execution time: 0.0035
DEBUG - 2022-02-11 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:07:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:07:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:07:53 --> Total execution time: 0.0038
DEBUG - 2022-02-11 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:07:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 14:07:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 14:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:08:03 --> Total execution time: 0.0028
DEBUG - 2022-02-11 14:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:08:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 14:08:03 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 14:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:08:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:08:11 --> Total execution time: 0.0044
DEBUG - 2022-02-11 14:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:09:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 14:09:41 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182419336 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 14:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:09:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:09:46 --> Total execution time: 0.0041
DEBUG - 2022-02-11 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:11:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:11:12 --> Total execution time: 0.0036
DEBUG - 2022-02-11 14:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:11:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 14:11:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182419336 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 14:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:12:10 --> Total execution time: 39.8778
DEBUG - 2022-02-11 14:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:12:11 --> No URI present. Default controller set.
DEBUG - 2022-02-11 14:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:12:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:12:11 --> Total execution time: 0.0034
DEBUG - 2022-02-11 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:13:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 14:13:43 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182419336 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 14:19:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:19:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 14:19:48 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182419336 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:20:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:20:32 --> Total execution time: 0.0058
DEBUG - 2022-02-11 14:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:23:41 --> Total execution time: 0.0053
DEBUG - 2022-02-11 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:28:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:28:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:28:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:28:03 --> Total execution time: 0.0055
DEBUG - 2022-02-11 14:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:29:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 14:29:43 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-11 14:29:43 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Karina & Arif', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 'Rp. 8.500.000', 'Rp. 1.000.000', '', 'Rp. 7.500.000', '', '', '', '', '', '2018-01-06', '', '', '', '', '', '', '', '', '', '', '', '', 'Kopo Sulaksana', '', '2017-10-31', '', '2018-01-04', '', '', '', '', '', '')
DEBUG - 2022-02-11 14:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:29:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:29:43 --> Total execution time: 0.0060
DEBUG - 2022-02-11 14:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:29:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 14:29:52 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182662496 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:32:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:32:13 --> Total execution time: 0.0319
DEBUG - 2022-02-11 14:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:32:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 14:32:19 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182662496 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:39:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:39:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:39:14 --> Total execution time: 0.0055
DEBUG - 2022-02-11 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:39:30 --> No URI present. Default controller set.
DEBUG - 2022-02-11 14:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:39:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:39:30 --> Total execution time: 0.0050
DEBUG - 2022-02-11 14:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:39:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 14:39:30 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:40:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:40:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:40:45 --> Total execution time: 0.0034
DEBUG - 2022-02-11 14:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:40:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 14:40:56 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 182784240 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 14:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:45:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:45:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:45:19 --> Total execution time: 0.0059
DEBUG - 2022-02-11 14:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:53:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:53:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:53:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:53:53 --> Total execution time: 0.0062
DEBUG - 2022-02-11 14:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:57:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 14:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 14:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 14:57:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 14:57:40 --> Total execution time: 0.0058
DEBUG - 2022-02-11 15:01:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:01:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 15:01:40 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 183149096 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 15:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:04:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 15:04:34 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-11 15:04:34 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Nadira & Fitransyah', '', '', NULL, '', 'custom', '', '(16RP) 1', '', '1 acara + 1 group', '', '', 'full editing', '3 (16RP) + 5 (4R) prewed(perubahan dari 7wedding))', '', '', '', '', '', 'Rp. 9.000.000', '', '', 'Rp. 9.000.000', '', '', '', '2017-11-29', '', '2017-01-06', '', '', '2018-01-05', '', '', '', '', '', '', '', '', '', 'Gedung Biru Wiradinata', '', '', '', '2018-01-27', '', '', '', '', '', '')
DEBUG - 2022-02-11 15:04:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:04:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:04:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:04:34 --> Total execution time: 0.0053
DEBUG - 2022-02-11 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:07:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 15:07:22 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 183149096 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 15:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:07:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:07:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:07:47 --> Total execution time: 0.0045
DEBUG - 2022-02-11 15:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:12:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 15:12:46 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-11 15:12:46 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Caca & Farid', '', '', NULL, '', 'Custom', '(20RP) 2', '(16RP) 1 + (20RP) 1', '', '1 acara + 1 group', '', '', 'full editing', 'prewedding clip concept, ', '', '', '082334397777', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-02-11 15:12:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:12:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:12:47 --> Total execution time: 0.0057
DEBUG - 2022-02-11 15:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:17:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:17:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:17:26 --> Total execution time: 0.0057
DEBUG - 2022-02-11 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:20:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:20:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:20:49 --> Total execution time: 0.0059
DEBUG - 2022-02-11 15:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:27:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:27:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:27:13 --> Total execution time: 0.0056
DEBUG - 2022-02-11 15:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:30:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:30:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:30:19 --> Total execution time: 0.0057
DEBUG - 2022-02-11 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:35:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:35:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:35:23 --> Total execution time: 0.0055
DEBUG - 2022-02-11 15:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:48:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 15:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 15:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 15:48:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 15:48:33 --> Total execution time: 0.0058
DEBUG - 2022-02-11 16:01:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:01:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:01:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:01:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:01:48 --> Total execution time: 0.0058
DEBUG - 2022-02-11 16:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:05:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:05:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:05:53 --> Total execution time: 0.0068
DEBUG - 2022-02-11 16:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:08:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:08:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:08:27 --> Total execution time: 0.0059
DEBUG - 2022-02-11 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:12:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:12:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:12:25 --> Total execution time: 0.0060
DEBUG - 2022-02-11 16:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:21:26 --> Total execution time: 0.0060
DEBUG - 2022-02-11 16:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:23:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:23:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:23:10 --> Total execution time: 0.0059
DEBUG - 2022-02-11 16:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:25:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:25:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:25:35 --> Total execution time: 0.0057
DEBUG - 2022-02-11 16:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:34:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:34:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:34:22 --> Total execution time: 0.0065
DEBUG - 2022-02-11 16:36:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:36:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 16:36:49 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 184849112 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 16:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:39:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:39:57 --> Total execution time: 0.0341
DEBUG - 2022-02-11 16:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:41:53 --> Total execution time: 0.0064
DEBUG - 2022-02-11 16:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:44:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:44:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:44:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:44:52 --> Total execution time: 0.0054
DEBUG - 2022-02-11 16:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:49:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:49:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:49:07 --> Total execution time: 0.0052
DEBUG - 2022-02-11 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:50:02 --> Total execution time: 0.0037
DEBUG - 2022-02-11 16:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:55:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:55:16 --> Total execution time: 0.0038
DEBUG - 2022-02-11 16:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:55:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 16:55:16 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 16:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:59:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:59:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 16:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 16:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 16:59:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 16:59:01 --> Total execution time: 0.0063
DEBUG - 2022-02-11 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:00:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:00:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:00:21 --> Total execution time: 0.0058
DEBUG - 2022-02-11 17:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:01:31 --> No URI present. Default controller set.
DEBUG - 2022-02-11 17:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:01:31 --> Total execution time: 0.0048
DEBUG - 2022-02-11 17:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 17:01:31 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 17:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:01:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:01:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:01:52 --> Total execution time: 0.0039
DEBUG - 2022-02-11 17:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:02:14 --> No URI present. Default controller set.
DEBUG - 2022-02-11 17:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:02:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:02:14 --> Total execution time: 0.0049
DEBUG - 2022-02-11 17:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:02:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 17:02:15 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 17:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:05:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:05:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:05:39 --> Total execution time: 0.0065
DEBUG - 2022-02-11 17:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:20:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:20:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:20:17 --> Total execution time: 0.0056
DEBUG - 2022-02-11 17:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:25:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:25:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:25:29 --> Total execution time: 0.0056
DEBUG - 2022-02-11 17:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:32:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:32:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:32:59 --> Total execution time: 0.0055
DEBUG - 2022-02-11 17:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 17:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 17:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 17:35:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 17:35:36 --> Total execution time: 0.0049
DEBUG - 2022-02-11 19:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:01:59 --> No URI present. Default controller set.
DEBUG - 2022-02-11 19:01:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:01:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 19:01:59 --> Total execution time: 0.0302
DEBUG - 2022-02-11 19:01:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:01:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-11 19:01:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-11 19:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:02:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 19:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:02:13 --> Total execution time: 0.0051
DEBUG - 2022-02-11 19:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:02:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 19:02:20 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 186185592 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 19:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:03:19 --> Total execution time: 0.0050
DEBUG - 2022-02-11 19:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:03:35 --> No URI present. Default controller set.
DEBUG - 2022-02-11 19:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:03:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-11 19:03:35 --> Total execution time: 0.0041
DEBUG - 2022-02-11 19:03:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:03:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:03:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 19:03:40 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 186185592 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-11 19:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:03:42 --> Total execution time: 0.0045
DEBUG - 2022-02-11 19:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-11 19:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-11 19:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-11 19:03:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-11 19:03:49 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 186185592 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
