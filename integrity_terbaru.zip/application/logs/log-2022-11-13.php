<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-11-13 09:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:40:17 --> Total execution time: 0.1445
DEBUG - 2022-11-13 09:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:40:24 --> Total execution time: 0.0970
DEBUG - 2022-11-13 09:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:40:27 --> Total execution time: 0.1275
DEBUG - 2022-11-13 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-13 09:40:27 --> 404 Page Not Found: Auth/js
ERROR - 2022-11-13 09:40:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-11-13 09:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:27 --> UTF-8 Support Enabled
ERROR - 2022-11-13 09:40:27 --> 404 Page Not Found: Auth/css
ERROR - 2022-11-13 09:40:27 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-11-13 09:40:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-11-13 09:40:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-13 09:40:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-11-13 09:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:40:29 --> Total execution time: 0.0983
DEBUG - 2022-11-13 09:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:40:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:40:38 --> Total execution time: 0.0899
DEBUG - 2022-11-13 09:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:46 --> Total execution time: 0.1362
DEBUG - 2022-11-13 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:40:54 --> Total execution time: 0.1045
DEBUG - 2022-11-13 09:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:41:01 --> Total execution time: 0.1108
DEBUG - 2022-11-13 09:50:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:50:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:50:35 --> Total execution time: 0.1339
DEBUG - 2022-11-13 09:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:54:42 --> Total execution time: 0.1692
DEBUG - 2022-11-13 09:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 09:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 09:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 09:58:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 09:58:35 --> Total execution time: 0.1566
DEBUG - 2022-11-13 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:00:37 --> Total execution time: 0.1845
DEBUG - 2022-11-13 10:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:03:11 --> Total execution time: 0.1859
DEBUG - 2022-11-13 10:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:05:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:05:33 --> Total execution time: 0.1680
DEBUG - 2022-11-13 10:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:05:36 --> Total execution time: 0.1224
DEBUG - 2022-11-13 10:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:05:39 --> Total execution time: 0.1459
DEBUG - 2022-11-13 10:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:05:44 --> Total execution time: 0.1217
DEBUG - 2022-11-13 10:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:05:45 --> Total execution time: 0.1192
DEBUG - 2022-11-13 10:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:05:47 --> Total execution time: 0.1169
DEBUG - 2022-11-13 10:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:05:48 --> Total execution time: 0.1189
DEBUG - 2022-11-13 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:05:52 --> Total execution time: 0.1358
DEBUG - 2022-11-13 10:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:06:08 --> Total execution time: 0.1273
DEBUG - 2022-11-13 10:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:06:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:06:12 --> Total execution time: 0.2330
DEBUG - 2022-11-13 10:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:06:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:06:15 --> Total execution time: 0.1323
DEBUG - 2022-11-13 10:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:06:18 --> Total execution time: 0.1952
DEBUG - 2022-11-13 10:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:06:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:06:24 --> Total execution time: 0.1333
DEBUG - 2022-11-13 10:06:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:06:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:06:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:06:30 --> Total execution time: 0.1234
DEBUG - 2022-11-13 10:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:07:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:07:19 --> Total execution time: 0.1293
DEBUG - 2022-11-13 10:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:07:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:07:24 --> Total execution time: 0.1289
DEBUG - 2022-11-13 10:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:07:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:07:27 --> Total execution time: 0.1364
DEBUG - 2022-11-13 10:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:07:29 --> Total execution time: 0.2678
DEBUG - 2022-11-13 10:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:07:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:07:40 --> Total execution time: 0.1327
DEBUG - 2022-11-13 10:07:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:07:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:07:42 --> Total execution time: 0.1529
DEBUG - 2022-11-13 10:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:13:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:13:53 --> Total execution time: 0.1616
DEBUG - 2022-11-13 10:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:13:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:13:58 --> Total execution time: 0.1589
DEBUG - 2022-11-13 10:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:19:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:19:40 --> Total execution time: 0.1122
DEBUG - 2022-11-13 10:19:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:19:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:19:46 --> Total execution time: 0.1580
DEBUG - 2022-11-13 10:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:19:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:19:49 --> Total execution time: 0.2755
DEBUG - 2022-11-13 10:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:20:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:20:02 --> Total execution time: 0.1401
DEBUG - 2022-11-13 10:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:20:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:20:04 --> Total execution time: 0.1588
DEBUG - 2022-11-13 10:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:23:41 --> Total execution time: 0.1996
DEBUG - 2022-11-13 10:23:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:23:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:23:43 --> Total execution time: 0.1447
DEBUG - 2022-11-13 10:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:23:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:23:46 --> Total execution time: 0.1766
DEBUG - 2022-11-13 10:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:02 --> Total execution time: 0.1356
DEBUG - 2022-11-13 10:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:06 --> Total execution time: 0.1366
DEBUG - 2022-11-13 10:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:09 --> Total execution time: 0.1374
DEBUG - 2022-11-13 10:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:18 --> Total execution time: 0.1136
DEBUG - 2022-11-13 10:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:29 --> Total execution time: 0.1794
DEBUG - 2022-11-13 10:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:33 --> Total execution time: 0.1786
DEBUG - 2022-11-13 10:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:51 --> Total execution time: 0.1634
DEBUG - 2022-11-13 10:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:52 --> Total execution time: 0.1295
DEBUG - 2022-11-13 10:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:28:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:28:55 --> Total execution time: 0.1460
DEBUG - 2022-11-13 10:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:31:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:31:00 --> Total execution time: 0.1922
DEBUG - 2022-11-13 10:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:31:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:31:01 --> Total execution time: 0.1446
DEBUG - 2022-11-13 10:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 10:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 10:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 10:31:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 10:31:06 --> Total execution time: 0.1319
DEBUG - 2022-11-13 16:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:32:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:32:00 --> Total execution time: 0.1566
DEBUG - 2022-11-13 16:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:32:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:32:02 --> Total execution time: 0.1299
DEBUG - 2022-11-13 16:32:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:32:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:32:05 --> Total execution time: 0.1840
DEBUG - 2022-11-13 16:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:34:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:34:47 --> Total execution time: 0.2087
DEBUG - 2022-11-13 16:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:34:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:34:49 --> Total execution time: 0.1560
DEBUG - 2022-11-13 16:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:37:14 --> Total execution time: 0.1097
DEBUG - 2022-11-13 16:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:38:15 --> Total execution time: 0.1497
DEBUG - 2022-11-13 16:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:38:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:38:21 --> Total execution time: 0.1194
DEBUG - 2022-11-13 16:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:38:22 --> Total execution time: 0.1086
DEBUG - 2022-11-13 16:38:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:38:24 --> Total execution time: 0.1794
DEBUG - 2022-11-13 16:41:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:41:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:41:55 --> Total execution time: 0.1195
DEBUG - 2022-11-13 16:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:42:32 --> Total execution time: 0.1321
DEBUG - 2022-11-13 16:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:43:03 --> Total execution time: 0.1309
DEBUG - 2022-11-13 16:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:43:45 --> Total execution time: 0.1489
DEBUG - 2022-11-13 16:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:43:46 --> Total execution time: 0.1430
DEBUG - 2022-11-13 16:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:44:11 --> Total execution time: 0.2442
DEBUG - 2022-11-13 16:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:44:20 --> Total execution time: 0.1355
DEBUG - 2022-11-13 16:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:44:22 --> Total execution time: 0.1188
DEBUG - 2022-11-13 16:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:44:24 --> Total execution time: 0.1174
DEBUG - 2022-11-13 16:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:44:25 --> Total execution time: 0.1158
DEBUG - 2022-11-13 16:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:44:28 --> Total execution time: 0.1379
DEBUG - 2022-11-13 16:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:48:12 --> Total execution time: 0.1149
DEBUG - 2022-11-13 16:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:48:13 --> Total execution time: 0.2375
DEBUG - 2022-11-13 16:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:48:17 --> Total execution time: 0.1404
DEBUG - 2022-11-13 16:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:48:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:48:32 --> Total execution time: 0.1453
DEBUG - 2022-11-13 16:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:48:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:48:34 --> Total execution time: 0.1384
DEBUG - 2022-11-13 16:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:48:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:48:37 --> Total execution time: 0.1679
DEBUG - 2022-11-13 16:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 16:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 16:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 16:48:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 16:48:47 --> Total execution time: 0.1235
DEBUG - 2022-11-13 17:09:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:09:58 --> Total execution time: 0.1203
DEBUG - 2022-11-13 17:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:44:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:44:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:44:28 --> Total execution time: 0.1062
DEBUG - 2022-11-13 17:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:44:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:44:41 --> Total execution time: 0.1405
DEBUG - 2022-11-13 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:45:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:45:12 --> Total execution time: 0.0942
DEBUG - 2022-11-13 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-13 17:45:12 --> 404 Page Not Found: Auth/css
DEBUG - 2022-11-13 17:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-13 17:45:12 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-11-13 17:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-11-13 17:45:12 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-11-13 17:45:12 --> 404 Page Not Found: Auth/js
ERROR - 2022-11-13 17:45:12 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-11-13 17:45:12 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-11-13 17:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:45:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:45:39 --> Total execution time: 0.1991
DEBUG - 2022-11-13 17:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:45:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:45:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:45:56 --> Total execution time: 0.1264
DEBUG - 2022-11-13 17:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:46:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:46:02 --> Total execution time: 0.1074
DEBUG - 2022-11-13 17:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:46:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:46:08 --> Total execution time: 0.2060
DEBUG - 2022-11-13 17:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:46:34 --> Total execution time: 0.1282
DEBUG - 2022-11-13 17:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:48:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:48:26 --> Total execution time: 0.1473
DEBUG - 2022-11-13 17:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:48:41 --> Total execution time: 0.1116
DEBUG - 2022-11-13 17:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:48:49 --> Total execution time: 0.0941
DEBUG - 2022-11-13 17:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:48:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:48:50 --> Total execution time: 0.2328
DEBUG - 2022-11-13 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:48:51 --> Total execution time: 0.2246
DEBUG - 2022-11-13 17:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:12 --> Total execution time: 0.1224
DEBUG - 2022-11-13 17:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:18 --> Total execution time: 0.0944
DEBUG - 2022-11-13 17:49:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:19 --> Total execution time: 0.2315
DEBUG - 2022-11-13 17:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:21 --> Total execution time: 0.1983
DEBUG - 2022-11-13 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:22 --> Total execution time: 0.1766
DEBUG - 2022-11-13 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:22 --> Total execution time: 0.1870
DEBUG - 2022-11-13 17:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:23 --> Total execution time: 0.1781
DEBUG - 2022-11-13 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:23 --> Total execution time: 0.1731
DEBUG - 2022-11-13 17:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:23 --> Total execution time: 0.1878
DEBUG - 2022-11-13 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:24 --> Total execution time: 0.1728
DEBUG - 2022-11-13 17:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:24 --> Total execution time: 0.1957
DEBUG - 2022-11-13 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:25 --> Total execution time: 0.1945
DEBUG - 2022-11-13 17:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:25 --> Total execution time: 0.1763
DEBUG - 2022-11-13 17:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:49:54 --> Total execution time: 0.1234
DEBUG - 2022-11-13 17:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:00 --> Total execution time: 0.0961
DEBUG - 2022-11-13 17:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:01 --> Total execution time: 0.1924
DEBUG - 2022-11-13 17:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:02 --> Total execution time: 0.1855
DEBUG - 2022-11-13 17:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:02 --> Total execution time: 0.1892
DEBUG - 2022-11-13 17:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:03 --> Total execution time: 0.1845
DEBUG - 2022-11-13 17:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:03 --> Total execution time: 0.1756
DEBUG - 2022-11-13 17:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:04 --> Total execution time: 0.1832
DEBUG - 2022-11-13 17:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:04 --> Total execution time: 0.1793
DEBUG - 2022-11-13 17:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:04 --> Total execution time: 0.1823
DEBUG - 2022-11-13 17:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:05 --> Total execution time: 0.1762
DEBUG - 2022-11-13 17:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:32 --> Total execution time: 0.1382
DEBUG - 2022-11-13 17:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:39 --> Total execution time: 0.1008
DEBUG - 2022-11-13 17:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:39 --> Total execution time: 0.2160
DEBUG - 2022-11-13 17:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:43 --> Total execution time: 0.1794
DEBUG - 2022-11-13 17:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:44 --> Total execution time: 0.1777
DEBUG - 2022-11-13 17:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:44 --> Total execution time: 0.1873
DEBUG - 2022-11-13 17:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:44 --> Total execution time: 0.1834
DEBUG - 2022-11-13 17:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:45 --> Total execution time: 0.1868
DEBUG - 2022-11-13 17:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:47 --> Total execution time: 0.2409
DEBUG - 2022-11-13 17:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:48 --> Total execution time: 0.1835
DEBUG - 2022-11-13 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:50:49 --> Total execution time: 0.1862
DEBUG - 2022-11-13 17:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:13 --> Total execution time: 0.1204
DEBUG - 2022-11-13 17:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:15 --> Total execution time: 0.1082
DEBUG - 2022-11-13 17:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:15 --> Total execution time: 0.1972
DEBUG - 2022-11-13 17:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:16 --> Total execution time: 0.1835
DEBUG - 2022-11-13 17:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:17 --> Total execution time: 0.2152
DEBUG - 2022-11-13 17:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:17 --> Total execution time: 0.1820
DEBUG - 2022-11-13 17:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:18 --> Total execution time: 0.1898
DEBUG - 2022-11-13 17:51:18 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:18 --> Total execution time: 0.1954
DEBUG - 2022-11-13 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:19 --> Total execution time: 0.1799
DEBUG - 2022-11-13 17:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:19 --> Total execution time: 0.1711
DEBUG - 2022-11-13 17:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:20 --> Total execution time: 0.2021
DEBUG - 2022-11-13 17:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:43 --> Total execution time: 0.1262
DEBUG - 2022-11-13 17:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:51:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:51:48 --> Total execution time: 0.1444
DEBUG - 2022-11-13 17:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:52:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:52:13 --> Total execution time: 0.1931
DEBUG - 2022-11-13 17:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:52:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:52:42 --> Total execution time: 0.1484
DEBUG - 2022-11-13 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:53:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:53:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:53:22 --> Total execution time: 0.1199
DEBUG - 2022-11-13 17:53:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:53:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:53:50 --> Total execution time: 0.1212
DEBUG - 2022-11-13 17:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:54:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:54:14 --> Total execution time: 0.1435
DEBUG - 2022-11-13 17:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:54:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:54:17 --> Total execution time: 0.1242
DEBUG - 2022-11-13 17:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:54:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:54:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:54:59 --> Total execution time: 0.0991
DEBUG - 2022-11-13 17:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:55:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:55:02 --> Total execution time: 0.1031
DEBUG - 2022-11-13 17:55:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:55:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:55:05 --> Total execution time: 0.1331
DEBUG - 2022-11-13 17:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:55:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:55:08 --> Total execution time: 0.1671
DEBUG - 2022-11-13 17:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:55:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:55:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:55:44 --> Total execution time: 0.1227
DEBUG - 2022-11-13 17:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:55:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:55:47 --> Total execution time: 0.1509
DEBUG - 2022-11-13 17:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:55:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:55:49 --> Total execution time: 0.1206
DEBUG - 2022-11-13 17:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:55:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:55:59 --> Total execution time: 0.2021
DEBUG - 2022-11-13 17:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:56:02 --> Total execution time: 0.1510
DEBUG - 2022-11-13 17:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:56:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:56:08 --> Total execution time: 0.1769
DEBUG - 2022-11-13 17:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:57:23 --> Total execution time: 0.1194
DEBUG - 2022-11-13 17:57:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:26 --> Total execution time: 0.1153
DEBUG - 2022-11-13 17:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:35 --> Total execution time: 0.1491
DEBUG - 2022-11-13 17:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:40 --> Total execution time: 0.1116
DEBUG - 2022-11-13 17:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:43 --> Total execution time: 0.1797
DEBUG - 2022-11-13 17:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:44 --> Total execution time: 0.1111
DEBUG - 2022-11-13 17:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:46 --> Total execution time: 0.1311
DEBUG - 2022-11-13 17:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:47 --> Total execution time: 0.1131
DEBUG - 2022-11-13 17:57:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:49 --> Total execution time: 0.1177
DEBUG - 2022-11-13 17:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:49 --> Total execution time: 0.1130
DEBUG - 2022-11-13 17:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:52 --> Total execution time: 0.1132
DEBUG - 2022-11-13 17:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:53 --> Total execution time: 0.1138
DEBUG - 2022-11-13 17:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:55 --> Total execution time: 0.1166
DEBUG - 2022-11-13 17:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:56 --> Total execution time: 0.1290
DEBUG - 2022-11-13 17:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:57:58 --> Total execution time: 0.1271
DEBUG - 2022-11-13 17:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:58:02 --> Total execution time: 0.1209
DEBUG - 2022-11-13 17:58:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:58:07 --> Total execution time: 0.2047
DEBUG - 2022-11-13 17:58:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:58:10 --> Total execution time: 0.1112
DEBUG - 2022-11-13 17:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:58:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:58:13 --> Total execution time: 0.1599
DEBUG - 2022-11-13 17:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:59:12 --> Total execution time: 0.1662
DEBUG - 2022-11-13 17:59:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:14 --> Total execution time: 0.1132
DEBUG - 2022-11-13 17:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:21 --> Total execution time: 0.1293
DEBUG - 2022-11-13 17:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:22 --> Total execution time: 0.1116
DEBUG - 2022-11-13 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:24 --> Total execution time: 0.1241
DEBUG - 2022-11-13 17:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:26 --> Total execution time: 0.1217
DEBUG - 2022-11-13 17:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:28 --> Total execution time: 0.1360
DEBUG - 2022-11-13 17:59:29 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:29 --> Total execution time: 0.1270
DEBUG - 2022-11-13 17:59:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:32 --> Total execution time: 0.1164
DEBUG - 2022-11-13 17:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:33 --> Total execution time: 0.1170
DEBUG - 2022-11-13 17:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:35 --> Total execution time: 0.1159
DEBUG - 2022-11-13 17:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:38 --> Total execution time: 0.1132
DEBUG - 2022-11-13 17:59:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 17:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 17:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 17:59:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 17:59:40 --> Total execution time: 0.1540
DEBUG - 2022-11-13 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:01:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:01:56 --> Total execution time: 0.1298
DEBUG - 2022-11-13 18:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:02 --> Total execution time: 0.1182
DEBUG - 2022-11-13 18:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:13 --> Total execution time: 0.1500
DEBUG - 2022-11-13 18:02:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:14 --> Total execution time: 0.1106
DEBUG - 2022-11-13 18:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:16 --> Total execution time: 0.1595
DEBUG - 2022-11-13 18:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:17 --> Total execution time: 0.1050
DEBUG - 2022-11-13 18:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:19 --> Total execution time: 0.1191
DEBUG - 2022-11-13 18:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:20 --> Total execution time: 0.1066
DEBUG - 2022-11-13 18:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:02:23 --> Total execution time: 0.1767
DEBUG - 2022-11-13 18:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:02:34 --> Total execution time: 0.1362
DEBUG - 2022-11-13 18:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:02:48 --> Total execution time: 0.1244
DEBUG - 2022-11-13 18:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:02:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:02:52 --> Total execution time: 0.1385
DEBUG - 2022-11-13 18:03:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:03:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:03:35 --> Total execution time: 0.1760
DEBUG - 2022-11-13 18:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:03:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:03:52 --> Total execution time: 0.1446
DEBUG - 2022-11-13 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:05:21 --> Total execution time: 0.1277
DEBUG - 2022-11-13 18:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:24 --> Total execution time: 0.1354
DEBUG - 2022-11-13 18:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:27 --> Total execution time: 0.1266
DEBUG - 2022-11-13 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:34 --> Total execution time: 0.1793
DEBUG - 2022-11-13 18:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:36 --> Total execution time: 0.1128
DEBUG - 2022-11-13 18:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:05:38 --> Total execution time: 0.1821
DEBUG - 2022-11-13 18:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:05:44 --> Total execution time: 0.1381
DEBUG - 2022-11-13 18:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:05:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:05:51 --> Total execution time: 0.1779
DEBUG - 2022-11-13 18:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:08:52 --> Total execution time: 0.1960
DEBUG - 2022-11-13 18:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:09:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:09:01 --> Total execution time: 0.1846
DEBUG - 2022-11-13 18:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:09:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:09:31 --> Total execution time: 0.1603
DEBUG - 2022-11-13 18:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:09:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:09:40 --> Total execution time: 0.1516
DEBUG - 2022-11-13 18:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:08 --> Total execution time: 0.1073
DEBUG - 2022-11-13 18:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:14 --> Total execution time: 0.1437
DEBUG - 2022-11-13 18:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:15 --> Total execution time: 0.1646
DEBUG - 2022-11-13 18:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:17 --> Total execution time: 0.1568
DEBUG - 2022-11-13 18:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:19 --> Total execution time: 0.1288
DEBUG - 2022-11-13 18:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:21 --> Total execution time: 0.1907
DEBUG - 2022-11-13 18:14:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:25 --> Total execution time: 0.1302
DEBUG - 2022-11-13 18:14:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:26 --> Total execution time: 0.1684
DEBUG - 2022-11-13 18:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:30 --> Total execution time: 0.1275
DEBUG - 2022-11-13 18:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:35 --> Total execution time: 0.1375
DEBUG - 2022-11-13 18:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:38 --> Total execution time: 0.1128
DEBUG - 2022-11-13 18:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:14:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:14:42 --> Total execution time: 0.2199
DEBUG - 2022-11-13 18:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:15:03 --> Total execution time: 0.1441
DEBUG - 2022-11-13 18:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:15:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:15:05 --> Total execution time: 0.1465
DEBUG - 2022-11-13 18:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:16:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:16:50 --> Total execution time: 0.2243
DEBUG - 2022-11-13 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:16:53 --> Total execution time: 0.1685
DEBUG - 2022-11-13 18:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:17:01 --> Total execution time: 0.2525
DEBUG - 2022-11-13 18:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:17:02 --> Total execution time: 0.2075
DEBUG - 2022-11-13 18:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:17:04 --> Total execution time: 0.1318
DEBUG - 2022-11-13 18:20:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:20:48 --> Total execution time: 0.1379
DEBUG - 2022-11-13 18:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:21:12 --> Total execution time: 0.1052
DEBUG - 2022-11-13 18:21:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:21:16 --> Total execution time: 0.1497
DEBUG - 2022-11-13 18:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:21:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:21:47 --> Total execution time: 0.2115
DEBUG - 2022-11-13 18:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:21:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:21:51 --> Total execution time: 0.1667
DEBUG - 2022-11-13 18:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:21:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:21:56 --> Total execution time: 0.1041
DEBUG - 2022-11-13 18:22:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:22:00 --> Total execution time: 0.1746
DEBUG - 2022-11-13 18:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:22:23 --> Total execution time: 0.1028
DEBUG - 2022-11-13 18:22:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:22:33 --> Total execution time: 0.1246
DEBUG - 2022-11-13 18:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:23:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:23:46 --> Total execution time: 0.1081
DEBUG - 2022-11-13 18:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:24:35 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:24:35 --> Total execution time: 0.0814
DEBUG - 2022-11-13 18:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:24:42 --> Total execution time: 0.1093
DEBUG - 2022-11-13 18:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:26:01 --> Total execution time: 0.1321
DEBUG - 2022-11-13 18:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:26:07 --> Total execution time: 0.0985
DEBUG - 2022-11-13 18:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:26:12 --> Total execution time: 0.1001
DEBUG - 2022-11-13 18:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:26:13 --> Total execution time: 0.1123
DEBUG - 2022-11-13 18:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:27:07 --> Total execution time: 0.1021
DEBUG - 2022-11-13 18:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:27:25 --> Total execution time: 0.1542
DEBUG - 2022-11-13 18:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:28:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:28:14 --> Total execution time: 0.1666
DEBUG - 2022-11-13 18:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:28:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:28:15 --> Total execution time: 0.1389
DEBUG - 2022-11-13 18:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:28:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:28:20 --> Total execution time: 0.1574
DEBUG - 2022-11-13 18:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:28:21 --> Total execution time: 0.1443
DEBUG - 2022-11-13 18:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:28:54 --> Total execution time: 0.1126
DEBUG - 2022-11-13 18:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:28:57 --> Total execution time: 0.1970
DEBUG - 2022-11-13 18:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:29:33 --> Total execution time: 0.1610
DEBUG - 2022-11-13 18:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:29:41 --> Total execution time: 0.1788
DEBUG - 2022-11-13 18:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:30:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:30:25 --> Total execution time: 0.1627
DEBUG - 2022-11-13 18:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:30:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:30:27 --> Total execution time: 0.1381
DEBUG - 2022-11-13 18:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:30:30 --> Total execution time: 0.1245
DEBUG - 2022-11-13 18:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:30:32 --> Total execution time: 0.1440
DEBUG - 2022-11-13 18:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:30:54 --> Total execution time: 0.1134
DEBUG - 2022-11-13 18:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:31:06 --> Total execution time: 0.2598
DEBUG - 2022-11-13 18:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:31:36 --> Total execution time: 0.1818
DEBUG - 2022-11-13 18:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:32:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:32:32 --> Total execution time: 0.1332
DEBUG - 2022-11-13 18:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:32:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:32:37 --> Total execution time: 0.1030
DEBUG - 2022-11-13 18:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:32:40 --> Total execution time: 0.1832
DEBUG - 2022-11-13 18:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:33:00 --> Total execution time: 0.1080
DEBUG - 2022-11-13 18:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:33:10 --> Total execution time: 0.2059
DEBUG - 2022-11-13 18:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:33:13 --> Total execution time: 0.1044
DEBUG - 2022-11-13 18:33:15 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:33:16 --> Total execution time: 0.1261
DEBUG - 2022-11-13 18:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:33:41 --> Total execution time: 0.1425
DEBUG - 2022-11-13 18:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:34:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:34:24 --> Total execution time: 0.1924
DEBUG - 2022-11-13 18:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:34:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:34:25 --> Total execution time: 0.1382
DEBUG - 2022-11-13 18:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:34:30 --> Total execution time: 0.1234
DEBUG - 2022-11-13 18:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:34:33 --> Total execution time: 0.1612
DEBUG - 2022-11-13 18:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:34:54 --> Total execution time: 0.1107
DEBUG - 2022-11-13 18:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:35:02 --> Total execution time: 0.1501
DEBUG - 2022-11-13 18:35:04 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:35:04 --> Total execution time: 0.1265
DEBUG - 2022-11-13 18:35:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:35:06 --> Total execution time: 0.1214
DEBUG - 2022-11-13 18:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:35:29 --> Total execution time: 0.1113
DEBUG - 2022-11-13 18:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:35:30 --> Total execution time: 0.1234
DEBUG - 2022-11-13 18:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:35:32 --> Total execution time: 0.1118
DEBUG - 2022-11-13 18:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:35:34 --> Total execution time: 0.1997
DEBUG - 2022-11-13 18:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:35:36 --> Total execution time: 0.2025
DEBUG - 2022-11-13 18:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:36:16 --> Total execution time: 0.1708
DEBUG - 2022-11-13 18:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:36:23 --> Total execution time: 0.1288
DEBUG - 2022-11-13 18:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:26 --> Total execution time: 0.1630
DEBUG - 2022-11-13 18:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:28 --> Total execution time: 0.1191
DEBUG - 2022-11-13 18:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:30 --> Total execution time: 0.1193
DEBUG - 2022-11-13 18:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:36:34 --> Total execution time: 0.1591
DEBUG - 2022-11-13 18:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:40 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:36:40 --> Total execution time: 0.1238
DEBUG - 2022-11-13 18:36:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:36:46 --> Total execution time: 0.1338
DEBUG - 2022-11-13 18:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:37:06 --> Total execution time: 0.1217
DEBUG - 2022-11-13 18:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:37:14 --> Total execution time: 0.1774
DEBUG - 2022-11-13 18:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:37:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:37:37 --> Total execution time: 0.1806
DEBUG - 2022-11-13 18:37:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:37:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:37:41 --> Total execution time: 0.1307
DEBUG - 2022-11-13 18:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:38:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:38:21 --> Total execution time: 0.1215
DEBUG - 2022-11-13 18:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:38:25 --> Total execution time: 0.1680
DEBUG - 2022-11-13 18:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:39:27 --> Total execution time: 0.1002
DEBUG - 2022-11-13 18:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:39:37 --> Total execution time: 0.1735
DEBUG - 2022-11-13 18:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:40:01 --> Total execution time: 0.1099
DEBUG - 2022-11-13 18:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:40:13 --> Total execution time: 0.1446
DEBUG - 2022-11-13 18:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:40:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:40:55 --> Total execution time: 0.2223
DEBUG - 2022-11-13 18:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 18:41:06 --> Total execution time: 0.1667
DEBUG - 2022-11-13 18:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:08 --> Total execution time: 0.1437
DEBUG - 2022-11-13 18:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:10 --> Total execution time: 0.1426
DEBUG - 2022-11-13 18:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:14 --> Total execution time: 0.1530
DEBUG - 2022-11-13 18:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:16 --> Total execution time: 0.1197
DEBUG - 2022-11-13 18:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:43 --> Total execution time: 0.1167
DEBUG - 2022-11-13 18:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:41:48 --> Total execution time: 0.1919
DEBUG - 2022-11-13 18:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 18:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 18:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 18:42:16 --> Total execution time: 0.1547
DEBUG - 2022-11-13 20:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:25:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:25:54 --> Total execution time: 0.1637
DEBUG - 2022-11-13 20:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:26:36 --> Total execution time: 0.1023
DEBUG - 2022-11-13 20:26:41 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:26:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:26:41 --> Total execution time: 0.0873
DEBUG - 2022-11-13 20:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:26:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:26:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:26:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:26:51 --> Total execution time: 0.1405
DEBUG - 2022-11-13 20:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:26:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:26:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:26:54 --> Total execution time: 0.0868
DEBUG - 2022-11-13 20:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:26:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:27:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:27:00 --> Total execution time: 0.1942
DEBUG - 2022-11-13 20:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:27:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:27:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:27:06 --> Total execution time: 0.0994
DEBUG - 2022-11-13 20:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:27:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:27:12 --> Total execution time: 0.1206
DEBUG - 2022-11-13 20:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:27:15 --> Total execution time: 0.2254
DEBUG - 2022-11-13 20:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:27:26 --> Total execution time: 0.1099
DEBUG - 2022-11-13 20:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 20:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 20:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 20:50:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-11-13 20:50:47 --> Total execution time: 0.1756
DEBUG - 2022-11-13 21:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:16:52 --> Total execution time: 0.1257
DEBUG - 2022-11-13 21:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:18:03 --> Total execution time: 0.1264
DEBUG - 2022-11-13 21:21:43 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:21:43 --> Total execution time: 0.1312
DEBUG - 2022-11-13 21:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:28:47 --> Total execution time: 0.1875
DEBUG - 2022-11-13 21:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:30:33 --> Total execution time: 0.1673
DEBUG - 2022-11-13 21:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:30:37 --> Total execution time: 0.1285
DEBUG - 2022-11-13 21:32:19 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:32:20 --> Total execution time: 0.1278
DEBUG - 2022-11-13 21:32:23 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:32:23 --> Total execution time: 0.1164
DEBUG - 2022-11-13 21:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:38:05 --> Total execution time: 0.2440
DEBUG - 2022-11-13 21:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:38:08 --> Total execution time: 0.1190
DEBUG - 2022-11-13 21:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:41:46 --> Total execution time: 0.1594
DEBUG - 2022-11-13 21:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:41:49 --> Total execution time: 0.1325
DEBUG - 2022-11-13 21:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:43:59 --> Total execution time: 0.1339
DEBUG - 2022-11-13 21:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:44:02 --> Total execution time: 0.1383
DEBUG - 2022-11-13 21:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:46:34 --> Total execution time: 0.1514
DEBUG - 2022-11-13 21:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 21:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 21:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 21:46:37 --> Total execution time: 0.1300
DEBUG - 2022-11-13 22:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-11-13 22:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-11-13 22:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-11-13 22:16:34 --> Total execution time: 0.1534
