<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-08-08 05:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:14:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:14:12 --> Total execution time: 0.1656
DEBUG - 2022-08-08 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:15:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:15:02 --> Total execution time: 0.1301
DEBUG - 2022-08-08 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:15:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:15:02 --> Total execution time: 0.1007
DEBUG - 2022-08-08 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-08 05:15:03 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-08 05:15:03 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-08 05:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-08 05:15:03 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-08 05:15:03 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-08 05:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-08 05:15:03 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-08 05:15:03 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-08 05:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:21:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:21:17 --> Total execution time: 0.1458
DEBUG - 2022-08-08 05:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:21:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:21:19 --> Total execution time: 0.0904
DEBUG - 2022-08-08 05:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:21:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:21:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:21:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:21:21 --> Total execution time: 0.1288
DEBUG - 2022-08-08 05:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:21:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:21:21 --> Total execution time: 0.1230
DEBUG - 2022-08-08 05:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:21:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:21:40 --> Total execution time: 0.0917
DEBUG - 2022-08-08 05:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:21:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:21:41 --> Total execution time: 0.1369
DEBUG - 2022-08-08 05:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:21:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:21:41 --> Total execution time: 0.1320
DEBUG - 2022-08-08 05:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:21:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:21:45 --> Total execution time: 0.1278
DEBUG - 2022-08-08 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:22:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:22:48 --> Total execution time: 0.0945
DEBUG - 2022-08-08 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-08 05:22:48 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-08 05:22:48 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-08 05:22:48 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-08 05:22:48 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-08 05:22:48 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-08 05:22:48 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-08 05:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:22:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:22:50 --> Total execution time: 0.1591
DEBUG - 2022-08-08 05:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:22:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:22:56 --> Total execution time: 0.1214
DEBUG - 2022-08-08 05:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:02 --> Total execution time: 0.1156
DEBUG - 2022-08-08 05:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:02 --> Total execution time: 0.1120
DEBUG - 2022-08-08 05:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:10 --> Total execution time: 0.1090
DEBUG - 2022-08-08 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:12 --> Total execution time: 0.0933
DEBUG - 2022-08-08 05:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:13 --> Total execution time: 0.1013
DEBUG - 2022-08-08 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:15 --> Total execution time: 0.1341
DEBUG - 2022-08-08 05:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 05:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 05:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 05:23:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 05:23:22 --> Total execution time: 0.1180
DEBUG - 2022-08-08 06:01:12 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 06:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 06:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 06:01:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 06:01:12 --> Total execution time: 0.1397
DEBUG - 2022-08-08 06:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-08 06:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-08 06:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-08 06:01:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-08 06:01:38 --> Total execution time: 0.1124
