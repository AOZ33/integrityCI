<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-24 09:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 09:42:19 --> No URI present. Default controller set.
DEBUG - 2022-02-24 09:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 09:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 09:42:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 09:42:19 --> Total execution time: 0.0312
DEBUG - 2022-02-24 09:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 09:42:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 09:42:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 09:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 09:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 09:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 09:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 09:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 09:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 09:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 09:42:32 --> Total execution time: 0.0059
DEBUG - 2022-02-24 09:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 09:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 09:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 09:42:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-24 09:42:34 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-24 09:42:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 09:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 09:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 09:42:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 09:42:36 --> Total execution time: 0.0041
DEBUG - 2022-02-24 10:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:16:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:16:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:16:25 --> Total execution time: 0.0064
DEBUG - 2022-02-24 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:19:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:19:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:19:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:19:54 --> Total execution time: 0.0056
DEBUG - 2022-02-24 10:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:35:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:35:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:35:34 --> Total execution time: 0.0065
DEBUG - 2022-02-24 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:39:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:39:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:39:41 --> Total execution time: 0.0063
DEBUG - 2022-02-24 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:47:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:47:25 --> Total execution time: 0.0060
DEBUG - 2022-02-24 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:49:18 --> Total execution time: 0.0052
DEBUG - 2022-02-24 10:59:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:59:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 10:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 10:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 10:59:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 10:59:35 --> Total execution time: 0.0065
DEBUG - 2022-02-24 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 11:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 11:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 11:38:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 11:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 11:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 11:38:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:38:15 --> Total execution time: 0.0067
DEBUG - 2022-02-24 11:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 11:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 11:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 11:47:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:47:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 11:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 11:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 11:47:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:47:16 --> Total execution time: 0.0062
DEBUG - 2022-02-24 11:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 11:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 11:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 11:51:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 11:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 11:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 11:51:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:51:51 --> Total execution time: 0.0054
DEBUG - 2022-02-24 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 11:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 11:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 11:53:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 11:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 11:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 11:53:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 11:53:43 --> Total execution time: 0.0049
DEBUG - 2022-02-24 12:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 12:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 12:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 12:05:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 12:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 12:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 12:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 12:05:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 12:05:17 --> Total execution time: 0.0061
DEBUG - 2022-02-24 14:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:09:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:09:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-24 14:09:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-24 14:09:11 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-24 14:09:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:09:19 --> No URI present. Default controller set.
DEBUG - 2022-02-24 14:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:09:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:09:19 --> Total execution time: 0.0047
DEBUG - 2022-02-24 14:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:09:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 14:09:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 14:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:09:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:09:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:09:22 --> Total execution time: 0.0058
DEBUG - 2022-02-24 14:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:09:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-24 14:09:23 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-24 14:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:09:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:09:25 --> Total execution time: 0.0038
DEBUG - 2022-02-24 14:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:11:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:11:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:11:52 --> Total execution time: 0.0054
DEBUG - 2022-02-24 14:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:13:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:13:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:13:28 --> Total execution time: 0.0053
DEBUG - 2022-02-24 14:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:18:19 --> Total execution time: 0.0054
DEBUG - 2022-02-24 14:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:49:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 14:49:08 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:49:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:49:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:49:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:49:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:49:18 --> Total execution time: 0.0065
DEBUG - 2022-02-24 14:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:49:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-24 14:49:21 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1314
DEBUG - 2022-02-24 14:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:49:58 --> Total execution time: 0.0047
DEBUG - 2022-02-24 14:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:50:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 14:50:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 14:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:50:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 14:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 14:50:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 14:50:23 --> Total execution time: 0.0032
DEBUG - 2022-02-24 14:50:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 14:50:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 14:50:23 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 15:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:00:06 --> No URI present. Default controller set.
DEBUG - 2022-02-24 15:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 15:00:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 15:00:06 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-02-24 15:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 15:00:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:00:06 --> Total execution time: 0.0312
DEBUG - 2022-02-24 15:00:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:00:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 15:00:06 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 15:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:08:54 --> No URI present. Default controller set.
DEBUG - 2022-02-24 15:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 15:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 15:08:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:08:54 --> Total execution time: 0.0311
DEBUG - 2022-02-24 15:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:08:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 15:08:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 15:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 15:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 15:08:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 15:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 15:08:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:08:58 --> Total execution time: 0.0031
DEBUG - 2022-02-24 15:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:08:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 15:08:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 15:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 15:09:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 15:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 15:09:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:09:04 --> Total execution time: 0.0031
DEBUG - 2022-02-24 15:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:09:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-24 15:09:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-24 15:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 15:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 15:09:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:09:29 --> Total execution time: 0.0041
DEBUG - 2022-02-24 15:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-24 15:09:31 --> No URI present. Default controller set.
DEBUG - 2022-02-24 15:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-24 15:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-24 15:09:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-24 15:09:31 --> Total execution time: 0.0029
