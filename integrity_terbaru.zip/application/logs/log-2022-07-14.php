<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-14 03:46:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 03:46:48 --> No URI present. Default controller set.
DEBUG - 2022-07-14 03:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 03:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 03:46:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 03:46:48 --> Total execution time: 0.1530
DEBUG - 2022-07-14 05:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:44 --> No URI present. Default controller set.
DEBUG - 2022-07-14 05:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 05:07:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 05:07:44 --> Total execution time: 0.1204
DEBUG - 2022-07-14 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 05:07:46 --> Total execution time: 0.0970
DEBUG - 2022-07-14 05:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 05:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 05:07:46 --> Total execution time: 0.0870
DEBUG - 2022-07-14 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-14 05:07:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-14 05:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-14 05:07:46 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-14 05:07:46 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-14 05:07:46 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-14 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:07:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-14 05:07:46 --> 404 Page Not Found: Auth/css
ERROR - 2022-07-14 05:07:46 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-14 05:07:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:07:49 --> No URI present. Default controller set.
DEBUG - 2022-07-14 05:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 05:07:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 05:07:49 --> Total execution time: 0.1073
DEBUG - 2022-07-14 05:10:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:10:23 --> No URI present. Default controller set.
DEBUG - 2022-07-14 05:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 05:10:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 05:10:23 --> Total execution time: 0.1352
DEBUG - 2022-07-14 05:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:16:50 --> No URI present. Default controller set.
DEBUG - 2022-07-14 05:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 05:16:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 05:16:50 --> Total execution time: 0.2771
DEBUG - 2022-07-14 05:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:16:50 --> No URI present. Default controller set.
DEBUG - 2022-07-14 05:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 05:16:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 05:16:50 --> Total execution time: 0.1134
DEBUG - 2022-07-14 05:31:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 05:31:43 --> No URI present. Default controller set.
DEBUG - 2022-07-14 05:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 05:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 05:31:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 05:31:44 --> Total execution time: 0.1534
DEBUG - 2022-07-14 06:05:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 06:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 06:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 06:05:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 06:05:04 --> Total execution time: 0.0904
DEBUG - 2022-07-14 06:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 06:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 06:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 06:09:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 06:09:44 --> Total execution time: 0.0939
DEBUG - 2022-07-14 07:07:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 07:07:19 --> No URI present. Default controller set.
DEBUG - 2022-07-14 07:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 07:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 07:07:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 07:07:20 --> Total execution time: 0.1023
DEBUG - 2022-07-14 07:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 07:26:00 --> No URI present. Default controller set.
DEBUG - 2022-07-14 07:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 07:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 07:26:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 07:26:00 --> Total execution time: 0.0455
DEBUG - 2022-07-14 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 07:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 07:26:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 07:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 07:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 07:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 07:26:06 --> Total execution time: 0.1494
DEBUG - 2022-07-14 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 07:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 07:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 07:26:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 07:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 07:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 07:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 07:26:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 07:26:11 --> Total execution time: 0.1251
DEBUG - 2022-07-14 09:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:27:17 --> No URI present. Default controller set.
DEBUG - 2022-07-14 09:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:27:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:27:17 --> Total execution time: 0.1496
DEBUG - 2022-07-14 09:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:27:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:27:24 --> Total execution time: 0.1222
DEBUG - 2022-07-14 09:27:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:27:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:27:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:27:28 --> Total execution time: 0.1126
DEBUG - 2022-07-14 09:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:27:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:27:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:27:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:27:49 --> Total execution time: 0.1584
DEBUG - 2022-07-14 09:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:27:52 --> Total execution time: 0.1344
DEBUG - 2022-07-14 09:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:05 --> Total execution time: 0.1427
DEBUG - 2022-07-14 09:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:28:08 --> Total execution time: 0.1689
DEBUG - 2022-07-14 09:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:28:10 --> Total execution time: 0.2014
DEBUG - 2022-07-14 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:11 --> Total execution time: 0.0985
DEBUG - 2022-07-14 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:28:14 --> Total execution time: 0.1908
DEBUG - 2022-07-14 09:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:28:27 --> Total execution time: 0.1664
DEBUG - 2022-07-14 09:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:31 --> Total execution time: 0.1228
DEBUG - 2022-07-14 09:28:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:38 --> Total execution time: 0.1186
DEBUG - 2022-07-14 09:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:28:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:28:41 --> Total execution time: 0.2310
DEBUG - 2022-07-14 09:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:29:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:29:05 --> Total execution time: 0.1458
DEBUG - 2022-07-14 09:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:29:07 --> Total execution time: 0.1200
DEBUG - 2022-07-14 09:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:29:27 --> Total execution time: 0.1211
DEBUG - 2022-07-14 09:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:29:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:29:28 --> Total execution time: 0.1057
DEBUG - 2022-07-14 09:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:29:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:29:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:29:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:29:57 --> Total execution time: 0.1395
DEBUG - 2022-07-14 09:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:00 --> Total execution time: 0.0845
DEBUG - 2022-07-14 09:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:07 --> Total execution time: 0.1446
DEBUG - 2022-07-14 09:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:09 --> Total execution time: 0.0952
DEBUG - 2022-07-14 09:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:14 --> Total execution time: 0.1035
DEBUG - 2022-07-14 09:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:38 --> Total execution time: 0.1077
DEBUG - 2022-07-14 09:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:30:55 --> Total execution time: 0.1458
DEBUG - 2022-07-14 09:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:30:58 --> Total execution time: 0.1257
DEBUG - 2022-07-14 09:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-14 09:31:05 --> 404 Page Not Found: User/editrole
DEBUG - 2022-07-14 09:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:31:08 --> Total execution time: 0.1042
DEBUG - 2022-07-14 09:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:31:10 --> Total execution time: 0.1019
DEBUG - 2022-07-14 09:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:31:34 --> Total execution time: 0.1066
DEBUG - 2022-07-14 09:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:31:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:31:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:31:41 --> Total execution time: 0.0886
DEBUG - 2022-07-14 09:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:31:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:31:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:31:47 --> Total execution time: 0.1091
DEBUG - 2022-07-14 09:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:31:49 --> Total execution time: 0.1325
DEBUG - 2022-07-14 09:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:38 --> Total execution time: 0.1013
DEBUG - 2022-07-14 09:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:32:42 --> Total execution time: 0.0902
DEBUG - 2022-07-14 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:32:47 --> Total execution time: 0.0952
DEBUG - 2022-07-14 09:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:51 --> Total execution time: 0.0969
DEBUG - 2022-07-14 09:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:32:54 --> Total execution time: 0.1458
DEBUG - 2022-07-14 09:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:32:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:32:58 --> Total execution time: 0.1164
DEBUG - 2022-07-14 09:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:33:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:33:04 --> Total execution time: 0.1002
DEBUG - 2022-07-14 09:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:33:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:33:08 --> Total execution time: 0.1680
DEBUG - 2022-07-14 09:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:33:24 --> Total execution time: 0.1140
DEBUG - 2022-07-14 09:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:34:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:34:32 --> Total execution time: 0.1621
DEBUG - 2022-07-14 09:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:35:03 --> Total execution time: 0.1365
DEBUG - 2022-07-14 09:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:35:22 --> Total execution time: 0.0714
DEBUG - 2022-07-14 09:35:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:35:37 --> Total execution time: 0.1147
DEBUG - 2022-07-14 09:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:35:38 --> Total execution time: 0.0720
DEBUG - 2022-07-14 09:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:35:57 --> Total execution time: 0.0768
DEBUG - 2022-07-14 09:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:35:59 --> Total execution time: 0.1391
DEBUG - 2022-07-14 09:36:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:36:00 --> Total execution time: 0.1100
DEBUG - 2022-07-14 09:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:36:03 --> Total execution time: 0.1098
DEBUG - 2022-07-14 09:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:39:20 --> Total execution time: 0.1430
DEBUG - 2022-07-14 09:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:39:30 --> Total execution time: 0.0914
DEBUG - 2022-07-14 09:39:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:39:41 --> Total execution time: 0.0990
DEBUG - 2022-07-14 09:39:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:39:56 --> Total execution time: 0.1146
DEBUG - 2022-07-14 09:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:40:36 --> Total execution time: 0.0919
DEBUG - 2022-07-14 09:40:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:40:48 --> Total execution time: 0.1014
DEBUG - 2022-07-14 09:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:40:55 --> Total execution time: 0.0720
DEBUG - 2022-07-14 09:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:40:57 --> Total execution time: 0.0691
DEBUG - 2022-07-14 09:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:41:03 --> Total execution time: 0.0964
DEBUG - 2022-07-14 09:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:41:15 --> Total execution time: 0.1049
DEBUG - 2022-07-14 09:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:41:56 --> Total execution time: 0.1161
DEBUG - 2022-07-14 09:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:45:40 --> Total execution time: 0.1098
DEBUG - 2022-07-14 09:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:45:44 --> Total execution time: 0.1107
DEBUG - 2022-07-14 09:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:45:48 --> Total execution time: 0.1147
DEBUG - 2022-07-14 09:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:46:09 --> Total execution time: 0.1585
DEBUG - 2022-07-14 09:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:46:13 --> Total execution time: 0.1370
DEBUG - 2022-07-14 09:46:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:46:26 --> Total execution time: 0.1192
DEBUG - 2022-07-14 09:46:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:46:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:46:29 --> Total execution time: 0.1305
DEBUG - 2022-07-14 09:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:46:36 --> Total execution time: 0.1422
DEBUG - 2022-07-14 09:46:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:46:56 --> Total execution time: 0.1112
DEBUG - 2022-07-14 09:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:11 --> Total execution time: 0.1153
DEBUG - 2022-07-14 09:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:18 --> Total execution time: 0.1197
DEBUG - 2022-07-14 09:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:47:24 --> Total execution time: 0.1040
DEBUG - 2022-07-14 09:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:26 --> Total execution time: 0.0966
DEBUG - 2022-07-14 09:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:47:27 --> Total execution time: 0.2397
DEBUG - 2022-07-14 09:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:47:30 --> Total execution time: 0.1508
DEBUG - 2022-07-14 09:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:47:35 --> Total execution time: 0.1863
DEBUG - 2022-07-14 09:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:38 --> Total execution time: 0.1277
DEBUG - 2022-07-14 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:47:40 --> Total execution time: 0.1058
DEBUG - 2022-07-14 09:48:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:48:16 --> Total execution time: 0.1096
DEBUG - 2022-07-14 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:48:26 --> Total execution time: 0.1092
DEBUG - 2022-07-14 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:48:31 --> Total execution time: 0.1194
DEBUG - 2022-07-14 09:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:48:44 --> Total execution time: 0.1198
DEBUG - 2022-07-14 09:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:48:47 --> Total execution time: 0.1452
DEBUG - 2022-07-14 09:49:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:49:09 --> Total execution time: 0.1027
DEBUG - 2022-07-14 09:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:49:22 --> Total execution time: 0.1140
DEBUG - 2022-07-14 09:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:49:29 --> Total execution time: 0.1139
DEBUG - 2022-07-14 09:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:49:33 --> Total execution time: 0.1271
DEBUG - 2022-07-14 09:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:49:56 --> Total execution time: 0.1047
DEBUG - 2022-07-14 09:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:49:59 --> Total execution time: 0.1069
DEBUG - 2022-07-14 09:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:50:02 --> Total execution time: 0.0976
DEBUG - 2022-07-14 09:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:50:04 --> Total execution time: 0.1350
DEBUG - 2022-07-14 09:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:50:07 --> Total execution time: 0.1127
DEBUG - 2022-07-14 09:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:50:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:50:09 --> Total execution time: 0.1619
DEBUG - 2022-07-14 09:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:50:11 --> Total execution time: 0.1188
DEBUG - 2022-07-14 09:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:50:37 --> Total execution time: 0.1304
DEBUG - 2022-07-14 09:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:51:21 --> Total execution time: 0.1215
DEBUG - 2022-07-14 09:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:51:41 --> Total execution time: 0.1305
DEBUG - 2022-07-14 09:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:51:51 --> Total execution time: 0.1123
DEBUG - 2022-07-14 09:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:52:04 --> Total execution time: 0.1026
DEBUG - 2022-07-14 09:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:52:10 --> Total execution time: 0.1599
DEBUG - 2022-07-14 09:55:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:55:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:55:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:55:50 --> Total execution time: 0.1976
DEBUG - 2022-07-14 09:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:56:02 --> Total execution time: 0.2087
DEBUG - 2022-07-14 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:56:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:56:05 --> Total execution time: 0.2037
DEBUG - 2022-07-14 09:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:56:16 --> Total execution time: 0.1216
DEBUG - 2022-07-14 09:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:56:20 --> Total execution time: 0.1218
DEBUG - 2022-07-14 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:56:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:56:30 --> Total execution time: 0.1735
DEBUG - 2022-07-14 09:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:56:39 --> Total execution time: 0.1240
DEBUG - 2022-07-14 09:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:56:41 --> Total execution time: 0.1295
DEBUG - 2022-07-14 09:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:56:45 --> Total execution time: 0.1444
DEBUG - 2022-07-14 09:57:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:57:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:57:04 --> Total execution time: 0.2172
DEBUG - 2022-07-14 09:57:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:57:38 --> Total execution time: 0.1338
DEBUG - 2022-07-14 09:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:57:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:57:40 --> Total execution time: 0.1808
DEBUG - 2022-07-14 09:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-14 09:57:41 --> Total execution time: 0.1555
DEBUG - 2022-07-14 09:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-14 09:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-14 09:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-14 09:57:43 --> Total execution time: 0.1661
