<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-06 09:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 09:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 09:54:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-06 09:54:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-06 09:54:03 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-06 09:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-06 09:54:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-06 09:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:09 --> No URI present. Default controller set.
DEBUG - 2022-01-06 09:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 09:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 09:54:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 09:54:09 --> Total execution time: 0.0052
DEBUG - 2022-01-06 09:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-06 09:54:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-06 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 09:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 09:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 09:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 09:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 09:54:20 --> Total execution time: 0.0045
DEBUG - 2022-01-06 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-06 09:54:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-06 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 09:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 09:54:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 09:54:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 09:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 09:54:30 --> Total execution time: 0.0067
DEBUG - 2022-01-06 09:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 09:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 09:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 09:54:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 09:54:33 --> Total execution time: 0.0770
DEBUG - 2022-01-06 10:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:10:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:10:06 --> Total execution time: 0.0350
DEBUG - 2022-01-06 10:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:20:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:20:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:20:12 --> Total execution time: 0.0074
DEBUG - 2022-01-06 10:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:26:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:26:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:26:39 --> Total execution time: 0.0071
DEBUG - 2022-01-06 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:30:16 --> Total execution time: 0.0060
DEBUG - 2022-01-06 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:35:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:35:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:35:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:35:58 --> Total execution time: 0.0066
DEBUG - 2022-01-06 10:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:39:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:39:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:39:01 --> Total execution time: 0.0061
DEBUG - 2022-01-06 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:43:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:43:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:43:01 --> Total execution time: 0.0060
DEBUG - 2022-01-06 10:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:46:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:46:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:46:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:46:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:46:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:46:22 --> Total execution time: 0.0064
DEBUG - 2022-01-06 10:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:49:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:49:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:49:34 --> Total execution time: 0.0056
DEBUG - 2022-01-06 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:56:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:56:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:56:23 --> Total execution time: 0.0062
DEBUG - 2022-01-06 10:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:58:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 10:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 10:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 10:58:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 10:58:42 --> Total execution time: 0.0046
DEBUG - 2022-01-06 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:02:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:02:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:02:36 --> Total execution time: 0.0066
DEBUG - 2022-01-06 11:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:14:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:14:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:14:56 --> Total execution time: 0.0065
DEBUG - 2022-01-06 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:19:27 --> Total execution time: 0.0059
DEBUG - 2022-01-06 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:28:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:28:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:28:10 --> Total execution time: 0.0068
DEBUG - 2022-01-06 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:36:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:36:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:36:32 --> Total execution time: 0.0059
DEBUG - 2022-01-06 11:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:41:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:41:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:41:01 --> Total execution time: 0.0061
DEBUG - 2022-01-06 11:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:45:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:45:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:45:33 --> Total execution time: 0.0060
DEBUG - 2022-01-06 11:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:50:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:50:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:50:43 --> Total execution time: 0.0058
DEBUG - 2022-01-06 11:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:55:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:55:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:55:34 --> Total execution time: 0.0063
DEBUG - 2022-01-06 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:57:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:57:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:57:27 --> Total execution time: 0.0051
DEBUG - 2022-01-06 11:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 11:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 11:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 11:58:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 11:58:22 --> Total execution time: 0.0783
DEBUG - 2022-01-06 13:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:28:33 --> Total execution time: 0.0365
DEBUG - 2022-01-06 13:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:28:33 --> Total execution time: 0.0034
DEBUG - 2022-01-06 13:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:35:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:35:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:35:43 --> Total execution time: 0.0063
DEBUG - 2022-01-06 13:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:42:22 --> Total execution time: 0.0059
DEBUG - 2022-01-06 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:48:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:48:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:48:11 --> Total execution time: 0.0062
DEBUG - 2022-01-06 13:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:50:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:50:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:50:12 --> Total execution time: 0.0054
DEBUG - 2022-01-06 13:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:50:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:50:52 --> Total execution time: 0.0796
DEBUG - 2022-01-06 13:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:51:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:51:52 --> Total execution time: 0.0049
DEBUG - 2022-01-06 13:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:55:16 --> Total execution time: 0.0059
DEBUG - 2022-01-06 13:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:58:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:58:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 13:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 13:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 13:58:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 13:58:31 --> Total execution time: 0.0057
DEBUG - 2022-01-06 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:06:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:06:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:06:01 --> Total execution time: 0.0065
DEBUG - 2022-01-06 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:10:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:10:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:10:52 --> Total execution time: 0.0060
DEBUG - 2022-01-06 14:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:14:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:14:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:14:13 --> Total execution time: 0.0057
DEBUG - 2022-01-06 14:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:18:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:18:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:18:05 --> Total execution time: 0.0062
DEBUG - 2022-01-06 14:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:13 --> No URI present. Default controller set.
DEBUG - 2022-01-06 14:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:23:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:13 --> Total execution time: 0.0303
DEBUG - 2022-01-06 14:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-06 14:23:13 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-01-06 14:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-06 14:23:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-06 14:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:13 --> No URI present. Default controller set.
DEBUG - 2022-01-06 14:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:23:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:23:13 --> Total execution time: 0.0047
DEBUG - 2022-01-06 14:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:23:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:23:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:23:19 --> Total execution time: 0.0032
DEBUG - 2022-01-06 14:23:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-06 14:23:19 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-06 14:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:23:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:23:24 --> Total execution time: 0.0057
DEBUG - 2022-01-06 14:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:23:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:23:26 --> Total execution time: 0.0796
DEBUG - 2022-01-06 14:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:23:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:23:31 --> Total execution time: 0.0046
DEBUG - 2022-01-06 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:24:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:24:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:24:15 --> Total execution time: 0.0041
DEBUG - 2022-01-06 14:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:29:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:29:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:29:27 --> Total execution time: 0.0060
DEBUG - 2022-01-06 14:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:33:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:33:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:33:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:33:47 --> Total execution time: 0.0058
DEBUG - 2022-01-06 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:38:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:38:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:38:49 --> Total execution time: 0.0061
DEBUG - 2022-01-06 14:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:41:53 --> Total execution time: 0.0051
DEBUG - 2022-01-06 14:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:44:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:44:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:44:53 --> Total execution time: 0.0061
DEBUG - 2022-01-06 14:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:48:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:48:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:48:35 --> Total execution time: 0.0062
DEBUG - 2022-01-06 14:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 14:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 14:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 14:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 14:56:02 --> Total execution time: 0.0062
DEBUG - 2022-01-06 15:02:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:02:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:02:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:02:53 --> Total execution time: 0.0058
DEBUG - 2022-01-06 15:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:02:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:02:54 --> Total execution time: 0.0805
DEBUG - 2022-01-06 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:14:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:14:07 --> Total execution time: 0.0335
DEBUG - 2022-01-06 15:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:17:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:17:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:17:43 --> Total execution time: 0.0063
DEBUG - 2022-01-06 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:32:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:32:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:32:26 --> Total execution time: 0.0059
DEBUG - 2022-01-06 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:32:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:32:31 --> Total execution time: 0.0817
DEBUG - 2022-01-06 15:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 15:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 15:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 15:33:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 15:33:03 --> Total execution time: 0.0049
DEBUG - 2022-01-06 16:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:01:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:01:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:01:10 --> Total execution time: 0.0069
DEBUG - 2022-01-06 16:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:05:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:05:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:05:45 --> Total execution time: 0.0066
DEBUG - 2022-01-06 16:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:10:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:10:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:10:15 --> Total execution time: 0.0066
DEBUG - 2022-01-06 16:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:14:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:14:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:14:34 --> Total execution time: 0.0066
DEBUG - 2022-01-06 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:21:00 --> Total execution time: 0.0061
DEBUG - 2022-01-06 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:29:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:29:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:29:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:29:03 --> Total execution time: 0.0060
DEBUG - 2022-01-06 16:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:36:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:36:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:36:36 --> Total execution time: 0.0054
DEBUG - 2022-01-06 16:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:42:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:42:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:42:19 --> Total execution time: 0.0066
DEBUG - 2022-01-06 16:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:48:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-06 16:48:51 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-06 16:48:51 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Yunisa Meutia Putri & yeyep Mutaali', 'Puput & Yeyep', '', NULL, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-01-06 16:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:48:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:48:51 --> Total execution time: 0.0058
DEBUG - 2022-01-06 16:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 16:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 16:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 16:48:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 16:48:54 --> Total execution time: 0.0824
DEBUG - 2022-01-06 17:00:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 17:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 17:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 17:00:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 17:00:18 --> Total execution time: 0.1411
DEBUG - 2022-01-06 17:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 17:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 17:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 17:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 17:03:18 --> Total execution time: 0.0351
DEBUG - 2022-01-06 17:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 17:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 17:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 17:03:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 17:03:40 --> Total execution time: 0.1101
DEBUG - 2022-01-06 17:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 17:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 17:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 17:04:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 17:04:28 --> Total execution time: 0.0050
DEBUG - 2022-01-06 17:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 17:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 17:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 17:09:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 17:09:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 17:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 17:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 17:09:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 17:09:09 --> Total execution time: 0.0060
DEBUG - 2022-01-06 17:09:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-06 17:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-06 17:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-06 17:09:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-06 17:09:14 --> Total execution time: 0.0966
