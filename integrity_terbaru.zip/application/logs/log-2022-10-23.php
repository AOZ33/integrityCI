<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-10-23 16:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:07:46 --> No URI present. Default controller set.
DEBUG - 2022-10-23 16:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-23 16:07:46 --> Total execution time: 0.1785
DEBUG - 2022-10-23 16:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:07:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-23 16:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:07:54 --> Total execution time: 0.1506
DEBUG - 2022-10-23 16:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:01 --> Total execution time: 0.1011
DEBUG - 2022-10-23 16:08:01 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:01 --> Total execution time: 0.2446
DEBUG - 2022-10-23 16:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:07 --> Total execution time: 0.1001
DEBUG - 2022-10-23 16:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:11 --> Total execution time: 0.1190
DEBUG - 2022-10-23 16:08:11 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:11 --> Total execution time: 0.2092
DEBUG - 2022-10-23 16:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:12 --> Total execution time: 0.1051
DEBUG - 2022-10-23 16:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:14 --> Total execution time: 0.0829
DEBUG - 2022-10-23 16:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:14 --> Total execution time: 0.2251
DEBUG - 2022-10-23 16:08:16 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:16 --> Total execution time: 0.1482
DEBUG - 2022-10-23 16:08:18 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:19 --> Total execution time: 0.2635
DEBUG - 2022-10-23 16:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-23 16:08:22 --> Total execution time: 0.2073
DEBUG - 2022-10-23 16:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-10-23 16:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-10-23 16:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-10-23 16:08:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-10-23 16:08:24 --> Total execution time: 0.1700
