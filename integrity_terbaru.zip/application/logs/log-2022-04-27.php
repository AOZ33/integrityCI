<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-27 03:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:09 --> No URI present. Default controller set.
DEBUG - 2022-04-27 03:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:46:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 03:46:09 --> Total execution time: 0.0494
DEBUG - 2022-04-27 03:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 03:46:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-27 03:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 03:46:09 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-27 03:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 03:46:09 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-27 03:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 03:46:09 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-27 03:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 03:46:09 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-27 03:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 03:46:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-27 03:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:46:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 03:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:46:12 --> Total execution time: 0.0097
DEBUG - 2022-04-27 03:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:46:59 --> Total execution time: 0.0026
DEBUG - 2022-04-27 03:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:46:59 --> Total execution time: 0.0465
DEBUG - 2022-04-27 03:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:01 --> Total execution time: 0.0529
DEBUG - 2022-04-27 03:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:01 --> Total execution time: 0.0450
DEBUG - 2022-04-27 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:02 --> Total execution time: 0.0475
DEBUG - 2022-04-27 03:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:02 --> Total execution time: 0.0479
DEBUG - 2022-04-27 03:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:03 --> Total execution time: 0.0508
DEBUG - 2022-04-27 03:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:03 --> Total execution time: 0.0422
DEBUG - 2022-04-27 03:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:04 --> Total execution time: 0.0413
DEBUG - 2022-04-27 03:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:24 --> Total execution time: 0.0026
DEBUG - 2022-04-27 03:47:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:27 --> Total execution time: 0.0034
DEBUG - 2022-04-27 03:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 03:47:29 --> Total execution time: 0.0023
DEBUG - 2022-04-27 03:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 03:47:29 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-27 03:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:47:34 --> Total execution time: 0.0024
DEBUG - 2022-04-27 03:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:54:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 03:54:26 --> Total execution time: 0.0684
DEBUG - 2022-04-27 03:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 03:54:26 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-27 03:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:54:45 --> Total execution time: 0.0021
DEBUG - 2022-04-27 03:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 03:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 03:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 03:54:45 --> Total execution time: 0.0470
DEBUG - 2022-04-27 04:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 04:04:05 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-04-27 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:05:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 04:05:47 --> Total execution time: 0.0622
DEBUG - 2022-04-27 04:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:05:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 04:05:47 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-27 04:05:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:05:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:05:55 --> Total execution time: 0.0049
DEBUG - 2022-04-27 04:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:06:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 04:06:01 --> 404 Page Not Found: Calendar/index3
DEBUG - 2022-04-27 04:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:06:02 --> Total execution time: 0.0044
DEBUG - 2022-04-27 04:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:31 --> Total execution time: 0.0538
DEBUG - 2022-04-27 04:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:38 --> Total execution time: 0.0026
DEBUG - 2022-04-27 04:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:38 --> Total execution time: 0.0493
DEBUG - 2022-04-27 04:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:40 --> Total execution time: 0.0496
DEBUG - 2022-04-27 04:08:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:40 --> Total execution time: 0.0401
DEBUG - 2022-04-27 04:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:41 --> Total execution time: 0.0410
DEBUG - 2022-04-27 04:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:48 --> Total execution time: 0.0028
DEBUG - 2022-04-27 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 04:08:51 --> Total execution time: 0.0232
DEBUG - 2022-04-27 04:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 04:08:51 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-27 04:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 04:08:52 --> Total execution time: 0.0153
DEBUG - 2022-04-27 04:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 04:09:01 --> Total execution time: 0.0236
DEBUG - 2022-04-27 04:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:20 --> Total execution time: 0.0022
DEBUG - 2022-04-27 04:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:20 --> Total execution time: 0.0567
DEBUG - 2022-04-27 04:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:21 --> Total execution time: 0.0440
DEBUG - 2022-04-27 04:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:23 --> Total execution time: 0.0406
DEBUG - 2022-04-27 04:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:24 --> Total execution time: 0.0442
DEBUG - 2022-04-27 04:09:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:25 --> Total execution time: 0.0439
DEBUG - 2022-04-27 04:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:26 --> Total execution time: 0.0437
DEBUG - 2022-04-27 04:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:26 --> Total execution time: 0.0429
DEBUG - 2022-04-27 04:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:09:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 04:09:27 --> Total execution time: 0.0048
DEBUG - 2022-04-27 04:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:25:44 --> Total execution time: 0.0380
DEBUG - 2022-04-27 04:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:25:44 --> Total execution time: 0.0466
DEBUG - 2022-04-27 04:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 04:26:42 --> Total execution time: 0.0105
DEBUG - 2022-04-27 04:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:44 --> Total execution time: 0.0017
DEBUG - 2022-04-27 04:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:44 --> Total execution time: 0.0544
DEBUG - 2022-04-27 04:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:48 --> Total execution time: 0.0565
DEBUG - 2022-04-27 04:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:49 --> Total execution time: 0.0446
DEBUG - 2022-04-27 04:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:50 --> Total execution time: 0.0528
DEBUG - 2022-04-27 04:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:50 --> Total execution time: 0.0485
DEBUG - 2022-04-27 04:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:52 --> Total execution time: 0.0439
DEBUG - 2022-04-27 04:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:52 --> Total execution time: 0.0494
DEBUG - 2022-04-27 04:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:53 --> Total execution time: 0.0435
DEBUG - 2022-04-27 04:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:54 --> Total execution time: 0.0398
DEBUG - 2022-04-27 04:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:55 --> Total execution time: 0.0469
DEBUG - 2022-04-27 04:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:55 --> Total execution time: 0.0416
DEBUG - 2022-04-27 04:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:56 --> Total execution time: 0.0381
DEBUG - 2022-04-27 04:26:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:26:56 --> Total execution time: 0.0430
DEBUG - 2022-04-27 04:27:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:02 --> Total execution time: 0.0494
DEBUG - 2022-04-27 04:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:03 --> Total execution time: 0.0457
DEBUG - 2022-04-27 04:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:04 --> Total execution time: 0.0423
DEBUG - 2022-04-27 04:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:04 --> Total execution time: 0.0508
DEBUG - 2022-04-27 04:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:41 --> Total execution time: 0.0025
DEBUG - 2022-04-27 04:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:41 --> Total execution time: 0.0496
DEBUG - 2022-04-27 04:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:43 --> Total execution time: 0.0475
DEBUG - 2022-04-27 04:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:44 --> Total execution time: 0.0392
DEBUG - 2022-04-27 04:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:47 --> Total execution time: 0.0469
DEBUG - 2022-04-27 04:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:49 --> Total execution time: 0.0385
DEBUG - 2022-04-27 04:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:27:50 --> Total execution time: 0.0432
DEBUG - 2022-04-27 04:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:24 --> Total execution time: 0.0027
DEBUG - 2022-04-27 04:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:24 --> Total execution time: 0.0495
DEBUG - 2022-04-27 04:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:25 --> Total execution time: 0.0393
DEBUG - 2022-04-27 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:26 --> Total execution time: 0.0444
DEBUG - 2022-04-27 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:26 --> Total execution time: 0.0419
DEBUG - 2022-04-27 04:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:27 --> Total execution time: 0.0478
DEBUG - 2022-04-27 04:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:28 --> Total execution time: 0.0488
DEBUG - 2022-04-27 04:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:29 --> Total execution time: 0.0452
DEBUG - 2022-04-27 04:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:55 --> Total execution time: 0.0501
DEBUG - 2022-04-27 04:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:56 --> Total execution time: 0.0484
DEBUG - 2022-04-27 04:28:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:28:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:28:56 --> Total execution time: 0.0424
DEBUG - 2022-04-27 04:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:29:00 --> Total execution time: 0.0430
DEBUG - 2022-04-27 04:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:29:43 --> Total execution time: 0.0023
DEBUG - 2022-04-27 04:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:29:43 --> Total execution time: 0.0469
DEBUG - 2022-04-27 04:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:29:45 --> Total execution time: 0.0498
DEBUG - 2022-04-27 04:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:29:45 --> Total execution time: 0.0461
DEBUG - 2022-04-27 04:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 04:30:33 --> Total execution time: 0.0069
DEBUG - 2022-04-27 04:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:35 --> Total execution time: 0.0018
DEBUG - 2022-04-27 04:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:35 --> Total execution time: 0.0459
DEBUG - 2022-04-27 04:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:54 --> Total execution time: 0.0520
DEBUG - 2022-04-27 04:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:54 --> Total execution time: 0.0471
DEBUG - 2022-04-27 04:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:55 --> Total execution time: 0.0478
DEBUG - 2022-04-27 04:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:55 --> Total execution time: 0.0439
DEBUG - 2022-04-27 04:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:55 --> Total execution time: 0.0444
DEBUG - 2022-04-27 04:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:55 --> Total execution time: 0.0440
DEBUG - 2022-04-27 04:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:56 --> Total execution time: 0.0433
DEBUG - 2022-04-27 04:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:56 --> Total execution time: 0.0460
DEBUG - 2022-04-27 04:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:57 --> Total execution time: 0.0446
DEBUG - 2022-04-27 04:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:57 --> Total execution time: 0.0575
DEBUG - 2022-04-27 04:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:57 --> Total execution time: 0.0436
DEBUG - 2022-04-27 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:58 --> Total execution time: 0.0420
DEBUG - 2022-04-27 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:58 --> Total execution time: 0.0477
DEBUG - 2022-04-27 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:58 --> Total execution time: 0.0460
DEBUG - 2022-04-27 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:58 --> Total execution time: 0.0451
DEBUG - 2022-04-27 04:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:58 --> Total execution time: 0.0444
DEBUG - 2022-04-27 04:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:59 --> Total execution time: 0.0442
DEBUG - 2022-04-27 04:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:59 --> Total execution time: 0.0431
DEBUG - 2022-04-27 04:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:30:59 --> Total execution time: 0.0428
DEBUG - 2022-04-27 04:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:31:00 --> Total execution time: 0.0489
DEBUG - 2022-04-27 04:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:31:00 --> Total execution time: 0.0558
DEBUG - 2022-04-27 04:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:31:00 --> Total execution time: 0.0420
DEBUG - 2022-04-27 04:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:31:01 --> Total execution time: 0.0530
DEBUG - 2022-04-27 04:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 04:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 04:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 04:45:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 04:45:27 --> Total execution time: 0.0465
DEBUG - 2022-04-27 06:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:18:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 06:18:52 --> Total execution time: 0.0641
DEBUG - 2022-04-27 06:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:19:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 06:19:05 --> Total execution time: 0.0075
DEBUG - 2022-04-27 06:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:19:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 06:19:08 --> Total execution time: 0.0077
DEBUG - 2022-04-27 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:19:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 06:19:11 --> Total execution time: 0.0096
DEBUG - 2022-04-27 06:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:19:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 06:19:15 --> Total execution time: 0.0093
DEBUG - 2022-04-27 06:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:19:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 06:19:19 --> Total execution time: 0.0049
DEBUG - 2022-04-27 06:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:19:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 06:19:22 --> Total execution time: 0.0050
DEBUG - 2022-04-27 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:45:56 --> Total execution time: 0.0390
DEBUG - 2022-04-27 06:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:45:56 --> Total execution time: 0.0504
DEBUG - 2022-04-27 06:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:45:58 --> Total execution time: 0.0465
DEBUG - 2022-04-27 06:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:45:58 --> Total execution time: 0.0399
DEBUG - 2022-04-27 06:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:45:59 --> Total execution time: 0.0427
DEBUG - 2022-04-27 06:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 06:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 06:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 06:46:00 --> Total execution time: 0.0472
DEBUG - 2022-04-27 07:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:13:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:13:10 --> Total execution time: 0.0500
DEBUG - 2022-04-27 07:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:13:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:13:14 --> Total execution time: 0.0076
DEBUG - 2022-04-27 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:13 --> Total execution time: 0.0019
DEBUG - 2022-04-27 07:14:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:13 --> Total execution time: 0.0496
DEBUG - 2022-04-27 07:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:30 --> Total execution time: 0.0014
DEBUG - 2022-04-27 07:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:30 --> Total execution time: 0.0498
DEBUG - 2022-04-27 07:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:14:31 --> Total execution time: 0.0041
DEBUG - 2022-04-27 07:14:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:14:39 --> Total execution time: 0.0167
DEBUG - 2022-04-27 07:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:48 --> Total execution time: 0.0020
DEBUG - 2022-04-27 07:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:48 --> Total execution time: 0.0410
DEBUG - 2022-04-27 07:14:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:50 --> Total execution time: 0.0409
DEBUG - 2022-04-27 07:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:52 --> Total execution time: 0.0621
DEBUG - 2022-04-27 07:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:54 --> Total execution time: 0.0414
DEBUG - 2022-04-27 07:14:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:14:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:14:55 --> Total execution time: 0.0477
DEBUG - 2022-04-27 07:16:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:18 --> Total execution time: 0.0016
DEBUG - 2022-04-27 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:19 --> Total execution time: 0.0433
DEBUG - 2022-04-27 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:16:23 --> Total execution time: 0.0025
DEBUG - 2022-04-27 07:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:16:28 --> Total execution time: 0.0106
DEBUG - 2022-04-27 07:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:16:36 --> Total execution time: 0.0051
DEBUG - 2022-04-27 07:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:52 --> Total execution time: 0.0015
DEBUG - 2022-04-27 07:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:52 --> Total execution time: 0.0584
DEBUG - 2022-04-27 07:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:53 --> Total execution time: 0.0436
DEBUG - 2022-04-27 07:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:56 --> Total execution time: 0.0525
DEBUG - 2022-04-27 07:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:16:58 --> Total execution time: 0.0042
DEBUG - 2022-04-27 07:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:02 --> Total execution time: 0.0056
DEBUG - 2022-04-27 07:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:10 --> Total execution time: 0.0084
DEBUG - 2022-04-27 07:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:15 --> Total execution time: 0.0114
DEBUG - 2022-04-27 07:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:19 --> Total execution time: 0.0088
DEBUG - 2022-04-27 07:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:24 --> Total execution time: 0.0170
DEBUG - 2022-04-27 07:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:26 --> Total execution time: 0.0100
DEBUG - 2022-04-27 07:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:32 --> Total execution time: 0.0248
DEBUG - 2022-04-27 07:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:36 --> Total execution time: 0.0168
DEBUG - 2022-04-27 07:20:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:20:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:20:41 --> Total execution time: 0.0048
DEBUG - 2022-04-27 07:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:24:55 --> Total execution time: 0.0426
DEBUG - 2022-04-27 07:24:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:24:58 --> Total execution time: 0.0020
DEBUG - 2022-04-27 07:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:25:56 --> Total execution time: 0.0025
DEBUG - 2022-04-27 07:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:26:59 --> Total execution time: 0.0371
DEBUG - 2022-04-27 07:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:26:59 --> Total execution time: 0.0510
DEBUG - 2022-04-27 07:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:27:23 --> Total execution time: 0.0464
DEBUG - 2022-04-27 07:27:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:27:23 --> Total execution time: 0.0453
DEBUG - 2022-04-27 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:32:26 --> Total execution time: 0.0377
DEBUG - 2022-04-27 07:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:32:26 --> Total execution time: 0.0506
DEBUG - 2022-04-27 07:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:32:28 --> Total execution time: 0.0488
DEBUG - 2022-04-27 07:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:32:28 --> Total execution time: 0.0467
DEBUG - 2022-04-27 07:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:32:36 --> Total execution time: 0.0018
DEBUG - 2022-04-27 07:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:32:37 --> Total execution time: 0.0485
DEBUG - 2022-04-27 07:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:32:38 --> Total execution time: 0.0438
DEBUG - 2022-04-27 07:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:32:39 --> Total execution time: 0.0428
DEBUG - 2022-04-27 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:33:11 --> Total execution time: 0.0046
DEBUG - 2022-04-27 07:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:33:11 --> Total execution time: 0.0842
DEBUG - 2022-04-27 07:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:33:12 --> Total execution time: 0.1186
DEBUG - 2022-04-27 07:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:33:13 --> Total execution time: 0.0886
DEBUG - 2022-04-27 07:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:31 --> Total execution time: 0.0573
DEBUG - 2022-04-27 07:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:37 --> Total execution time: 0.0040
DEBUG - 2022-04-27 07:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:40 --> Total execution time: 0.0068
DEBUG - 2022-04-27 07:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:43 --> Total execution time: 0.0035
DEBUG - 2022-04-27 07:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:44 --> Total execution time: 0.0055
DEBUG - 2022-04-27 07:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:47 --> Total execution time: 0.0027
DEBUG - 2022-04-27 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:49 --> Total execution time: 0.0062
DEBUG - 2022-04-27 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:52 --> Total execution time: 0.0040
DEBUG - 2022-04-27 07:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:53 --> Total execution time: 0.0025
DEBUG - 2022-04-27 07:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:55 --> Total execution time: 0.0047
DEBUG - 2022-04-27 07:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:37:59 --> Total execution time: 0.0041
DEBUG - 2022-04-27 07:38:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:02 --> Total execution time: 0.0066
DEBUG - 2022-04-27 07:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:05 --> Total execution time: 0.0035
DEBUG - 2022-04-27 07:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:07 --> Total execution time: 0.0026
DEBUG - 2022-04-27 07:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:07 --> Total execution time: 0.0490
DEBUG - 2022-04-27 07:38:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:09 --> Total execution time: 0.0026
DEBUG - 2022-04-27 07:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:12 --> Total execution time: 0.0033
DEBUG - 2022-04-27 07:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:14 --> Total execution time: 0.0022
DEBUG - 2022-04-27 07:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:15 --> Total execution time: 0.0064
DEBUG - 2022-04-27 07:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:18 --> Total execution time: 0.0038
DEBUG - 2022-04-27 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:20 --> Total execution time: 0.0032
DEBUG - 2022-04-27 07:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:38:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:38:22 --> Total execution time: 0.0374
DEBUG - 2022-04-27 07:38:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:38:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 07:38:22 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-27 07:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:47:48 --> Total execution time: 0.0508
DEBUG - 2022-04-27 07:47:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:47:48 --> Total execution time: 0.0469
DEBUG - 2022-04-27 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:49:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:49:37 --> Total execution time: 0.0612
DEBUG - 2022-04-27 07:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 07:49:37 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-27 07:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:49:42 --> Total execution time: 0.0065
DEBUG - 2022-04-27 07:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:49:46 --> Total execution time: 0.0029
DEBUG - 2022-04-27 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:49:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-27 07:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-27 07:49:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-27 07:49:49 --> Total execution time: 0.0227
DEBUG - 2022-04-27 07:49:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-27 07:49:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-27 07:49:49 --> 404 Page Not Found: Img/undraw_posting_photo.svg
