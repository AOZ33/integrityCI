<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-02 10:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 10:29:30 --> No URI present. Default controller set.
DEBUG - 2022-02-02 10:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 10:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 10:29:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 10:29:30 --> Total execution time: 0.0302
DEBUG - 2022-02-02 10:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 10:29:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-02 10:29:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-02 10:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 10:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 10:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 10:29:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 10:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 10:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 10:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 10:29:41 --> Total execution time: 0.0068
DEBUG - 2022-02-02 10:29:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 10:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 10:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 10:29:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-02 10:29:44 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 144015680 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-02 10:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 10:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 10:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 10:29:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 10:29:49 --> Total execution time: 0.0046
DEBUG - 2022-02-02 11:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:04:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:04:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:04:14 --> Total execution time: 0.0065
DEBUG - 2022-02-02 11:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:08:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:08:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:08:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:08:38 --> Total execution time: 0.0063
DEBUG - 2022-02-02 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:10:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:10:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:10:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:10:52 --> Total execution time: 0.0051
DEBUG - 2022-02-02 11:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:15:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:15:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:15:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:15:52 --> Total execution time: 0.0061
DEBUG - 2022-02-02 11:18:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:18:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:18:19 --> Total execution time: 0.0051
DEBUG - 2022-02-02 11:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:20:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:20:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:20:04 --> Total execution time: 0.0054
DEBUG - 2022-02-02 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:22:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:22:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:22:23 --> Total execution time: 0.0056
DEBUG - 2022-02-02 11:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:25:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:25:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:25:29 --> Total execution time: 0.0061
DEBUG - 2022-02-02 11:43:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:43:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:43:36 --> Total execution time: 0.0364
DEBUG - 2022-02-02 11:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:46:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:46:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:46:58 --> Total execution time: 0.0047
DEBUG - 2022-02-02 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 11:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 11:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 11:49:23 --> Total execution time: 0.0052
DEBUG - 2022-02-02 12:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:07:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:07:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:07:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:07:47 --> Total execution time: 0.0067
DEBUG - 2022-02-02 12:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:11:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:11:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:11:17 --> Total execution time: 0.0049
DEBUG - 2022-02-02 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:12:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:12:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:12:42 --> Total execution time: 0.0054
DEBUG - 2022-02-02 12:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:18:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:18:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:18:39 --> Total execution time: 0.0065
DEBUG - 2022-02-02 12:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:21:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:21:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:21:10 --> Total execution time: 0.0048
DEBUG - 2022-02-02 12:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:23:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 12:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 12:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 12:23:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 12:23:25 --> Total execution time: 0.0058
DEBUG - 2022-02-02 13:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:32:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:32:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:32:14 --> Total execution time: 0.0062
DEBUG - 2022-02-02 13:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:35:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:35:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:35:12 --> Total execution time: 0.0051
DEBUG - 2022-02-02 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:37:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:37:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:37:52 --> Total execution time: 0.0048
DEBUG - 2022-02-02 13:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:42:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:42:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:42:14 --> Total execution time: 0.0063
DEBUG - 2022-02-02 13:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:50:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:50:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:50:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:50:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:50:17 --> Total execution time: 0.0061
DEBUG - 2022-02-02 13:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:54:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:54:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:54:49 --> Total execution time: 0.0059
DEBUG - 2022-02-02 13:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:58:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 13:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 13:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 13:58:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 13:58:30 --> Total execution time: 0.0067
DEBUG - 2022-02-02 14:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:02:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:02:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:02:19 --> Total execution time: 0.0062
DEBUG - 2022-02-02 14:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:07:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:07:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:07:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:07:58 --> Total execution time: 0.0057
DEBUG - 2022-02-02 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:11:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:11:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:11:27 --> Total execution time: 0.0047
DEBUG - 2022-02-02 14:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:19:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:19:21 --> Total execution time: 0.0372
DEBUG - 2022-02-02 14:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:19:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 14:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 14:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 14:22:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 14:22:55 --> Total execution time: 0.0336
DEBUG - 2022-02-02 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:20:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:20:01 --> Total execution time: 0.0068
DEBUG - 2022-02-02 15:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:25:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:25:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:25:36 --> Total execution time: 0.0061
DEBUG - 2022-02-02 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:32:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:32:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:32:43 --> Total execution time: 0.0062
DEBUG - 2022-02-02 15:42:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:42:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:42:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:42:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:42:53 --> Total execution time: 0.0059
DEBUG - 2022-02-02 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:46:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:46:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:46:46 --> Total execution time: 0.0060
DEBUG - 2022-02-02 15:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:53:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 15:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 15:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 15:53:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 15:53:15 --> Total execution time: 0.0064
DEBUG - 2022-02-02 16:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:30:18 --> Total execution time: 0.0067
DEBUG - 2022-02-02 16:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:35:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:35:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:35:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:35:24 --> Total execution time: 0.0056
DEBUG - 2022-02-02 16:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:42:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:42:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:42:30 --> Total execution time: 0.0058
DEBUG - 2022-02-02 16:45:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:45:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:45:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:45:18 --> Total execution time: 0.0063
DEBUG - 2022-02-02 16:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:49:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:49:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:49:22 --> Total execution time: 0.0059
DEBUG - 2022-02-02 16:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:52:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 16:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 16:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 16:52:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 16:52:44 --> Total execution time: 0.0062
DEBUG - 2022-02-02 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 17:00:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 17:00:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 17:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 17:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 17:00:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 17:00:29 --> Total execution time: 0.0075
DEBUG - 2022-02-02 17:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 17:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 17:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 17:01:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-02 17:01:49 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-02 17:01:49 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Gita nanda Reisya & Nikita Luqman Adurrahim', '', 'Full package 2\\', NULL, '', '', '', '', '', '', '', '', '', '', '', 'Jl. Teratai Mekar VII Ni. II Rt 004/ 009 Panyileukan Bandung', '081312427072', '', 'gitanreisya15@gmail.com', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-02-02 17:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 17:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 17:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 17:01:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 17:01:50 --> Total execution time: 0.0059
DEBUG - 2022-02-02 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 17:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 17:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 17:04:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 17:04:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-02 17:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-02 17:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-02 17:04:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-02 17:04:56 --> Total execution time: 0.0060
