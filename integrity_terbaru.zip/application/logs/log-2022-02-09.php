<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-09 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 09:32:47 --> No URI present. Default controller set.
DEBUG - 2022-02-09 09:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 09:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 09:32:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 09:32:47 --> Total execution time: 0.0302
DEBUG - 2022-02-09 09:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 09:32:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-09 09:32:47 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-09 09:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 09:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 09:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 09:52:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 09:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 09:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 09:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 09:52:48 --> Total execution time: 0.0059
DEBUG - 2022-02-09 09:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 09:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 09:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 09:55:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-09 09:55:44 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 170754064 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-09 09:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 09:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 09:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 09:55:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 09:55:48 --> Total execution time: 0.0049
DEBUG - 2022-02-09 10:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:10:58 --> No URI present. Default controller set.
DEBUG - 2022-02-09 10:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:10:58 --> Total execution time: 0.0312
DEBUG - 2022-02-09 10:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:10:58 --> No URI present. Default controller set.
DEBUG - 2022-02-09 10:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:10:58 --> Total execution time: 0.0034
DEBUG - 2022-02-09 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:10:59 --> No URI present. Default controller set.
DEBUG - 2022-02-09 10:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:10:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:10:59 --> Total execution time: 0.0032
DEBUG - 2022-02-09 10:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:10:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-09 10:10:59 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-02-09 10:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:17:47 --> No URI present. Default controller set.
DEBUG - 2022-02-09 10:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:17:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:17:47 --> Total execution time: 0.0306
DEBUG - 2022-02-09 10:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:17:47 --> No URI present. Default controller set.
DEBUG - 2022-02-09 10:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:17:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:17:47 --> Total execution time: 0.0029
DEBUG - 2022-02-09 10:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:17:48 --> No URI present. Default controller set.
DEBUG - 2022-02-09 10:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:17:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:17:48 --> Total execution time: 0.0043
DEBUG - 2022-02-09 10:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-09 10:17:48 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-02-09 10:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:20:13 --> No URI present. Default controller set.
DEBUG - 2022-02-09 10:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:20:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:20:13 --> Total execution time: 0.0300
DEBUG - 2022-02-09 10:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:32:41 --> No URI present. Default controller set.
DEBUG - 2022-02-09 10:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:32:41 --> Total execution time: 0.0302
DEBUG - 2022-02-09 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:34:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:34:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:34:25 --> Total execution time: 0.0070
DEBUG - 2022-02-09 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 10:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 10:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 10:56:18 --> Total execution time: 0.0059
DEBUG - 2022-02-09 11:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:04:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:04:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:04:48 --> Total execution time: 0.0055
DEBUG - 2022-02-09 11:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:12:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:12:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:12:26 --> Total execution time: 0.0065
DEBUG - 2022-02-09 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:28:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:28:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:28:57 --> Total execution time: 0.0056
DEBUG - 2022-02-09 11:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:30:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:30:31 --> Total execution time: 0.0045
DEBUG - 2022-02-09 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:39:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:39:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:39:16 --> Total execution time: 0.0063
DEBUG - 2022-02-09 11:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:48:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:48:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 11:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 11:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 11:48:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 11:48:44 --> Total execution time: 0.0053
DEBUG - 2022-02-09 12:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:09:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:09:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:09:15 --> Total execution time: 0.0066
DEBUG - 2022-02-09 12:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:16:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:16:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:16:27 --> Total execution time: 0.0064
DEBUG - 2022-02-09 12:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:20:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:20:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:20:46 --> Total execution time: 0.0058
DEBUG - 2022-02-09 12:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:25:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:25:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:25:11 --> Total execution time: 0.0057
DEBUG - 2022-02-09 12:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:27:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:27:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:27:00 --> Total execution time: 0.0050
DEBUG - 2022-02-09 12:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:33:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:33:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:33:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:33:17 --> Total execution time: 0.0066
DEBUG - 2022-02-09 12:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:35:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:35:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:35:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:35:26 --> Total execution time: 0.0052
DEBUG - 2022-02-09 12:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:40:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 12:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 12:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 12:40:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 12:40:37 --> Total execution time: 0.0063
DEBUG - 2022-02-09 14:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:06:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:06:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:06:50 --> Total execution time: 0.0068
DEBUG - 2022-02-09 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:13:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:13:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:13:46 --> Total execution time: 0.0065
DEBUG - 2022-02-09 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:28:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:28:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:28:30 --> Total execution time: 0.0061
DEBUG - 2022-02-09 14:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:37:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:37:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:37:11 --> Total execution time: 0.0063
DEBUG - 2022-02-09 14:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:45:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:45:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:45:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:45:28 --> Total execution time: 0.0060
DEBUG - 2022-02-09 14:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:50:39 --> Total execution time: 0.0065
DEBUG - 2022-02-09 14:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:54:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:54:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:54:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:54:33 --> Total execution time: 0.0053
DEBUG - 2022-02-09 14:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:59:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 14:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 14:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 14:59:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 14:59:22 --> Total execution time: 0.0064
DEBUG - 2022-02-09 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:10:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:10:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:10:02 --> Total execution time: 0.0063
DEBUG - 2022-02-09 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:17:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:17:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:17:14 --> Total execution time: 0.0066
DEBUG - 2022-02-09 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:25:03 --> Total execution time: 0.0061
DEBUG - 2022-02-09 15:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:34:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:34:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:34:10 --> Total execution time: 0.0057
DEBUG - 2022-02-09 15:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:36:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:36:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:36:25 --> Total execution time: 0.0044
DEBUG - 2022-02-09 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:39:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:39:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:39:06 --> Total execution time: 0.0047
DEBUG - 2022-02-09 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:42:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:42:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:42:38 --> Total execution time: 0.0060
DEBUG - 2022-02-09 15:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:48:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 15:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 15:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 15:48:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 15:48:19 --> Total execution time: 0.0066
DEBUG - 2022-02-09 16:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:06:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:06:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:06:12 --> Total execution time: 0.0066
DEBUG - 2022-02-09 16:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:11:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:11:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:11:42 --> Total execution time: 0.0055
DEBUG - 2022-02-09 16:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:14:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:14:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:14:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:14:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:14:04 --> Total execution time: 0.0055
DEBUG - 2022-02-09 16:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:16:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:16:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:16:05 --> Total execution time: 0.0058
DEBUG - 2022-02-09 16:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:17:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:17:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:17:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:17:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:17:49 --> Total execution time: 0.0046
DEBUG - 2022-02-09 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:21:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:21:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:21:03 --> Total execution time: 0.0063
DEBUG - 2022-02-09 16:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:24:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:24:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:24:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:24:11 --> Total execution time: 0.0049
DEBUG - 2022-02-09 16:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:28:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:28:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:28:59 --> Total execution time: 0.0056
DEBUG - 2022-02-09 16:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:50:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:50:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 16:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 16:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 16:50:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 16:50:40 --> Total execution time: 0.0062
DEBUG - 2022-02-09 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 17:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 17:07:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 17:07:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 17:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 17:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 17:07:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 17:07:36 --> Total execution time: 0.0057
DEBUG - 2022-02-09 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 17:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 17:09:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 17:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 17:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 17:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 17:09:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 17:09:46 --> Total execution time: 0.0057
DEBUG - 2022-02-09 17:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 17:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 17:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 17:26:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 17:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 17:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 17:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 17:26:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 17:26:58 --> Total execution time: 0.0067
DEBUG - 2022-02-09 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 17:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 17:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 17:50:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-09 17:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-09 17:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-09 17:50:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-09 17:50:55 --> Total execution time: 0.0062
