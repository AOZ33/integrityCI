<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-13 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-13 17:53:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-13 17:53:04 --> 404 Page Not Found: Wp-loginphp/index
