<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-24 04:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-24 04:14:58 --> No URI present. Default controller set.
DEBUG - 2022-04-24 04:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-24 04:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-24 04:14:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-24 04:14:58 --> Total execution time: 0.0479
