<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-06 04:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-06 04:57:29 --> No URI present. Default controller set.
DEBUG - 2022-02-06 04:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-06 04:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-06 04:57:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 04:57:29 --> Total execution time: 0.0306
DEBUG - 2022-02-06 04:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-06 04:58:00 --> No URI present. Default controller set.
DEBUG - 2022-02-06 04:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-06 04:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-06 04:58:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 04:58:00 --> Total execution time: 0.0039
DEBUG - 2022-02-06 07:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-06 07:20:27 --> No URI present. Default controller set.
DEBUG - 2022-02-06 07:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-06 07:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-06 07:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-06 07:20:27 --> Total execution time: 0.0302
