<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-19 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:29:23 --> No URI present. Default controller set.
DEBUG - 2021-11-19 06:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:29:23 --> Total execution time: 0.3787
DEBUG - 2021-11-19 06:29:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:29:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:29:25 --> Total execution time: 0.0505
DEBUG - 2021-11-19 06:29:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:29:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:29:28 --> Total execution time: 0.0628
DEBUG - 2021-11-19 06:29:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:29:31 --> Total execution time: 0.0556
DEBUG - 2021-11-19 06:29:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:29:33 --> Total execution time: 0.0382
DEBUG - 2021-11-19 06:29:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:29:35 --> Total execution time: 0.0413
DEBUG - 2021-11-19 06:35:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:35:01 --> Total execution time: 0.0428
DEBUG - 2021-11-19 06:38:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:38:53 --> Total execution time: 0.0431
DEBUG - 2021-11-19 06:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:43:56 --> Total execution time: 0.0296
DEBUG - 2021-11-19 06:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:43:56 --> Total execution time: 0.0455
DEBUG - 2021-11-19 06:44:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:44:24 --> Total execution time: 0.0424
DEBUG - 2021-11-19 06:44:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 06:44:24 --> 404 Page Not Found: Appointment/libs
DEBUG - 2021-11-19 06:44:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:44:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:44:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:44:24 --> Total execution time: 0.0276
DEBUG - 2021-11-19 06:44:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:44:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 06:44:24 --> 404 Page Not Found: Appointment/libs
DEBUG - 2021-11-19 06:45:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:45:16 --> Total execution time: 0.0388
DEBUG - 2021-11-19 06:45:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:45:18 --> Total execution time: 0.0424
DEBUG - 2021-11-19 06:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:46:55 --> Total execution time: 0.0368
DEBUG - 2021-11-19 06:46:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:46:56 --> Total execution time: 0.0430
DEBUG - 2021-11-19 06:46:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:46:57 --> Total execution time: 0.0446
DEBUG - 2021-11-19 06:56:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:56:16 --> Total execution time: 0.0457
DEBUG - 2021-11-19 06:56:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:56:26 --> Total execution time: 0.0438
DEBUG - 2021-11-19 06:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:56:32 --> Total execution time: 0.0408
DEBUG - 2021-11-19 06:58:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:58:11 --> Total execution time: 0.0459
DEBUG - 2021-11-19 06:58:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:58:36 --> Total execution time: 0.0465
DEBUG - 2021-11-19 06:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:58:44 --> Total execution time: 0.0513
DEBUG - 2021-11-19 06:59:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:59:08 --> Total execution time: 0.0279
DEBUG - 2021-11-19 06:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:59:32 --> Total execution time: 0.0286
DEBUG - 2021-11-19 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:59:35 --> Total execution time: 0.0585
DEBUG - 2021-11-19 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 06:59:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 06:59:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 06:59:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 06:59:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:59:52 --> Total execution time: 0.0396
DEBUG - 2021-11-19 06:59:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:59:55 --> Total execution time: 0.0573
DEBUG - 2021-11-19 06:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 06:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 06:59:58 --> Total execution time: 0.0459
DEBUG - 2021-11-19 06:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 06:59:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 06:59:58 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:00:00 --> Total execution time: 0.0518
DEBUG - 2021-11-19 07:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:00:00 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:00:00 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:00:02 --> Total execution time: 0.0525
DEBUG - 2021-11-19 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:00:02 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:00:02 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:00:03 --> Total execution time: 0.0423
DEBUG - 2021-11-19 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:00:03 --> Total execution time: 0.0469
DEBUG - 2021-11-19 07:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:00:03 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:00:04 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:00:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:00:04 --> Total execution time: 0.0370
DEBUG - 2021-11-19 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:00:05 --> Total execution time: 0.0549
DEBUG - 2021-11-19 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:00:05 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:00:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:00:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:00:05 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:02:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:02:55 --> Total execution time: 0.0410
DEBUG - 2021-11-19 07:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:02:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:02:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:02:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:01 --> Total execution time: 0.0500
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:01 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:01 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:01 --> Total execution time: 0.0280
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:01 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:01 --> Total execution time: 0.0257
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:01 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:01 --> Total execution time: 0.0375
DEBUG - 2021-11-19 07:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:01 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:02 --> Total execution time: 0.0268
DEBUG - 2021-11-19 07:03:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:03 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:03 --> Total execution time: 0.0412
DEBUG - 2021-11-19 07:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:04 --> Total execution time: 0.0385
DEBUG - 2021-11-19 07:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:04 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:04 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:05 --> Total execution time: 0.0365
DEBUG - 2021-11-19 07:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:03:05 --> Total execution time: 0.0389
DEBUG - 2021-11-19 07:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:05 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:03:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-19 07:03:05 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-19 07:05:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:05:17 --> Total execution time: 0.0446
DEBUG - 2021-11-19 07:05:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:05:18 --> Total execution time: 0.0372
DEBUG - 2021-11-19 07:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:05:19 --> Total execution time: 0.0554
DEBUG - 2021-11-19 07:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:05:20 --> Total execution time: 0.0493
DEBUG - 2021-11-19 07:07:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:07:55 --> Total execution time: 0.0297
DEBUG - 2021-11-19 07:08:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:08:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:08:45 --> Total execution time: 0.0462
DEBUG - 2021-11-19 07:08:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:08:47 --> Total execution time: 0.0452
DEBUG - 2021-11-19 07:10:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:10:52 --> Total execution time: 0.0277
DEBUG - 2021-11-19 07:10:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:10:59 --> Total execution time: 0.0464
DEBUG - 2021-11-19 07:11:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:11:30 --> Total execution time: 0.0373
DEBUG - 2021-11-19 07:12:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:12:06 --> Total execution time: 0.0366
DEBUG - 2021-11-19 07:14:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:14:51 --> Total execution time: 0.0300
DEBUG - 2021-11-19 07:15:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:15:20 --> Total execution time: 0.0486
DEBUG - 2021-11-19 07:17:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:17:30 --> Query error: Column 'date' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `package`, `price`, `date`) VALUES ('Farhan', 'pakt1', '1000000', NULL)
DEBUG - 2021-11-19 07:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:19:32 --> Total execution time: 0.0504
DEBUG - 2021-11-19 07:19:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:19:34 --> Total execution time: 0.0449
DEBUG - 2021-11-19 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:19:47 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:19:47 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:19:47 --> Total execution time: 0.0395
DEBUG - 2021-11-19 07:20:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:20:43 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:20:43 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:20:43 --> Total execution time: 0.0421
DEBUG - 2021-11-19 07:20:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:20:56 --> Query error: Unknown column 'tanggal' in 'field list' - Invalid query: INSERT INTO `appointment` (`name`, `package`, `price`, `tanggal`) VALUES ('Farhan', 'pakt1', '1000000', '11/18/2021')
DEBUG - 2021-11-19 07:21:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:21:12 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:21:12 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:21:12 --> Total execution time: 0.0283
DEBUG - 2021-11-19 07:21:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:21:13 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:21:13 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:21:13 --> Total execution time: 0.0430
DEBUG - 2021-11-19 07:21:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:21:19 --> Query error: Column 'date' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `package`, `price`, `date`) VALUES ('Farhan', 'pakt1', '1000000', NULL)
DEBUG - 2021-11-19 07:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:22:15 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:22:15 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:22:15 --> Total execution time: 0.0504
DEBUG - 2021-11-19 07:22:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:22:16 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:22:16 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:22:16 --> Total execution time: 0.0287
DEBUG - 2021-11-19 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:22:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:22:37 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:22:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:22:37 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:22:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:22:37 --> Total execution time: 0.0455
DEBUG - 2021-11-19 07:23:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:23:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:23:11 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:11 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:11 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:11 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:23:11 --> Total execution time: 0.0460
DEBUG - 2021-11-19 07:23:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:23:57 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:57 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:57 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:23:57 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:23:57 --> Total execution time: 0.0503
DEBUG - 2021-11-19 07:24:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:24:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:24:03 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:24:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:24:03 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:24:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:24:03 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:24:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:24:03 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
ERROR - 2021-11-19 07:24:03 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 179
DEBUG - 2021-11-19 07:24:03 --> Total execution time: 0.0312
DEBUG - 2021-11-19 07:24:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:24:33 --> Total execution time: 0.0388
DEBUG - 2021-11-19 07:24:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:24:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:24:35 --> Total execution time: 0.0420
DEBUG - 2021-11-19 07:24:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:24:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:24:38 --> Total execution time: 0.0420
DEBUG - 2021-11-19 07:25:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-19 07:25:00 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\nesnu\application\views\appointment\index.php 155
ERROR - 2021-11-19 07:25:00 --> Severity: Notice --> Undefined variable: date C:\xampp\htdocs\nesnu\application\views\appointment\index.php 155
DEBUG - 2021-11-19 07:25:00 --> Total execution time: 0.0532
DEBUG - 2021-11-19 07:25:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:25:32 --> Total execution time: 0.0465
DEBUG - 2021-11-19 07:26:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:26:47 --> Total execution time: 0.0527
DEBUG - 2021-11-19 07:26:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:26:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:26:53 --> Total execution time: 0.0413
DEBUG - 2021-11-19 07:26:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:26:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:26:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:26:58 --> Total execution time: 0.0458
DEBUG - 2021-11-19 07:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:27:04 --> Total execution time: 0.0365
DEBUG - 2021-11-19 07:28:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:28:59 --> Total execution time: 0.0440
DEBUG - 2021-11-19 07:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:29:17 --> Total execution time: 0.0478
DEBUG - 2021-11-19 07:30:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:30:21 --> Total execution time: 0.0390
DEBUG - 2021-11-19 07:31:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:19 --> Total execution time: 0.0415
DEBUG - 2021-11-19 07:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:27 --> Total execution time: 0.0427
DEBUG - 2021-11-19 07:31:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:30 --> Total execution time: 0.0415
DEBUG - 2021-11-19 07:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:32 --> Total execution time: 0.0466
DEBUG - 2021-11-19 07:31:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:35 --> Total execution time: 0.0433
DEBUG - 2021-11-19 07:31:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:39 --> Total execution time: 0.0266
DEBUG - 2021-11-19 07:31:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:31:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:31:43 --> Total execution time: 0.0513
DEBUG - 2021-11-19 07:38:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:38:48 --> Total execution time: 0.0517
DEBUG - 2021-11-19 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:38:56 --> Total execution time: 0.0267
DEBUG - 2021-11-19 07:42:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:42:37 --> Total execution time: 0.0274
DEBUG - 2021-11-19 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:42:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:42:45 --> Total execution time: 0.0411
DEBUG - 2021-11-19 07:43:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:43:12 --> Total execution time: 0.0403
DEBUG - 2021-11-19 07:43:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:43:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:43:17 --> Total execution time: 0.0273
DEBUG - 2021-11-19 07:43:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:43:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:43:23 --> Total execution time: 0.0448
DEBUG - 2021-11-19 07:43:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:43:37 --> Total execution time: 0.0290
DEBUG - 2021-11-19 07:43:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:43:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:43:41 --> Total execution time: 0.0455
DEBUG - 2021-11-19 07:44:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:44:02 --> Total execution time: 0.0478
DEBUG - 2021-11-19 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:44:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:44:11 --> Total execution time: 0.0420
DEBUG - 2021-11-19 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:44:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:44:14 --> Total execution time: 0.0273
DEBUG - 2021-11-19 07:51:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:03 --> Total execution time: 0.0426
DEBUG - 2021-11-19 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:12 --> Total execution time: 0.0416
DEBUG - 2021-11-19 07:51:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:15 --> Total execution time: 0.0419
DEBUG - 2021-11-19 07:51:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:16 --> Total execution time: 0.0376
DEBUG - 2021-11-19 07:51:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:30 --> Total execution time: 0.0454
DEBUG - 2021-11-19 07:51:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:51:39 --> Total execution time: 0.0289
DEBUG - 2021-11-19 07:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:54:20 --> Total execution time: 0.0465
DEBUG - 2021-11-19 07:54:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:54:23 --> Total execution time: 0.0502
DEBUG - 2021-11-19 07:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:54:24 --> Total execution time: 0.0471
DEBUG - 2021-11-19 07:54:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:54:43 --> Total execution time: 0.0372
DEBUG - 2021-11-19 07:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:55:03 --> Total execution time: 0.0438
DEBUG - 2021-11-19 07:55:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:55:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:55:11 --> Total execution time: 0.0447
DEBUG - 2021-11-19 07:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:56:08 --> Total execution time: 0.0527
DEBUG - 2021-11-19 07:58:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:58:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:58:03 --> Total execution time: 0.0271
DEBUG - 2021-11-19 07:59:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:59:10 --> Total execution time: 0.0276
DEBUG - 2021-11-19 07:59:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:59:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 07:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 07:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 07:59:18 --> Total execution time: 0.0429
DEBUG - 2021-11-19 08:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 08:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 08:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 08:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 08:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 08:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 08:00:42 --> Total execution time: 0.0414
DEBUG - 2021-11-19 08:00:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 08:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 08:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 08:00:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 08:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 08:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 08:00:54 --> Total execution time: 0.0420
DEBUG - 2021-11-19 08:00:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 08:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 08:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 08:00:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 08:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 08:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 08:00:58 --> Total execution time: 0.0522
DEBUG - 2021-11-19 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:15:20 --> No URI present. Default controller set.
DEBUG - 2021-11-19 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:15:20 --> Total execution time: 0.0289
DEBUG - 2021-11-19 09:15:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:15:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:15:21 --> Total execution time: 0.0414
DEBUG - 2021-11-19 09:15:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:15:22 --> Total execution time: 0.0386
DEBUG - 2021-11-19 09:15:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:15:27 --> Total execution time: 0.0468
DEBUG - 2021-11-19 09:15:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:15:37 --> Total execution time: 0.0428
DEBUG - 2021-11-19 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:15:40 --> Total execution time: 0.0443
DEBUG - 2021-11-19 09:16:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:16:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:16:04 --> Total execution time: 0.0506
DEBUG - 2021-11-19 09:16:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:16:42 --> Total execution time: 0.0445
DEBUG - 2021-11-19 09:16:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:16:44 --> Total execution time: 0.0531
DEBUG - 2021-11-19 09:16:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:16:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:16:47 --> Total execution time: 0.0400
DEBUG - 2021-11-19 09:16:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:16:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-19 09:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-19 09:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-19 09:16:49 --> Total execution time: 0.0238
