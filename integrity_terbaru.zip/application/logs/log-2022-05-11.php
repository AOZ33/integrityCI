<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-11 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:09:53 --> No URI present. Default controller set.
DEBUG - 2022-05-11 02:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:09:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 02:09:53 --> Total execution time: 0.0484
DEBUG - 2022-05-11 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:09:53 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-11 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:09:53 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-11 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:09:53 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-11 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:09:53 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-11 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:09:53 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-11 02:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:09:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-11 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:10:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 02:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:10:12 --> Total execution time: 0.0051
DEBUG - 2022-05-11 02:10:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:10:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:10:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-11 02:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:10:22 --> Total execution time: 0.0063
DEBUG - 2022-05-11 02:24:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:24:40 --> No URI present. Default controller set.
DEBUG - 2022-05-11 02:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:24:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 02:24:40 --> Total execution time: 0.0371
DEBUG - 2022-05-11 02:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:24:46 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-11 02:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:24:46 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-11 02:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:24:46 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-11 02:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:24:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:24:46 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-11 02:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:24:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:24:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-11 02:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:25:31 --> No URI present. Default controller set.
DEBUG - 2022-05-11 02:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:25:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 02:25:31 --> Total execution time: 0.0024
DEBUG - 2022-05-11 02:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:25:42 --> No URI present. Default controller set.
DEBUG - 2022-05-11 02:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:25:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 02:25:42 --> Total execution time: 0.0017
DEBUG - 2022-05-11 02:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:25:46 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-11 02:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:26:16 --> No URI present. Default controller set.
DEBUG - 2022-05-11 02:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:26:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 02:26:16 --> Total execution time: 0.0028
DEBUG - 2022-05-11 02:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:26:18 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-11 02:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:26:18 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-11 02:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:26:18 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-11 02:26:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 02:26:18 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-11 02:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:38:07 --> Total execution time: 0.0562
DEBUG - 2022-05-11 02:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:53:11 --> Total execution time: 0.0454
DEBUG - 2022-05-11 02:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:53:16 --> Total execution time: 0.0063
DEBUG - 2022-05-11 02:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:53:38 --> Total execution time: 0.0036
DEBUG - 2022-05-11 02:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:53:43 --> Total execution time: 0.0032
DEBUG - 2022-05-11 02:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:53:57 --> Total execution time: 0.0031
DEBUG - 2022-05-11 02:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:54:18 --> Total execution time: 0.0024
DEBUG - 2022-05-11 02:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:54:51 --> Total execution time: 0.0034
DEBUG - 2022-05-11 02:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:54:59 --> Total execution time: 0.0027
DEBUG - 2022-05-11 02:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:55:38 --> Total execution time: 0.0024
DEBUG - 2022-05-11 02:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:55:45 --> Total execution time: 0.0025
DEBUG - 2022-05-11 02:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:56:07 --> Total execution time: 0.0036
DEBUG - 2022-05-11 02:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:56:13 --> Total execution time: 0.0026
DEBUG - 2022-05-11 02:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:56:22 --> Total execution time: 0.0035
DEBUG - 2022-05-11 02:56:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 02:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 02:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 02:56:25 --> Total execution time: 0.0032
DEBUG - 2022-05-11 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:28 --> No URI present. Default controller set.
DEBUG - 2022-05-11 03:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 03:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 03:11:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 03:11:28 --> Total execution time: 0.0466
DEBUG - 2022-05-11 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 03:11:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-11 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 03:11:28 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-11 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 03:11:28 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-11 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 03:11:28 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-11 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 03:11:28 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-11 03:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 03:11:28 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-11 03:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 03:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 03:11:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 03:11:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 03:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 03:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 03:11:32 --> Total execution time: 0.0038
DEBUG - 2022-05-11 04:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:31:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:31:11 --> Total execution time: 0.0775
DEBUG - 2022-05-11 04:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:31:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:31:16 --> Total execution time: 0.0187
DEBUG - 2022-05-11 04:31:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:31:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:31:31 --> Total execution time: 0.0167
DEBUG - 2022-05-11 04:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:31:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:31:39 --> Total execution time: 0.0034
DEBUG - 2022-05-11 04:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:32:38 --> No URI present. Default controller set.
DEBUG - 2022-05-11 04:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:32:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:32:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:32:38 --> Total execution time: 0.0050
DEBUG - 2022-05-11 04:32:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:32:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:32:48 --> Total execution time: 0.0178
DEBUG - 2022-05-11 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:32:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:32:52 --> Total execution time: 0.0038
DEBUG - 2022-05-11 04:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:41:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:41:54 --> Total execution time: 0.0676
DEBUG - 2022-05-11 04:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:41:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:41:56 --> Total execution time: 0.0106
DEBUG - 2022-05-11 04:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:45:14 --> Total execution time: 0.0454
DEBUG - 2022-05-11 04:45:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:45:16 --> Total execution time: 0.0043
DEBUG - 2022-05-11 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:51:13 --> Total execution time: 0.0428
DEBUG - 2022-05-11 04:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 04:51:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-11 04:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:15 --> Total execution time: 0.0057
DEBUG - 2022-05-11 04:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:16 --> Total execution time: 0.0034
DEBUG - 2022-05-11 04:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:51:20 --> Total execution time: 0.0258
DEBUG - 2022-05-11 04:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:51:22 --> Total execution time: 0.0108
DEBUG - 2022-05-11 04:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:24 --> Total execution time: 0.0038
DEBUG - 2022-05-11 04:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:51:26 --> Total execution time: 0.0013
DEBUG - 2022-05-11 04:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 04:51:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-11 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:27 --> Total execution time: 0.0027
DEBUG - 2022-05-11 04:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:51:28 --> Total execution time: 0.0066
DEBUG - 2022-05-11 04:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:51:28 --> Total execution time: 0.0300
DEBUG - 2022-05-11 04:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 04:51:30 --> Total execution time: 0.0070
DEBUG - 2022-05-11 04:51:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:33 --> Total execution time: 0.0052
DEBUG - 2022-05-11 04:51:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:34 --> Total execution time: 0.0035
DEBUG - 2022-05-11 04:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:39 --> Total execution time: 0.0031
DEBUG - 2022-05-11 04:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 04:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 04:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 04:51:39 --> Total execution time: 0.0028
DEBUG - 2022-05-11 05:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 05:15:26 --> No URI present. Default controller set.
DEBUG - 2022-05-11 05:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 05:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 05:15:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 05:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 05:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 05:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 05:15:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 05:15:26 --> Total execution time: 0.0114
DEBUG - 2022-05-11 05:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 05:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 05:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 05:15:36 --> Total execution time: 0.0061
DEBUG - 2022-05-11 05:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 05:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 05:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 05:15:38 --> Total execution time: 0.0042
DEBUG - 2022-05-11 06:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:00:00 --> Total execution time: 0.0403
DEBUG - 2022-05-11 06:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:00:01 --> Total execution time: 0.0484
DEBUG - 2022-05-11 06:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:00:02 --> Total execution time: 0.0157
DEBUG - 2022-05-11 06:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:22:44 --> Total execution time: 0.0377
DEBUG - 2022-05-11 06:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:22:45 --> Total execution time: 0.0578
DEBUG - 2022-05-11 06:22:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:22:50 --> Total execution time: 0.0040
DEBUG - 2022-05-11 06:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:23:47 --> Total execution time: 0.0049
DEBUG - 2022-05-11 06:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:26:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 06:26:20 --> Total execution time: 0.0510
DEBUG - 2022-05-11 06:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:27:04 --> Total execution time: 0.0048
DEBUG - 2022-05-11 06:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:27:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 06:27:05 --> Total execution time: 0.0020
DEBUG - 2022-05-11 06:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-11 06:27:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-11 06:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:27:07 --> Total execution time: 0.0023
DEBUG - 2022-05-11 06:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:27:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 06:27:07 --> Total execution time: 0.0080
DEBUG - 2022-05-11 06:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:27:09 --> Total execution time: 0.0057
DEBUG - 2022-05-11 06:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:27:11 --> Total execution time: 0.0031
DEBUG - 2022-05-11 06:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:27:12 --> Total execution time: 0.0029
DEBUG - 2022-05-11 06:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:31:23 --> Total execution time: 0.0588
DEBUG - 2022-05-11 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:31:41 --> Total execution time: 0.0048
DEBUG - 2022-05-11 06:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:31:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 06:31:44 --> Total execution time: 0.0274
DEBUG - 2022-05-11 06:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:31:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 06:31:46 --> Total execution time: 0.0138
DEBUG - 2022-05-11 06:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 06:46:13 --> Total execution time: 0.0777
DEBUG - 2022-05-11 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 06:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 06:46:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 06:46:16 --> Total execution time: 0.0141
DEBUG - 2022-05-11 07:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 07:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 07:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 07:19:51 --> Total execution time: 0.0448
DEBUG - 2022-05-11 07:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 07:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 07:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 07:19:53 --> Total execution time: 0.0051
DEBUG - 2022-05-11 07:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 07:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 07:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 07:20:10 --> Total execution time: 0.0052
DEBUG - 2022-05-11 07:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 07:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 07:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 07:20:22 --> Total execution time: 0.0048
DEBUG - 2022-05-11 07:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 07:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 07:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 07:27:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 07:27:04 --> Total execution time: 0.0498
DEBUG - 2022-05-11 07:27:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 07:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 07:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 07:27:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 07:27:40 --> Total execution time: 0.0038
DEBUG - 2022-05-11 07:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-11 07:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-11 07:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-11 07:27:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-11 07:27:46 --> Total execution time: 0.0065
