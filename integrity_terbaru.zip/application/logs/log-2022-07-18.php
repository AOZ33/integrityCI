<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-18 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:14:48 --> No URI present. Default controller set.
DEBUG - 2022-07-18 04:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 04:14:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 04:14:48 --> Total execution time: 0.1646
DEBUG - 2022-07-18 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:03 --> No URI present. Default controller set.
DEBUG - 2022-07-18 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 04:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 04:15:03 --> Total execution time: 0.1381
DEBUG - 2022-07-18 04:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 04:15:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 04:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 04:15:24 --> Total execution time: 0.1539
DEBUG - 2022-07-18 04:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 04:15:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 04:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 04:15:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 04:15:28 --> Total execution time: 0.1014
DEBUG - 2022-07-18 04:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 04:15:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 04:15:29 --> Total execution time: 0.0859
DEBUG - 2022-07-18 04:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 04:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 04:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 04:15:30 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-18 04:15:30 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-18 04:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 04:15:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 04:15:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 04:15:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 04:15:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-18 05:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:24 --> Total execution time: 0.1006
DEBUG - 2022-07-18 05:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:41:24 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-18 05:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:41:24 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-18 05:41:24 --> UTF-8 Support Enabled
ERROR - 2022-07-18 05:41:24 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-18 05:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:41:24 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-18 05:41:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:41:24 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 05:41:24 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-18 05:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:28 --> Total execution time: 0.0937
DEBUG - 2022-07-18 05:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:32 --> Total execution time: 0.0972
DEBUG - 2022-07-18 05:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:34 --> Total execution time: 0.1455
DEBUG - 2022-07-18 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:41:35 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 05:41:35 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-18 05:41:35 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 05:41:35 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 05:41:35 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 05:41:35 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-18 05:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:36 --> Total execution time: 0.1057
DEBUG - 2022-07-18 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:43 --> Total execution time: 0.1419
DEBUG - 2022-07-18 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:41:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:41:47 --> Total execution time: 0.1021
DEBUG - 2022-07-18 05:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:42:32 --> Total execution time: 0.1766
DEBUG - 2022-07-18 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:42:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:42:34 --> Total execution time: 0.0993
DEBUG - 2022-07-18 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:42:34 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-18 05:42:34 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-18 05:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:42:34 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-18 05:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:42:34 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-18 05:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-18 05:42:34 --> 404 Page Not Found: Auth/js
ERROR - 2022-07-18 05:42:34 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-18 05:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:43:30 --> Total execution time: 0.0954
DEBUG - 2022-07-18 05:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:43:30 --> Total execution time: 0.1000
DEBUG - 2022-07-18 05:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:43:31 --> Total execution time: 0.0881
DEBUG - 2022-07-18 05:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:43:32 --> Total execution time: 0.1392
DEBUG - 2022-07-18 05:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 05:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:41 --> Total execution time: 0.1227
DEBUG - 2022-07-18 05:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:45 --> Total execution time: 0.1097
DEBUG - 2022-07-18 05:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 05:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 05:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 05:43:47 --> Total execution time: 0.1368
DEBUG - 2022-07-18 06:58:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 06:58:04 --> No URI present. Default controller set.
DEBUG - 2022-07-18 06:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 06:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 06:58:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 06:58:04 --> Total execution time: 0.1114
DEBUG - 2022-07-18 07:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-07-18 07:10:08 --> Severity: error --> Exception: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 C:\xampp\htdocs\NESNUMOTO\integrity\system\database\drivers\mysqli\mysqli_driver.php 307
DEBUG - 2022-07-18 07:10:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:28 --> No URI present. Default controller set.
DEBUG - 2022-07-18 07:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:10:28 --> Total execution time: 0.1058
DEBUG - 2022-07-18 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:36 --> Total execution time: 0.1059
DEBUG - 2022-07-18 07:10:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:39 --> Total execution time: 0.0975
DEBUG - 2022-07-18 07:10:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:10:40 --> Total execution time: 0.0934
DEBUG - 2022-07-18 07:10:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:41 --> Total execution time: 0.0986
DEBUG - 2022-07-18 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:10:43 --> Total execution time: 0.2567
DEBUG - 2022-07-18 07:10:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:10:44 --> Total execution time: 0.1938
DEBUG - 2022-07-18 07:10:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:47 --> Total execution time: 0.1702
DEBUG - 2022-07-18 07:10:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:10:48 --> Total execution time: 0.1486
DEBUG - 2022-07-18 07:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:33:50 --> No URI present. Default controller set.
DEBUG - 2022-07-18 07:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:33:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:33:50 --> Total execution time: 0.1428
DEBUG - 2022-07-18 07:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:33:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 07:33:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 07:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 07:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 07:33:56 --> Total execution time: 0.1363
DEBUG - 2022-07-18 11:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-18 11:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-18 11:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-18 11:24:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-18 11:24:44 --> Total execution time: 0.2044
