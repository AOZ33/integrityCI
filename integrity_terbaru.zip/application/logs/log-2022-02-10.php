<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-10 09:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 09:40:44 --> No URI present. Default controller set.
DEBUG - 2022-02-10 09:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 09:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 09:40:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 09:40:44 --> Total execution time: 0.0307
DEBUG - 2022-02-10 09:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 09:40:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 09:40:44 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-10 09:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 09:40:44 --> No URI present. Default controller set.
DEBUG - 2022-02-10 09:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 09:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 09:40:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 09:40:44 --> Total execution time: 0.0030
DEBUG - 2022-02-10 10:09:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:09:23 --> No URI present. Default controller set.
DEBUG - 2022-02-10 10:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:09:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:09:23 --> Total execution time: 0.0298
DEBUG - 2022-02-10 10:09:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:09:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 10:09:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-10 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:10:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:10:05 --> Total execution time: 0.0061
DEBUG - 2022-02-10 10:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:10:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 10:10:39 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 176221480 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 10:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:10:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:10:57 --> Total execution time: 0.0055
DEBUG - 2022-02-10 10:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:11:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:11:20 --> Total execution time: 0.0034
DEBUG - 2022-02-10 10:11:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:11:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 10:11:43 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 176221480 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 10:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:11:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:11:45 --> Total execution time: 0.0037
DEBUG - 2022-02-10 10:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:23:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:23:41 --> Total execution time: 0.0061
DEBUG - 2022-02-10 10:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:40:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:40:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:40:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:40:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:40:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:40:33 --> Total execution time: 0.0059
DEBUG - 2022-02-10 10:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:48:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:48:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:48:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:48:24 --> Total execution time: 0.0065
DEBUG - 2022-02-10 10:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:51:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 10:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 10:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 10:51:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 10:51:24 --> Total execution time: 0.0053
DEBUG - 2022-02-10 11:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:03:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:03:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:03:14 --> Total execution time: 0.0057
DEBUG - 2022-02-10 11:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:11:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:11:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:11:15 --> Total execution time: 0.0054
DEBUG - 2022-02-10 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:22:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:22:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:22:26 --> Total execution time: 0.0059
DEBUG - 2022-02-10 11:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:34:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:34:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:34:56 --> Total execution time: 0.0058
DEBUG - 2022-02-10 11:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:55:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:55:31 --> Total execution time: 0.0346
DEBUG - 2022-02-10 11:57:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 11:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 11:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 11:57:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 11:57:27 --> Total execution time: 0.0057
DEBUG - 2022-02-10 12:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 12:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 12:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 12:03:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 12:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 12:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 12:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 12:03:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 12:03:29 --> Total execution time: 0.0060
DEBUG - 2022-02-10 12:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 12:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 12:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 12:30:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 12:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 12:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 12:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 12:30:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 12:30:32 --> Total execution time: 0.0063
DEBUG - 2022-02-10 12:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 12:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 12:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 12:40:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 12:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 12:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 12:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 12:41:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 12:41:00 --> Total execution time: 0.0059
DEBUG - 2022-02-10 13:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 13:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 13:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 13:30:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 13:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 13:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 13:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 13:30:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 13:30:21 --> Total execution time: 0.0066
DEBUG - 2022-02-10 13:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 13:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 13:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 13:39:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 13:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 13:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 13:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 13:39:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 13:39:21 --> Total execution time: 0.0065
DEBUG - 2022-02-10 13:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 13:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 13:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 13:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 13:53:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 13:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 13:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 13:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 13:53:25 --> Total execution time: 0.0053
DEBUG - 2022-02-10 14:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:12:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:12:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:12:59 --> Total execution time: 0.0057
DEBUG - 2022-02-10 14:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:14:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:14:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-10 14:14:17 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-10 14:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:15:27 --> No URI present. Default controller set.
DEBUG - 2022-02-10 14:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:15:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:15:27 --> Total execution time: 0.0049
DEBUG - 2022-02-10 14:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:15:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 14:15:27 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-10 14:16:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:16:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:16:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:16:15 --> Total execution time: 0.0058
DEBUG - 2022-02-10 14:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:16:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:16:29 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178044200 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:16:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 14:16:31 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-02-10 14:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:16:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:16:35 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178044200 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 14:16:56 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-02-10 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:17:43 --> No URI present. Default controller set.
DEBUG - 2022-02-10 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:17:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:17:43 --> Total execution time: 0.0041
DEBUG - 2022-02-10 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:17:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:17:43 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178044200 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:17:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 14:17:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-10 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:20:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:20:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:20:32 --> Total execution time: 0.0047
DEBUG - 2022-02-10 14:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:28:33 --> Total execution time: 0.0054
DEBUG - 2022-02-10 14:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:33:16 --> No URI present. Default controller set.
DEBUG - 2022-02-10 14:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:33:16 --> Total execution time: 0.0305
DEBUG - 2022-02-10 14:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 14:33:16 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-10 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:33:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:33:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:33:44 --> Total execution time: 0.0050
DEBUG - 2022-02-10 14:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:33:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:33:52 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178287072 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:36:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:36:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:36:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:36:32 --> Total execution time: 0.0056
DEBUG - 2022-02-10 14:39:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:39:06 --> No URI present. Default controller set.
DEBUG - 2022-02-10 14:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:39:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:39:06 --> Total execution time: 0.0308
DEBUG - 2022-02-10 14:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:39:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 14:39:07 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-10 14:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:39:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:39:42 --> Total execution time: 0.0054
DEBUG - 2022-02-10 14:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:39:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:39:50 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178408832 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:39:53 --> Total execution time: 0.0039
DEBUG - 2022-02-10 14:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:40:46 --> No URI present. Default controller set.
DEBUG - 2022-02-10 14:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:40:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:40:46 --> Total execution time: 0.0040
DEBUG - 2022-02-10 14:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:40:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-10 14:40:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-10 14:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:40:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:40:55 --> Total execution time: 0.0053
DEBUG - 2022-02-10 14:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:40:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:40:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:40:57 --> Total execution time: 0.0038
DEBUG - 2022-02-10 14:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:41:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:41:11 --> Total execution time: 0.0036
DEBUG - 2022-02-10 14:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:41:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:41:24 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178530144 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:42:08 --> Total execution time: 0.0047
DEBUG - 2022-02-10 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:44:16 --> Total execution time: 0.0064
DEBUG - 2022-02-10 14:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:47:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:47:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:47:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:47:08 --> Total execution time: 0.0050
DEBUG - 2022-02-10 14:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:47:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:47:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178773392 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:47:25 --> Total execution time: 0.0039
DEBUG - 2022-02-10 14:47:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:47:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:47:36 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178773392 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:47:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:47:43 --> Total execution time: 0.0039
DEBUG - 2022-02-10 14:48:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:48:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:48:11 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178773392 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:48:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:48:13 --> Total execution time: 0.0041
DEBUG - 2022-02-10 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:49:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-10 14:49:24 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 178773392 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-10 14:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:49:59 --> Total execution time: 0.0038
DEBUG - 2022-02-10 14:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:57:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 14:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 14:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 14:57:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 14:57:32 --> Total execution time: 0.0058
DEBUG - 2022-02-10 15:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:00:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:00:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:00:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:00:22 --> Total execution time: 0.0057
DEBUG - 2022-02-10 15:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:39:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:39:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:39:54 --> Total execution time: 0.0067
DEBUG - 2022-02-10 15:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:44:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:44:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:44:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:44:25 --> Total execution time: 0.0061
DEBUG - 2022-02-10 15:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:52:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:52:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:52:28 --> Total execution time: 0.0056
DEBUG - 2022-02-10 15:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 15:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 15:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 15:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 15:57:51 --> Total execution time: 0.0058
DEBUG - 2022-02-10 16:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:11:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:11:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:11:51 --> Total execution time: 0.0064
DEBUG - 2022-02-10 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:34:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:34:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:34:19 --> Total execution time: 0.0053
DEBUG - 2022-02-10 16:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:37:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:37:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:37:13 --> Total execution time: 0.0034
DEBUG - 2022-02-10 16:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:43:53 --> Total execution time: 0.0057
DEBUG - 2022-02-10 16:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:49:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 16:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 16:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 16:49:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 16:49:29 --> Total execution time: 0.0063
DEBUG - 2022-02-10 17:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 17:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 17:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 17:01:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 17:01:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 17:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 17:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 17:01:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 17:01:17 --> Total execution time: 0.0058
DEBUG - 2022-02-10 17:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 17:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 17:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 17:04:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 17:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-10 17:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-10 17:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-10 17:04:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-10 17:04:40 --> Total execution time: 0.0054
