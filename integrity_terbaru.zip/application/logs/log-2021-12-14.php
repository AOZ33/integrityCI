<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-14 03:08:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:08:41 --> No URI present. Default controller set.
DEBUG - 2021-12-14 03:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:08:41 --> Total execution time: 0.0706
DEBUG - 2021-12-14 03:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:08:42 --> Total execution time: 0.0397
DEBUG - 2021-12-14 03:08:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:08:45 --> Total execution time: 0.0477
DEBUG - 2021-12-14 03:08:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:08:47 --> Total execution time: 0.0410
DEBUG - 2021-12-14 03:09:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:09:05 --> Total execution time: 0.0452
DEBUG - 2021-12-14 03:10:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:10:24 --> Total execution time: 0.0400
DEBUG - 2021-12-14 03:11:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:11:58 --> Total execution time: 0.0448
DEBUG - 2021-12-14 03:17:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:17:54 --> Total execution time: 0.0464
DEBUG - 2021-12-14 03:18:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:18:42 --> Total execution time: 0.4356
DEBUG - 2021-12-14 03:19:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:19:04 --> Total execution time: 0.0445
DEBUG - 2021-12-14 03:19:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:19:35 --> Total execution time: 0.0430
DEBUG - 2021-12-14 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:19:37 --> Total execution time: 0.0386
DEBUG - 2021-12-14 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:19:37 --> Total execution time: 0.0356
DEBUG - 2021-12-14 03:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:19:37 --> Total execution time: 0.0474
DEBUG - 2021-12-14 03:19:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:19:41 --> No URI present. Default controller set.
DEBUG - 2021-12-14 03:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:19:41 --> Total execution time: 0.0701
DEBUG - 2021-12-14 03:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:19:43 --> Total execution time: 0.0614
DEBUG - 2021-12-14 03:20:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:20:02 --> Total execution time: 0.0549
DEBUG - 2021-12-14 03:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:20:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 03:20:08 --> 404 Page Not Found: Wedding/index
DEBUG - 2021-12-14 03:20:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:20:09 --> Total execution time: 0.0503
DEBUG - 2021-12-14 03:20:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:20:10 --> Total execution time: 0.0502
DEBUG - 2021-12-14 03:20:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:20:13 --> Total execution time: 0.0941
DEBUG - 2021-12-14 03:20:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:20:14 --> Total execution time: 0.0389
DEBUG - 2021-12-14 03:21:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:21:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:21:22 --> Total execution time: 0.0261
DEBUG - 2021-12-14 03:21:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:21:23 --> Total execution time: 0.0319
DEBUG - 2021-12-14 03:21:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:21:30 --> Total execution time: 0.0415
DEBUG - 2021-12-14 03:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:21:31 --> Total execution time: 0.0409
DEBUG - 2021-12-14 03:21:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:21:46 --> Total execution time: 0.0474
DEBUG - 2021-12-14 03:22:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:22:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:22:23 --> Total execution time: 0.0527
DEBUG - 2021-12-14 03:23:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:23:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:23:30 --> Total execution time: 0.0416
DEBUG - 2021-12-14 03:24:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:24:30 --> Total execution time: 0.0410
DEBUG - 2021-12-14 03:24:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:24:47 --> Total execution time: 0.0400
DEBUG - 2021-12-14 03:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:25:13 --> Total execution time: 0.0408
DEBUG - 2021-12-14 03:25:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:25:25 --> Total execution time: 0.0519
DEBUG - 2021-12-14 03:25:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:25:41 --> Total execution time: 0.0470
DEBUG - 2021-12-14 03:26:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:26:03 --> Total execution time: 0.0474
DEBUG - 2021-12-14 03:26:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:26:31 --> Total execution time: 0.0479
DEBUG - 2021-12-14 03:26:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:26:42 --> Total execution time: 0.0484
DEBUG - 2021-12-14 03:31:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:31:53 --> Total execution time: 0.0447
DEBUG - 2021-12-14 03:32:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:32:04 --> Total execution time: 0.0482
DEBUG - 2021-12-14 03:32:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:32:12 --> Total execution time: 0.0421
DEBUG - 2021-12-14 03:32:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:32:14 --> Total execution time: 0.0481
DEBUG - 2021-12-14 03:33:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:33:19 --> Total execution time: 0.0531
DEBUG - 2021-12-14 03:33:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:33:28 --> Total execution time: 0.0485
DEBUG - 2021-12-14 03:34:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:34:20 --> Total execution time: 0.0305
DEBUG - 2021-12-14 03:34:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:34:38 --> Total execution time: 0.0399
DEBUG - 2021-12-14 03:34:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:34:53 --> Total execution time: 0.0392
DEBUG - 2021-12-14 03:49:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:49:21 --> Total execution time: 0.0316
DEBUG - 2021-12-14 03:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:49:36 --> Total execution time: 0.0432
DEBUG - 2021-12-14 03:49:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:49:47 --> Total execution time: 0.0478
DEBUG - 2021-12-14 03:50:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:50:19 --> Total execution time: 0.0462
DEBUG - 2021-12-14 03:51:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:51:28 --> Total execution time: 0.0405
DEBUG - 2021-12-14 03:51:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:51:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:51:34 --> Total execution time: 0.0517
DEBUG - 2021-12-14 03:51:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:51:40 --> Total execution time: 0.0508
DEBUG - 2021-12-14 03:52:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:52:08 --> Total execution time: 0.0448
DEBUG - 2021-12-14 03:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:53:18 --> Total execution time: 0.0522
DEBUG - 2021-12-14 03:54:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:54:00 --> Total execution time: 0.0279
DEBUG - 2021-12-14 03:54:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:54:00 --> Total execution time: 0.0481
DEBUG - 2021-12-14 03:54:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:54:00 --> Total execution time: 0.0282
DEBUG - 2021-12-14 03:54:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:54:13 --> Total execution time: 0.0442
DEBUG - 2021-12-14 03:54:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:54:39 --> Total execution time: 0.0410
DEBUG - 2021-12-14 03:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:54:57 --> Total execution time: 0.0518
DEBUG - 2021-12-14 03:55:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:55:40 --> Total execution time: 0.0288
DEBUG - 2021-12-14 03:59:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 03:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 03:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 03:59:18 --> Total execution time: 0.0534
DEBUG - 2021-12-14 04:01:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:01:48 --> Total execution time: 0.0440
DEBUG - 2021-12-14 04:09:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:09:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:09:35 --> Total execution time: 0.0279
DEBUG - 2021-12-14 04:10:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:10:06 --> Total execution time: 0.0449
DEBUG - 2021-12-14 04:11:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:11:28 --> Total execution time: 0.0514
DEBUG - 2021-12-14 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:12:22 --> Total execution time: 0.0504
DEBUG - 2021-12-14 04:12:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:12:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 04:12:29 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-14 04:12:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:12:30 --> Total execution time: 0.0534
DEBUG - 2021-12-14 04:14:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:14:44 --> Total execution time: 0.0505
DEBUG - 2021-12-14 04:16:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:16:41 --> Total execution time: 0.0434
DEBUG - 2021-12-14 04:16:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:16:45 --> Total execution time: 0.0494
DEBUG - 2021-12-14 04:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:22:15 --> Total execution time: 0.0412
DEBUG - 2021-12-14 04:24:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:24:16 --> Total execution time: 0.0524
DEBUG - 2021-12-14 04:27:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:27:10 --> Total execution time: 0.0493
DEBUG - 2021-12-14 04:27:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:27:12 --> Total execution time: 0.0404
DEBUG - 2021-12-14 04:27:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:27:17 --> Total execution time: 0.0459
DEBUG - 2021-12-14 04:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:39:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 04:39:35 --> 404 Page Not Found: Wedding/index
DEBUG - 2021-12-14 04:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:39:37 --> Total execution time: 0.0309
DEBUG - 2021-12-14 04:41:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:41:04 --> Total execution time: 0.0463
DEBUG - 2021-12-14 04:41:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:41:35 --> Total execution time: 0.0410
DEBUG - 2021-12-14 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:48:53 --> Total execution time: 0.0453
DEBUG - 2021-12-14 04:49:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:49:00 --> Total execution time: 0.0461
DEBUG - 2021-12-14 04:51:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:51:41 --> Total execution time: 0.0442
DEBUG - 2021-12-14 04:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:51:43 --> Total execution time: 0.0282
DEBUG - 2021-12-14 04:52:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 04:52:18 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-14 04:52:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 04:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 04:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 04:52:20 --> Total execution time: 0.0422
DEBUG - 2021-12-14 05:39:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 05:39:44 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-14 05:39:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:39:45 --> Total execution time: 0.0532
DEBUG - 2021-12-14 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:43:49 --> Total execution time: 0.0472
DEBUG - 2021-12-14 05:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:46:05 --> Total execution time: 0.0519
DEBUG - 2021-12-14 05:46:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:46:25 --> Total execution time: 0.0400
DEBUG - 2021-12-14 05:47:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:47:06 --> Total execution time: 0.0457
DEBUG - 2021-12-14 05:48:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:48:56 --> Total execution time: 0.0288
DEBUG - 2021-12-14 05:49:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:49:13 --> Total execution time: 0.0395
DEBUG - 2021-12-14 05:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:52:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:52:14 --> Total execution time: 0.0495
DEBUG - 2021-12-14 05:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:56:52 --> Total execution time: 0.0448
DEBUG - 2021-12-14 05:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:57:48 --> Total execution time: 0.0495
DEBUG - 2021-12-14 05:58:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 05:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 05:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 05:58:39 --> Total execution time: 0.0437
DEBUG - 2021-12-14 06:01:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:01:15 --> Total execution time: 0.0488
DEBUG - 2021-12-14 06:05:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:05:03 --> Total execution time: 0.0508
DEBUG - 2021-12-14 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:05:25 --> Total execution time: 0.0276
DEBUG - 2021-12-14 06:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:05:26 --> Total execution time: 0.0397
DEBUG - 2021-12-14 06:05:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:05:29 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-14 06:05:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:05:32 --> Total execution time: 0.0418
DEBUG - 2021-12-14 06:07:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:07:44 --> Total execution time: 0.0515
DEBUG - 2021-12-14 06:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:07:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:07:45 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-14 06:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:07:46 --> Total execution time: 0.0294
DEBUG - 2021-12-14 06:07:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:07:47 --> Total execution time: 0.0449
DEBUG - 2021-12-14 06:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:07:48 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-14 06:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:07:49 --> Total execution time: 0.0439
DEBUG - 2021-12-14 06:08:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:08:32 --> Total execution time: 0.0460
DEBUG - 2021-12-14 06:08:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:08:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:08:33 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-14 06:10:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-14 06:10:59 --> Severity: error --> Exception: Unable to locate the model you have specified: Prewedding_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-14 06:11:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:11:14 --> Total execution time: 0.0266
DEBUG - 2021-12-14 06:11:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:11:17 --> Total execution time: 0.0432
DEBUG - 2021-12-14 06:11:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:11:17 --> 404 Page Not Found: Wedding/index
DEBUG - 2021-12-14 06:13:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:13:24 --> Total execution time: 0.0427
DEBUG - 2021-12-14 06:13:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:13:25 --> Total execution time: 0.0260
DEBUG - 2021-12-14 06:27:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:27:37 --> Total execution time: 0.0453
DEBUG - 2021-12-14 06:27:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:27:39 --> Total execution time: 0.0358
DEBUG - 2021-12-14 06:27:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:27:40 --> Total execution time: 0.0259
DEBUG - 2021-12-14 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:27:41 --> Total execution time: 0.0432
DEBUG - 2021-12-14 06:27:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:27:41 --> Total execution time: 0.0370
DEBUG - 2021-12-14 06:27:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:27:42 --> Total execution time: 0.0482
DEBUG - 2021-12-14 06:32:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:32:44 --> Total execution time: 0.0289
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:32:45 --> Total execution time: 0.0508
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Css/bootstrap.min.css
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Css/bootstrap-datetimepicker.min.css
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Css/font-awesome.min.css
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Js/moment.js
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Css/bootstrap-datetimepicker.min.css
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Js/bootstrap-datetimepicker.min.js
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Css/font-awesome.min.css
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Js/moment.js
DEBUG - 2021-12-14 06:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:32:45 --> 404 Page Not Found: Js/bootstrap-datetimepicker.min.js
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:33:42 --> Total execution time: 0.0462
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/css
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/css
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/js
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/js
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/js
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/css
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/js
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:33:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:34:07 --> Total execution time: 0.0432
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/js
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:34:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:34:08 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:34:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:34:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:34:08 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-14 06:40:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:40:15 --> Total execution time: 0.0446
DEBUG - 2021-12-14 06:40:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:40:16 --> 404 Page Not Found: Assets/fonts
DEBUG - 2021-12-14 06:40:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:40:16 --> 404 Page Not Found: Assets/fonts
DEBUG - 2021-12-14 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:40:29 --> Total execution time: 0.0377
DEBUG - 2021-12-14 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:40:29 --> 404 Page Not Found: Assets/fonts
DEBUG - 2021-12-14 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-14 06:40:29 --> 404 Page Not Found: Assets/fonts
DEBUG - 2021-12-14 06:46:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:46:54 --> Total execution time: 0.0293
DEBUG - 2021-12-14 06:47:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:02 --> Total execution time: 0.0458
DEBUG - 2021-12-14 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:03 --> Total execution time: 0.0347
DEBUG - 2021-12-14 06:47:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:04 --> Total execution time: 0.0250
DEBUG - 2021-12-14 06:47:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:05 --> Total execution time: 0.0253
DEBUG - 2021-12-14 06:47:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:05 --> Total execution time: 0.0287
DEBUG - 2021-12-14 06:47:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:06 --> Total execution time: 0.0427
DEBUG - 2021-12-14 06:47:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:13 --> Total execution time: 0.0533
DEBUG - 2021-12-14 06:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:21 --> Total execution time: 0.0420
DEBUG - 2021-12-14 06:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:22 --> Total execution time: 0.0469
DEBUG - 2021-12-14 06:47:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:24 --> Total execution time: 0.0283
DEBUG - 2021-12-14 06:47:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:24 --> Total execution time: 0.0278
DEBUG - 2021-12-14 06:47:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 06:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 06:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 06:47:35 --> Total execution time: 0.0381
DEBUG - 2021-12-14 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:16:40 --> Total execution time: 0.0531
DEBUG - 2021-12-14 07:24:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:24:08 --> Total execution time: 0.0450
DEBUG - 2021-12-14 07:26:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:26:55 --> Total execution time: 0.0284
DEBUG - 2021-12-14 07:27:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:27:11 --> Total execution time: 0.0454
DEBUG - 2021-12-14 07:27:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:27:22 --> Total execution time: 0.0349
DEBUG - 2021-12-14 07:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:27:39 --> Total execution time: 0.0466
DEBUG - 2021-12-14 07:28:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:28:01 --> Total execution time: 0.0459
DEBUG - 2021-12-14 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:44:39 --> Total execution time: 0.0408
DEBUG - 2021-12-14 07:44:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:44:39 --> Total execution time: 0.0365
DEBUG - 2021-12-14 07:45:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:45:22 --> Total execution time: 0.0413
DEBUG - 2021-12-14 07:52:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:44 --> Total execution time: 0.0483
DEBUG - 2021-12-14 07:52:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:45 --> Total execution time: 0.0271
DEBUG - 2021-12-14 07:52:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:46 --> Total execution time: 0.0512
DEBUG - 2021-12-14 07:52:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:47 --> Total execution time: 0.0325
DEBUG - 2021-12-14 07:52:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:47 --> Total execution time: 0.0311
DEBUG - 2021-12-14 07:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:48 --> Total execution time: 0.0384
DEBUG - 2021-12-14 07:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:48 --> Total execution time: 0.0307
DEBUG - 2021-12-14 07:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:49 --> Total execution time: 0.0311
DEBUG - 2021-12-14 07:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:52:58 --> Total execution time: 0.0464
DEBUG - 2021-12-14 07:53:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:53:00 --> Total execution time: 0.0503
DEBUG - 2021-12-14 07:53:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:53:00 --> Total execution time: 0.0355
DEBUG - 2021-12-14 07:53:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:53:01 --> Total execution time: 0.0449
DEBUG - 2021-12-14 07:53:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:53:01 --> Total execution time: 0.0375
DEBUG - 2021-12-14 07:53:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:53:02 --> Total execution time: 0.0427
DEBUG - 2021-12-14 07:53:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 07:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 07:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 07:53:03 --> Total execution time: 0.0496
DEBUG - 2021-12-14 08:39:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 08:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 08:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 08:39:03 --> Total execution time: 0.0397
DEBUG - 2021-12-14 08:39:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 08:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 08:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 08:39:04 --> Total execution time: 0.0513
DEBUG - 2021-12-14 09:06:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:06:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:06:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:06:44 --> Total execution time: 0.0410
DEBUG - 2021-12-14 09:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:07:12 --> Total execution time: 0.0424
DEBUG - 2021-12-14 09:13:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:13:56 --> Total execution time: 0.0524
DEBUG - 2021-12-14 09:14:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:14:38 --> Total execution time: 0.0520
DEBUG - 2021-12-14 09:15:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:15:07 --> Total execution time: 0.0423
DEBUG - 2021-12-14 09:15:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:15:20 --> Total execution time: 0.0525
DEBUG - 2021-12-14 09:15:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:15:28 --> Total execution time: 0.0524
DEBUG - 2021-12-14 09:15:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:15:45 --> Total execution time: 0.0533
DEBUG - 2021-12-14 09:16:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:16:41 --> Total execution time: 0.0469
DEBUG - 2021-12-14 09:16:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:16:52 --> Total execution time: 0.0480
DEBUG - 2021-12-14 09:16:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:16:57 --> Total execution time: 0.0451
DEBUG - 2021-12-14 09:17:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:17:51 --> Total execution time: 0.0433
DEBUG - 2021-12-14 09:20:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:20:08 --> Total execution time: 0.0487
DEBUG - 2021-12-14 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:20:20 --> Total execution time: 0.0290
DEBUG - 2021-12-14 09:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:20:42 --> Total execution time: 0.0301
DEBUG - 2021-12-14 09:21:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:21:05 --> Total execution time: 0.0290
DEBUG - 2021-12-14 09:21:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:21:20 --> Total execution time: 0.0507
DEBUG - 2021-12-14 09:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:21:31 --> Total execution time: 0.0425
DEBUG - 2021-12-14 09:23:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:23:02 --> Total execution time: 0.0499
DEBUG - 2021-12-14 09:23:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:23:24 --> Total execution time: 0.0470
DEBUG - 2021-12-14 09:23:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:23:42 --> Total execution time: 0.0530
DEBUG - 2021-12-14 09:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:24:00 --> Total execution time: 0.0303
DEBUG - 2021-12-14 09:24:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:24:31 --> Total execution time: 0.0385
DEBUG - 2021-12-14 09:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:24:43 --> Total execution time: 0.0399
DEBUG - 2021-12-14 09:24:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:24:58 --> Total execution time: 0.0399
DEBUG - 2021-12-14 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:25:09 --> Total execution time: 0.0424
DEBUG - 2021-12-14 09:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:25:19 --> Total execution time: 0.0523
DEBUG - 2021-12-14 09:27:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:27:00 --> Total execution time: 0.0325
DEBUG - 2021-12-14 09:27:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:27:21 --> Total execution time: 0.0399
DEBUG - 2021-12-14 09:27:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:27:58 --> Total execution time: 0.0461
DEBUG - 2021-12-14 09:28:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:28:13 --> Total execution time: 0.0534
DEBUG - 2021-12-14 09:28:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:28:47 --> Total execution time: 0.0455
DEBUG - 2021-12-14 09:29:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:29:51 --> Total execution time: 0.0484
DEBUG - 2021-12-14 09:30:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:30:10 --> Total execution time: 0.0302
DEBUG - 2021-12-14 09:30:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:30:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:30:22 --> Total execution time: 0.0507
DEBUG - 2021-12-14 09:30:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:30:32 --> Total execution time: 0.0289
DEBUG - 2021-12-14 09:30:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:30:38 --> Total execution time: 0.0483
DEBUG - 2021-12-14 09:37:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:37:31 --> Total execution time: 0.0521
DEBUG - 2021-12-14 09:41:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:41:05 --> Total execution time: 0.0444
DEBUG - 2021-12-14 09:48:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:48:14 --> Total execution time: 0.0522
DEBUG - 2021-12-14 09:48:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:48:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-14 09:48:16 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 88
DEBUG - 2021-12-14 09:48:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:48:19 --> Total execution time: 0.0504
DEBUG - 2021-12-14 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-14 09:48:27 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 88
DEBUG - 2021-12-14 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:48:30 --> Total execution time: 0.0439
DEBUG - 2021-12-14 09:50:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:50:08 --> Total execution time: 0.0438
DEBUG - 2021-12-14 09:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-14 09:50:14 --> Severity: Warning --> Undefined property: Data::$Spk_model C:\xampp\htdocs\nesnu\application\controllers\data.php 107
ERROR - 2021-12-14 09:50:14 --> Severity: error --> Exception: Call to a member function spk_prewed() on null C:\xampp\htdocs\nesnu\application\controllers\data.php 107
DEBUG - 2021-12-14 09:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:53:32 --> Total execution time: 0.0496
DEBUG - 2021-12-14 09:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:53:52 --> Total execution time: 0.0490
DEBUG - 2021-12-14 09:54:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-14 09:54:00 --> Severity: Warning --> Undefined property: Prewedding::$Spk_model C:\xampp\htdocs\nesnu\application\controllers\prewedding.php 47
ERROR - 2021-12-14 09:54:00 --> Severity: error --> Exception: Call to a member function spk_prewed() on null C:\xampp\htdocs\nesnu\application\controllers\prewedding.php 47
DEBUG - 2021-12-14 09:54:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:54:29 --> Total execution time: 0.0479
DEBUG - 2021-12-14 09:54:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:54:32 --> Total execution time: 0.0292
DEBUG - 2021-12-14 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:54:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:54:39 --> Total execution time: 0.0477
DEBUG - 2021-12-14 09:54:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:54:41 --> Total execution time: 0.0406
DEBUG - 2021-12-14 09:55:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:55:16 --> Total execution time: 0.0457
DEBUG - 2021-12-14 09:55:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:55:17 --> Total execution time: 0.0402
DEBUG - 2021-12-14 09:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:55:18 --> Total execution time: 0.0527
DEBUG - 2021-12-14 09:57:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:57:40 --> Total execution time: 0.0423
DEBUG - 2021-12-14 09:57:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:57:50 --> Total execution time: 0.0446
DEBUG - 2021-12-14 09:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 09:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 09:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 09:59:01 --> Total execution time: 0.0524
DEBUG - 2021-12-14 10:00:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 10:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 10:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 10:00:10 --> Total execution time: 0.0560
DEBUG - 2021-12-14 10:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-14 10:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-14 10:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-14 10:00:42 --> Total execution time: 0.0510
