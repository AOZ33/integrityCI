<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-23 03:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:05 --> No URI present. Default controller set.
DEBUG - 2022-05-23 03:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 03:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 03:10:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 03:10:05 --> Total execution time: 0.0565
DEBUG - 2022-05-23 03:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:10:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-23 03:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:10:05 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-23 03:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:10:05 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-23 03:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:10:05 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-23 03:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:10:05 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-23 03:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:10:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-23 03:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 03:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 03:10:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 03:10:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 03:10:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 03:10:06 --> Total execution time: 0.0061
DEBUG - 2022-05-23 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:33 --> No URI present. Default controller set.
DEBUG - 2022-05-23 03:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 03:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 03:34:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 03:34:33 --> Total execution time: 0.0396
DEBUG - 2022-05-23 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:34:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-23 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:34:33 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-23 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:34:33 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-23 03:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:34:33 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-23 03:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:34:33 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-23 03:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 03:34:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-23 03:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 03:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 03:34:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 03:34:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 03:34:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 03:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 03:34:51 --> Total execution time: 0.0036
DEBUG - 2022-05-23 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:46 --> No URI present. Default controller set.
DEBUG - 2022-05-23 07:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:02:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 07:02:46 --> Total execution time: 0.0375
DEBUG - 2022-05-23 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 07:02:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-23 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 07:02:46 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-23 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 07:02:46 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-23 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 07:02:46 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-23 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 07:02:46 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-23 07:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 07:02:47 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-23 07:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:02:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 07:02:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:02:55 --> Total execution time: 0.0038
DEBUG - 2022-05-23 07:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:02:58 --> Total execution time: 0.0089
DEBUG - 2022-05-23 07:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:03:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 07:03:15 --> 404 Page Not Found: Personal/p_lamar_f
DEBUG - 2022-05-23 07:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:03:18 --> Total execution time: 0.0042
DEBUG - 2022-05-23 07:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:05:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 07:05:26 --> 404 Page Not Found: Personal/p_lamar_v
DEBUG - 2022-05-23 07:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:07:31 --> Total execution time: 0.0419
DEBUG - 2022-05-23 07:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:11:48 --> Total execution time: 0.0424
DEBUG - 2022-05-23 07:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:11:54 --> Total execution time: 0.0057
DEBUG - 2022-05-23 07:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:12:09 --> Total execution time: 0.0043
DEBUG - 2022-05-23 07:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:12:15 --> Total execution time: 0.0043
DEBUG - 2022-05-23 07:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:12:19 --> Total execution time: 0.0050
DEBUG - 2022-05-23 07:12:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:12:21 --> Total execution time: 0.0037
DEBUG - 2022-05-23 07:12:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:12:23 --> Total execution time: 0.0043
DEBUG - 2022-05-23 07:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:15:01 --> Total execution time: 0.0430
DEBUG - 2022-05-23 07:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:15:02 --> Total execution time: 0.0044
DEBUG - 2022-05-23 07:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:15:24 --> Total execution time: 0.0055
DEBUG - 2022-05-23 07:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:15:29 --> Total execution time: 0.0058
DEBUG - 2022-05-23 07:17:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:17:07 --> Total execution time: 0.0451
DEBUG - 2022-05-23 07:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:17:09 --> Total execution time: 0.0030
DEBUG - 2022-05-23 07:17:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:17:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:17:12 --> Total execution time: 0.0038
DEBUG - 2022-05-23 07:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:17:14 --> Total execution time: 0.0039
DEBUG - 2022-05-23 07:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:17:17 --> Total execution time: 0.0037
DEBUG - 2022-05-23 07:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 07:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 07:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 07:17:19 --> Total execution time: 0.0058
DEBUG - 2022-05-23 08:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:29 --> Total execution time: 0.0501
DEBUG - 2022-05-23 08:35:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:32 --> Total execution time: 0.0051
DEBUG - 2022-05-23 08:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:34 --> Total execution time: 0.0025
DEBUG - 2022-05-23 08:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:35 --> Total execution time: 0.0031
DEBUG - 2022-05-23 08:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:36 --> Total execution time: 0.0024
DEBUG - 2022-05-23 08:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:38 --> Total execution time: 0.0027
DEBUG - 2022-05-23 08:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:50 --> Total execution time: 0.0039
DEBUG - 2022-05-23 08:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:35:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 08:35:54 --> Total execution time: 0.0130
DEBUG - 2022-05-23 08:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:36:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 08:36:12 --> Total execution time: 0.0062
DEBUG - 2022-05-23 08:36:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:36:14 --> Total execution time: 0.0050
DEBUG - 2022-05-23 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:36:36 --> Total execution time: 0.0031
DEBUG - 2022-05-23 08:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:36:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 08:36:44 --> Total execution time: 0.0051
DEBUG - 2022-05-23 08:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:37:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 08:37:02 --> Total execution time: 0.0057
DEBUG - 2022-05-23 08:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:37:38 --> Total execution time: 0.0035
DEBUG - 2022-05-23 08:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:37:42 --> Total execution time: 0.0033
DEBUG - 2022-05-23 08:37:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:37:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:37:58 --> Total execution time: 0.0033
DEBUG - 2022-05-23 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:38:38 --> Total execution time: 0.0034
DEBUG - 2022-05-23 08:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:38:52 --> Total execution time: 0.0031
DEBUG - 2022-05-23 08:39:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:39:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 08:39:36 --> Total execution time: 0.0058
DEBUG - 2022-05-23 08:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:39:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 08:39:40 --> Total execution time: 0.0038
DEBUG - 2022-05-23 08:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:50:05 --> Total execution time: 0.0581
DEBUG - 2022-05-23 08:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:50:09 --> Total execution time: 0.0039
DEBUG - 2022-05-23 08:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:50:12 --> Total execution time: 0.0041
DEBUG - 2022-05-23 08:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:50:32 --> Total execution time: 0.0146
DEBUG - 2022-05-23 08:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:50:47 --> Total execution time: 0.0034
DEBUG - 2022-05-23 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:51:10 --> Total execution time: 0.0031
DEBUG - 2022-05-23 08:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:53:44 --> Total execution time: 0.0040
DEBUG - 2022-05-23 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:53:57 --> Total execution time: 0.0039
DEBUG - 2022-05-23 08:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:55:14 --> Total execution time: 0.0041
DEBUG - 2022-05-23 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 08:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 08:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 08:55:26 --> Total execution time: 0.0034
DEBUG - 2022-05-23 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 09:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 09:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 09:48:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 09:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 09:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 09:48:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 09:48:53 --> Total execution time: 0.0018
DEBUG - 2022-05-23 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 09:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 09:48:53 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-23 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 09:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 09:48:53 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-23 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 09:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 09:48:53 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-23 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 09:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 09:48:53 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-23 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 09:48:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 09:48:53 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-23 13:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 13:35:50 --> No URI present. Default controller set.
DEBUG - 2022-05-23 13:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 13:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 13:35:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 13:35:50 --> Total execution time: 0.0427
DEBUG - 2022-05-23 13:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 13:35:51 --> No URI present. Default controller set.
DEBUG - 2022-05-23 13:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-23 13:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-23 13:35:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-23 13:35:51 --> Total execution time: 0.0020
DEBUG - 2022-05-23 23:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-23 23:44:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-23 23:44:34 --> 404 Page Not Found: Wp-loginphp/index
