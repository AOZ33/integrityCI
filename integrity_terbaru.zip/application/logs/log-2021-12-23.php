<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-23 00:43:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 00:43:03 --> No URI present. Default controller set.
DEBUG - 2021-12-23 00:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 00:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 00:43:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 00:43:03 --> Total execution time: 0.0318
DEBUG - 2021-12-23 00:43:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 00:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 00:43:03 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-23 02:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 02:37:59 --> No URI present. Default controller set.
DEBUG - 2021-12-23 02:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 02:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 02:37:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 02:37:59 --> Total execution time: 0.0306
DEBUG - 2021-12-23 02:38:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 02:38:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 02:38:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-23 04:14:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 04:14:09 --> No URI present. Default controller set.
DEBUG - 2021-12-23 04:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 04:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 04:14:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 04:14:09 --> Total execution time: 0.0342
DEBUG - 2021-12-23 04:14:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 04:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 04:14:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-23 04:14:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 04:14:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 04:14:09 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-23 06:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 06:05:38 --> No URI present. Default controller set.
DEBUG - 2021-12-23 06:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 06:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 06:05:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 06:05:38 --> Total execution time: 0.0307
DEBUG - 2021-12-23 06:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 06:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 06:05:39 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-23 06:20:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 06:20:03 --> No URI present. Default controller set.
DEBUG - 2021-12-23 06:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 06:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 06:20:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 06:20:03 --> Total execution time: 0.0306
DEBUG - 2021-12-23 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 06:20:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 06:20:04 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-23 11:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:00 --> No URI present. Default controller set.
DEBUG - 2021-12-23 11:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:03:00 --> Total execution time: 0.0306
DEBUG - 2021-12-23 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:03:01 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-23 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:03:01 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-23 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:13 --> Total execution time: 0.0074
DEBUG - 2021-12-23 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:03:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-23 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:03:15 --> Total execution time: 0.0042
DEBUG - 2021-12-23 11:03:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:03:16 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-23 11:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:17 --> Total execution time: 0.0051
DEBUG - 2021-12-23 11:03:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:03:18 --> Total execution time: 0.0057
DEBUG - 2021-12-23 11:03:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:03:18 --> Total execution time: 0.0085
DEBUG - 2021-12-23 11:03:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:19 --> Total execution time: 0.0056
DEBUG - 2021-12-23 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:20 --> Total execution time: 0.0055
DEBUG - 2021-12-23 11:03:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:20 --> Total execution time: 0.0060
DEBUG - 2021-12-23 11:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:21 --> Total execution time: 0.0062
DEBUG - 2021-12-23 11:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:21 --> Total execution time: 0.0064
DEBUG - 2021-12-23 11:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:22 --> Total execution time: 0.0066
DEBUG - 2021-12-23 11:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:27 --> Total execution time: 0.0046
DEBUG - 2021-12-23 11:03:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:29 --> Total execution time: 0.0062
DEBUG - 2021-12-23 11:03:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:30 --> Total execution time: 0.0064
DEBUG - 2021-12-23 11:03:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:32 --> Total execution time: 0.0047
DEBUG - 2021-12-23 11:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:33 --> Total execution time: 0.0047
DEBUG - 2021-12-23 11:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:35 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:03:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:03:56 --> Total execution time: 0.0047
DEBUG - 2021-12-23 11:03:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:04:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:04:35 --> Total execution time: 0.0331
DEBUG - 2021-12-23 11:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:04:36 --> Total execution time: 0.0059
DEBUG - 2021-12-23 11:04:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:04:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:04:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:04:56 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:04:58 --> Total execution time: 0.0056
DEBUG - 2021-12-23 11:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:04:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:04:58 --> Total execution time: 0.0056
DEBUG - 2021-12-23 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:05:37 --> Total execution time: 0.0331
DEBUG - 2021-12-23 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:05:37 --> Total execution time: 0.0052
DEBUG - 2021-12-23 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:05:37 --> Total execution time: 0.0062
DEBUG - 2021-12-23 11:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:05:38 --> Total execution time: 0.0067
DEBUG - 2021-12-23 11:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:05:39 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:06:27 --> Total execution time: 0.0325
DEBUG - 2021-12-23 11:06:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:06:28 --> Total execution time: 0.0058
DEBUG - 2021-12-23 11:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:06:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:06:31 --> Total execution time: 0.0049
DEBUG - 2021-12-23 11:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:06:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:06:31 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-23 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:06:41 --> Total execution time: 0.0049
DEBUG - 2021-12-23 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:19 --> Total execution time: 0.0334
DEBUG - 2021-12-23 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:19 --> Total execution time: 0.0059
DEBUG - 2021-12-23 11:07:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:19 --> Total execution time: 0.0056
DEBUG - 2021-12-23 11:07:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:20 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:07:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:21 --> Total execution time: 0.0055
DEBUG - 2021-12-23 11:07:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:21 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:22 --> Total execution time: 0.0052
DEBUG - 2021-12-23 11:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:24 --> Total execution time: 0.0052
DEBUG - 2021-12-23 11:07:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:07:25 --> Total execution time: 0.0072
DEBUG - 2021-12-23 11:07:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:07:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:07:25 --> Total execution time: 0.0058
DEBUG - 2021-12-23 11:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:08:21 --> No URI present. Default controller set.
DEBUG - 2021-12-23 11:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:08:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:08:21 --> Total execution time: 0.0312
DEBUG - 2021-12-23 11:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:08:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-23 11:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:08:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-23 11:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:08:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:08:29 --> Total execution time: 0.0070
DEBUG - 2021-12-23 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:08:35 --> Total execution time: 0.0062
DEBUG - 2021-12-23 11:09:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:09:08 --> Total execution time: 0.0332
DEBUG - 2021-12-23 11:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:09:10 --> Total execution time: 0.0060
DEBUG - 2021-12-23 11:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:10:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:10:40 --> Total execution time: 0.0333
DEBUG - 2021-12-23 11:10:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:10:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:10:59 --> Total execution time: 0.0066
DEBUG - 2021-12-23 11:11:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:11:01 --> Total execution time: 0.0054
DEBUG - 2021-12-23 11:11:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:11:02 --> Total execution time: 0.0048
DEBUG - 2021-12-23 11:11:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:11:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:11:04 --> Total execution time: 0.0050
DEBUG - 2021-12-23 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:11:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:11:06 --> Total execution time: 0.0081
DEBUG - 2021-12-23 11:11:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:11:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:11:10 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:11:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:11:13 --> Total execution time: 0.0056
DEBUG - 2021-12-23 11:12:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:12:07 --> Total execution time: 0.0346
DEBUG - 2021-12-23 11:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:12 --> Total execution time: 0.0061
DEBUG - 2021-12-23 11:12:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:13 --> Total execution time: 0.0046
DEBUG - 2021-12-23 11:12:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:12:14 --> Total execution time: 0.0054
DEBUG - 2021-12-23 11:12:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:12:15 --> Total execution time: 0.0059
DEBUG - 2021-12-23 11:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:22 --> Total execution time: 0.0062
DEBUG - 2021-12-23 11:12:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:25 --> Total execution time: 0.0050
DEBUG - 2021-12-23 11:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:27 --> Total execution time: 0.0048
DEBUG - 2021-12-23 11:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:27 --> Total execution time: 0.0052
DEBUG - 2021-12-23 11:12:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:31 --> Total execution time: 0.0057
DEBUG - 2021-12-23 11:12:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:32 --> Total execution time: 0.0058
DEBUG - 2021-12-23 11:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:12:35 --> Total execution time: 0.0050
DEBUG - 2021-12-23 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:12:37 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:12:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:12:52 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-12-23 11:12:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:12:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:12:54 --> Total execution time: 0.0052
DEBUG - 2021-12-23 11:13:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:13:08 --> Total execution time: 0.0063
DEBUG - 2021-12-23 11:13:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:13:09 --> Total execution time: 0.0049
DEBUG - 2021-12-23 11:13:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:13:10 --> Total execution time: 0.0051
DEBUG - 2021-12-23 11:13:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:13:11 --> Total execution time: 0.0067
DEBUG - 2021-12-23 11:13:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:13:12 --> Total execution time: 0.0061
DEBUG - 2021-12-23 11:13:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:13:14 --> Total execution time: 0.0059
DEBUG - 2021-12-23 11:13:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:13:15 --> Total execution time: 0.0046
DEBUG - 2021-12-23 11:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:13:17 --> Total execution time: 0.0059
DEBUG - 2021-12-23 11:15:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:15:02 --> Total execution time: 0.0345
DEBUG - 2021-12-23 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:15:06 --> No URI present. Default controller set.
DEBUG - 2021-12-23 11:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:15:06 --> Total execution time: 0.0047
DEBUG - 2021-12-23 11:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:15:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 11:15:06 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-23 11:15:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:15:08 --> Total execution time: 0.0049
DEBUG - 2021-12-23 11:15:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:15:09 --> Total execution time: 0.0066
DEBUG - 2021-12-23 11:15:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:15:33 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:15:35 --> Total execution time: 0.0047
DEBUG - 2021-12-23 11:18:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:18:22 --> Total execution time: 0.0337
DEBUG - 2021-12-23 11:18:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:18:23 --> Total execution time: 0.0055
DEBUG - 2021-12-23 11:18:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:18:25 --> Total execution time: 0.0054
DEBUG - 2021-12-23 11:18:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:18:26 --> Total execution time: 0.0061
DEBUG - 2021-12-23 11:18:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:18:27 --> Total execution time: 0.0055
DEBUG - 2021-12-23 11:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:18:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:18:37 --> Total execution time: 0.0078
DEBUG - 2021-12-23 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-23 11:19:00 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Spk.php 173
ERROR - 2021-12-23 11:19:00 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Farhan & FItri', '2022-02-26', '2021-12-10', '2021-12-31', NULL, 'PHOTO', '')
DEBUG - 2021-12-23 11:19:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:19:00 --> Total execution time: 0.0051
DEBUG - 2021-12-23 11:19:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:04 --> Total execution time: 0.0051
DEBUG - 2021-12-23 11:19:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:07 --> Total execution time: 0.0051
DEBUG - 2021-12-23 11:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:08 --> Total execution time: 0.0049
DEBUG - 2021-12-23 11:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:09 --> Total execution time: 0.0050
DEBUG - 2021-12-23 11:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:09 --> Total execution time: 0.0056
DEBUG - 2021-12-23 11:19:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:10 --> Total execution time: 0.0047
DEBUG - 2021-12-23 11:19:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:10 --> Total execution time: 0.0061
DEBUG - 2021-12-23 11:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:11 --> Total execution time: 0.0055
DEBUG - 2021-12-23 11:19:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:13 --> Total execution time: 0.0061
DEBUG - 2021-12-23 11:19:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:15 --> Total execution time: 0.0046
DEBUG - 2021-12-23 11:19:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:19:17 --> Total execution time: 0.0057
DEBUG - 2021-12-23 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:19:42 --> Total execution time: 0.0050
DEBUG - 2021-12-23 11:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:19:45 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:44:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:44:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:44:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:44:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:44:18 --> Total execution time: 0.0096
DEBUG - 2021-12-23 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:49:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:49:16 --> Total execution time: 0.0354
DEBUG - 2021-12-23 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:49:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:49:54 --> Total execution time: 0.0343
DEBUG - 2021-12-23 11:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:49:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:49:54 --> Total execution time: 0.0049
DEBUG - 2021-12-23 11:49:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:49:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:49:55 --> Total execution time: 0.0055
DEBUG - 2021-12-23 11:49:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:49:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:49:56 --> Total execution time: 0.0052
DEBUG - 2021-12-23 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:49:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:49:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:49:58 --> Total execution time: 0.0051
DEBUG - 2021-12-23 11:50:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:01 --> Total execution time: 0.0069
DEBUG - 2021-12-23 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:04 --> Total execution time: 0.0050
DEBUG - 2021-12-23 11:50:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:06 --> Total execution time: 0.0061
DEBUG - 2021-12-23 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:09 --> Total execution time: 0.0046
DEBUG - 2021-12-23 11:50:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:50:10 --> Total execution time: 0.0054
DEBUG - 2021-12-23 11:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:50:14 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:50:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:50:16 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:50:23 --> Total execution time: 0.0055
DEBUG - 2021-12-23 11:50:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:24 --> Total execution time: 0.0063
DEBUG - 2021-12-23 11:50:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:27 --> Total execution time: 0.0048
DEBUG - 2021-12-23 11:50:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:50:28 --> Total execution time: 0.0053
DEBUG - 2021-12-23 11:50:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:30 --> Total execution time: 0.0060
DEBUG - 2021-12-23 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:32 --> Total execution time: 0.0044
DEBUG - 2021-12-23 11:50:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:34 --> Total execution time: 0.0059
DEBUG - 2021-12-23 11:50:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:50:34 --> Total execution time: 0.0049
DEBUG - 2021-12-23 11:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:36 --> Total execution time: 0.0044
DEBUG - 2021-12-23 11:50:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:39 --> Total execution time: 0.0069
DEBUG - 2021-12-23 11:50:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:42 --> Total execution time: 0.0049
DEBUG - 2021-12-23 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:45 --> Total execution time: 0.0050
DEBUG - 2021-12-23 11:50:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:50:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:50:47 --> Total execution time: 0.0048
DEBUG - 2021-12-23 11:55:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:55:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:55:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:55:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:55:13 --> Total execution time: 0.0071
DEBUG - 2021-12-23 11:55:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:55:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:55:15 --> Total execution time: 0.0082
DEBUG - 2021-12-23 11:55:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 11:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 11:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 11:55:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 11:55:20 --> Total execution time: 0.0053
DEBUG - 2021-12-23 12:00:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:00:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-23 12:00:04 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2021-12-23 12:00:04 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`) VALUES ('Heny', '', 'Initimate Innermost', NULL, '', 'Nesnu x Keia', '', '16RP(1)', '', 'Akad', '', '', '10-15m', '', '', '', '', '', '', 'Rp. 7.000.000', '', '', '', '', '', '', '', '', '2022-01-08', '08:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2021-12-23 12:00:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:00:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:00:05 --> Total execution time: 0.0076
DEBUG - 2021-12-23 12:00:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:00:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:00:50 --> Total execution time: 0.0341
DEBUG - 2021-12-23 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:01:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-23 12:01:00 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Data.php 29
DEBUG - 2021-12-23 12:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:01:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:01:00 --> Total execution time: 0.0054
DEBUG - 2021-12-23 12:01:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:01:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:01:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:01:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:01:20 --> Total execution time: 0.0059
DEBUG - 2021-12-23 12:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:01:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:01:43 --> Total execution time: 0.0326
DEBUG - 2021-12-23 12:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:01:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:01:44 --> Total execution time: 0.0078
DEBUG - 2021-12-23 12:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:01:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:01:45 --> Total execution time: 0.0050
DEBUG - 2021-12-23 12:30:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:30:34 --> No URI present. Default controller set.
DEBUG - 2021-12-23 12:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:30:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:30:34 --> Total execution time: 0.0311
DEBUG - 2021-12-23 12:30:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:30:34 --> No URI present. Default controller set.
DEBUG - 2021-12-23 12:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:30:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:30:34 --> Total execution time: 0.0038
DEBUG - 2021-12-23 12:30:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:30:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 12:30:34 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:30:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:30:42 --> Total execution time: 0.0068
DEBUG - 2021-12-23 12:30:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:30:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:30:44 --> Total execution time: 0.0073
DEBUG - 2021-12-23 12:32:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:32:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:32:30 --> Total execution time: 0.0346
DEBUG - 2021-12-23 12:32:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:32:41 --> Total execution time: 0.0067
DEBUG - 2021-12-23 12:33:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:33:16 --> No URI present. Default controller set.
DEBUG - 2021-12-23 12:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:33:16 --> Total execution time: 0.0304
DEBUG - 2021-12-23 12:52:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 12:52:01 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-23 12:52:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:52:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:52:03 --> Total execution time: 0.0289
DEBUG - 2021-12-23 12:52:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:52:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:52:29 --> Total execution time: 0.0054
DEBUG - 2021-12-23 12:52:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 12:52:31 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-23 12:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:52:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:52:34 --> Total execution time: 0.0058
DEBUG - 2021-12-23 12:57:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:57:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:57:12 --> Total execution time: 0.0351
DEBUG - 2021-12-23 12:57:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 12:57:13 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-23 12:57:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:57:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:57:15 --> Total execution time: 0.0057
DEBUG - 2021-12-23 12:57:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:57:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:57:16 --> Total execution time: 0.0051
DEBUG - 2021-12-23 12:57:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:57:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:57:17 --> Total execution time: 0.0054
DEBUG - 2021-12-23 12:57:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 12:57:18 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-23 12:57:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:57:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:57:21 --> Total execution time: 0.0056
DEBUG - 2021-12-23 12:57:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 12:57:22 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-23 12:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 12:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 12:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 12:57:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 12:57:25 --> Total execution time: 0.0053
DEBUG - 2021-12-23 13:02:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:02:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:02:13 --> Total execution time: 0.0362
DEBUG - 2021-12-23 13:06:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:06:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:06:58 --> Total execution time: 0.0352
DEBUG - 2021-12-23 13:07:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:07:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:07:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:07:02 --> Total execution time: 0.0052
DEBUG - 2021-12-23 13:07:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:07:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:07:06 --> Total execution time: 0.0056
DEBUG - 2021-12-23 13:08:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:08:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-23 13:08:19 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2021-12-23 13:08:19 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`) VALUES ('Heny', '', 'Initimate Innermost', NULL, '', 'Nesnu x Keia', '', '16RP(1)', '', 'Akad', '', '', '10-15m', '', '', '', '', '', '', 'Rp. 7.000.000', '', '', '', '', '', '', '', '', '2022-01-08', '08:00:00', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2021-12-23 13:08:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:08:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:08:19 --> Total execution time: 0.0062
DEBUG - 2021-12-23 13:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:08:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:08:21 --> Total execution time: 0.0068
DEBUG - 2021-12-23 13:08:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:08:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:08:22 --> Total execution time: 0.0052
DEBUG - 2021-12-23 13:08:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:08:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:08:28 --> Total execution time: 0.0052
DEBUG - 2021-12-23 13:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:10:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:10:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:10:18 --> Total execution time: 0.0061
DEBUG - 2021-12-23 13:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:10:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:10:20 --> Total execution time: 0.0072
DEBUG - 2021-12-23 13:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:10:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:10:23 --> Total execution time: 0.0056
DEBUG - 2021-12-23 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:10:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:10:57 --> Total execution time: 0.0321
DEBUG - 2021-12-23 13:15:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:15:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:15:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:15:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:15:04 --> Total execution time: 0.0072
DEBUG - 2021-12-23 13:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:15:06 --> Total execution time: 0.0077
DEBUG - 2021-12-23 13:15:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:15:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:15:43 --> Total execution time: 0.0324
DEBUG - 2021-12-23 13:19:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:19:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:19:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:19:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:19:19 --> Total execution time: 0.0073
DEBUG - 2021-12-23 13:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:19:20 --> Total execution time: 0.0063
DEBUG - 2021-12-23 13:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:19:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:19:22 --> Total execution time: 0.0077
DEBUG - 2021-12-23 13:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:19:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:19:57 --> Total execution time: 0.0331
DEBUG - 2021-12-23 13:25:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:25:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:25:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:25:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:25:28 --> Total execution time: 0.0076
DEBUG - 2021-12-23 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:25:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:25:43 --> Total execution time: 0.0082
DEBUG - 2021-12-23 13:25:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:25:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:25:45 --> Total execution time: 0.0049
DEBUG - 2021-12-23 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:32:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:32:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:32:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:32:49 --> Total execution time: 0.0075
DEBUG - 2021-12-23 13:34:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:34:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:34:54 --> Total execution time: 0.0354
DEBUG - 2021-12-23 13:38:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:38:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:38:55 --> Total execution time: 0.0334
DEBUG - 2021-12-23 13:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:39:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:39:46 --> Total execution time: 0.0350
DEBUG - 2021-12-23 13:40:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:40:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:40:06 --> Total execution time: 0.0058
DEBUG - 2021-12-23 13:44:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:44:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:44:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:44:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:44:30 --> Total execution time: 0.0080
DEBUG - 2021-12-23 13:44:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:44:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:44:41 --> Total execution time: 0.0358
DEBUG - 2021-12-23 13:44:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:44:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:44:48 --> Total execution time: 0.0056
DEBUG - 2021-12-23 13:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 13:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 13:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 13:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 13:52:40 --> Total execution time: 0.0080
DEBUG - 2021-12-23 14:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:19:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 14:19:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2021-12-23 14:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:19:26 --> Total execution time: 0.0345
DEBUG - 2021-12-23 14:28:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:28:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:28:17 --> Total execution time: 0.0371
DEBUG - 2021-12-23 14:28:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:28:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 14:28:20 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-23 14:28:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:28:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:28:22 --> Total execution time: 0.0068
DEBUG - 2021-12-23 14:30:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:30:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:30:14 --> Total execution time: 0.0367
DEBUG - 2021-12-23 14:30:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:30:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 14:30:16 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-23 14:30:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:30:18 --> Total execution time: 0.0065
DEBUG - 2021-12-23 14:30:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:30:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:30:39 --> Total execution time: 0.0077
DEBUG - 2021-12-23 14:30:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-23 14:30:40 --> 404 Page Not Found: Appointment/print
DEBUG - 2021-12-23 14:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:30:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:30:42 --> Total execution time: 0.0060
DEBUG - 2021-12-23 14:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:36:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:36:07 --> Total execution time: 0.0367
DEBUG - 2021-12-23 14:36:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:36:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:36:43 --> Total execution time: 0.0336
DEBUG - 2021-12-23 14:42:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:42:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:42:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:42:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:42:17 --> Total execution time: 0.0071
DEBUG - 2021-12-23 14:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:46:13 --> Total execution time: 0.0074
DEBUG - 2021-12-23 14:46:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:46:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:46:16 --> Total execution time: 0.0094
DEBUG - 2021-12-23 14:47:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:47:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:47:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:47:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:47:29 --> Total execution time: 0.0109
DEBUG - 2021-12-23 14:47:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:47:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:47:32 --> Total execution time: 0.0062
DEBUG - 2021-12-23 14:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:47:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:47:48 --> Total execution time: 0.0075
DEBUG - 2021-12-23 14:47:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:47:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 14:47:52 --> Total execution time: 0.0054
DEBUG - 2021-12-23 14:58:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:58:58 --> Total execution time: 0.0354
DEBUG - 2021-12-23 14:58:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:58:59 --> Total execution time: 0.0063
DEBUG - 2021-12-23 14:59:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 14:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 14:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 14:59:00 --> Total execution time: 0.0050
DEBUG - 2021-12-23 15:04:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:04:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 15:04:24 --> Total execution time: 0.0350
DEBUG - 2021-12-23 15:04:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:04:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 15:04:25 --> Total execution time: 0.0106
DEBUG - 2021-12-23 15:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:05:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 15:05:39 --> Total execution time: 0.0358
DEBUG - 2021-12-23 15:38:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:38:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 15:38:21 --> Total execution time: 0.0384
DEBUG - 2021-12-23 15:38:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:38:26 --> Total execution time: 0.0063
DEBUG - 2021-12-23 15:38:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:38:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 15:38:30 --> Total execution time: 0.0073
DEBUG - 2021-12-23 15:38:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:38:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:38:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 15:38:48 --> Total execution time: 0.0072
DEBUG - 2021-12-23 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 15:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 15:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 15:38:51 --> Total execution time: 0.0052
DEBUG - 2021-12-23 16:00:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-23 16:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-23 16:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-23 16:00:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-23 16:00:25 --> Total execution time: 0.0356
