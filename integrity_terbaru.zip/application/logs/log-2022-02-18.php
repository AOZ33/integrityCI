<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-18 09:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 09:56:21 --> No URI present. Default controller set.
DEBUG - 2022-02-18 09:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 09:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 09:56:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 09:56:21 --> Total execution time: 0.0308
DEBUG - 2022-02-18 09:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 09:56:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-18 09:56:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-18 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 09:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 09:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 09:56:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 09:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 09:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 09:56:30 --> Total execution time: 0.0058
DEBUG - 2022-02-18 09:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 09:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 09:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 09:56:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-18 09:56:42 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1457
DEBUG - 2022-02-18 09:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 09:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 09:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 09:56:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 09:56:49 --> Total execution time: 0.0039
DEBUG - 2022-02-18 10:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:11:33 --> No URI present. Default controller set.
DEBUG - 2022-02-18 10:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:11:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:11:33 --> Total execution time: 0.0300
DEBUG - 2022-02-18 10:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:11:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-18 10:11:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-18 10:11:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:11:33 --> No URI present. Default controller set.
DEBUG - 2022-02-18 10:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:11:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:11:33 --> Total execution time: 0.0040
DEBUG - 2022-02-18 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:32:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:32:00 --> Total execution time: 0.0060
DEBUG - 2022-02-18 10:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:32:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-18 10:32:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1457
DEBUG - 2022-02-18 10:32:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:32:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:32:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:32:18 --> Total execution time: 0.0043
DEBUG - 2022-02-18 10:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:34:30 --> Total execution time: 0.0057
DEBUG - 2022-02-18 10:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:46:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:46:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:46:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:46:04 --> Total execution time: 0.0059
DEBUG - 2022-02-18 10:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:49:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:49:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:49:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:49:41 --> Total execution time: 0.0057
DEBUG - 2022-02-18 10:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:50:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:50:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:50:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:50:32 --> Total execution time: 0.0045
DEBUG - 2022-02-18 10:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:57:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 10:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 10:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 10:57:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 10:57:43 --> Total execution time: 0.0063
DEBUG - 2022-02-18 11:02:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:02:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:02:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:02:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:02:36 --> Total execution time: 0.0061
DEBUG - 2022-02-18 11:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:02:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:02:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:02:48 --> Total execution time: 0.0048
DEBUG - 2022-02-18 11:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:05:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:05:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:05:54 --> Total execution time: 0.0050
DEBUG - 2022-02-18 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:06:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:06:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:06:41 --> Total execution time: 0.0042
DEBUG - 2022-02-18 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:10:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:10:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:10:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:10:11 --> Total execution time: 0.0056
DEBUG - 2022-02-18 11:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:15:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:15:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:15:44 --> Total execution time: 0.0061
DEBUG - 2022-02-18 11:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:16:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:16:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:16:00 --> Total execution time: 0.0045
DEBUG - 2022-02-18 11:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:20:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:20:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:20:32 --> Total execution time: 0.0067
DEBUG - 2022-02-18 11:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:26:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:26:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:26:37 --> Total execution time: 0.0055
DEBUG - 2022-02-18 11:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:32:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:32:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:32:02 --> Total execution time: 0.0062
DEBUG - 2022-02-18 11:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:33:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:33:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:33:38 --> Total execution time: 0.0054
DEBUG - 2022-02-18 11:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:35:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 11:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 11:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 11:35:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 11:35:20 --> Total execution time: 0.0048
DEBUG - 2022-02-18 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:19:13 --> Total execution time: 0.0066
DEBUG - 2022-02-18 13:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:20:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:20:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:20:54 --> Total execution time: 0.0055
DEBUG - 2022-02-18 13:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:22:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:22:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:22:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:22:40 --> Total execution time: 0.0052
DEBUG - 2022-02-18 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:23:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:23:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:23:16 --> Total execution time: 0.0035
DEBUG - 2022-02-18 13:28:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:28:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:28:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:28:58 --> Total execution time: 0.0060
DEBUG - 2022-02-18 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:31:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:31:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:31:10 --> Total execution time: 0.0059
DEBUG - 2022-02-18 13:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:46:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:46:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:46:17 --> Total execution time: 0.0053
DEBUG - 2022-02-18 13:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:52:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 13:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 13:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 13:52:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 13:52:06 --> Total execution time: 0.0062
DEBUG - 2022-02-18 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:17:53 --> Total execution time: 0.0072
DEBUG - 2022-02-18 14:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:24:50 --> Total execution time: 0.0059
DEBUG - 2022-02-18 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:42:09 --> Total execution time: 0.0065
DEBUG - 2022-02-18 14:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:46:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:46:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:46:06 --> Total execution time: 0.0065
DEBUG - 2022-02-18 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:50:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:50:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:50:41 --> Total execution time: 0.0059
DEBUG - 2022-02-18 14:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:54:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 14:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 14:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 14:54:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 14:54:44 --> Total execution time: 0.0069
DEBUG - 2022-02-18 15:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:06:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:06:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:06:13 --> Total execution time: 0.0057
DEBUG - 2022-02-18 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:08:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:08:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:08:31 --> Total execution time: 0.0045
DEBUG - 2022-02-18 15:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:11:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:11:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:11:39 --> Total execution time: 0.0045
DEBUG - 2022-02-18 15:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:15:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:15:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:15:08 --> Total execution time: 0.0054
DEBUG - 2022-02-18 15:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:23:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:23:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:23:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:23:47 --> Total execution time: 0.0061
DEBUG - 2022-02-18 15:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:29:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:29:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:29:32 --> Total execution time: 0.0060
DEBUG - 2022-02-18 15:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:36:16 --> Total execution time: 0.0056
DEBUG - 2022-02-18 15:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:42:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:42:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:42:03 --> Total execution time: 0.0064
DEBUG - 2022-02-18 15:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:47:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:47:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:47:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:47:20 --> Total execution time: 0.0065
DEBUG - 2022-02-18 15:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:54:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:54:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:54:52 --> Total execution time: 0.0062
DEBUG - 2022-02-18 15:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:58:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 15:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 15:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 15:58:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 15:58:14 --> Total execution time: 0.0046
DEBUG - 2022-02-18 16:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:03:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:03:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:03:29 --> Total execution time: 0.0060
DEBUG - 2022-02-18 16:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:35:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:35:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:35:55 --> Total execution time: 0.0071
DEBUG - 2022-02-18 16:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:46:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:46:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:46:34 --> Total execution time: 0.0055
DEBUG - 2022-02-18 16:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:49:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:49:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:49:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:49:33 --> Total execution time: 0.0049
DEBUG - 2022-02-18 16:54:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:54:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:54:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:54:50 --> Total execution time: 0.0070
DEBUG - 2022-02-18 16:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:55:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:55:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-18 16:55:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-18 16:55:25 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-18 16:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:55:44 --> No URI present. Default controller set.
DEBUG - 2022-02-18 16:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:55:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:55:44 --> Total execution time: 0.0055
DEBUG - 2022-02-18 16:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:55:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-18 16:55:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-18 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:55:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:55:53 --> Total execution time: 0.0036
DEBUG - 2022-02-18 16:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:55:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-18 16:55:57 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1445
DEBUG - 2022-02-18 16:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:57:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:57:16 --> Total execution time: 0.0333
DEBUG - 2022-02-18 16:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:59:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 16:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 16:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 16:59:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 16:59:05 --> Total execution time: 0.0060
DEBUG - 2022-02-18 17:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:01:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:01:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:01:58 --> Total execution time: 0.0061
DEBUG - 2022-02-18 17:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:02:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:02:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:02:48 --> Total execution time: 0.0043
DEBUG - 2022-02-18 17:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:07:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:07:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:07:01 --> Total execution time: 0.0057
DEBUG - 2022-02-18 17:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:09:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:09:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:09:41 --> Total execution time: 0.0052
DEBUG - 2022-02-18 17:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:12:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:12:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:12:36 --> Total execution time: 0.0050
DEBUG - 2022-02-18 17:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:12:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-18 17:12:38 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
DEBUG - 2022-02-18 17:12:38 --> Total execution time: 0.0038
DEBUG - 2022-02-18 17:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:15:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-18 17:15:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-18 17:15:21 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-18 17:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:17:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:17:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:17:44 --> Total execution time: 0.0050
DEBUG - 2022-02-18 17:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:18:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:18:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:18:55 --> Total execution time: 0.0046
DEBUG - 2022-02-18 17:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:19:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:19:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:19:51 --> Total execution time: 0.0040
DEBUG - 2022-02-18 17:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:20:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:20:36 --> Total execution time: 0.0046
DEBUG - 2022-02-18 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:22:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:22:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:22:29 --> Total execution time: 0.0048
DEBUG - 2022-02-18 17:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:24:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:24:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:24:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:24:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:24:15 --> Total execution time: 0.0053
DEBUG - 2022-02-18 17:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:24:18 --> Total execution time: 0.0041
DEBUG - 2022-02-18 17:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:24:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:24:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:24:25 --> Total execution time: 0.0030
DEBUG - 2022-02-18 17:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:24:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-18 17:24:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-18 17:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-18 17:25:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-18 17:25:46 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-18 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:26:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:26:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:26:27 --> Total execution time: 0.0047
DEBUG - 2022-02-18 17:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:27:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:27:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:27:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:27:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:27:55 --> Total execution time: 0.0049
DEBUG - 2022-02-18 17:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:32:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:32:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 17:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 17:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 17:32:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-18 17:32:12 --> Total execution time: 0.0063
DEBUG - 2022-02-18 18:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 18:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 18:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 18:15:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-18 18:15:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-18 18:15:58 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-18 20:27:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-18 20:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-18 20:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-18 20:27:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-18 20:27:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-18 20:27:54 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
