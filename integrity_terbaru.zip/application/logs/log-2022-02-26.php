<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-26 14:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:20:13 --> No URI present. Default controller set.
DEBUG - 2022-02-26 14:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:20:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:20:13 --> Total execution time: 0.0314
DEBUG - 2022-02-26 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:20:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-26 14:20:14 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-26 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:20:14 --> No URI present. Default controller set.
DEBUG - 2022-02-26 14:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:20:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:20:14 --> Total execution time: 0.0039
DEBUG - 2022-02-26 14:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:20:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:20:21 --> Total execution time: 0.0065
DEBUG - 2022-02-26 14:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:21:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-26 14:21:13 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-26 14:21:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:21:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:21:15 --> Total execution time: 0.0044
DEBUG - 2022-02-26 14:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:31:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:31:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:31:03 --> Total execution time: 0.0059
DEBUG - 2022-02-26 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:35:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:35:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:35:39 --> Total execution time: 0.0061
DEBUG - 2022-02-26 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:48:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 14:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 14:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 14:48:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 14:48:28 --> Total execution time: 0.0056
DEBUG - 2022-02-26 15:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:14:35 --> Total execution time: 0.0069
DEBUG - 2022-02-26 15:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:22:02 --> Total execution time: 0.0057
DEBUG - 2022-02-26 15:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:36:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:36:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:36:04 --> Total execution time: 0.0060
DEBUG - 2022-02-26 15:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:40:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:40:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:40:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:40:46 --> Total execution time: 0.0058
DEBUG - 2022-02-26 15:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:43:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 15:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 15:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 15:43:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 15:43:39 --> Total execution time: 0.0048
DEBUG - 2022-02-26 16:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:01:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:01:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:01:11 --> Total execution time: 0.0056
DEBUG - 2022-02-26 16:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:06:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:06:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:06:50 --> Total execution time: 0.0052
DEBUG - 2022-02-26 16:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:12:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:12:10 --> Total execution time: 0.0058
DEBUG - 2022-02-26 16:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:22:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:22:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:22:46 --> Total execution time: 0.0062
DEBUG - 2022-02-26 16:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:27:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:27:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:27:10 --> Total execution time: 0.0047
DEBUG - 2022-02-26 16:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:29:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:29:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:29:09 --> Total execution time: 0.0040
DEBUG - 2022-02-26 16:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:59:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:59:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 16:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 16:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 16:59:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 16:59:45 --> Total execution time: 0.0064
DEBUG - 2022-02-26 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 17:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 17:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 17:05:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 17:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 17:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 17:05:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 17:05:24 --> Total execution time: 0.0055
DEBUG - 2022-02-26 17:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 17:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 17:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 17:08:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 17:08:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 17:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 17:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 17:08:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 17:08:09 --> Total execution time: 0.0055
DEBUG - 2022-02-26 17:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-26 17:33:24 --> No URI present. Default controller set.
DEBUG - 2022-02-26 17:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-26 17:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-26 17:33:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-26 17:33:24 --> Total execution time: 0.0302
