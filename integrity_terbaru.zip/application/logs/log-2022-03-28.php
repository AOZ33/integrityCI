<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-28 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:01 --> No URI present. Default controller set.
DEBUG - 2022-03-28 11:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:03:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:03:01 --> Total execution time: 0.0307
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-28 11:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:02 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-28 11:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:03:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:03:09 --> Total execution time: 0.0052
DEBUG - 2022-03-28 11:03:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 11:03:09 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-28 11:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:03:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:03:13 --> Total execution time: 0.0132
DEBUG - 2022-03-28 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:03:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:03:15 --> Total execution time: 0.0046
DEBUG - 2022-03-28 11:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:08:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:08:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:08:35 --> Total execution time: 0.0066
DEBUG - 2022-03-28 11:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:15:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 11:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 11:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 11:15:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 11:15:49 --> Total execution time: 0.0058
DEBUG - 2022-03-28 12:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 12:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 12:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 12:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 12:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 12:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 12:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 12:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 12:30:56 --> Total execution time: 0.0076
DEBUG - 2022-03-28 13:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 13:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 13:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 13:14:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 13:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 13:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 13:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 13:14:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 13:14:47 --> Total execution time: 0.0062
DEBUG - 2022-03-28 14:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 14:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 14:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 14:35:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 14:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 14:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 14:35:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:35:53 --> Total execution time: 0.0067
DEBUG - 2022-03-28 14:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 14:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 14:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 14:39:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:39:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 14:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 14:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 14:39:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:39:55 --> Total execution time: 0.0058
DEBUG - 2022-03-28 14:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 14:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 14:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 14:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 14:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 14:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 14:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 14:44:20 --> Total execution time: 0.0057
DEBUG - 2022-03-28 20:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 20:20:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-28 20:20:40 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-28 20:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-28 20:20:44 --> No URI present. Default controller set.
DEBUG - 2022-03-28 20:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-28 20:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-28 20:20:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-28 20:20:44 --> Total execution time: 0.0218
