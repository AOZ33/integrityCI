<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-11 00:48:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 00:48:19 --> No URI present. Default controller set.
DEBUG - 2022-01-11 00:48:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 00:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 00:48:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 00:48:19 --> Total execution time: 0.0314
DEBUG - 2022-01-11 02:11:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 02:11:14 --> No URI present. Default controller set.
DEBUG - 2022-01-11 02:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 02:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 02:11:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 02:11:15 --> Total execution time: 0.0312
DEBUG - 2022-01-11 10:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:30:09 --> No URI present. Default controller set.
DEBUG - 2022-01-11 10:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 10:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 10:30:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 10:30:09 --> Total execution time: 0.0313
DEBUG - 2022-01-11 10:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:30:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-11 10:30:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-11 10:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 10:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 10:30:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 10:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 10:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 10:30:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 10:30:14 --> Total execution time: 0.0033
DEBUG - 2022-01-11 10:30:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-11 10:30:14 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-11 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 10:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 10:30:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 10:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 10:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 10:30:27 --> Total execution time: 0.0059
DEBUG - 2022-01-11 10:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 10:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 10:30:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 10:30:30 --> Total execution time: 0.1186
DEBUG - 2022-01-11 10:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 10:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 10:51:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 10:51:39 --> Total execution time: 0.1471
DEBUG - 2022-01-11 10:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 10:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 10:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 10:55:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 10:55:31 --> Total execution time: 0.0342
DEBUG - 2022-01-11 11:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:00:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:00:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:00:12 --> Total execution time: 0.0062
DEBUG - 2022-01-11 11:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:14:35 --> Total execution time: 0.0063
DEBUG - 2022-01-11 11:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:24:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:24:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:24:59 --> Total execution time: 0.0068
DEBUG - 2022-01-11 11:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:32:39 --> Total execution time: 0.0061
DEBUG - 2022-01-11 11:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:43:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:43:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:43:52 --> Total execution time: 0.0066
DEBUG - 2022-01-11 11:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:54:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 11:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 11:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 11:54:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 11:54:17 --> Total execution time: 0.0057
DEBUG - 2022-01-11 12:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 12:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 12:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 12:00:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 12:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 12:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 12:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 12:00:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 12:00:59 --> Total execution time: 0.0062
DEBUG - 2022-01-11 13:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 13:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 13:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 13:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 13:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 13:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 13:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 13:41:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 13:41:17 --> Total execution time: 0.0063
DEBUG - 2022-01-11 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 13:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 13:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 13:47:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 13:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 13:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 13:47:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 13:47:09 --> Total execution time: 0.0057
DEBUG - 2022-01-11 13:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 13:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 13:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 13:55:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 13:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 13:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 13:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 13:55:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 13:55:44 --> Total execution time: 0.0059
DEBUG - 2022-01-11 14:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:03:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:03:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:03:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:03:59 --> Total execution time: 0.0062
DEBUG - 2022-01-11 14:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:12:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:12:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:12:07 --> Total execution time: 0.0065
DEBUG - 2022-01-11 14:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:17:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:17:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:17:02 --> Total execution time: 0.0057
DEBUG - 2022-01-11 14:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:20:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:20:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:20:44 --> Total execution time: 0.0057
DEBUG - 2022-01-11 14:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:24:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:24:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:24:08 --> Total execution time: 0.0047
DEBUG - 2022-01-11 14:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:27:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:27:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:27:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:27:22 --> Total execution time: 0.0055
DEBUG - 2022-01-11 14:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:34:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:34:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:34:22 --> Total execution time: 0.0057
DEBUG - 2022-01-11 14:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:40:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:40:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:40:40 --> Total execution time: 0.0066
DEBUG - 2022-01-11 14:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:49:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:49:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:49:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:49:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:49:48 --> Total execution time: 0.0059
DEBUG - 2022-01-11 14:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:54:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:54:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:54:18 --> Total execution time: 0.0053
DEBUG - 2022-01-11 14:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:54:20 --> Total execution time: 0.1209
DEBUG - 2022-01-11 14:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 14:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 14:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 14:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 14:55:01 --> Total execution time: 0.0052
DEBUG - 2022-01-11 15:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:02:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:02:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:02:31 --> Total execution time: 0.0055
DEBUG - 2022-01-11 15:04:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:04:01 --> No URI present. Default controller set.
DEBUG - 2022-01-11 15:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:04:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:04:01 --> Total execution time: 0.0302
DEBUG - 2022-01-11 15:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:10:24 --> Total execution time: 0.0063
DEBUG - 2022-01-11 15:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:16:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:16:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:16:35 --> Total execution time: 0.0058
DEBUG - 2022-01-11 15:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:23:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:23:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:23:51 --> Total execution time: 0.0057
DEBUG - 2022-01-11 15:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:35:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:35:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:35:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:35:53 --> Total execution time: 0.0061
DEBUG - 2022-01-11 15:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:45:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:45:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:45:36 --> Total execution time: 0.0062
DEBUG - 2022-01-11 15:53:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:53:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:53:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 15:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 15:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 15:53:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 15:53:59 --> Total execution time: 0.0068
DEBUG - 2022-01-11 16:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:01:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:01:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:01:36 --> Total execution time: 0.0066
DEBUG - 2022-01-11 16:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:04:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:04:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:04:50 --> Total execution time: 0.0053
DEBUG - 2022-01-11 16:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:11:54 --> Total execution time: 0.0054
DEBUG - 2022-01-11 16:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:11:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:11:57 --> Total execution time: 0.1229
DEBUG - 2022-01-11 16:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:12:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:12:39 --> Total execution time: 0.0054
DEBUG - 2022-01-11 16:13:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:13:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:13:08 --> Total execution time: 0.0048
DEBUG - 2022-01-11 16:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:16:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:16:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:16:16 --> Total execution time: 0.0062
DEBUG - 2022-01-11 16:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:21:55 --> No URI present. Default controller set.
DEBUG - 2022-01-11 16:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:21:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:21:55 --> Total execution time: 0.0303
DEBUG - 2022-01-11 16:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:30:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:30:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:30:36 --> Total execution time: 0.0067
DEBUG - 2022-01-11 16:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:36:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:36:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:36:18 --> Total execution time: 0.0060
DEBUG - 2022-01-11 16:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:40:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 16:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 16:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 16:40:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 16:40:33 --> Total execution time: 0.0051
DEBUG - 2022-01-11 17:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:09:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:09:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:09:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:09:40 --> Total execution time: 0.0066
DEBUG - 2022-01-11 17:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:17:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:17:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:17:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:17:37 --> Total execution time: 0.0059
DEBUG - 2022-01-11 17:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:20:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:20:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:20:51 --> Total execution time: 0.0054
DEBUG - 2022-01-11 17:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:25:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:25:21 --> Total execution time: 0.0059
DEBUG - 2022-01-11 17:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:29:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:29:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:29:23 --> Total execution time: 0.0066
DEBUG - 2022-01-11 17:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-11 17:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-11 17:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-11 17:29:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-11 17:29:31 --> Total execution time: 0.1544
