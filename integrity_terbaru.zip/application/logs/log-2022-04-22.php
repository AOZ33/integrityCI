<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-22 02:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:12 --> No URI present. Default controller set.
DEBUG - 2022-04-22 02:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:41:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 02:41:12 --> Total execution time: 0.0494
DEBUG - 2022-04-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 02:41:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 02:41:13 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 02:41:13 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 02:41:13 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-22 02:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 02:41:13 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-22 02:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 02:41:13 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-22 02:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:41:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 02:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:41:14 --> Total execution time: 0.0077
DEBUG - 2022-04-22 02:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:45:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:45:57 --> Total execution time: 0.0469
DEBUG - 2022-04-22 02:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:55:41 --> Total execution time: 0.0435
DEBUG - 2022-04-22 02:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:55:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 02:55:44 --> Total execution time: 0.0263
DEBUG - 2022-04-22 02:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:55:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 02:55:44 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 02:55:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:55:52 --> Total execution time: 0.0024
DEBUG - 2022-04-22 02:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:55:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 02:55:54 --> Total execution time: 0.0225
DEBUG - 2022-04-22 02:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 02:55:55 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 02:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 02:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 02:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 02:55:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 02:55:57 --> Total execution time: 0.0125
DEBUG - 2022-04-22 03:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:02:17 --> Total execution time: 0.0459
DEBUG - 2022-04-22 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:02:21 --> Total execution time: 0.0022
DEBUG - 2022-04-22 03:02:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:02:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:02:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:02:22 --> Total execution time: 0.0098
DEBUG - 2022-04-22 03:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:02:28 --> Total execution time: 0.0036
DEBUG - 2022-04-22 03:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:02:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:02:30 --> Total execution time: 0.0031
DEBUG - 2022-04-22 03:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:04:11 --> Total execution time: 0.0419
DEBUG - 2022-04-22 03:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:04:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:04:24 --> Total execution time: 0.0239
DEBUG - 2022-04-22 03:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:04:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 03:04:24 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 03:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:15:03 --> Total execution time: 0.0554
DEBUG - 2022-04-22 03:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:22:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:22:41 --> Total execution time: 0.0219
DEBUG - 2022-04-22 03:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:22:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:22:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:22:55 --> Total execution time: 0.0049
DEBUG - 2022-04-22 03:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:23:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:23:05 --> Total execution time: 0.0073
DEBUG - 2022-04-22 03:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:23:21 --> Total execution time: 0.0072
DEBUG - 2022-04-22 03:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:23:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:23:50 --> Total execution time: 0.0068
DEBUG - 2022-04-22 03:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-22 03:24:17 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-04-22 03:24:17 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Livia Dea Yuliani & Baruguiera Ardhani Febrian Agradriya', '2022-01-08', '', '2022-01-08', '', NULL, 'PHOTO', '')
DEBUG - 2022-04-22 03:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:24:17 --> Total execution time: 0.0081
DEBUG - 2022-04-22 03:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:24:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:24:36 --> Total execution time: 0.0066
DEBUG - 2022-04-22 03:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:24:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:24:49 --> Total execution time: 0.0191
DEBUG - 2022-04-22 03:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:25:00 --> Total execution time: 0.0053
DEBUG - 2022-04-22 03:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:03 --> Total execution time: 0.0068
DEBUG - 2022-04-22 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:05 --> Total execution time: 0.0079
DEBUG - 2022-04-22 03:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:07 --> Total execution time: 0.0078
DEBUG - 2022-04-22 03:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:09 --> Total execution time: 0.0064
DEBUG - 2022-04-22 03:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:54 --> Total execution time: 0.0049
DEBUG - 2022-04-22 03:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:57 --> Total execution time: 0.0022
DEBUG - 2022-04-22 03:25:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:25:59 --> Total execution time: 0.0024
DEBUG - 2022-04-22 03:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:00 --> Total execution time: 0.0033
DEBUG - 2022-04-22 03:26:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:00 --> Total execution time: 0.0023
DEBUG - 2022-04-22 03:26:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:03 --> Total execution time: 0.0028
DEBUG - 2022-04-22 03:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:04 --> Total execution time: 0.0023
DEBUG - 2022-04-22 03:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:07 --> Total execution time: 0.0037
DEBUG - 2022-04-22 03:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:11 --> Total execution time: 0.0035
DEBUG - 2022-04-22 03:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:13 --> Total execution time: 0.0029
DEBUG - 2022-04-22 03:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:15 --> Total execution time: 0.0034
DEBUG - 2022-04-22 03:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:26:35 --> Total execution time: 0.0033
DEBUG - 2022-04-22 03:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:01 --> Total execution time: 0.0029
DEBUG - 2022-04-22 03:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:05 --> Total execution time: 0.0037
DEBUG - 2022-04-22 03:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:09 --> Total execution time: 0.0028
DEBUG - 2022-04-22 03:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:14 --> Total execution time: 0.0023
DEBUG - 2022-04-22 03:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:37 --> Total execution time: 0.0027
DEBUG - 2022-04-22 03:27:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:42 --> Total execution time: 0.0026
DEBUG - 2022-04-22 03:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:27:59 --> Total execution time: 0.0030
DEBUG - 2022-04-22 03:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:28:06 --> Total execution time: 0.0030
DEBUG - 2022-04-22 03:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:28:10 --> Total execution time: 0.0050
DEBUG - 2022-04-22 03:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:28:13 --> Total execution time: 0.0048
DEBUG - 2022-04-22 03:28:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:28:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:28:16 --> Total execution time: 0.0058
DEBUG - 2022-04-22 03:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:28:53 --> Total execution time: 0.0030
DEBUG - 2022-04-22 03:28:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:28:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:28:59 --> Total execution time: 0.0062
DEBUG - 2022-04-22 03:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:29:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:29:22 --> Total execution time: 0.0057
DEBUG - 2022-04-22 03:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:29:26 --> Total execution time: 0.0033
DEBUG - 2022-04-22 03:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:29:31 --> Total execution time: 0.0033
DEBUG - 2022-04-22 03:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:29:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:29:55 --> Total execution time: 0.0249
DEBUG - 2022-04-22 03:29:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:29:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 03:29:56 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 03:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:49:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:49:10 --> Total execution time: 0.0752
DEBUG - 2022-04-22 03:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 03:49:10 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 03:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:55:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:55:29 --> Total execution time: 0.0665
DEBUG - 2022-04-22 03:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:55:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 03:55:29 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 03:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 03:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 03:59:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 03:59:13 --> Total execution time: 0.0669
DEBUG - 2022-04-22 03:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 03:59:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 03:59:13 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:05:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:05:15 --> Total execution time: 0.0733
DEBUG - 2022-04-22 04:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:05:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:05:15 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:09:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:09:39 --> Total execution time: 0.0644
DEBUG - 2022-04-22 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:09:39 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:11:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:11:56 --> Total execution time: 0.0275
DEBUG - 2022-04-22 04:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:11:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:11:57 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:12:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:12:22 --> Total execution time: 0.0264
DEBUG - 2022-04-22 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:12:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:12:22 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:13:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:13:17 --> Total execution time: 0.0243
DEBUG - 2022-04-22 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:13:17 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:15:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:15:39 --> Total execution time: 0.0284
DEBUG - 2022-04-22 04:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:15:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:15:39 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:16:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:16:02 --> Total execution time: 0.0261
DEBUG - 2022-04-22 04:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:16:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:16:02 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:20:59 --> No URI present. Default controller set.
DEBUG - 2022-04-22 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:20:59 --> Total execution time: 0.0036
DEBUG - 2022-04-22 04:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:22:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:22:18 --> Total execution time: 0.0630
DEBUG - 2022-04-22 04:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:22:19 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:23:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:23:03 --> Total execution time: 0.0240
DEBUG - 2022-04-22 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:23:03 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:23:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:23:38 --> Total execution time: 0.0238
DEBUG - 2022-04-22 04:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:23:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:23:39 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:32:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:32:52 --> Total execution time: 0.0796
DEBUG - 2022-04-22 04:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:32:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:32:53 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:33:16 --> Total execution time: 0.0411
DEBUG - 2022-04-22 04:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:33:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:33:16 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 04:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 04:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 04:34:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 04:34:15 --> Total execution time: 0.0269
DEBUG - 2022-04-22 04:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 04:34:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 04:34:15 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 05:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:55:56 --> Total execution time: 0.0412
DEBUG - 2022-04-22 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:56:39 --> Total execution time: 0.0033
DEBUG - 2022-04-22 05:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:56:42 --> Total execution time: 0.0042
DEBUG - 2022-04-22 05:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:57:39 --> Total execution time: 0.0039
DEBUG - 2022-04-22 05:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:58:23 --> Total execution time: 0.0076
DEBUG - 2022-04-22 05:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:58:41 --> Total execution time: 0.0052
DEBUG - 2022-04-22 05:59:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:59:35 --> Total execution time: 0.0049
DEBUG - 2022-04-22 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:59:37 --> Total execution time: 0.0019
DEBUG - 2022-04-22 05:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 05:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 05:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 05:59:37 --> Total execution time: 0.0020
DEBUG - 2022-04-22 06:00:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:00:20 --> Total execution time: 0.0070
DEBUG - 2022-04-22 06:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:00:40 --> Total execution time: 0.0050
DEBUG - 2022-04-22 06:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:00:42 --> Severity: error --> Exception: syntax error, unexpected ';' /home/nsnmt.com/integrity/application/controllers/Calendar.php 150
DEBUG - 2022-04-22 06:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:00:46 --> Total execution time: 0.0022
DEBUG - 2022-04-22 06:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:03:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:03:23 --> Severity: error --> Exception: syntax error, unexpected ';' /home/nsnmt.com/integrity/application/controllers/Calendar.php 150
DEBUG - 2022-04-22 06:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:03:26 --> Total execution time: 0.0029
DEBUG - 2022-04-22 06:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:12:10 --> Total execution time: 0.0617
DEBUG - 2022-04-22 06:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:12:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:12:12 --> Severity: error --> Exception: syntax error, unexpected ';' /home/nsnmt.com/integrity/application/controllers/Calendar.php 150
DEBUG - 2022-04-22 06:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:12:42 --> Total execution time: 0.0024
DEBUG - 2022-04-22 06:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:12:43 --> Total execution time: 0.0022
DEBUG - 2022-04-22 06:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:14:15 --> Total execution time: 0.0059
DEBUG - 2022-04-22 06:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:14:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:14:15 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:15:28 --> Total execution time: 0.0025
DEBUG - 2022-04-22 06:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:15:29 --> Total execution time: 0.0014
DEBUG - 2022-04-22 06:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:15:29 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:15:30 --> Total execution time: 0.0015
DEBUG - 2022-04-22 06:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:15:31 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:15:32 --> Total execution time: 0.0016
DEBUG - 2022-04-22 06:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:15:32 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:15:32 --> Total execution time: 0.0019
DEBUG - 2022-04-22 06:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:15:32 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:15:33 --> Total execution time: 0.0015
DEBUG - 2022-04-22 06:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:15:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:15:33 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:16:40 --> Total execution time: 0.0026
DEBUG - 2022-04-22 06:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:40 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:40 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:16:46 --> Total execution time: 0.0022
DEBUG - 2022-04-22 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:46 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:46 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:16:47 --> Total execution time: 0.0022
DEBUG - 2022-04-22 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:47 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:16:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:47 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:16:49 --> Total execution time: 0.0022
DEBUG - 2022-04-22 06:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:49 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:49 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:16:50 --> Total execution time: 0.0021
DEBUG - 2022-04-22 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:50 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:16:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:16:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:16:50 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:17:54 --> Total execution time: 0.0048
DEBUG - 2022-04-22 06:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:17:54 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:17:54 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:17:59 --> Total execution time: 0.0030
DEBUG - 2022-04-22 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:17:59 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:17:59 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:17:59 --> Total execution time: 0.0021
DEBUG - 2022-04-22 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:17:59 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:17:59 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:17:59 --> Total execution time: 0.0029
DEBUG - 2022-04-22 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:18:00 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:18:00 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:18:00 --> Total execution time: 0.0025
DEBUG - 2022-04-22 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:18:00 --> 404 Page Not Found: Css/style.css
DEBUG - 2022-04-22 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:18:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:18:00 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:23:34 --> Total execution time: 0.0058
DEBUG - 2022-04-22 06:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:23:34 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:23:38 --> Total execution time: 0.0021
DEBUG - 2022-04-22 06:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:23:38 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:23:39 --> Total execution time: 0.0027
DEBUG - 2022-04-22 06:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:23:40 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:23:41 --> Total execution time: 0.0029
DEBUG - 2022-04-22 06:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:23:41 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:23:42 --> Total execution time: 0.0030
DEBUG - 2022-04-22 06:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:23:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:23:42 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:25:14 --> Total execution time: 0.0024
DEBUG - 2022-04-22 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:25:14 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:25:16 --> Total execution time: 0.0029
DEBUG - 2022-04-22 06:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:25:16 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:25:17 --> Total execution time: 0.0029
DEBUG - 2022-04-22 06:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:25:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:25:17 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:25:18 --> Total execution time: 0.0030
DEBUG - 2022-04-22 06:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:25:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:25:18 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:26:09 --> Total execution time: 0.0026
DEBUG - 2022-04-22 06:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:26:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:26:09 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:26:10 --> Total execution time: 0.0025
DEBUG - 2022-04-22 06:26:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:26:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:26:10 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:26:11 --> Total execution time: 0.0021
DEBUG - 2022-04-22 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:26:11 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:26:11 --> Total execution time: 0.0023
DEBUG - 2022-04-22 06:26:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:26:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:26:11 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:36:57 --> Total execution time: 0.0561
DEBUG - 2022-04-22 06:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:37:01 --> Total execution time: 0.0033
DEBUG - 2022-04-22 06:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:37:02 --> Total execution time: 0.0018
DEBUG - 2022-04-22 06:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:37:02 --> Total execution time: 0.0021
DEBUG - 2022-04-22 06:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:37:02 --> Total execution time: 0.0018
DEBUG - 2022-04-22 06:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:37:03 --> Total execution time: 0.0017
DEBUG - 2022-04-22 06:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:38:04 --> Total execution time: 0.0058
DEBUG - 2022-04-22 06:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:38:04 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:38:06 --> Total execution time: 0.0031
DEBUG - 2022-04-22 06:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:38:07 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:38:39 --> Total execution time: 0.0033
DEBUG - 2022-04-22 06:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:38:39 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-22 06:38:45 --> Severity: Warning --> A non-numeric value encountered /home/nsnmt.com/integrity/system/libraries/Calendar.php 437
DEBUG - 2022-04-22 06:38:45 --> Total execution time: 0.0027
DEBUG - 2022-04-22 06:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:38:45 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:38:55 --> Total execution time: 0.0022
DEBUG - 2022-04-22 06:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:39:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:39:02 --> 404 Page Not Found: Https:/integrity.nsnmt.com
DEBUG - 2022-04-22 06:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:39:07 --> Total execution time: 0.0023
DEBUG - 2022-04-22 06:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:15 --> Total execution time: 0.0040
DEBUG - 2022-04-22 06:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:16 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:18 --> Total execution time: 0.0029
DEBUG - 2022-04-22 06:40:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:18 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:19 --> Total execution time: 0.0027
DEBUG - 2022-04-22 06:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:19 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:21 --> Total execution time: 0.0021
DEBUG - 2022-04-22 06:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:21 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:22 --> Total execution time: 0.0028
DEBUG - 2022-04-22 06:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:22 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:23 --> Total execution time: 0.0022
DEBUG - 2022-04-22 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:24 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:26 --> Total execution time: 0.0029
DEBUG - 2022-04-22 06:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:26 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:35 --> Total execution time: 0.0029
DEBUG - 2022-04-22 06:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:35 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:40:36 --> Total execution time: 0.0020
DEBUG - 2022-04-22 06:40:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:40:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:40:36 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:42:20 --> Total execution time: 0.0497
DEBUG - 2022-04-22 06:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:42:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:42:20 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:42:21 --> Total execution time: 0.0031
DEBUG - 2022-04-22 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:42:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:42:21 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:53:18 --> Total execution time: 0.0397
DEBUG - 2022-04-22 06:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:54:11 --> Total execution time: 0.0055
DEBUG - 2022-04-22 06:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:54:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:54:11 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:54:17 --> Total execution time: 0.0019
DEBUG - 2022-04-22 06:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:54:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:54:18 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:54:22 --> Total execution time: 0.0059
DEBUG - 2022-04-22 06:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:54:25 --> Total execution time: 0.0025
DEBUG - 2022-04-22 06:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:54:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:54:25 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 06:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 06:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 06:58:25 --> Total execution time: 0.0402
DEBUG - 2022-04-22 06:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 06:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 06:58:25 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:02:17 --> Total execution time: 0.0399
DEBUG - 2022-04-22 08:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:02:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:02:17 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 08:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:02:18 --> Total execution time: 0.0086
DEBUG - 2022-04-22 08:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:03:03 --> Total execution time: 0.0040
DEBUG - 2022-04-22 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:03:04 --> Total execution time: 0.0025
DEBUG - 2022-04-22 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:03:04 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:03:04 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:03:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:03:04 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:18:20 --> Total execution time: 0.0466
DEBUG - 2022-04-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:20 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:20 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:20 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 08:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:18:21 --> Total execution time: 0.0025
DEBUG - 2022-04-22 08:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:21 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:22 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:22 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 08:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:18:39 --> Total execution time: 0.0021
DEBUG - 2022-04-22 08:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:39 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:39 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:39 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 08:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:18:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 08:18:44 --> Total execution time: 0.0115
DEBUG - 2022-04-22 08:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:18:48 --> Total execution time: 0.0034
DEBUG - 2022-04-22 08:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:18:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 08:18:52 --> Total execution time: 0.0258
DEBUG - 2022-04-22 08:18:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:18:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:18:52 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-22 08:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 08:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 08:19:14 --> Total execution time: 0.0022
DEBUG - 2022-04-22 08:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:19:14 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:19:14 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-22 08:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 08:19:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 08:19:14 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-22 10:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 10:18:25 --> No URI present. Default controller set.
DEBUG - 2022-04-22 10:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 10:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 10:18:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 10:18:25 --> Total execution time: 0.0382
DEBUG - 2022-04-22 11:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 11:25:07 --> No URI present. Default controller set.
DEBUG - 2022-04-22 11:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 11:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 11:25:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 11:25:07 --> Total execution time: 0.0459
DEBUG - 2022-04-22 16:42:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 16:42:12 --> No URI present. Default controller set.
DEBUG - 2022-04-22 16:42:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 16:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 16:42:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 16:42:12 --> Total execution time: 0.0427
DEBUG - 2022-04-22 16:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 16:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-22 16:42:13 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-22 18:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 18:56:09 --> No URI present. Default controller set.
DEBUG - 2022-04-22 18:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 18:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 18:56:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 18:56:09 --> Total execution time: 0.0388
DEBUG - 2022-04-22 19:19:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-22 19:19:26 --> No URI present. Default controller set.
DEBUG - 2022-04-22 19:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-22 19:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-22 19:19:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-22 19:19:26 --> Total execution time: 0.0491
