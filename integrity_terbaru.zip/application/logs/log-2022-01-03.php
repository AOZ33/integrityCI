<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-03 10:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:29:54 --> No URI present. Default controller set.
DEBUG - 2022-01-03 10:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:29:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:29:54 --> Total execution time: 0.0322
DEBUG - 2022-01-03 10:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:29:54 --> No URI present. Default controller set.
DEBUG - 2022-01-03 10:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:29:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:29:54 --> Total execution time: 0.0041
DEBUG - 2022-01-03 10:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 10:29:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-03 10:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:29:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 10:29:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-03 10:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:31:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:31:18 --> Total execution time: 0.0081
DEBUG - 2022-01-03 10:31:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:31:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:31:34 --> Total execution time: 0.0615
DEBUG - 2022-01-03 10:31:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:31:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:31:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:31:59 --> Total execution time: 0.0060
DEBUG - 2022-01-03 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:40:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:40:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:40:13 --> Total execution time: 0.0077
DEBUG - 2022-01-03 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:43:04 --> No URI present. Default controller set.
DEBUG - 2022-01-03 10:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:43:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:43:04 --> Total execution time: 0.0317
DEBUG - 2022-01-03 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:43:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 10:43:04 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-03 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:43:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 10:43:04 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-01-03 10:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:43:05 --> No URI present. Default controller set.
DEBUG - 2022-01-03 10:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:43:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:43:05 --> Total execution time: 0.0045
DEBUG - 2022-01-03 10:43:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:43:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 10:43:06 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-03 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:43:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:43:11 --> Total execution time: 0.0054
DEBUG - 2022-01-03 10:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:43:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:43:14 --> Total execution time: 0.0457
DEBUG - 2022-01-03 10:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:44:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:44:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:44:41 --> Total execution time: 0.0066
DEBUG - 2022-01-03 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:59:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 10:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 10:59:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 10:59:21 --> Total execution time: 0.0088
DEBUG - 2022-01-03 11:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 11:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 11:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 11:24:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 11:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 11:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 11:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 11:24:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 11:24:22 --> Total execution time: 0.0078
DEBUG - 2022-01-03 11:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 11:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 11:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 11:33:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 11:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 11:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 11:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 11:33:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 11:33:34 --> Total execution time: 0.0072
DEBUG - 2022-01-03 11:36:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 11:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 11:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 11:36:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 11:36:20 --> Total execution time: 0.0714
DEBUG - 2022-01-03 13:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:10:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-03 13:10:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-03 13:10:46 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-03 13:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:10:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-03 13:10:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-03 13:10:53 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-03 13:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-01-03 13:10:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-03 13:10:57 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-03 13:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:10:58 --> No URI present. Default controller set.
DEBUG - 2022-01-03 13:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:10:58 --> Total execution time: 0.0047
DEBUG - 2022-01-03 13:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:11:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:11:09 --> Total execution time: 0.0062
DEBUG - 2022-01-03 13:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:11:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:11:22 --> Total execution time: 0.0424
DEBUG - 2022-01-03 13:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:33:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-03 13:33:58 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-03 13:33:58 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-03 13:37:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-03 13:37:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-03 13:37:11 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-03 13:37:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-03 13:37:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-03 13:37:12 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-03 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:18 --> No URI present. Default controller set.
DEBUG - 2022-01-03 13:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:37:18 --> Total execution time: 0.0048
DEBUG - 2022-01-03 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 13:37:18 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-03 13:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:18 --> No URI present. Default controller set.
DEBUG - 2022-01-03 13:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:37:18 --> Total execution time: 0.0042
DEBUG - 2022-01-03 13:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:37:27 --> Total execution time: 0.0040
DEBUG - 2022-01-03 13:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 13:37:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-03 13:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:35 --> Total execution time: 0.0068
DEBUG - 2022-01-03 13:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:37:38 --> Total execution time: 0.0416
DEBUG - 2022-01-03 13:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:37:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:37:40 --> Total execution time: 0.0058
DEBUG - 2022-01-03 13:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:42:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:42:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:42:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:42:06 --> Total execution time: 0.0076
DEBUG - 2022-01-03 13:54:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:54:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:54:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:54:10 --> Total execution time: 0.0739
DEBUG - 2022-01-03 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:58:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:58:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:58:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:58:48 --> Total execution time: 0.0072
DEBUG - 2022-01-03 13:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 13:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 13:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 13:58:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 13:58:57 --> Total execution time: 0.0453
DEBUG - 2022-01-03 14:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:00:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:00:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:00:25 --> Total execution time: 0.0450
DEBUG - 2022-01-03 14:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:02:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:02:32 --> Total execution time: 0.0678
DEBUG - 2022-01-03 14:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:06:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:06:04 --> Total execution time: 0.0720
DEBUG - 2022-01-03 14:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:13:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:13:16 --> Total execution time: 0.0836
DEBUG - 2022-01-03 14:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:03 --> No URI present. Default controller set.
DEBUG - 2022-01-03 14:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:15:03 --> Total execution time: 0.0310
DEBUG - 2022-01-03 14:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:03 --> No URI present. Default controller set.
DEBUG - 2022-01-03 14:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:15:03 --> Total execution time: 0.0043
DEBUG - 2022-01-03 14:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 14:15:03 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-03 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:15:11 --> Total execution time: 0.0037
DEBUG - 2022-01-03 14:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-03 14:15:11 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-03 14:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:15:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:17 --> Total execution time: 0.0075
DEBUG - 2022-01-03 14:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:19 --> Total execution time: 0.0055
DEBUG - 2022-01-03 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:15:20 --> Total execution time: 0.0446
DEBUG - 2022-01-03 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:42 --> Total execution time: 0.0067
DEBUG - 2022-01-03 14:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:15:45 --> Total execution time: 0.0070
DEBUG - 2022-01-03 14:16:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:16:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:16:05 --> Total execution time: 0.0615
DEBUG - 2022-01-03 14:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:17:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:17:03 --> Total execution time: 0.0873
DEBUG - 2022-01-03 14:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:17:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:17:23 --> Total execution time: 0.0057
DEBUG - 2022-01-03 14:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:17:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:17:44 --> Total execution time: 0.0407
DEBUG - 2022-01-03 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:20:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:20:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:20:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:20:39 --> Total execution time: 0.0447
DEBUG - 2022-01-03 14:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:22:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:22:06 --> Total execution time: 0.0687
DEBUG - 2022-01-03 14:25:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:25:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:25:18 --> Total execution time: 0.0335
DEBUG - 2022-01-03 14:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:27:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:27:01 --> Total execution time: 0.0716
DEBUG - 2022-01-03 14:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:27:31 --> Total execution time: 0.0062
DEBUG - 2022-01-03 14:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:34:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:34:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:34:35 --> Total execution time: 0.0069
DEBUG - 2022-01-03 14:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:37:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:37:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:37:52 --> Total execution time: 0.0066
DEBUG - 2022-01-03 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:43:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 14:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 14:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 14:43:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 14:43:13 --> Total execution time: 0.0071
DEBUG - 2022-01-03 15:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:23:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:23:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:23:26 --> Total execution time: 0.0077
DEBUG - 2022-01-03 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:25:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:25:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:25:42 --> Total execution time: 0.0066
DEBUG - 2022-01-03 15:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:30:18 --> Total execution time: 0.0080
DEBUG - 2022-01-03 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:32:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:32:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:32:17 --> Total execution time: 0.0066
DEBUG - 2022-01-03 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:34:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:34:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:34:42 --> Total execution time: 0.0064
DEBUG - 2022-01-03 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:35:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:35:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:35:09 --> Total execution time: 0.0045
DEBUG - 2022-01-03 15:35:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:35:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:35:13 --> Total execution time: 0.0461
DEBUG - 2022-01-03 15:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:37:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:37:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:37:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:37:57 --> Total execution time: 0.0486
DEBUG - 2022-01-03 15:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:38:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:38:40 --> Total execution time: 0.0334
DEBUG - 2022-01-03 15:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:41:29 --> Total execution time: 0.0063
DEBUG - 2022-01-03 15:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:43:53 --> Total execution time: 0.0068
DEBUG - 2022-01-03 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:46:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 15:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 15:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 15:46:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 15:46:21 --> Total execution time: 0.0063
DEBUG - 2022-01-03 16:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:15:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:15:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:15:57 --> Total execution time: 0.0083
DEBUG - 2022-01-03 16:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:17:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:17:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:17:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:17:47 --> Total execution time: 0.0061
DEBUG - 2022-01-03 16:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:25:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:25:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:25:47 --> Total execution time: 0.0075
DEBUG - 2022-01-03 16:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:30:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:30:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:30:46 --> Total execution time: 0.0071
DEBUG - 2022-01-03 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:33:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:33:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:33:49 --> Total execution time: 0.0071
DEBUG - 2022-01-03 16:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:39:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:39:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:39:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:39:30 --> Total execution time: 0.0067
DEBUG - 2022-01-03 16:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:44:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:44:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:44:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:44:49 --> Total execution time: 0.0077
DEBUG - 2022-01-03 16:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:46:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:46:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:46:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:46:17 --> Total execution time: 0.0063
DEBUG - 2022-01-03 16:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:46:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:46:30 --> Total execution time: 0.0793
DEBUG - 2022-01-03 16:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:48:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:48:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:48:08 --> Total execution time: 0.0481
DEBUG - 2022-01-03 16:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:52:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:52:25 --> Total execution time: 0.0341
DEBUG - 2022-01-03 16:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:58:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 16:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 16:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 16:58:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 16:58:52 --> Total execution time: 0.0068
DEBUG - 2022-01-03 17:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 17:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 17:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 17:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 17:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 17:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 17:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 17:01:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 17:01:55 --> Total execution time: 0.0076
DEBUG - 2022-01-03 17:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 17:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 17:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 17:03:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 17:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 17:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 17:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 17:03:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 17:03:21 --> Total execution time: 0.0066
DEBUG - 2022-01-03 17:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 17:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 17:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 17:04:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 17:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 17:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 17:04:43 --> Total execution time: 0.0069
DEBUG - 2022-01-03 17:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-03 17:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-03 17:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-03 17:04:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-03 17:04:47 --> Total execution time: 0.0561
