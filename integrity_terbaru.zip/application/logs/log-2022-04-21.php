<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-21 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:52 --> No URI present. Default controller set.
DEBUG - 2022-04-21 03:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:26:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 03:26:52 --> Total execution time: 0.0488
DEBUG - 2022-04-21 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:26:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-21 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:26:52 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-21 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:26:52 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-21 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:26:52 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-21 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:26:52 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-21 03:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:26:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-21 03:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:53 --> No URI present. Default controller set.
DEBUG - 2022-04-21 03:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:26:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 03:26:53 --> Total execution time: 0.0022
DEBUG - 2022-04-21 03:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:26:53 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-21 03:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:26:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 03:26:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:26:55 --> Total execution time: 0.0109
DEBUG - 2022-04-21 03:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 03:28:25 --> Total execution time: 0.0022
DEBUG - 2022-04-21 03:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 03:28:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-21 03:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:28:48 --> Total execution time: 0.0046
DEBUG - 2022-04-21 03:52:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:52:01 --> Total execution time: 0.0519
DEBUG - 2022-04-21 03:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:52:04 --> Total execution time: 0.0031
DEBUG - 2022-04-21 03:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:52:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:52:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:52:12 --> Total execution time: 0.0052
DEBUG - 2022-04-21 03:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:57:55 --> Total execution time: 0.0118
DEBUG - 2022-04-21 03:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:57:58 --> Total execution time: 0.0051
DEBUG - 2022-04-21 03:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:58:01 --> Total execution time: 0.0058
DEBUG - 2022-04-21 03:59:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:59:11 --> Total execution time: 0.0036
DEBUG - 2022-04-21 03:59:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:59:13 --> Total execution time: 0.0025
DEBUG - 2022-04-21 03:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 03:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 03:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 03:59:44 --> Total execution time: 0.0060
DEBUG - 2022-04-21 04:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:00:19 --> Total execution time: 0.0043
DEBUG - 2022-04-21 04:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:00:37 --> Total execution time: 0.0048
DEBUG - 2022-04-21 04:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:00:39 --> Total execution time: 0.0022
DEBUG - 2022-04-21 04:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:00:41 --> Total execution time: 0.0023
DEBUG - 2022-04-21 04:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:00:42 --> Total execution time: 0.0031
DEBUG - 2022-04-21 04:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:00:44 --> Total execution time: 0.0029
DEBUG - 2022-04-21 04:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:00:49 --> Total execution time: 0.0059
DEBUG - 2022-04-21 04:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:01:09 --> Total execution time: 0.0048
DEBUG - 2022-04-21 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:01:31 --> Total execution time: 0.0047
DEBUG - 2022-04-21 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:01:46 --> Total execution time: 0.0032
DEBUG - 2022-04-21 04:03:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:03:42 --> Total execution time: 0.0042
DEBUG - 2022-04-21 04:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:03:43 --> Total execution time: 0.0026
DEBUG - 2022-04-21 04:03:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:03:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:03:56 --> Total execution time: 0.0023
DEBUG - 2022-04-21 04:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:03:57 --> Total execution time: 0.0030
DEBUG - 2022-04-21 04:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:25:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 04:25:19 --> Total execution time: 0.0530
DEBUG - 2022-04-21 04:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 04:25:21 --> Total execution time: 0.0037
DEBUG - 2022-04-21 04:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:25:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 04:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:25:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 04:25:24 --> Total execution time: 0.0060
DEBUG - 2022-04-21 04:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:25:28 --> Total execution time: 0.0037
DEBUG - 2022-04-21 04:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:25:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 04:25:30 --> 404 Page Not Found: Techmeet/detail_techmeet
DEBUG - 2022-04-21 04:28:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:28:52 --> Total execution time: 0.0442
DEBUG - 2022-04-21 04:31:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:31:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:31:11 --> Total execution time: 0.0407
DEBUG - 2022-04-21 04:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:33:05 --> Total execution time: 0.0859
DEBUG - 2022-04-21 04:34:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:34:04 --> Total execution time: 0.0026
DEBUG - 2022-04-21 04:35:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:35:40 --> Total execution time: 0.0025
DEBUG - 2022-04-21 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:36:33 --> Total execution time: 0.0035
DEBUG - 2022-04-21 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:36:59 --> Total execution time: 0.0034
DEBUG - 2022-04-21 04:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:37:00 --> Total execution time: 0.0027
DEBUG - 2022-04-21 04:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:37:20 --> Total execution time: 0.0034
DEBUG - 2022-04-21 04:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:37:48 --> Total execution time: 0.0029
DEBUG - 2022-04-21 04:38:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:38:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:38:32 --> Total execution time: 0.0035
DEBUG - 2022-04-21 04:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:39:28 --> Total execution time: 0.0024
DEBUG - 2022-04-21 04:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:39:29 --> Total execution time: 0.0022
DEBUG - 2022-04-21 04:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:50:33 --> Total execution time: 0.0398
DEBUG - 2022-04-21 04:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:54:45 --> Total execution time: 0.0027
DEBUG - 2022-04-21 04:56:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:56:15 --> Total execution time: 0.0036
DEBUG - 2022-04-21 04:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:57:24 --> Total execution time: 0.0025
DEBUG - 2022-04-21 04:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:57:50 --> Total execution time: 0.0027
DEBUG - 2022-04-21 04:58:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 04:58:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 04:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 04:58:35 --> Total execution time: 0.0029
DEBUG - 2022-04-21 05:00:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:00:54 --> Total execution time: 0.0026
DEBUG - 2022-04-21 05:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:01:25 --> Total execution time: 0.0030
DEBUG - 2022-04-21 05:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:18:57 --> Total execution time: 0.0401
DEBUG - 2022-04-21 05:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:19:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:19:03 --> Total execution time: 0.0108
DEBUG - 2022-04-21 05:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:19:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:19:06 --> Total execution time: 0.0024
DEBUG - 2022-04-21 05:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:20:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:20:29 --> Total execution time: 0.0041
DEBUG - 2022-04-21 05:20:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:20:31 --> Total execution time: 0.0030
DEBUG - 2022-04-21 05:20:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:20:33 --> Total execution time: 0.0028
DEBUG - 2022-04-21 05:21:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:21:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:21:29 --> Total execution time: 0.0049
DEBUG - 2022-04-21 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:23:15 --> Total execution time: 0.0025
DEBUG - 2022-04-21 05:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:24:53 --> Total execution time: 0.0459
DEBUG - 2022-04-21 05:25:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:25:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:25:31 --> Total execution time: 0.0103
DEBUG - 2022-04-21 05:25:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:25:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:25:33 --> Total execution time: 0.0032
DEBUG - 2022-04-21 05:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:28:39 --> Total execution time: 0.0023
DEBUG - 2022-04-21 05:28:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:28:42 --> Total execution time: 0.0029
DEBUG - 2022-04-21 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:29:21 --> Total execution time: 0.0028
DEBUG - 2022-04-21 05:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:29:23 --> Total execution time: 0.0051
DEBUG - 2022-04-21 05:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:31:11 --> Total execution time: 0.0420
DEBUG - 2022-04-21 05:33:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:33:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:33:28 --> Total execution time: 0.1625
DEBUG - 2022-04-21 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:33:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:33:28 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-21 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:33:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:33:29 --> Total execution time: 0.0277
DEBUG - 2022-04-21 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:33:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:33:31 --> Total execution time: 0.0060
DEBUG - 2022-04-21 05:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:55:31 --> Total execution time: 0.0490
DEBUG - 2022-04-21 05:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:55:38 --> Total execution time: 0.0036
DEBUG - 2022-04-21 05:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:57:02 --> Total execution time: 0.0478
DEBUG - 2022-04-21 05:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:57:05 --> Total execution time: 0.0025
DEBUG - 2022-04-21 05:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:58:08 --> Total execution time: 0.0024
DEBUG - 2022-04-21 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:21 --> No URI present. Default controller set.
DEBUG - 2022-04-21 05:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:58:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:58:21 --> Total execution time: 0.0030
DEBUG - 2022-04-21 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:21 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-21 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:21 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-21 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:58:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:21 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-21 05:58:21 --> UTF-8 Support Enabled
ERROR - 2022-04-21 05:58:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-21 05:58:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:21 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-21 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:22 --> No URI present. Default controller set.
DEBUG - 2022-04-21 05:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:58:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:58:22 --> Total execution time: 0.0023
DEBUG - 2022-04-21 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:22 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-21 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:22 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-21 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:22 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-21 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:22 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-21 05:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 05:58:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-21 05:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:58:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 05:58:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:58:27 --> Total execution time: 0.0029
DEBUG - 2022-04-21 05:58:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:58:30 --> Total execution time: 0.0037
DEBUG - 2022-04-21 05:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 05:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 05:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 05:58:33 --> Total execution time: 0.0039
DEBUG - 2022-04-21 06:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:00:30 --> Total execution time: 0.0041
DEBUG - 2022-04-21 06:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:01:22 --> Total execution time: 0.0052
DEBUG - 2022-04-21 06:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:01:32 --> Total execution time: 0.0029
DEBUG - 2022-04-21 06:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:01:55 --> Total execution time: 0.0038
DEBUG - 2022-04-21 06:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:02:01 --> Total execution time: 0.0041
DEBUG - 2022-04-21 06:02:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:02:01 --> Total execution time: 0.0035
DEBUG - 2022-04-21 06:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:02:06 --> Total execution time: 0.0028
DEBUG - 2022-04-21 06:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:02:29 --> Total execution time: 0.0025
DEBUG - 2022-04-21 06:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:02:42 --> Total execution time: 0.0020
DEBUG - 2022-04-21 06:02:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:02:49 --> Total execution time: 0.0047
DEBUG - 2022-04-21 06:03:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:03:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:03:02 --> Total execution time: 0.0302
DEBUG - 2022-04-21 06:03:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:03:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 06:03:03 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-21 06:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:03:07 --> Total execution time: 0.0028
DEBUG - 2022-04-21 06:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:05:21 --> Total execution time: 0.0565
DEBUG - 2022-04-21 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:05:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:05:25 --> Total execution time: 0.0043
DEBUG - 2022-04-21 06:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:05:47 --> Total execution time: 0.0048
DEBUG - 2022-04-21 06:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:05:49 --> Total execution time: 0.0045
DEBUG - 2022-04-21 06:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:07:48 --> Total execution time: 0.0458
DEBUG - 2022-04-21 06:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:07:50 --> Total execution time: 0.0042
DEBUG - 2022-04-21 06:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:07:54 --> Total execution time: 0.0045
DEBUG - 2022-04-21 06:09:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:09:48 --> Total execution time: 0.0449
DEBUG - 2022-04-21 06:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:09:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:09:50 --> Total execution time: 0.0108
DEBUG - 2022-04-21 06:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:09:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:09:52 --> Total execution time: 0.0054
DEBUG - 2022-04-21 06:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:10:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:10:15 --> Total execution time: 0.0035
DEBUG - 2022-04-21 06:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:10:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:10:22 --> Total execution time: 0.0090
DEBUG - 2022-04-21 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:12:34 --> Total execution time: 0.0407
DEBUG - 2022-04-21 06:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:12:35 --> Total execution time: 0.0025
DEBUG - 2022-04-21 06:12:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:12:38 --> Total execution time: 0.0044
DEBUG - 2022-04-21 06:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:13:06 --> Total execution time: 0.0039
DEBUG - 2022-04-21 06:13:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:13:09 --> Total execution time: 0.0045
DEBUG - 2022-04-21 06:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:13:10 --> Total execution time: 0.0023
DEBUG - 2022-04-21 06:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:13:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:13:16 --> Total execution time: 0.0149
DEBUG - 2022-04-21 06:21:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:21:31 --> Total execution time: 0.0501
DEBUG - 2022-04-21 06:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:22:23 --> Total execution time: 0.0039
DEBUG - 2022-04-21 06:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:22:31 --> Total execution time: 0.0030
DEBUG - 2022-04-21 06:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:24:02 --> Total execution time: 0.0188
DEBUG - 2022-04-21 06:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:24:20 --> Total execution time: 0.0024
DEBUG - 2022-04-21 06:24:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:24:25 --> Total execution time: 0.0044
DEBUG - 2022-04-21 06:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:24:27 --> Total execution time: 0.0026
DEBUG - 2022-04-21 06:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:24:50 --> Total execution time: 0.0029
DEBUG - 2022-04-21 06:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:27:17 --> Total execution time: 0.0419
DEBUG - 2022-04-21 06:27:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:27:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:27:21 --> Total execution time: 0.0030
DEBUG - 2022-04-21 06:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:30:59 --> Total execution time: 0.0730
DEBUG - 2022-04-21 06:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:31:02 --> Total execution time: 0.0037
DEBUG - 2022-04-21 06:45:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 06:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 06:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 06:45:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 06:45:02 --> Total execution time: 0.0570
DEBUG - 2022-04-21 07:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:06:38 --> Total execution time: 0.0428
DEBUG - 2022-04-21 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:06:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:06:39 --> Total execution time: 0.0023
DEBUG - 2022-04-21 07:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:06:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:06:40 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-21 07:06:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:06:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:06:41 --> Total execution time: 0.0022
DEBUG - 2022-04-21 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:07:01 --> Total execution time: 0.0282
DEBUG - 2022-04-21 07:07:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:07:01 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-21 07:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:07:12 --> Total execution time: 0.0134
DEBUG - 2022-04-21 07:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:07:20 --> Total execution time: 0.0037
DEBUG - 2022-04-21 07:07:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:07:35 --> Total execution time: 0.0077
DEBUG - 2022-04-21 07:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:37 --> Total execution time: 0.0031
DEBUG - 2022-04-21 07:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:41 --> Total execution time: 0.0026
DEBUG - 2022-04-21 07:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:48 --> Total execution time: 0.0059
DEBUG - 2022-04-21 07:07:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:07:50 --> Total execution time: 0.0029
DEBUG - 2022-04-21 07:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:08:35 --> Total execution time: 0.0047
DEBUG - 2022-04-21 07:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:08:37 --> Total execution time: 0.0043
DEBUG - 2022-04-21 07:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:08:39 --> Total execution time: 0.0043
DEBUG - 2022-04-21 07:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:08:41 --> Total execution time: 0.0043
DEBUG - 2022-04-21 07:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:08:43 --> Total execution time: 0.0024
DEBUG - 2022-04-21 07:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:08:45 --> Total execution time: 0.0028
DEBUG - 2022-04-21 07:08:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:08:56 --> Total execution time: 0.0026
DEBUG - 2022-04-21 07:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:08:59 --> Total execution time: 0.0022
DEBUG - 2022-04-21 07:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:09:04 --> Total execution time: 0.0043
DEBUG - 2022-04-21 07:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:00 --> No URI present. Default controller set.
DEBUG - 2022-04-21 07:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:40:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:40:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:40:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:40:01 --> Total execution time: 0.0163
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:01 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> No URI present. Default controller set.
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:40:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:40:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:40:01 --> Total execution time: 0.0063
DEBUG - 2022-04-21 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:40:28 --> Total execution time: 0.0019
DEBUG - 2022-04-21 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-21 07:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:28 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-21 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:29 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-21 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:29 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-21 07:40:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:29 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-21 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:32 --> No URI present. Default controller set.
DEBUG - 2022-04-21 07:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:40:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:40:32 --> Total execution time: 0.0019
DEBUG - 2022-04-21 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-21 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:32 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-21 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:32 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-21 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:32 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-21 07:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:40:32 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-21 07:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:49:07 --> Total execution time: 0.0449
DEBUG - 2022-04-21 07:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:52:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:52:21 --> Total execution time: 0.0677
DEBUG - 2022-04-21 07:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:52:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-21 07:52:22 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-21 07:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:55:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:55:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:55:59 --> Total execution time: 0.0036
DEBUG - 2022-04-21 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:58:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:58:13 --> Total execution time: 0.0161
DEBUG - 2022-04-21 07:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 07:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 07:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 07:59:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 07:59:22 --> Total execution time: 0.0035
DEBUG - 2022-04-21 08:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 08:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 08:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 08:01:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 08:01:18 --> Total execution time: 0.0066
DEBUG - 2022-04-21 13:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 13:57:01 --> No URI present. Default controller set.
DEBUG - 2022-04-21 13:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 13:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 13:57:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 13:57:01 --> Total execution time: 0.0418
DEBUG - 2022-04-21 16:50:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-21 16:50:30 --> No URI present. Default controller set.
DEBUG - 2022-04-21 16:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-21 16:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-21 16:50:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-21 16:50:30 --> Total execution time: 0.0379
