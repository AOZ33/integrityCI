<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-05 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:38:39 --> No URI present. Default controller set.
DEBUG - 2022-01-05 09:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:38:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:38:39 --> Total execution time: 0.0305
DEBUG - 2022-01-05 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:38:39 --> No URI present. Default controller set.
DEBUG - 2022-01-05 09:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:38:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:38:39 --> Total execution time: 0.0038
DEBUG - 2022-01-05 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 09:38:39 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 09:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:38:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 09:38:39 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-05 09:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:39:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:39:01 --> Total execution time: 0.0075
DEBUG - 2022-01-05 09:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:39:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:39:03 --> Total execution time: 0.0624
DEBUG - 2022-01-05 09:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:40:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:40:25 --> Total execution time: 0.0324
DEBUG - 2022-01-05 09:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:46:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:46:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:46:19 --> Total execution time: 0.0078
DEBUG - 2022-01-05 09:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:52:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:52:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:52:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:52:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:52:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:52:03 --> Total execution time: 0.0074
DEBUG - 2022-01-05 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:54:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:54:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:54:14 --> Total execution time: 0.0070
DEBUG - 2022-01-05 09:54:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:54:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:54:23 --> Total execution time: 0.0625
DEBUG - 2022-01-05 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:56:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:56:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:56:36 --> Total execution time: 0.0631
DEBUG - 2022-01-05 09:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:56:47 --> No URI present. Default controller set.
DEBUG - 2022-01-05 09:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:56:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:56:47 --> Total execution time: 0.0048
DEBUG - 2022-01-05 09:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:56:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 09:56:47 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 09:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:56:48 --> No URI present. Default controller set.
DEBUG - 2022-01-05 09:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:56:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:56:48 --> Total execution time: 0.0040
DEBUG - 2022-01-05 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:09 --> No URI present. Default controller set.
DEBUG - 2022-01-05 09:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:57:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:57:09 --> Total execution time: 0.0053
DEBUG - 2022-01-05 09:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 09:57:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 09:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:16 --> No URI present. Default controller set.
DEBUG - 2022-01-05 09:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:57:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:57:16 --> Total execution time: 0.0049
DEBUG - 2022-01-05 09:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 09:57:16 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 09:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 09:57:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-05 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:44 --> No URI present. Default controller set.
DEBUG - 2022-01-05 09:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:57:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:57:44 --> Total execution time: 0.0043
DEBUG - 2022-01-05 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 09:57:44 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 09:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 09:57:44 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-05 09:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:57:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:57:53 --> Total execution time: 0.0064
DEBUG - 2022-01-05 09:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:57:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:57:55 --> Total execution time: 0.0558
DEBUG - 2022-01-05 09:57:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:57:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:57:57 --> Total execution time: 0.0058
DEBUG - 2022-01-05 09:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:59:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 09:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 09:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 09:59:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 09:59:33 --> Total execution time: 0.0065
DEBUG - 2022-01-05 10:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:01:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:01:31 --> Total execution time: 0.0068
DEBUG - 2022-01-05 10:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:05:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:05:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:05:13 --> Total execution time: 0.0072
DEBUG - 2022-01-05 10:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:24:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-05 10:24:52 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-05 10:24:52 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Indira & Bagus (Putri His)', '', '14 jt His ', NULL, '4R(5) Foto Akad + 4R(5) Foto Resepsi', 'Custom 3 in 1', '20RP(1) + 16RP(3)', '16RP(1) u/Resepsi', '', 'Acara, Grup & Prewedd', '', '', '20-30m', '', '', 'Jakarta', '081319761380', '', '', 'Rp. 14.000.000', 'Rp. 2.000.000', 'Rp. 5.600.000', '', '', '', '', '', '', '2021-08-21', '07:00', '14:00', '', '', '', '', '', '', '2021-11-14', 'Resepsi', '', '', 'Kologdam', '', '2021-08-19', '2021-08-19', '', '', 'Di alihkan ke pengsir', 'Resepsi beda hari', 'Di alihkan ke akad', '', '')
DEBUG - 2022-01-05 10:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:24:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:24:52 --> Total execution time: 0.0080
DEBUG - 2022-01-05 10:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:26:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:26:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:26:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:26:40 --> Total execution time: 0.0068
DEBUG - 2022-01-05 10:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:33:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:33:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:33:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:33:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:33:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:33:32 --> Total execution time: 0.0080
DEBUG - 2022-01-05 10:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:33:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:33:34 --> Total execution time: 0.0633
DEBUG - 2022-01-05 10:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:34:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:34:24 --> Total execution time: 0.0336
DEBUG - 2022-01-05 10:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:39:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:39:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:39:14 --> Total execution time: 0.0076
DEBUG - 2022-01-05 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:56:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 10:56:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 10:56:40 --> Total execution time: 0.0081
DEBUG - 2022-01-05 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:02:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:02:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:02:57 --> Total execution time: 0.0070
DEBUG - 2022-01-05 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:12:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:12:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:12:03 --> Total execution time: 0.0075
DEBUG - 2022-01-05 11:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:16:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:16:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:16:13 --> Total execution time: 0.0071
DEBUG - 2022-01-05 11:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:19:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:19:08 --> Total execution time: 0.0336
DEBUG - 2022-01-05 11:21:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:21:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:21:19 --> Total execution time: 0.0331
DEBUG - 2022-01-05 11:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:21:45 --> No URI present. Default controller set.
DEBUG - 2022-01-05 11:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:21:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:21:45 --> Total execution time: 0.0049
DEBUG - 2022-01-05 11:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:21:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:21:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 11:21:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:21:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:21:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-05 11:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:21:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:21:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:21:59 --> Total execution time: 0.0046
DEBUG - 2022-01-05 11:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:22:52 --> No URI present. Default controller set.
DEBUG - 2022-01-05 11:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:22:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:22:52 --> Total execution time: 0.0305
DEBUG - 2022-01-05 11:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:22:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 11:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:22:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:22:53 --> Total execution time: 0.0646
DEBUG - 2022-01-05 11:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:23:02 --> No URI present. Default controller set.
DEBUG - 2022-01-05 11:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:23:02 --> Total execution time: 0.0303
DEBUG - 2022-01-05 11:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:23:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:23:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 11:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:27:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:27:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:27:33 --> Total execution time: 0.0054
DEBUG - 2022-01-05 11:27:33 --> Total execution time: 0.0917
DEBUG - 2022-01-05 11:27:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:27:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:27:36 --> Total execution time: 0.0051
DEBUG - 2022-01-05 11:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:37:04 --> No URI present. Default controller set.
DEBUG - 2022-01-05 11:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:37:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:37:04 --> Total execution time: 0.0312
DEBUG - 2022-01-05 11:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:48:47 --> No URI present. Default controller set.
DEBUG - 2022-01-05 11:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:48:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:48:47 --> Total execution time: 0.0309
DEBUG - 2022-01-05 11:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:48:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:48:47 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:48:56 --> No URI present. Default controller set.
DEBUG - 2022-01-05 11:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:48:56 --> Total execution time: 0.0046
DEBUG - 2022-01-05 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:48:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 11:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:48:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:48:56 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-05 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:49:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:49:14 --> Total execution time: 0.0068
DEBUG - 2022-01-05 11:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:49:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:49:16 --> Total execution time: 0.0637
DEBUG - 2022-01-05 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:49:23 --> Total execution time: 0.0335
DEBUG - 2022-01-05 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:49:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-05 11:49:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-05 11:49:24 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-05 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:25 --> No URI present. Default controller set.
DEBUG - 2022-01-05 11:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:49:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:49:25 --> Total execution time: 0.0047
DEBUG - 2022-01-05 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:49:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:49:25 --> Total execution time: 0.0038
DEBUG - 2022-01-05 11:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:49:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 11:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:49:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 11:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:50:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-05 11:50:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-05 11:50:00 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-05 11:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:50:48 --> No URI present. Default controller set.
DEBUG - 2022-01-05 11:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:50:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:50:48 --> Total execution time: 0.0312
DEBUG - 2022-01-05 11:50:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 11:50:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:51:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:51:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:51:41 --> Total execution time: 0.0076
DEBUG - 2022-01-05 11:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:51:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:51:43 --> Total execution time: 0.0640
DEBUG - 2022-01-05 11:53:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 11:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 11:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 11:53:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 11:53:51 --> Total execution time: 0.0343
DEBUG - 2022-01-05 12:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:00:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:00:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:00:10 --> Total execution time: 0.0076
DEBUG - 2022-01-05 12:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:07:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:07:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:07:57 --> Total execution time: 0.0070
DEBUG - 2022-01-05 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:33:41 --> No URI present. Default controller set.
DEBUG - 2022-01-05 12:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:33:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:33:41 --> Total execution time: 0.0317
DEBUG - 2022-01-05 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 12:33:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 12:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:33:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 12:33:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-05 12:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:33:46 --> No URI present. Default controller set.
DEBUG - 2022-01-05 12:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:33:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:33:46 --> Total execution time: 0.0043
DEBUG - 2022-01-05 12:33:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:33:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 12:33:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-05 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:33:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:33:53 --> Total execution time: 0.0075
DEBUG - 2022-01-05 12:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:34:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:34:08 --> Total execution time: 0.0871
DEBUG - 2022-01-05 12:35:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:35:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-05 12:35:00 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-01-05 12:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 12:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 12:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 12:35:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 12:35:04 --> Total execution time: 0.1149
DEBUG - 2022-01-05 13:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:11:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:11:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:11:44 --> Total execution time: 0.0080
DEBUG - 2022-01-05 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:14:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:14:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:14:06 --> Total execution time: 0.0061
DEBUG - 2022-01-05 13:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:16:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:16:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:16:02 --> Total execution time: 0.0065
DEBUG - 2022-01-05 13:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:17:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:17:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:17:03 --> Total execution time: 0.0064
DEBUG - 2022-01-05 13:22:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:22:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:22:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:22:21 --> Total execution time: 0.0070
DEBUG - 2022-01-05 13:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:25:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:25:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:25:19 --> Total execution time: 0.0065
DEBUG - 2022-01-05 13:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:28:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:28:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:28:44 --> Total execution time: 0.0073
DEBUG - 2022-01-05 13:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:33:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:33:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:33:04 --> Total execution time: 0.0070
DEBUG - 2022-01-05 13:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:46:37 --> Total execution time: 0.0072
DEBUG - 2022-01-05 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:48:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:48:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:48:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:48:03 --> Total execution time: 0.0063
DEBUG - 2022-01-05 13:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:53:40 --> Total execution time: 0.0072
DEBUG - 2022-01-05 13:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:56:02 --> Total execution time: 0.0061
DEBUG - 2022-01-05 13:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:57:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:57:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 13:57:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 13:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 13:57:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 13:57:58 --> Total execution time: 0.0064
DEBUG - 2022-01-05 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:00:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:00:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:00:02 --> Total execution time: 0.0067
DEBUG - 2022-01-05 14:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:06:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:06:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:06:09 --> Total execution time: 0.0070
DEBUG - 2022-01-05 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:07:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:07:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:07:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:07:54 --> Total execution time: 0.0064
DEBUG - 2022-01-05 14:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:08:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:08:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:08:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:08:54 --> Total execution time: 0.0063
DEBUG - 2022-01-05 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:11:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:11:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:11:15 --> Total execution time: 0.0064
DEBUG - 2022-01-05 14:12:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:12:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:12:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:12:51 --> Total execution time: 0.0061
DEBUG - 2022-01-05 14:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:13:59 --> Total execution time: 0.0070
DEBUG - 2022-01-05 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:15:42 --> Total execution time: 0.0073
DEBUG - 2022-01-05 14:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:17:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:17:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:17:18 --> Total execution time: 0.0077
DEBUG - 2022-01-05 14:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:19:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:19:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:19:42 --> Total execution time: 0.0058
DEBUG - 2022-01-05 14:19:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:19:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:19:45 --> Total execution time: 0.0678
DEBUG - 2022-01-05 14:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:20:28 --> Total execution time: 0.0327
DEBUG - 2022-01-05 14:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:27:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:27:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:27:20 --> Total execution time: 0.0124
DEBUG - 2022-01-05 14:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:29:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:29:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:29:28 --> Total execution time: 0.0066
DEBUG - 2022-01-05 14:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:32:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:32:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:32:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:32:17 --> Total execution time: 0.0070
DEBUG - 2022-01-05 14:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:34:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:34:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:34:00 --> Total execution time: 0.0062
DEBUG - 2022-01-05 14:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:37:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:37:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:37:15 --> Total execution time: 0.0065
DEBUG - 2022-01-05 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:38:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:38:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:38:37 --> Total execution time: 0.0068
DEBUG - 2022-01-05 14:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:41:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:41:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:41:32 --> Total execution time: 0.0075
DEBUG - 2022-01-05 14:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:43:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:43:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:43:03 --> Total execution time: 0.0062
DEBUG - 2022-01-05 14:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:47:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:47:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:47:22 --> Total execution time: 0.0073
DEBUG - 2022-01-05 14:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:50:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:50:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:50:09 --> Total execution time: 0.0075
DEBUG - 2022-01-05 14:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:51:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:51:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:51:46 --> Total execution time: 0.0063
DEBUG - 2022-01-05 14:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:56:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:56:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:56:35 --> Total execution time: 0.0083
DEBUG - 2022-01-05 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:57:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-05 14:57:52 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-05 14:57:52 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Hapsari K. Diah & Hafizh Adhitama', '', 'Lamaran 5.75jt', NULL, '', '1 in 1', '', '', '', 'Lamaran', '', '', '2-3m', '', '', '', '', '', '', 'Rp. 5.750.000', 'Rp. 1.150.000', '', '', '2021-11-28', '10:00', 'Hotel Malaka', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2021-09-11', '', '', '', '', '', '', '', '')
DEBUG - 2022-01-05 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 14:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 14:57:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 14:57:52 --> Total execution time: 0.0065
DEBUG - 2022-01-05 15:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:04:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:04:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:04:18 --> Total execution time: 0.0073
DEBUG - 2022-01-05 15:05:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:05:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:05:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:05:28 --> Total execution time: 0.0068
DEBUG - 2022-01-05 15:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:09:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:09:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:09:52 --> Total execution time: 0.0075
DEBUG - 2022-01-05 15:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:12:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:12:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:12:24 --> Total execution time: 0.0073
DEBUG - 2022-01-05 15:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:14:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:14:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:14:19 --> Total execution time: 0.0075
DEBUG - 2022-01-05 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:16:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:16:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:16:24 --> Total execution time: 0.0068
DEBUG - 2022-01-05 15:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:21:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:21:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:21:51 --> Total execution time: 0.0071
DEBUG - 2022-01-05 15:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:21:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:21:57 --> Total execution time: 0.0713
DEBUG - 2022-01-05 15:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:26:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:26:42 --> Total execution time: 0.0338
DEBUG - 2022-01-05 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:28:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:28:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:28:07 --> Total execution time: 0.0069
DEBUG - 2022-01-05 15:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:28:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:28:10 --> Total execution time: 0.0746
DEBUG - 2022-01-05 15:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:29:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:29:18 --> Total execution time: 0.0331
DEBUG - 2022-01-05 15:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:52:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:52:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:52:08 --> Total execution time: 0.0084
DEBUG - 2022-01-05 15:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:57:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 15:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 15:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 15:57:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 15:57:42 --> Total execution time: 0.0070
DEBUG - 2022-01-05 16:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:06:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:06:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:06:39 --> Total execution time: 0.0081
DEBUG - 2022-01-05 16:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:10:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:10:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:10:45 --> Total execution time: 0.0079
DEBUG - 2022-01-05 16:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:15:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:15:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:15:36 --> Total execution time: 0.0081
DEBUG - 2022-01-05 16:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:19:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:19:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:19:15 --> Total execution time: 0.0068
DEBUG - 2022-01-05 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:24:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:24:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:24:22 --> Total execution time: 0.0071
DEBUG - 2022-01-05 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:28:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:28:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:28:53 --> Total execution time: 0.0068
DEBUG - 2022-01-05 16:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:32:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:32:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:32:26 --> Total execution time: 0.0071
DEBUG - 2022-01-05 16:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:35:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:35:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:35:23 --> Total execution time: 0.0072
DEBUG - 2022-01-05 16:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:37:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:37:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:37:46 --> Total execution time: 0.0063
DEBUG - 2022-01-05 16:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:37:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:37:48 --> Total execution time: 0.0753
DEBUG - 2022-01-05 16:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:39:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:39:47 --> Total execution time: 0.0333
DEBUG - 2022-01-05 16:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:43:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:43:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:43:23 --> Total execution time: 0.0077
DEBUG - 2022-01-05 16:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:45:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:45:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:45:53 --> Total execution time: 0.0066
DEBUG - 2022-01-05 16:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:50:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:50:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:50:47 --> Total execution time: 0.0073
DEBUG - 2022-01-05 16:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:54:20 --> Total execution time: 0.0067
DEBUG - 2022-01-05 16:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 16:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 16:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 16:54:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 16:54:23 --> Total execution time: 0.0759
DEBUG - 2022-01-05 18:25:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-05 18:25:45 --> No URI present. Default controller set.
DEBUG - 2022-01-05 18:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-05 18:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-05 18:25:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-05 18:25:45 --> Total execution time: 0.0315
