<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-12 07:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 07:02:28 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 07:02:28 --> No URI present. Default controller set.
DEBUG - 2022-06-12 07:02:28 --> No URI present. Default controller set.
DEBUG - 2022-06-12 07:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 07:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 07:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 07:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 07:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 07:02:28 --> Total execution time: 0.0496
DEBUG - 2022-06-12 07:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 07:02:28 --> Total execution time: 0.0501
DEBUG - 2022-06-12 07:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 07:02:29 --> No URI present. Default controller set.
DEBUG - 2022-06-12 07:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 07:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 07:02:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 07:02:29 --> Total execution time: 0.0016
DEBUG - 2022-06-12 07:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 07:02:29 --> No URI present. Default controller set.
DEBUG - 2022-06-12 07:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 07:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 07:02:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 07:02:29 --> Total execution time: 0.0018
DEBUG - 2022-06-12 17:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 17:56:39 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 17:56:39 --> No URI present. Default controller set.
DEBUG - 2022-06-12 17:56:39 --> No URI present. Default controller set.
DEBUG - 2022-06-12 17:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 17:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 17:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 17:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 17:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 17:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 17:56:39 --> Total execution time: 0.0366
DEBUG - 2022-06-12 17:56:39 --> Total execution time: 0.0366
DEBUG - 2022-06-12 17:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 17:56:42 --> No URI present. Default controller set.
DEBUG - 2022-06-12 17:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 17:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 17:56:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 17:56:42 --> Total execution time: 0.0015
DEBUG - 2022-06-12 17:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 17:56:42 --> No URI present. Default controller set.
DEBUG - 2022-06-12 17:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 17:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 17:56:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 17:56:42 --> Total execution time: 0.0019
DEBUG - 2022-06-12 18:59:36 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 18:59:36 --> No URI present. Default controller set.
DEBUG - 2022-06-12 18:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 18:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 18:59:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 18:59:36 --> Total execution time: 0.0403
DEBUG - 2022-06-12 18:59:37 --> UTF-8 Support Enabled
DEBUG - 2022-06-12 18:59:37 --> No URI present. Default controller set.
DEBUG - 2022-06-12 18:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-06-12 18:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-06-12 18:59:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-06-12 18:59:37 --> Total execution time: 0.0022
