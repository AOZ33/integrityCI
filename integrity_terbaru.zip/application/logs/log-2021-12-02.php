<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-02 03:23:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:23:59 --> No URI present. Default controller set.
DEBUG - 2021-12-02 03:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:00 --> Total execution time: 0.1575
DEBUG - 2021-12-02 03:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:01 --> Total execution time: 0.0706
DEBUG - 2021-12-02 03:24:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:02 --> Total execution time: 0.0487
DEBUG - 2021-12-02 03:24:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 03:24:02 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:24:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:24:02 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:24:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:24:02 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:24:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 03:24:02 --> Total execution time: 0.0589
DEBUG - 2021-12-02 03:24:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:03 --> Total execution time: 0.0411
DEBUG - 2021-12-02 03:24:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:04 --> Total execution time: 0.0786
DEBUG - 2021-12-02 03:24:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:13 --> Total execution time: 0.0483
DEBUG - 2021-12-02 03:24:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 03:24:19 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-02 03:24:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:20 --> Total execution time: 0.0379
DEBUG - 2021-12-02 03:24:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:24:40 --> Total execution time: 0.0507
DEBUG - 2021-12-02 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:25:04 --> Total execution time: 0.0521
DEBUG - 2021-12-02 03:25:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 03:25:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:25:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:25:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:25:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 03:25:04 --> Total execution time: 0.0410
DEBUG - 2021-12-02 03:25:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:25:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:25:05 --> Total execution time: 0.0463
DEBUG - 2021-12-02 03:26:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:26:36 --> Total execution time: 0.0414
DEBUG - 2021-12-02 03:26:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:26:38 --> Total execution time: 0.0428
DEBUG - 2021-12-02 03:26:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 03:26:43 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-02 03:26:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:26:45 --> Total execution time: 0.0628
DEBUG - 2021-12-02 03:28:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:28:57 --> Total execution time: 0.0469
DEBUG - 2021-12-02 03:28:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:28:58 --> Total execution time: 0.0470
DEBUG - 2021-12-02 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:29:09 --> Total execution time: 0.0480
DEBUG - 2021-12-02 03:29:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:29:45 --> Total execution time: 0.0428
DEBUG - 2021-12-02 03:31:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:31:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:31:56 --> Total execution time: 0.0407
DEBUG - 2021-12-02 03:32:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:32:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:32:01 --> Total execution time: 0.0538
DEBUG - 2021-12-02 03:33:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:33:52 --> Total execution time: 0.0474
DEBUG - 2021-12-02 03:34:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:34:11 --> Total execution time: 0.0284
DEBUG - 2021-12-02 03:34:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:34:32 --> Total execution time: 0.0425
DEBUG - 2021-12-02 03:43:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:43:55 --> Total execution time: 0.0421
DEBUG - 2021-12-02 03:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:46:05 --> Total execution time: 0.0393
DEBUG - 2021-12-02 03:46:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:46:06 --> Total execution time: 0.0513
DEBUG - 2021-12-02 03:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:46:19 --> Total execution time: 0.0517
DEBUG - 2021-12-02 03:54:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:54:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:54:43 --> Total execution time: 0.0524
DEBUG - 2021-12-02 03:54:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 03:54:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:54:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:54:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:54:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:54:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:54:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 03:54:45 --> Total execution time: 0.0520
DEBUG - 2021-12-02 03:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:54:46 --> Total execution time: 0.0515
DEBUG - 2021-12-02 03:54:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:54:48 --> Total execution time: 0.0410
DEBUG - 2021-12-02 03:55:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 03:55:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:55:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:55:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:55:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:55:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:55:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 03:55:32 --> Total execution time: 0.0552
DEBUG - 2021-12-02 03:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 03:56:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:56:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:56:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:56:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:56:35 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 03:56:35 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 03:56:35 --> Total execution time: 0.0424
DEBUG - 2021-12-02 03:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 03:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 03:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 03:56:36 --> Total execution time: 0.0279
DEBUG - 2021-12-02 04:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:08:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:08:55 --> Total execution time: 0.0426
DEBUG - 2021-12-02 04:09:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:10 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:09:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-12-02 04:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:48 --> No URI present. Default controller set.
DEBUG - 2021-12-02 04:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:09:48 --> Total execution time: 0.0258
DEBUG - 2021-12-02 04:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:09:50 --> Total execution time: 0.0428
DEBUG - 2021-12-02 04:10:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:08 --> Total execution time: 0.0520
DEBUG - 2021-12-02 04:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:10 --> Total execution time: 0.0480
DEBUG - 2021-12-02 04:10:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:10:11 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:11 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:11 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 04:10:11 --> Total execution time: 0.0480
DEBUG - 2021-12-02 04:10:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:11 --> Total execution time: 0.0401
DEBUG - 2021-12-02 04:10:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:10:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:10:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 04:10:12 --> Total execution time: 0.0428
DEBUG - 2021-12-02 04:10:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:13 --> Total execution time: 0.0442
DEBUG - 2021-12-02 04:10:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:15 --> Total execution time: 0.0438
DEBUG - 2021-12-02 04:10:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:16 --> Total execution time: 0.0423
DEBUG - 2021-12-02 04:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:18 --> Total execution time: 0.0411
DEBUG - 2021-12-02 04:10:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:50 --> Total execution time: 0.0416
DEBUG - 2021-12-02 04:10:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:55 --> Total execution time: 0.0237
DEBUG - 2021-12-02 04:10:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:56 --> Total execution time: 0.0340
DEBUG - 2021-12-02 04:10:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:10:57 --> Total execution time: 0.0504
DEBUG - 2021-12-02 04:11:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:11:05 --> No URI present. Default controller set.
DEBUG - 2021-12-02 04:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:11:05 --> Total execution time: 0.0257
DEBUG - 2021-12-02 04:11:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:11:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:11:36 --> Total execution time: 0.0430
DEBUG - 2021-12-02 04:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:19:32 --> Total execution time: 0.0441
DEBUG - 2021-12-02 04:19:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:19:33 --> Total execution time: 0.0491
DEBUG - 2021-12-02 04:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:19:50 --> Total execution time: 0.0495
DEBUG - 2021-12-02 04:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:20:58 --> Total execution time: 0.0359
DEBUG - 2021-12-02 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:20:59 --> Total execution time: 0.0375
DEBUG - 2021-12-02 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:00 --> Total execution time: 0.0423
DEBUG - 2021-12-02 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:00 --> Total execution time: 0.0358
DEBUG - 2021-12-02 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:00 --> Total execution time: 0.0431
DEBUG - 2021-12-02 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:00 --> Total execution time: 0.0480
DEBUG - 2021-12-02 04:21:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:01 --> Total execution time: 0.0429
DEBUG - 2021-12-02 04:21:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:02 --> Total execution time: 0.0410
DEBUG - 2021-12-02 04:21:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:04 --> Total execution time: 0.0496
DEBUG - 2021-12-02 04:21:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:07 --> Total execution time: 0.0382
DEBUG - 2021-12-02 04:21:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:21:08 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:08 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:08 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 04:21:08 --> Total execution time: 0.0561
DEBUG - 2021-12-02 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:21:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:21:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 04:21:40 --> Total execution time: 0.0320
DEBUG - 2021-12-02 04:21:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:41 --> Total execution time: 0.0418
DEBUG - 2021-12-02 04:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:42 --> Total execution time: 0.0280
DEBUG - 2021-12-02 04:21:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:43 --> Total execution time: 0.0416
DEBUG - 2021-12-02 04:21:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:43 --> Total execution time: 0.0448
DEBUG - 2021-12-02 04:21:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:44 --> Total execution time: 0.0402
DEBUG - 2021-12-02 04:21:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:52 --> Total execution time: 0.0287
DEBUG - 2021-12-02 04:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:21:59 --> Total execution time: 0.0437
DEBUG - 2021-12-02 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:22:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:22:01 --> Total execution time: 0.0447
DEBUG - 2021-12-02 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:22:14 --> Total execution time: 0.0524
DEBUG - 2021-12-02 04:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:22:15 --> Total execution time: 0.0489
DEBUG - 2021-12-02 04:22:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:22:34 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:22:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:22:34 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:22:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:22:34 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:22:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 04:22:34 --> Total execution time: 0.0448
DEBUG - 2021-12-02 04:22:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:22:34 --> Total execution time: 0.0431
DEBUG - 2021-12-02 04:22:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:22:56 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-02 04:22:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:22:58 --> Total execution time: 0.0415
DEBUG - 2021-12-02 04:22:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:22:58 --> Total execution time: 0.0391
DEBUG - 2021-12-02 04:23:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:23:32 --> Total execution time: 0.0516
DEBUG - 2021-12-02 04:23:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:23:40 --> Total execution time: 0.0477
DEBUG - 2021-12-02 04:23:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:23:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 04:23:40 --> Total execution time: 0.0429
DEBUG - 2021-12-02 04:23:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:23:41 --> Total execution time: 0.0468
DEBUG - 2021-12-02 04:23:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:23:44 --> Total execution time: 0.0512
DEBUG - 2021-12-02 04:23:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:23:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 04:23:45 --> Total execution time: 0.0413
DEBUG - 2021-12-02 04:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:23:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 152
ERROR - 2021-12-02 04:23:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 152
DEBUG - 2021-12-02 04:23:46 --> Total execution time: 0.0448
DEBUG - 2021-12-02 04:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:23:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:23:47 --> Total execution time: 0.0413
DEBUG - 2021-12-02 04:23:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:23:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:23:49 --> Total execution time: 0.0254
DEBUG - 2021-12-02 04:24:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:24:11 --> Total execution time: 0.0440
DEBUG - 2021-12-02 04:24:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:24:23 --> Total execution time: 0.0478
DEBUG - 2021-12-02 04:24:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:24:27 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:24:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:24:27 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:24:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:24:27 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:24:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 04:24:28 --> Total execution time: 0.0550
DEBUG - 2021-12-02 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 04:28:31 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:28:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:28:31 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:28:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:28:31 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 04:28:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 04:28:31 --> Total execution time: 0.0546
DEBUG - 2021-12-02 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:28:31 --> Total execution time: 0.0494
DEBUG - 2021-12-02 04:30:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:30:08 --> Total execution time: 0.0459
DEBUG - 2021-12-02 04:30:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:30:33 --> Total execution time: 0.0451
DEBUG - 2021-12-02 04:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:33:42 --> Total execution time: 0.0475
DEBUG - 2021-12-02 04:36:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:36:08 --> Total execution time: 0.0470
DEBUG - 2021-12-02 04:37:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:37:16 --> Total execution time: 0.0448
DEBUG - 2021-12-02 04:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:38:24 --> Total execution time: 0.0459
DEBUG - 2021-12-02 04:38:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:38:39 --> Total execution time: 0.0519
DEBUG - 2021-12-02 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:39:39 --> Total execution time: 0.0533
DEBUG - 2021-12-02 04:40:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:40:08 --> Total execution time: 0.0377
DEBUG - 2021-12-02 04:40:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:40:23 --> Total execution time: 0.0417
DEBUG - 2021-12-02 04:41:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:41:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:42:00 --> Total execution time: 0.0493
DEBUG - 2021-12-02 04:42:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:42:20 --> Total execution time: 0.0476
DEBUG - 2021-12-02 04:42:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:42:26 --> Total execution time: 0.0448
DEBUG - 2021-12-02 04:44:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:44:31 --> Total execution time: 0.0525
DEBUG - 2021-12-02 04:46:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:46:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:46:04 --> Total execution time: 0.0492
DEBUG - 2021-12-02 04:46:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:46:28 --> Total execution time: 0.0393
DEBUG - 2021-12-02 04:46:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:46:48 --> Total execution time: 0.0504
DEBUG - 2021-12-02 04:47:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 04:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 04:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 04:47:15 --> Total execution time: 0.0279
DEBUG - 2021-12-02 05:17:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 05:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 05:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 05:17:16 --> Total execution time: 0.4967
DEBUG - 2021-12-02 05:17:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 05:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 05:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 05:17:40 --> Total execution time: 0.0485
DEBUG - 2021-12-02 05:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 05:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 05:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 05:19:08 --> Total execution time: 0.0403
DEBUG - 2021-12-02 06:01:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:01:18 --> Total execution time: 0.0541
DEBUG - 2021-12-02 06:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:01:46 --> Total execution time: 0.0433
DEBUG - 2021-12-02 06:01:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:01:57 --> Total execution time: 0.0428
DEBUG - 2021-12-02 06:02:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:02:39 --> Total execution time: 0.0488
DEBUG - 2021-12-02 06:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:03:21 --> Total execution time: 0.0293
DEBUG - 2021-12-02 06:04:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:47 --> Total execution time: 0.0500
DEBUG - 2021-12-02 06:04:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:53 --> Total execution time: 0.0508
DEBUG - 2021-12-02 06:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:54 --> Total execution time: 0.0426
DEBUG - 2021-12-02 06:04:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:57 --> Total execution time: 0.0285
DEBUG - 2021-12-02 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:04:59 --> Total execution time: 0.0412
DEBUG - 2021-12-02 06:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:05:00 --> Total execution time: 0.0448
DEBUG - 2021-12-02 06:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 06:05:25 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:25 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:25 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 06:05:25 --> Total execution time: 0.1117
DEBUG - 2021-12-02 06:05:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:05:27 --> Total execution time: 0.0482
DEBUG - 2021-12-02 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 06:05:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:37 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:37 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 06:05:37 --> Total execution time: 0.0319
DEBUG - 2021-12-02 06:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:05:37 --> Total execution time: 0.0384
DEBUG - 2021-12-02 06:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 06:05:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:39 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:05:39 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 06:05:39 --> Total execution time: 0.0556
DEBUG - 2021-12-02 06:05:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:05:40 --> Total execution time: 0.0512
DEBUG - 2021-12-02 06:06:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:06:14 --> Total execution time: 0.0277
DEBUG - 2021-12-02 06:06:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:06:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:06:16 --> Total execution time: 0.0428
DEBUG - 2021-12-02 06:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:06:43 --> Total execution time: 0.0421
DEBUG - 2021-12-02 06:07:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:07:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 06:07:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 06:07:49 --> Total execution time: 0.0489
DEBUG - 2021-12-02 06:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:07:50 --> Total execution time: 0.0272
DEBUG - 2021-12-02 06:07:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 06:07:51 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:51 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:51 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 06:07:51 --> Total execution time: 0.0546
DEBUG - 2021-12-02 06:07:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:07:52 --> Total execution time: 0.0438
DEBUG - 2021-12-02 06:07:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 06:07:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:07:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 06:07:56 --> Total execution time: 0.0433
DEBUG - 2021-12-02 06:08:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:08:05 --> Total execution time: 0.0394
DEBUG - 2021-12-02 06:08:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:08:05 --> Total execution time: 0.0382
DEBUG - 2021-12-02 06:11:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:11:32 --> Total execution time: 0.0415
DEBUG - 2021-12-02 06:11:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 06:11:33 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:11:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:11:33 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:11:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:11:33 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 06:11:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 06:11:33 --> Total execution time: 0.0550
DEBUG - 2021-12-02 06:11:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:11:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:11:33 --> Total execution time: 0.0282
DEBUG - 2021-12-02 06:11:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:11:34 --> Total execution time: 0.0520
DEBUG - 2021-12-02 06:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:13:54 --> Total execution time: 0.0526
DEBUG - 2021-12-02 06:13:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:13:56 --> Total execution time: 0.0438
DEBUG - 2021-12-02 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:14:25 --> Total execution time: 0.0268
DEBUG - 2021-12-02 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:14:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:14:39 --> Total execution time: 0.0469
DEBUG - 2021-12-02 06:15:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:15:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:15:48 --> Total execution time: 0.0360
DEBUG - 2021-12-02 06:15:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:15:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:15:50 --> Total execution time: 0.0459
DEBUG - 2021-12-02 06:15:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:15:51 --> Total execution time: 0.0464
DEBUG - 2021-12-02 06:16:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:16:23 --> Total execution time: 0.0392
DEBUG - 2021-12-02 06:16:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:16:49 --> Total execution time: 0.0253
DEBUG - 2021-12-02 06:16:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:16:51 --> Total execution time: 0.0407
DEBUG - 2021-12-02 06:24:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:24:35 --> Total execution time: 0.0379
DEBUG - 2021-12-02 06:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:31:37 --> Total execution time: 0.0367
DEBUG - 2021-12-02 06:32:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:32:05 --> Total execution time: 0.0455
DEBUG - 2021-12-02 06:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:33:04 --> Total execution time: 0.0381
DEBUG - 2021-12-02 06:38:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:38:02 --> Total execution time: 0.0478
DEBUG - 2021-12-02 06:38:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:38:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:38:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:38:03 --> Total execution time: 0.0486
DEBUG - 2021-12-02 06:38:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:38:06 --> Total execution time: 0.0455
DEBUG - 2021-12-02 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:38:08 --> Total execution time: 0.0497
DEBUG - 2021-12-02 06:38:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:38:10 --> Total execution time: 0.0484
DEBUG - 2021-12-02 06:38:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:38:11 --> Total execution time: 0.0501
DEBUG - 2021-12-02 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:38:12 --> Total execution time: 0.0469
DEBUG - 2021-12-02 06:39:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:05 --> Total execution time: 0.0488
DEBUG - 2021-12-02 06:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:06 --> Total execution time: 0.0430
DEBUG - 2021-12-02 06:39:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:07 --> Total execution time: 0.0398
DEBUG - 2021-12-02 06:39:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:08 --> Total execution time: 0.0349
DEBUG - 2021-12-02 06:39:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:09 --> Total execution time: 0.0475
DEBUG - 2021-12-02 06:39:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:10 --> Total execution time: 0.0258
DEBUG - 2021-12-02 06:39:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:10 --> Total execution time: 0.0423
DEBUG - 2021-12-02 06:39:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:11 --> Total execution time: 0.0468
DEBUG - 2021-12-02 06:39:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:31 --> Total execution time: 0.0251
DEBUG - 2021-12-02 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:32 --> Total execution time: 0.0426
DEBUG - 2021-12-02 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:32 --> Total execution time: 0.0394
DEBUG - 2021-12-02 06:39:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:33 --> Total execution time: 0.0409
DEBUG - 2021-12-02 06:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:34 --> Total execution time: 0.0379
DEBUG - 2021-12-02 06:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:34 --> Total execution time: 0.0453
DEBUG - 2021-12-02 06:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:35 --> Total execution time: 0.0447
DEBUG - 2021-12-02 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:37 --> Total execution time: 0.0456
DEBUG - 2021-12-02 06:39:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:38 --> Total execution time: 0.0481
DEBUG - 2021-12-02 06:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:39:40 --> Total execution time: 0.0403
DEBUG - 2021-12-02 06:47:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:47:45 --> Total execution time: 0.0424
DEBUG - 2021-12-02 06:49:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:49:47 --> Total execution time: 0.0450
DEBUG - 2021-12-02 06:50:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 06:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 06:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 06:50:12 --> Total execution time: 0.0261
DEBUG - 2021-12-02 07:45:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 07:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 07:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 07:45:38 --> Total execution time: 0.0288
DEBUG - 2021-12-02 07:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 07:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 07:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 07:50:51 --> Total execution time: 0.0448
DEBUG - 2021-12-02 07:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 07:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 07:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 07:55:06 --> Total execution time: 0.0390
DEBUG - 2021-12-02 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 07:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 07:59:50 --> Total execution time: 0.0453
DEBUG - 2021-12-02 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:00:02 --> Total execution time: 0.0434
DEBUG - 2021-12-02 08:00:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:00:30 --> Total execution time: 0.0504
DEBUG - 2021-12-02 08:01:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:01:47 --> Total execution time: 0.0393
DEBUG - 2021-12-02 08:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:01:54 --> Total execution time: 0.0386
DEBUG - 2021-12-02 08:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:01:55 --> Total execution time: 0.0414
DEBUG - 2021-12-02 08:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:02:00 --> Total execution time: 0.0251
DEBUG - 2021-12-02 08:02:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:02:21 --> Total execution time: 0.0406
DEBUG - 2021-12-02 08:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:02:33 --> Total execution time: 0.0391
DEBUG - 2021-12-02 08:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:02:43 --> Total execution time: 0.0403
DEBUG - 2021-12-02 08:02:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:02:50 --> Total execution time: 0.0263
DEBUG - 2021-12-02 08:36:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:36:19 --> Total execution time: 0.0474
DEBUG - 2021-12-02 08:37:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 08:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 08:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 08:37:31 --> Total execution time: 0.0467
DEBUG - 2021-12-02 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:05:27 --> Total execution time: 0.0418
DEBUG - 2021-12-02 09:08:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:08:24 --> Total execution time: 0.0483
DEBUG - 2021-12-02 09:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:10:36 --> Total execution time: 0.0481
DEBUG - 2021-12-02 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:19:30 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:19:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:19:30 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:19:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:19:30 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:19:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:19:30 --> Total execution time: 0.0361
DEBUG - 2021-12-02 09:19:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:19:33 --> Total execution time: 0.0418
DEBUG - 2021-12-02 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:21:56 --> Total execution time: 0.0414
DEBUG - 2021-12-02 09:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:21:58 --> Total execution time: 0.0468
DEBUG - 2021-12-02 09:22:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:22:31 --> Total execution time: 0.0422
DEBUG - 2021-12-02 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:22:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:22:44 --> Total execution time: 0.0507
DEBUG - 2021-12-02 09:22:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:22:47 --> Total execution time: 0.0507
DEBUG - 2021-12-02 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:22:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:22:52 --> Total execution time: 0.0585
DEBUG - 2021-12-02 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:22:53 --> Total execution time: 0.0434
DEBUG - 2021-12-02 09:22:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:22:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:22:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:22:54 --> Total execution time: 0.0421
DEBUG - 2021-12-02 09:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:22:57 --> Total execution time: 0.0375
DEBUG - 2021-12-02 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:23:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:23:52 --> Total execution time: 0.0423
DEBUG - 2021-12-02 09:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:23:53 --> Total execution time: 0.0476
DEBUG - 2021-12-02 09:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:24:18 --> Total execution time: 0.0427
DEBUG - 2021-12-02 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:24:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:24:21 --> Total execution time: 0.0483
DEBUG - 2021-12-02 09:24:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:24:21 --> Total execution time: 0.0475
DEBUG - 2021-12-02 09:24:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:24:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:24:24 --> Total execution time: 0.0451
DEBUG - 2021-12-02 09:24:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:24:35 --> Total execution time: 0.0302
DEBUG - 2021-12-02 09:24:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:24:54 --> Total execution time: 0.0510
DEBUG - 2021-12-02 09:24:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:24:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:55 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:24:55 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:24:55 --> Total execution time: 0.0423
DEBUG - 2021-12-02 09:24:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:24:55 --> Total execution time: 0.0389
DEBUG - 2021-12-02 09:24:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:24:56 --> Total execution time: 0.0427
DEBUG - 2021-12-02 09:25:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:25:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:09 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:25:09 --> Total execution time: 0.0470
DEBUG - 2021-12-02 09:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:25:15 --> Total execution time: 0.0460
DEBUG - 2021-12-02 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:25:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:25:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:25:46 --> Total execution time: 0.0476
DEBUG - 2021-12-02 09:25:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:25:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:25:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:25:47 --> Total execution time: 0.0510
DEBUG - 2021-12-02 09:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:25:54 --> Total execution time: 0.0412
DEBUG - 2021-12-02 09:26:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:26:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:26:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:26:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:26:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:26:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:26:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:26:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:26:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:26:12 --> Total execution time: 0.0511
DEBUG - 2021-12-02 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:26:13 --> Total execution time: 0.0463
DEBUG - 2021-12-02 09:26:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:26:57 --> Total execution time: 0.0507
DEBUG - 2021-12-02 09:27:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:27:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:27:35 --> Total execution time: 0.0386
DEBUG - 2021-12-02 09:27:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:27:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:27:37 --> Total execution time: 0.0486
DEBUG - 2021-12-02 09:27:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:27:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:27:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:27:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:27:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:27:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:27:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:27:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:27:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:27:38 --> Total execution time: 0.0445
DEBUG - 2021-12-02 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:27:39 --> Total execution time: 0.0497
DEBUG - 2021-12-02 09:28:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:28:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:28:00 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:28:00 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:28:00 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:28:00 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:28:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:28:00 --> Total execution time: 0.0344
DEBUG - 2021-12-02 09:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:28:03 --> Total execution time: 0.0430
DEBUG - 2021-12-02 09:28:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:28:24 --> Total execution time: 0.0298
DEBUG - 2021-12-02 09:28:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:28:31 --> Total execution time: 0.0483
DEBUG - 2021-12-02 09:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:28:38 --> Total execution time: 0.0409
DEBUG - 2021-12-02 09:29:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:29:20 --> Total execution time: 0.0392
DEBUG - 2021-12-02 09:29:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:29:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:29:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:29:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:29:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:29:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:29:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:29:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:29:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:29:41 --> Total execution time: 0.0475
DEBUG - 2021-12-02 09:29:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:29:43 --> Total execution time: 0.0417
DEBUG - 2021-12-02 09:32:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:32:19 --> Total execution time: 0.0282
DEBUG - 2021-12-02 09:33:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:33:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:33:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:33:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:33:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:33:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:33:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:33:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 151
ERROR - 2021-12-02 09:33:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 151
DEBUG - 2021-12-02 09:33:10 --> Total execution time: 0.0504
DEBUG - 2021-12-02 09:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:33:13 --> Total execution time: 0.0454
DEBUG - 2021-12-02 09:33:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:33:51 --> Total execution time: 0.0294
DEBUG - 2021-12-02 09:46:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:46:58 --> Total execution time: 0.0403
DEBUG - 2021-12-02 09:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:48:11 --> Total execution time: 0.0420
DEBUG - 2021-12-02 09:48:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:48:26 --> Total execution time: 0.0395
DEBUG - 2021-12-02 09:48:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:48:41 --> Total execution time: 0.0505
DEBUG - 2021-12-02 09:49:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:49:00 --> Total execution time: 0.0438
DEBUG - 2021-12-02 09:49:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:49:55 --> Total execution time: 0.0470
DEBUG - 2021-12-02 09:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:51:31 --> Total execution time: 0.0282
DEBUG - 2021-12-02 09:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:52:39 --> Total execution time: 0.0486
DEBUG - 2021-12-02 09:52:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:52:42 --> Total execution time: 0.0442
DEBUG - 2021-12-02 09:52:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:52:42 --> Query error: Table 'admin_nesnu.client' doesn't exist - Invalid query: SELECT *
FROM `client`
DEBUG - 2021-12-02 09:52:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:52:44 --> Total execution time: 0.0425
DEBUG - 2021-12-02 09:58:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:58:06 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\data\index.php 223
ERROR - 2021-12-02 09:58:06 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\data\index.php 224
ERROR - 2021-12-02 09:58:06 --> Severity: Warning --> Undefined array key "editor" C:\xampp\htdocs\nesnu\application\views\data\index.php 225
ERROR - 2021-12-02 09:58:06 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\data\index.php 226
DEBUG - 2021-12-02 09:58:06 --> Total execution time: 0.0574
DEBUG - 2021-12-02 09:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 09:58:10 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\data\index.php 223
ERROR - 2021-12-02 09:58:10 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\data\index.php 224
ERROR - 2021-12-02 09:58:10 --> Severity: Warning --> Undefined array key "editor" C:\xampp\htdocs\nesnu\application\views\data\index.php 225
ERROR - 2021-12-02 09:58:10 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\data\index.php 226
DEBUG - 2021-12-02 09:58:10 --> Total execution time: 0.0554
DEBUG - 2021-12-02 09:59:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 09:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 09:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 09:59:12 --> Total execution time: 0.0463
DEBUG - 2021-12-02 10:01:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:01:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:01:24 --> Severity: error --> Exception: syntax error, unexpected identifier "aper", expecting variable or "{" or "$" C:\xampp\htdocs\nesnu\application\views\data\index.php 223
DEBUG - 2021-12-02 10:01:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:01:27 --> Total execution time: 0.0483
DEBUG - 2021-12-02 10:01:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:01:30 --> Severity: error --> Exception: syntax error, unexpected identifier "aper", expecting variable or "{" or "$" C:\xampp\htdocs\nesnu\application\views\data\index.php 223
DEBUG - 2021-12-02 10:04:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:04:05 --> Total execution time: 0.0317
DEBUG - 2021-12-02 10:04:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:04:47 --> Total execution time: 0.0285
DEBUG - 2021-12-02 10:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:05:45 --> Total execution time: 0.0303
DEBUG - 2021-12-02 10:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:05:58 --> Total execution time: 0.0505
DEBUG - 2021-12-02 10:06:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:06:11 --> Total execution time: 0.0458
DEBUG - 2021-12-02 10:07:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:07:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:07:19 --> Query error: Table 'admin_nesnu.client' doesn't exist - Invalid query: SELECT *
FROM `client`
DEBUG - 2021-12-02 10:07:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:07:20 --> Total execution time: 0.0444
DEBUG - 2021-12-02 10:07:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:07:21 --> Total execution time: 0.0430
DEBUG - 2021-12-02 10:07:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:07:42 --> Total execution time: 0.0445
DEBUG - 2021-12-02 10:08:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:08:19 --> Total execution time: 0.0464
DEBUG - 2021-12-02 10:08:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:08:22 --> Total execution time: 0.0404
DEBUG - 2021-12-02 10:08:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:08:24 --> Total execution time: 0.0424
DEBUG - 2021-12-02 10:08:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:08:26 --> Total execution time: 0.0416
DEBUG - 2021-12-02 10:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:08:51 --> Query error: Table 'admin_nesnu.client' doesn't exist - Invalid query: SELECT *
FROM `client`
DEBUG - 2021-12-02 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:08:53 --> Total execution time: 0.0268
DEBUG - 2021-12-02 10:08:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:08:54 --> Total execution time: 0.0473
DEBUG - 2021-12-02 10:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:08:54 --> Total execution time: 0.0415
DEBUG - 2021-12-02 10:10:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:10:03 --> Total execution time: 0.0549
DEBUG - 2021-12-02 10:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:10:23 --> Total execution time: 0.0383
DEBUG - 2021-12-02 10:10:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:10:32 --> Total execution time: 0.0504
DEBUG - 2021-12-02 10:10:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:10:34 --> Query error: Table 'admin_nesnu.client' doesn't exist - Invalid query: SELECT *
FROM `client`
DEBUG - 2021-12-02 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:11:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:11:24 --> 404 Page Not Found: Client/index
DEBUG - 2021-12-02 10:11:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:11:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:11:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:11:24 --> Total execution time: 0.0469
DEBUG - 2021-12-02 10:15:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:15:52 --> Total execution time: 0.0404
DEBUG - 2021-12-02 10:15:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:15:56 --> Total execution time: 0.0374
DEBUG - 2021-12-02 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:15:57 --> Total execution time: 0.0470
DEBUG - 2021-12-02 10:15:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:15:57 --> Total execution time: 0.0488
DEBUG - 2021-12-02 10:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:15:58 --> Total execution time: 0.0419
DEBUG - 2021-12-02 10:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:15:59 --> Total execution time: 0.0470
DEBUG - 2021-12-02 10:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:15:59 --> Total execution time: 0.0520
DEBUG - 2021-12-02 10:16:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:16:11 --> Total execution time: 0.0497
DEBUG - 2021-12-02 10:16:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:16:17 --> Total execution time: 0.0416
DEBUG - 2021-12-02 10:16:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:16:18 --> Total execution time: 0.0379
DEBUG - 2021-12-02 10:16:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:16:24 --> Total execution time: 0.0490
DEBUG - 2021-12-02 10:16:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:16:25 --> Total execution time: 0.0246
DEBUG - 2021-12-02 10:16:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:16:26 --> Total execution time: 0.0495
DEBUG - 2021-12-02 10:16:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:16:27 --> Total execution time: 0.0450
DEBUG - 2021-12-02 10:16:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:16:37 --> Total execution time: 0.0459
DEBUG - 2021-12-02 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:18:34 --> Total execution time: 0.0426
DEBUG - 2021-12-02 10:18:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:18:36 --> Total execution time: 0.0466
DEBUG - 2021-12-02 10:19:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:19:07 --> Total execution time: 0.0378
DEBUG - 2021-12-02 10:19:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:19:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:19:10 --> Total execution time: 0.0262
DEBUG - 2021-12-02 10:19:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:19:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:19:19 --> Total execution time: 0.0384
DEBUG - 2021-12-02 10:19:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:19:23 --> Total execution time: 0.0377
DEBUG - 2021-12-02 10:19:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:19:24 --> Total execution time: 0.0479
DEBUG - 2021-12-02 10:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:19:30 --> Total execution time: 0.0452
DEBUG - 2021-12-02 10:24:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:24:40 --> Severity: Warning --> Undefined property: CI_Loader::$calendar C:\xampp\htdocs\nesnu\application\views\user\index.php 12
ERROR - 2021-12-02 10:24:40 --> Severity: error --> Exception: Call to a member function generate() on null C:\xampp\htdocs\nesnu\application\views\user\index.php 12
DEBUG - 2021-12-02 10:24:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:24:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:24:40 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:26:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:40:22 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:40:22 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:40:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:40:22 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:40:22 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:40:22 --> Total execution time: 0.0721
DEBUG - 2021-12-02 10:40:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:40:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:40:23 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:42:25 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:42:25 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:42:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:42:25 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:42:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:42:25 --> Total execution time: 0.0437
DEBUG - 2021-12-02 10:42:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:42:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:42:25 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:42:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 10:42:26 --> Total execution time: 0.0501
DEBUG - 2021-12-02 10:42:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:42:26 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:42:26 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:42:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:42:26 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:42:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:42:26 --> Total execution time: 0.0497
DEBUG - 2021-12-02 10:42:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:42:26 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:43:02 --> Total execution time: 0.0308
DEBUG - 2021-12-02 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:43:02 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:43:02 --> Total execution time: 0.0304
DEBUG - 2021-12-02 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:43:02 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:43:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:43:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:43:03 --> Total execution time: 0.0437
DEBUG - 2021-12-02 10:43:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:43:03 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:43:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:43:05 --> Total execution time: 0.0392
DEBUG - 2021-12-02 10:43:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:43:05 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:43:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:43:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:43:05 --> Total execution time: 0.0418
DEBUG - 2021-12-02 10:43:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:43:05 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:43:09 --> Total execution time: 0.0463
DEBUG - 2021-12-02 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:43:09 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:43:09 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:43:09 --> Total execution time: 0.0310
DEBUG - 2021-12-02 10:43:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:43:09 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:43:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:43:16 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
ERROR - 2021-12-02 10:43:16 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-02 10:43:16 --> Severity: Warning --> Undefined variable $user C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
ERROR - 2021-12-02 10:43:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-02 10:43:16 --> Total execution time: 0.0454
DEBUG - 2021-12-02 10:43:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:43:16 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:59:01 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 10:59:01 --> Total execution time: 0.0478
DEBUG - 2021-12-02 10:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:59:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:59:01 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:59:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:59:10 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 10:59:10 --> Total execution time: 0.0389
DEBUG - 2021-12-02 10:59:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:59:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:59:10 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:59:21 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 10:59:21 --> Total execution time: 0.0510
DEBUG - 2021-12-02 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 10:59:21 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 10:59:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:59:24 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 10:59:24 --> Total execution time: 0.0410
DEBUG - 2021-12-02 10:59:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 10:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 10:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 10:59:27 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 10:59:27 --> Total execution time: 0.0285
DEBUG - 2021-12-02 11:01:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 11:01:05 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 11:01:05 --> Total execution time: 0.0396
DEBUG - 2021-12-02 11:01:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:01:05 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:01:06 --> Total execution time: 0.0281
DEBUG - 2021-12-02 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 11:01:07 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 11:01:07 --> Total execution time: 0.0503
DEBUG - 2021-12-02 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:01:07 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 11:01:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 11:01:08 --> Total execution time: 0.0505
DEBUG - 2021-12-02 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:01:08 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 11:01:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 11:01:08 --> Total execution time: 0.0471
DEBUG - 2021-12-02 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:01:08 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 11:01:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 11:01:08 --> Total execution time: 0.0275
DEBUG - 2021-12-02 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:01:08 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 11:01:08 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 11:01:08 --> Total execution time: 0.0362
DEBUG - 2021-12-02 11:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:01:08 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 11:01:28 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 11:01:28 --> Total execution time: 0.0506
DEBUG - 2021-12-02 11:01:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:01:28 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-02 11:01:29 --> Severity: Warning --> Undefined variable $title C:\xampp\htdocs\nesnu\application\views\templates\header.php 12
DEBUG - 2021-12-02 11:01:29 --> Total execution time: 0.0437
DEBUG - 2021-12-02 11:01:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:01:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:01:29 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:39 --> Total execution time: 0.0393
DEBUG - 2021-12-02 11:02:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:02:39 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:40 --> Total execution time: 0.0465
DEBUG - 2021-12-02 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:02:40 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:40 --> Total execution time: 0.0357
DEBUG - 2021-12-02 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:02:40 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:40 --> Total execution time: 0.0486
DEBUG - 2021-12-02 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:02:40 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:40 --> Total execution time: 0.0454
DEBUG - 2021-12-02 11:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:02:40 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:42 --> Total execution time: 0.0405
DEBUG - 2021-12-02 11:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:02:42 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-02 11:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:43 --> Total execution time: 0.0476
DEBUG - 2021-12-02 11:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:43 --> Total execution time: 0.0458
DEBUG - 2021-12-02 11:02:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:44 --> Total execution time: 0.0469
DEBUG - 2021-12-02 11:02:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-02 11:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-02 11:02:44 --> Total execution time: 0.0456
DEBUG - 2021-12-02 11:02:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-02 11:02:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-02 11:02:44 --> 404 Page Not Found: Css/style.css
