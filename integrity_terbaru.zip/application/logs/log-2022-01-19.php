<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-19 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 09:53:54 --> No URI present. Default controller set.
DEBUG - 2022-01-19 09:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 09:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 09:53:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 09:53:54 --> Total execution time: 0.0307
DEBUG - 2022-01-19 09:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 09:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-19 09:53:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-19 09:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 09:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 09:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 09:54:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 09:54:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 09:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 09:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 09:54:02 --> Total execution time: 0.0059
DEBUG - 2022-01-19 09:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 09:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 09:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 09:54:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-19 09:54:04 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 94817464 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-19 09:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 09:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 09:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 09:54:07 --> Total execution time: 0.0036
DEBUG - 2022-01-19 10:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 10:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 10:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 10:01:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-19 10:01:09 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 94817464 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-19 10:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 10:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 10:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 10:01:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 10:01:18 --> Total execution time: 0.0044
DEBUG - 2022-01-19 11:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:01:31 --> Total execution time: 0.0069
DEBUG - 2022-01-19 11:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:08:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:08:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:08:39 --> Total execution time: 0.0070
DEBUG - 2022-01-19 11:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:14:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:14:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:14:53 --> Total execution time: 0.0063
DEBUG - 2022-01-19 11:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:24:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:24:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:24:37 --> Total execution time: 0.0065
DEBUG - 2022-01-19 11:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:52:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:52:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:52:45 --> Total execution time: 0.0069
DEBUG - 2022-01-19 11:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:59:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 11:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 11:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 11:59:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 11:59:53 --> Total execution time: 0.0058
DEBUG - 2022-01-19 12:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 12:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 12:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 12:19:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 12:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 12:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 12:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 12:19:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 12:19:39 --> Total execution time: 0.0063
DEBUG - 2022-01-19 12:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 12:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 12:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 12:27:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 12:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 12:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 12:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 12:27:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 12:27:19 --> Total execution time: 0.0076
DEBUG - 2022-01-19 13:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:04:31 --> Total execution time: 0.0066
DEBUG - 2022-01-19 13:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:08:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:08:23 --> Total execution time: 0.0077
DEBUG - 2022-01-19 13:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:16:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:16:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:16:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:16:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:16:31 --> Total execution time: 0.0058
DEBUG - 2022-01-19 13:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:26:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:26:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:26:52 --> Total execution time: 0.0056
DEBUG - 2022-01-19 13:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:29:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:29:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:29:42 --> Total execution time: 0.0058
DEBUG - 2022-01-19 13:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:33:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:33:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:33:00 --> Total execution time: 0.0062
DEBUG - 2022-01-19 13:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:33:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:33:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:33:57 --> Total execution time: 0.0052
DEBUG - 2022-01-19 13:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:35:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 13:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 13:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 13:35:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 13:35:15 --> Total execution time: 0.0058
DEBUG - 2022-01-19 14:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:00:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:00:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:00:55 --> Total execution time: 0.0077
DEBUG - 2022-01-19 14:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:02:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:02:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:02:15 --> Total execution time: 0.0056
DEBUG - 2022-01-19 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:09:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:09:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:09:26 --> Total execution time: 0.0060
DEBUG - 2022-01-19 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:11:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:11:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:11:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:11:36 --> Total execution time: 0.0059
DEBUG - 2022-01-19 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:15:20 --> Total execution time: 0.0057
DEBUG - 2022-01-19 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:20:01 --> Total execution time: 0.0071
DEBUG - 2022-01-19 14:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:27:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:27:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:27:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:27:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:27:46 --> Total execution time: 0.0063
DEBUG - 2022-01-19 14:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:30:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:30:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:30:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:30:38 --> Total execution time: 0.0062
DEBUG - 2022-01-19 14:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:32:21 --> Total execution time: 0.0061
DEBUG - 2022-01-19 14:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:36:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:36:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:36:26 --> Total execution time: 0.0066
DEBUG - 2022-01-19 14:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:54:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:54:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:54:19 --> Total execution time: 0.0076
DEBUG - 2022-01-19 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:58:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 14:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 14:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 14:58:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 14:58:43 --> Total execution time: 0.0063
DEBUG - 2022-01-19 15:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:09:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:09:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:09:44 --> Total execution time: 0.0064
DEBUG - 2022-01-19 15:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:12:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:12:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:12:30 --> Total execution time: 0.0060
DEBUG - 2022-01-19 15:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:14:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:14:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:14:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:14:20 --> Total execution time: 0.0067
DEBUG - 2022-01-19 15:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:22:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:22:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:22:36 --> Total execution time: 0.0062
DEBUG - 2022-01-19 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:25:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:25:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:25:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:25:25 --> Total execution time: 0.0061
DEBUG - 2022-01-19 15:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:28:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:28:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:28:13 --> Total execution time: 0.0065
DEBUG - 2022-01-19 15:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:29:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:29:59 --> Total execution time: 0.0055
DEBUG - 2022-01-19 15:31:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:31:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:31:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:31:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:31:58 --> Total execution time: 0.0068
DEBUG - 2022-01-19 15:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:34:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:34:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:34:50 --> Total execution time: 0.0061
DEBUG - 2022-01-19 15:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:36:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 15:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 15:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 15:36:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 15:36:49 --> Total execution time: 0.0059
DEBUG - 2022-01-19 16:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:03:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:03:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:03:32 --> Total execution time: 0.0071
DEBUG - 2022-01-19 16:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:05:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:05:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:05:06 --> Total execution time: 0.0059
DEBUG - 2022-01-19 16:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:07:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:07:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:07:15 --> Total execution time: 0.0067
DEBUG - 2022-01-19 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:12:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:12:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:12:46 --> Total execution time: 0.0064
DEBUG - 2022-01-19 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:18:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:18:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:18:12 --> Total execution time: 0.0069
DEBUG - 2022-01-19 16:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:21:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:21:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:21:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:21:41 --> Total execution time: 0.0057
DEBUG - 2022-01-19 16:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:23:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:23:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:23:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:23:22 --> Total execution time: 0.0063
DEBUG - 2022-01-19 16:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:25:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:25:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:25:42 --> Total execution time: 0.0062
DEBUG - 2022-01-19 16:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:27:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:27:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:27:09 --> Total execution time: 0.0061
DEBUG - 2022-01-19 16:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:32:34 --> Total execution time: 0.0061
DEBUG - 2022-01-19 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:33:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:33:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:33:29 --> Total execution time: 0.0039
DEBUG - 2022-01-19 16:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:35:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:35:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:35:36 --> Total execution time: 0.0060
DEBUG - 2022-01-19 16:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:37:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:37:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:37:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:37:39 --> Total execution time: 0.0065
DEBUG - 2022-01-19 16:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:43:57 --> Total execution time: 0.0062
DEBUG - 2022-01-19 16:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:46:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:46:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:46:54 --> Total execution time: 0.0061
DEBUG - 2022-01-19 16:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:48:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:48:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:48:43 --> Total execution time: 0.0062
DEBUG - 2022-01-19 16:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:51:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:51:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:51:56 --> Total execution time: 0.0061
DEBUG - 2022-01-19 16:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:53:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:53:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:53:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:53:09 --> Total execution time: 0.0061
DEBUG - 2022-01-19 16:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:55:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:55:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:55:08 --> Total execution time: 0.0062
DEBUG - 2022-01-19 16:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:57:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:57:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:57:19 --> Total execution time: 0.0063
DEBUG - 2022-01-19 16:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:59:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 16:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 16:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 16:59:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 16:59:04 --> Total execution time: 0.0066
DEBUG - 2022-01-19 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:00:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:00:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:00:45 --> Total execution time: 0.0061
DEBUG - 2022-01-19 17:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:03:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:03:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:03:12 --> Total execution time: 0.0063
DEBUG - 2022-01-19 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:04:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-19 17:04:20 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 102102816 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-19 17:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:04:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-19 17:04:55 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 102102816 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-19 17:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:00 --> No URI present. Default controller set.
DEBUG - 2022-01-19 17:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:05:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:05:00 --> Total execution time: 0.0044
DEBUG - 2022-01-19 17:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:05 --> No URI present. Default controller set.
DEBUG - 2022-01-19 17:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:05:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:05:05 --> Total execution time: 0.0045
DEBUG - 2022-01-19 17:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-19 17:05:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-19 17:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-19 17:05:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-19 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:05:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:05:13 --> Total execution time: 0.0046
DEBUG - 2022-01-19 17:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:05:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:05:46 --> Total execution time: 0.0037
DEBUG - 2022-01-19 17:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:05:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-19 17:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-19 17:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-19 17:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-19 17:05:46 --> Total execution time: 0.0032
