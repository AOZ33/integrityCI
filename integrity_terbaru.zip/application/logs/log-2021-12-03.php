<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-03 03:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:23:53 --> No URI present. Default controller set.
DEBUG - 2021-12-03 03:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:23:53 --> Total execution time: 0.1481
DEBUG - 2021-12-03 03:23:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:23:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:23:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:23:55 --> Total execution time: 0.0716
DEBUG - 2021-12-03 03:23:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:23:57 --> Total execution time: 0.0541
DEBUG - 2021-12-03 03:23:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:23:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:23:57 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:24:00 --> Total execution time: 0.0544
DEBUG - 2021-12-03 03:24:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:24:02 --> Total execution time: 0.0548
DEBUG - 2021-12-03 03:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:25:21 --> Total execution time: 0.0481
DEBUG - 2021-12-03 03:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:25:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:25:21 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:26:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:26:01 --> Total execution time: 0.0302
DEBUG - 2021-12-03 03:26:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:26:01 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:26:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:26:25 --> Total execution time: 0.0420
DEBUG - 2021-12-03 03:26:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:26:25 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:26:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:26:26 --> Total execution time: 0.0274
DEBUG - 2021-12-03 03:26:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:26:26 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:26:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:26:47 --> Total execution time: 0.0483
DEBUG - 2021-12-03 03:26:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:26:47 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:26:48 --> Total execution time: 0.0496
DEBUG - 2021-12-03 03:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:26:48 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:27:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:06 --> Total execution time: 0.0502
DEBUG - 2021-12-03 03:27:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:27:06 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:27:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:07 --> Total execution time: 0.0509
DEBUG - 2021-12-03 03:27:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:27:07 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:27:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:11 --> Total execution time: 0.0410
DEBUG - 2021-12-03 03:27:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:27:11 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:27:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 03:27:19 --> Severity: Warning --> Undefined variable $year C:\xampp\htdocs\nesnu\application\views\user\index.php 8
ERROR - 2021-12-03 03:27:19 --> Severity: Warning --> Undefined variable $month C:\xampp\htdocs\nesnu\application\views\user\index.php 8
DEBUG - 2021-12-03 03:27:19 --> Total execution time: 0.0294
DEBUG - 2021-12-03 03:27:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:27:19 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:27:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:22 --> Total execution time: 0.0275
DEBUG - 2021-12-03 03:27:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:27:22 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:27:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:43 --> Total execution time: 0.0445
DEBUG - 2021-12-03 03:27:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:27:43 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:27:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:43 --> Total execution time: 0.0496
DEBUG - 2021-12-03 03:27:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:44 --> Total execution time: 0.0530
DEBUG - 2021-12-03 03:27:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:45 --> Total execution time: 0.0487
DEBUG - 2021-12-03 03:27:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:27:45 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:27:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:27:58 --> Total execution time: 0.0348
DEBUG - 2021-12-03 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:11 --> Total execution time: 0.0420
DEBUG - 2021-12-03 03:28:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:28:11 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:28:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:15 --> Total execution time: 0.0437
DEBUG - 2021-12-03 03:28:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:27 --> Total execution time: 0.0543
DEBUG - 2021-12-03 03:28:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:28:27 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:29 --> Total execution time: 0.0568
DEBUG - 2021-12-03 03:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:28:29 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:28:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:30 --> Total execution time: 0.0369
DEBUG - 2021-12-03 03:28:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:30 --> Total execution time: 0.0522
DEBUG - 2021-12-03 03:28:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:34 --> Total execution time: 0.0279
DEBUG - 2021-12-03 03:28:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:28:34 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:28:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:35 --> Total execution time: 0.0391
DEBUG - 2021-12-03 03:28:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:36 --> Total execution time: 0.0460
DEBUG - 2021-12-03 03:28:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:36 --> Total execution time: 0.0411
DEBUG - 2021-12-03 03:28:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:28:36 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:28:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:39 --> Total execution time: 0.0424
DEBUG - 2021-12-03 03:28:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:28:44 --> Total execution time: 0.0428
DEBUG - 2021-12-03 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:29:09 --> Total execution time: 0.0417
DEBUG - 2021-12-03 03:29:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:29:09 --> Total execution time: 0.0274
DEBUG - 2021-12-03 03:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:29:10 --> Total execution time: 0.0469
DEBUG - 2021-12-03 03:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:29:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:29:10 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:29:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:29:24 --> Total execution time: 0.0395
DEBUG - 2021-12-03 03:29:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:29:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:29:24 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:30:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:30:49 --> Total execution time: 0.0455
DEBUG - 2021-12-03 03:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:30:52 --> Total execution time: 0.0480
DEBUG - 2021-12-03 03:50:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:14 --> Total execution time: 0.0488
DEBUG - 2021-12-03 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:14 --> Total execution time: 0.0477
DEBUG - 2021-12-03 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:14 --> Total execution time: 0.0408
DEBUG - 2021-12-03 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:15 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:21 --> Total execution time: 0.0462
DEBUG - 2021-12-03 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:32 --> Total execution time: 0.0442
DEBUG - 2021-12-03 03:50:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:32 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:34 --> 404 Page Not Found: 2022/01
DEBUG - 2021-12-03 03:50:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:46 --> 404 Page Not Found: 2022/01
DEBUG - 2021-12-03 03:50:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:46 --> Total execution time: 0.0514
DEBUG - 2021-12-03 03:50:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:48 --> Total execution time: 0.0412
DEBUG - 2021-12-03 03:50:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:48 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:49 --> Total execution time: 0.0442
DEBUG - 2021-12-03 03:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:49 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:50 --> Total execution time: 0.0440
DEBUG - 2021-12-03 03:50:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:50 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:51 --> Total execution time: 0.0267
DEBUG - 2021-12-03 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:51 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:51 --> Total execution time: 0.0367
DEBUG - 2021-12-03 03:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:51 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:52 --> Total execution time: 0.0455
DEBUG - 2021-12-03 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:52 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:52 --> Total execution time: 0.0464
DEBUG - 2021-12-03 03:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:52 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:53 --> Total execution time: 0.0503
DEBUG - 2021-12-03 03:50:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:53 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:53 --> Total execution time: 0.0377
DEBUG - 2021-12-03 03:50:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:53 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:54 --> Total execution time: 0.0397
DEBUG - 2021-12-03 03:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:54 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:54 --> Total execution time: 0.0365
DEBUG - 2021-12-03 03:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:54 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:54 --> Total execution time: 0.0487
DEBUG - 2021-12-03 03:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:54 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:55 --> Total execution time: 0.0507
DEBUG - 2021-12-03 03:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:55 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:55 --> Total execution time: 0.0432
DEBUG - 2021-12-03 03:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:55 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:50:55 --> Total execution time: 0.0497
DEBUG - 2021-12-03 03:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-03 03:50:55 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-12-03 03:51:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:51:14 --> Total execution time: 0.0492
DEBUG - 2021-12-03 03:51:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:51:15 --> Total execution time: 0.0375
DEBUG - 2021-12-03 03:51:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:51:15 --> Total execution time: 0.0427
DEBUG - 2021-12-03 03:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:51:18 --> Total execution time: 0.0447
DEBUG - 2021-12-03 03:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:51:18 --> Total execution time: 0.0415
DEBUG - 2021-12-03 03:51:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:51:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:51:18 --> Total execution time: 0.0463
DEBUG - 2021-12-03 03:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:52:59 --> Total execution time: 0.0272
DEBUG - 2021-12-03 03:53:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:02 --> Total execution time: 0.0464
DEBUG - 2021-12-03 03:53:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:02 --> Total execution time: 0.0369
DEBUG - 2021-12-03 03:53:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:03 --> Total execution time: 0.0541
DEBUG - 2021-12-03 03:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:04 --> Total execution time: 0.0398
DEBUG - 2021-12-03 03:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:04 --> Total execution time: 0.0589
DEBUG - 2021-12-03 03:53:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:05 --> Total execution time: 0.0392
DEBUG - 2021-12-03 03:53:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:06 --> Total execution time: 0.0259
DEBUG - 2021-12-03 03:53:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:07 --> Total execution time: 0.0375
DEBUG - 2021-12-03 03:53:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:07 --> Total execution time: 0.0478
DEBUG - 2021-12-03 03:53:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:22 --> Total execution time: 0.0516
DEBUG - 2021-12-03 03:53:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:23 --> Total execution time: 0.0493
DEBUG - 2021-12-03 03:53:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:53:23 --> Total execution time: 0.0395
DEBUG - 2021-12-03 03:54:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:16 --> Total execution time: 0.0442
DEBUG - 2021-12-03 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:16 --> Total execution time: 0.0368
DEBUG - 2021-12-03 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:16 --> Total execution time: 0.0420
DEBUG - 2021-12-03 03:54:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:17 --> Total execution time: 0.0463
DEBUG - 2021-12-03 03:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:19 --> Total execution time: 0.0379
DEBUG - 2021-12-03 03:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:20 --> Total execution time: 0.0467
DEBUG - 2021-12-03 03:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:20 --> Total execution time: 0.0494
DEBUG - 2021-12-03 03:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:20 --> Total execution time: 0.0380
DEBUG - 2021-12-03 03:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:20 --> Total execution time: 0.0274
DEBUG - 2021-12-03 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:21 --> Total execution time: 0.0468
DEBUG - 2021-12-03 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:21 --> Total execution time: 0.0463
DEBUG - 2021-12-03 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:21 --> Total execution time: 0.0458
DEBUG - 2021-12-03 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:21 --> Total execution time: 0.0372
DEBUG - 2021-12-03 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:21 --> Total execution time: 0.0502
DEBUG - 2021-12-03 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:22 --> Total execution time: 0.0259
DEBUG - 2021-12-03 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:22 --> Total execution time: 0.0409
DEBUG - 2021-12-03 03:54:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:23 --> Total execution time: 0.0419
DEBUG - 2021-12-03 03:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:24 --> Total execution time: 0.0394
DEBUG - 2021-12-03 03:54:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:25 --> Total execution time: 0.0364
DEBUG - 2021-12-03 03:54:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:27 --> Total execution time: 0.0406
DEBUG - 2021-12-03 03:54:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:30 --> Total execution time: 0.0454
DEBUG - 2021-12-03 03:54:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:54:31 --> Total execution time: 0.0468
DEBUG - 2021-12-03 03:55:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:55:29 --> Total execution time: 0.0413
DEBUG - 2021-12-03 03:58:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 03:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 03:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 03:58:02 --> Total execution time: 0.0510
DEBUG - 2021-12-03 04:07:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 04:07:51 --> Query error: Table 'admin_nesnu.calendar' doesn't exist - Invalid query: SELECT *
FROM `calendar`
DEBUG - 2021-12-03 04:09:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:09:13 --> Total execution time: 0.0423
DEBUG - 2021-12-03 04:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:09:14 --> Total execution time: 0.0602
DEBUG - 2021-12-03 04:09:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 04:09:15 --> Query error: Table 'admin_nesnu.calendar' doesn't exist - Invalid query: SELECT *
FROM `calendar`
DEBUG - 2021-12-03 04:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:09:57 --> Total execution time: 0.0465
DEBUG - 2021-12-03 04:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:20:42 --> Total execution time: 0.0300
DEBUG - 2021-12-03 04:22:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:00 --> Total execution time: 0.0272
DEBUG - 2021-12-03 04:22:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:00 --> Total execution time: 0.0395
DEBUG - 2021-12-03 04:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:53 --> Total execution time: 0.0420
DEBUG - 2021-12-03 04:22:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:54 --> Total execution time: 0.0374
DEBUG - 2021-12-03 04:22:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:54 --> Total execution time: 0.0419
DEBUG - 2021-12-03 04:22:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:57 --> Total execution time: 0.0394
DEBUG - 2021-12-03 04:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:57 --> Total execution time: 0.0292
DEBUG - 2021-12-03 04:22:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:58 --> Total execution time: 0.0246
DEBUG - 2021-12-03 04:22:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:59 --> Total execution time: 0.0372
DEBUG - 2021-12-03 04:22:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:22:59 --> Total execution time: 0.0461
DEBUG - 2021-12-03 04:23:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:00 --> Total execution time: 0.0444
DEBUG - 2021-12-03 04:23:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:01 --> Total execution time: 0.0359
DEBUG - 2021-12-03 04:23:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:02 --> Total execution time: 0.0395
DEBUG - 2021-12-03 04:23:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:02 --> Total execution time: 0.0447
DEBUG - 2021-12-03 04:23:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:03 --> Total execution time: 0.0377
DEBUG - 2021-12-03 04:23:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:04 --> Total execution time: 0.0444
DEBUG - 2021-12-03 04:23:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:05 --> Total execution time: 0.0503
DEBUG - 2021-12-03 04:23:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:06 --> Total execution time: 0.0269
DEBUG - 2021-12-03 04:23:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:09 --> Total execution time: 0.0420
DEBUG - 2021-12-03 04:23:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:23:36 --> Total execution time: 0.0395
DEBUG - 2021-12-03 04:32:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:32:08 --> Total execution time: 0.0489
DEBUG - 2021-12-03 04:32:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:32:08 --> Total execution time: 0.0368
DEBUG - 2021-12-03 04:32:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:32:09 --> Total execution time: 0.0439
DEBUG - 2021-12-03 04:32:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:32:10 --> Total execution time: 0.0293
DEBUG - 2021-12-03 04:32:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:32:11 --> Total execution time: 0.0494
DEBUG - 2021-12-03 04:32:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:32:11 --> Total execution time: 0.0329
DEBUG - 2021-12-03 04:32:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:32:12 --> Total execution time: 0.0269
DEBUG - 2021-12-03 04:32:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 04:32:20 --> Severity: Warning --> Undefined variable $_settings C:\xampp\htdocs\nesnu\application\views\user\index.php 1
ERROR - 2021-12-03 04:32:20 --> Severity: error --> Exception: Call to a member function info() on null C:\xampp\htdocs\nesnu\application\views\user\index.php 1
DEBUG - 2021-12-03 04:32:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:32:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 04:32:29 --> Severity: Warning --> Undefined variable $conn C:\xampp\htdocs\nesnu\application\views\user\index.php 30
ERROR - 2021-12-03 04:32:29 --> Severity: error --> Exception: Call to a member function query() on null C:\xampp\htdocs\nesnu\application\views\user\index.php 30
DEBUG - 2021-12-03 04:33:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 04:33:11 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\application\views\user\index.php 38
DEBUG - 2021-12-03 04:33:11 --> Total execution time: 0.0430
DEBUG - 2021-12-03 04:33:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:33:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 04:33:15 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\application\views\user\index.php 38
DEBUG - 2021-12-03 04:33:15 --> Total execution time: 0.0458
DEBUG - 2021-12-03 04:33:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 04:33:17 --> Total execution time: 0.0372
DEBUG - 2021-12-03 04:33:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 04:33:17 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\application\views\user\index.php 38
DEBUG - 2021-12-03 04:33:17 --> Total execution time: 0.0277
DEBUG - 2021-12-03 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 04:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 04:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 04:33:41 --> Severity: Warning --> Undefined variable $data C:\xampp\htdocs\nesnu\application\views\user\index.php 30
ERROR - 2021-12-03 04:33:41 --> Severity: error --> Exception: Call to a member function query() on null C:\xampp\htdocs\nesnu\application\views\user\index.php 30
DEBUG - 2021-12-03 05:19:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:19:34 --> Severity: Warning --> Undefined property: User::$event C:\xampp\htdocs\nesnu\application\controllers\user.php 52
ERROR - 2021-12-03 05:19:34 --> Severity: error --> Exception: Call to a member function getGroupCount() on null C:\xampp\htdocs\nesnu\application\controllers\user.php 52
DEBUG - 2021-12-03 05:21:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:21:04 --> Severity: Warning --> Undefined property: User::$event C:\xampp\htdocs\nesnu\application\controllers\user.php 52
ERROR - 2021-12-03 05:21:04 --> Severity: error --> Exception: Call to a member function getGroupCount() on null C:\xampp\htdocs\nesnu\application\controllers\user.php 52
DEBUG - 2021-12-03 05:21:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:21:04 --> Severity: Warning --> Undefined property: User::$event C:\xampp\htdocs\nesnu\application\controllers\user.php 52
ERROR - 2021-12-03 05:21:04 --> Severity: error --> Exception: Call to a member function getGroupCount() on null C:\xampp\htdocs\nesnu\application\controllers\user.php 52
DEBUG - 2021-12-03 05:21:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:21:05 --> Severity: Warning --> Undefined property: User::$event C:\xampp\htdocs\nesnu\application\controllers\user.php 52
ERROR - 2021-12-03 05:21:05 --> Severity: error --> Exception: Call to a member function getGroupCount() on null C:\xampp\htdocs\nesnu\application\controllers\user.php 52
DEBUG - 2021-12-03 05:21:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:21:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:21:05 --> Severity: Warning --> Undefined property: User::$event C:\xampp\htdocs\nesnu\application\controllers\user.php 52
ERROR - 2021-12-03 05:21:05 --> Severity: error --> Exception: Call to a member function getGroupCount() on null C:\xampp\htdocs\nesnu\application\controllers\user.php 52
DEBUG - 2021-12-03 05:21:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:21:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:21:06 --> Total execution time: 0.0283
DEBUG - 2021-12-03 05:21:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:21:08 --> Severity: Warning --> Undefined property: User::$event C:\xampp\htdocs\nesnu\application\controllers\user.php 52
ERROR - 2021-12-03 05:21:08 --> Severity: error --> Exception: Call to a member function getGroupCount() on null C:\xampp\htdocs\nesnu\application\controllers\user.php 52
DEBUG - 2021-12-03 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:21:25 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:25:54 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:25:54 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:25:54 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:25:54 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:25:54 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:25:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:25:54 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:27:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:27:00 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:27:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:27:00 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:27:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:27:00 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:27:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:27:01 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:32:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:32:53 --> Total execution time: 0.4556
DEBUG - 2021-12-03 05:33:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:33:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:33:17 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:33:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:33:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:33:18 --> Total execution time: 0.0467
DEBUG - 2021-12-03 05:33:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:33:23 --> Total execution time: 0.0509
DEBUG - 2021-12-03 05:33:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:33:25 --> Total execution time: 0.0515
DEBUG - 2021-12-03 05:33:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:33:28 --> Total execution time: 0.0496
DEBUG - 2021-12-03 05:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:33:30 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:33:31 --> Total execution time: 0.0289
DEBUG - 2021-12-03 05:34:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:34:12 --> Total execution time: 0.0430
DEBUG - 2021-12-03 05:34:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:34:16 --> Total execution time: 0.0439
DEBUG - 2021-12-03 05:34:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:34:17 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:35:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:35:36 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:35:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:35:36 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:36:07 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:36:07 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:38:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:38:17 --> Total execution time: 0.0302
DEBUG - 2021-12-03 05:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:38:57 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:39:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:39:18 --> Total execution time: 0.0393
DEBUG - 2021-12-03 05:39:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:39:20 --> Total execution time: 0.0389
DEBUG - 2021-12-03 05:46:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:46:08 --> Total execution time: 0.0404
DEBUG - 2021-12-03 05:46:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:46:09 --> Total execution time: 0.0278
DEBUG - 2021-12-03 05:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:46:10 --> Total execution time: 0.0372
DEBUG - 2021-12-03 05:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:46:10 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:46:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:46:12 --> Total execution time: 0.0464
DEBUG - 2021-12-03 05:53:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:53:07 --> Total execution time: 0.0281
DEBUG - 2021-12-03 05:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:53:08 --> Total execution time: 0.0449
DEBUG - 2021-12-03 05:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:53:09 --> Total execution time: 0.0419
DEBUG - 2021-12-03 05:53:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 05:53:09 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 05:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 05:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 05:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 05:53:11 --> Total execution time: 0.0281
DEBUG - 2021-12-03 06:28:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 06:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 06:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 06:28:43 --> Total execution time: 0.0560
DEBUG - 2021-12-03 06:36:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 06:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 06:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 06:36:10 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 06:36:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 06:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 06:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 06:36:11 --> Total execution time: 0.0389
DEBUG - 2021-12-03 06:36:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 06:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 06:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 06:36:14 --> Total execution time: 0.0444
DEBUG - 2021-12-03 06:36:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 06:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 06:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 06:36:24 --> Total execution time: 0.0357
DEBUG - 2021-12-03 06:41:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 06:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 06:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 06:41:39 --> Total execution time: 0.0507
DEBUG - 2021-12-03 06:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 06:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 06:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 06:41:44 --> Total execution time: 0.0475
DEBUG - 2021-12-03 06:41:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 06:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 06:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 06:41:45 --> Total execution time: 0.0428
DEBUG - 2021-12-03 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 07:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 07:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 07:26:38 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 07:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 07:26:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 07:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 07:26:40 --> Total execution time: 0.0482
DEBUG - 2021-12-03 08:15:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:15:54 --> Total execution time: 0.0320
DEBUG - 2021-12-03 08:15:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:15:54 --> Total execution time: 0.0501
DEBUG - 2021-12-03 08:15:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:15:55 --> Total execution time: 0.0501
DEBUG - 2021-12-03 08:15:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:15:55 --> Total execution time: 0.0432
DEBUG - 2021-12-03 08:15:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:15:56 --> Total execution time: 0.0430
DEBUG - 2021-12-03 08:15:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:15:56 --> Total execution time: 0.0405
DEBUG - 2021-12-03 08:15:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:15:57 --> Total execution time: 0.0510
DEBUG - 2021-12-03 08:15:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 08:15:58 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 08:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:15:59 --> Total execution time: 0.0296
DEBUG - 2021-12-03 08:16:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:16:00 --> Total execution time: 0.0389
DEBUG - 2021-12-03 08:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 08:16:02 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 08:16:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:16:03 --> Total execution time: 0.0501
DEBUG - 2021-12-03 08:16:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:16:05 --> Total execution time: 0.0473
DEBUG - 2021-12-03 08:22:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:22:39 --> Total execution time: 0.0501
DEBUG - 2021-12-03 08:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:22:40 --> Total execution time: 0.0499
DEBUG - 2021-12-03 08:22:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:22:44 --> Total execution time: 0.0526
DEBUG - 2021-12-03 08:23:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:23:07 --> Total execution time: 0.0528
DEBUG - 2021-12-03 08:23:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 08:23:08 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 08:23:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:23:09 --> Total execution time: 0.0470
DEBUG - 2021-12-03 08:23:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:23:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:23:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:23:18 --> Total execution time: 0.0451
DEBUG - 2021-12-03 08:31:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:31:25 --> Total execution time: 0.0418
DEBUG - 2021-12-03 08:31:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:31:26 --> Total execution time: 0.0425
DEBUG - 2021-12-03 08:31:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 08:31:28 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 08:31:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:31:29 --> Total execution time: 0.0279
DEBUG - 2021-12-03 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-03 08:55:28 --> Total execution time: 0.0488
DEBUG - 2021-12-03 08:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 08:55:28 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 08:55:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 08:55:30 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 08:55:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 08:55:31 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-03 08:55:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-03 08:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-03 08:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-03 08:55:31 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
