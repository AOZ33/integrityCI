<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-01 09:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 09:29:31 --> No URI present. Default controller set.
DEBUG - 2022-03-01 09:29:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 09:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 09:29:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 09:29:31 --> Total execution time: 0.0303
DEBUG - 2022-03-01 09:29:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 09:29:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 09:29:31 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 09:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 09:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 09:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 09:29:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 09:29:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 09:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 09:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 09:29:35 --> Total execution time: 0.0063
DEBUG - 2022-03-01 09:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 09:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 09:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 09:29:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-01 09:29:37 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-03-01 09:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 09:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 09:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 09:29:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 09:29:39 --> Total execution time: 0.0041
DEBUG - 2022-03-01 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:05 --> No URI present. Default controller set.
DEBUG - 2022-03-01 10:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:42:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:42:05 --> Total execution time: 0.0312
DEBUG - 2022-03-01 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 10:42:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:42:08 --> Total execution time: 0.0059
DEBUG - 2022-03-01 10:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:42:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-01 10:42:11 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-03-01 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:42:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:42:20 --> Total execution time: 0.0047
DEBUG - 2022-03-01 10:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:42:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:42:20 --> Total execution time: 0.0041
DEBUG - 2022-03-01 10:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:42:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-01 10:42:22 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-03-01 10:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:42:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:42:24 --> Total execution time: 0.0034
DEBUG - 2022-03-01 10:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:48:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:48:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:48:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:48:08 --> Total execution time: 0.0057
DEBUG - 2022-03-01 10:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:52:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:52:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:52:52 --> Total execution time: 0.0061
DEBUG - 2022-03-01 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:59:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 10:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 10:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 10:59:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 10:59:52 --> Total execution time: 0.0057
DEBUG - 2022-03-01 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:24:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:24:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:24:08 --> Total execution time: 0.0058
DEBUG - 2022-03-01 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:29:57 --> No URI present. Default controller set.
DEBUG - 2022-03-01 11:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:29:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:29:57 --> Total execution time: 0.0313
DEBUG - 2022-03-01 11:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 11:29:57 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 11:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:30:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:30:00 --> Total execution time: 0.0061
DEBUG - 2022-03-01 11:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:30:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-01 11:30:03 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1414
DEBUG - 2022-03-01 11:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:30:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:30:05 --> Total execution time: 0.0044
DEBUG - 2022-03-01 11:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:35:41 --> No URI present. Default controller set.
DEBUG - 2022-03-01 11:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:35:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:35:41 --> Total execution time: 0.0299
DEBUG - 2022-03-01 11:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:35:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 11:35:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 11:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:35:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:35:43 --> Total execution time: 0.0052
DEBUG - 2022-03-01 11:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:35:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:35:44 --> Total execution time: 0.0115
DEBUG - 2022-03-01 11:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:40:26 --> No URI present. Default controller set.
DEBUG - 2022-03-01 11:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:40:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:40:26 --> Total execution time: 0.0324
DEBUG - 2022-03-01 11:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:40:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 11:40:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:40:27 --> No URI present. Default controller set.
DEBUG - 2022-03-01 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:40:27 --> Total execution time: 0.0036
DEBUG - 2022-03-01 11:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:40:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:40:35 --> Total execution time: 0.0040
DEBUG - 2022-03-01 11:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:40:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:40:40 --> Total execution time: 0.0107
DEBUG - 2022-03-01 11:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:40:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:40:50 --> Total execution time: 0.0040
DEBUG - 2022-03-01 11:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:42:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:42:34 --> Total execution time: 0.0373
DEBUG - 2022-03-01 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:42:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:42:39 --> Total execution time: 0.0043
DEBUG - 2022-03-01 11:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:42:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:42:39 --> Total execution time: 0.0042
DEBUG - 2022-03-01 11:45:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:45:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:45:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:45:19 --> Total execution time: 0.0374
DEBUG - 2022-03-01 11:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:45:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:45:36 --> Total execution time: 0.0105
DEBUG - 2022-03-01 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:46:01 --> No URI present. Default controller set.
DEBUG - 2022-03-01 11:46:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:46:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:46:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:46:01 --> Total execution time: 0.0051
DEBUG - 2022-03-01 11:46:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:46:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 11:46:01 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:46:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:46:05 --> Total execution time: 0.0047
DEBUG - 2022-03-01 11:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:46:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:46:11 --> Total execution time: 0.0039
DEBUG - 2022-03-01 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:46:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:46:14 --> Total execution time: 0.0098
DEBUG - 2022-03-01 11:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:46:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:46:18 --> Total execution time: 0.0035
DEBUG - 2022-03-01 11:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:57:41 --> No URI present. Default controller set.
DEBUG - 2022-03-01 11:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:57:41 --> Total execution time: 0.0313
DEBUG - 2022-03-01 11:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:57:41 --> No URI present. Default controller set.
DEBUG - 2022-03-01 11:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:57:41 --> Total execution time: 0.0030
DEBUG - 2022-03-01 11:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:57:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 11:57:42 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 11:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:57:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:57:44 --> Total execution time: 0.0051
DEBUG - 2022-03-01 11:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:57:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 11:57:47 --> Total execution time: 0.0108
DEBUG - 2022-03-01 11:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:57:49 --> Total execution time: 0.0043
DEBUG - 2022-03-01 11:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 11:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 11:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 11:57:50 --> Total execution time: 0.0034
DEBUG - 2022-03-01 12:12:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:12:52 --> Total execution time: 0.0339
DEBUG - 2022-03-01 12:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:13:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:13:01 --> Total execution time: 0.0106
DEBUG - 2022-03-01 12:13:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:13:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:13:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:13:06 --> Total execution time: 0.0084
DEBUG - 2022-03-01 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:21:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:21:55 --> Total execution time: 0.0385
DEBUG - 2022-03-01 12:23:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:23:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:23:42 --> Total execution time: 0.0383
DEBUG - 2022-03-01 12:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:25:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:25:54 --> Total execution time: 0.0362
DEBUG - 2022-03-01 12:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:26:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:26:24 --> Total execution time: 0.0135
DEBUG - 2022-03-01 12:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:26:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:26:27 --> Total execution time: 0.0099
DEBUG - 2022-03-01 12:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:27:14 --> Total execution time: 0.0060
DEBUG - 2022-03-01 12:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:45:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:45:04 --> Total execution time: 0.0397
DEBUG - 2022-03-01 12:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:45:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:45:07 --> Total execution time: 0.0059
DEBUG - 2022-03-01 12:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:47:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:47:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:47:51 --> Total execution time: 0.0055
DEBUG - 2022-03-01 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:58:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:58:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 12:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 12:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 12:58:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 12:58:53 --> Total execution time: 0.0054
DEBUG - 2022-03-01 13:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:01:54 --> No URI present. Default controller set.
DEBUG - 2022-03-01 13:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:01:54 --> Total execution time: 0.0301
DEBUG - 2022-03-01 13:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 13:01:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 13:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:01:55 --> No URI present. Default controller set.
DEBUG - 2022-03-01 13:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:01:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:01:55 --> Total execution time: 0.0038
DEBUG - 2022-03-01 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:02:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:02:02 --> Total execution time: 0.0046
DEBUG - 2022-03-01 13:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:02:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:02:05 --> Total execution time: 0.0127
DEBUG - 2022-03-01 13:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:18:14 --> Total execution time: 0.0342
DEBUG - 2022-03-01 13:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:18:16 --> Total execution time: 0.0042
DEBUG - 2022-03-01 13:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:18:19 --> Total execution time: 0.0109
DEBUG - 2022-03-01 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:21:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:21:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:21:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:21:02 --> Total execution time: 0.0057
DEBUG - 2022-03-01 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:29:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:29:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:29:36 --> Total execution time: 0.0082
DEBUG - 2022-03-01 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:35:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:35:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:35:38 --> Total execution time: 0.0060
DEBUG - 2022-03-01 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:42:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:42:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:42:37 --> Total execution time: 0.0063
DEBUG - 2022-03-01 13:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 13:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 13:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 13:48:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 13:48:14 --> Total execution time: 0.0399
DEBUG - 2022-03-01 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:43 --> No URI present. Default controller set.
DEBUG - 2022-03-01 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:17:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:17:43 --> Total execution time: 0.0305
DEBUG - 2022-03-01 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 14:17:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 14:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:44 --> No URI present. Default controller set.
DEBUG - 2022-03-01 14:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:17:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:17:44 --> Total execution time: 0.0036
DEBUG - 2022-03-01 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:17:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:17:46 --> Total execution time: 0.0065
DEBUG - 2022-03-01 14:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:17:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:17:48 --> Total execution time: 0.0234
DEBUG - 2022-03-01 14:17:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 14:17:52 --> 404 Page Not Found: Index/20
DEBUG - 2022-03-01 14:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:17:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:17:55 --> Total execution time: 0.0090
DEBUG - 2022-03-01 14:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 14:17:57 --> 404 Page Not Found: Index/40
DEBUG - 2022-03-01 14:18:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:18:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:18:04 --> Total execution time: 0.0110
DEBUG - 2022-03-01 14:18:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:18:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:18:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:18:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:18:54 --> Total execution time: 0.0149
DEBUG - 2022-03-01 14:18:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:18:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:18:55 --> Total execution time: 0.0088
DEBUG - 2022-03-01 14:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:18:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:18:58 --> Total execution time: 0.0091
DEBUG - 2022-03-01 14:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:19:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:19:02 --> Total execution time: 0.0090
DEBUG - 2022-03-01 14:19:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:19:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:19:37 --> Total execution time: 0.0114
DEBUG - 2022-03-01 14:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:20:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:20:47 --> Total execution time: 0.0107
DEBUG - 2022-03-01 14:20:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:20:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:20:50 --> Total execution time: 0.0085
DEBUG - 2022-03-01 14:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:20:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:20:54 --> Total execution time: 0.0103
DEBUG - 2022-03-01 14:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:21:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:21:01 --> Total execution time: 0.0087
DEBUG - 2022-03-01 14:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:21:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:21:04 --> Total execution time: 0.0114
DEBUG - 2022-03-01 14:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:21:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:21:11 --> Total execution time: 0.0094
DEBUG - 2022-03-01 14:21:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:21:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:21:14 --> Total execution time: 0.0093
DEBUG - 2022-03-01 14:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:25:21 --> Total execution time: 0.0387
DEBUG - 2022-03-01 14:25:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:25:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:25:26 --> Total execution time: 0.0061
DEBUG - 2022-03-01 14:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:25:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:25:34 --> Total execution time: 0.0099
DEBUG - 2022-03-01 14:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:44:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:44:58 --> Total execution time: 0.0513
DEBUG - 2022-03-01 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:45:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:45:00 --> Total execution time: 0.0100
DEBUG - 2022-03-01 14:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:45:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:45:03 --> Total execution time: 0.0116
DEBUG - 2022-03-01 14:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:45:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:45:25 --> Total execution time: 0.0171
DEBUG - 2022-03-01 14:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:45:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:45:39 --> Total execution time: 0.0134
DEBUG - 2022-03-01 14:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:48:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:48:06 --> Total execution time: 0.0419
DEBUG - 2022-03-01 14:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:48:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:48:36 --> Total execution time: 0.0133
DEBUG - 2022-03-01 14:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:50:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:50:00 --> Total execution time: 0.0416
DEBUG - 2022-03-01 14:59:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 14:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 14:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 14:59:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 14:59:19 --> Total execution time: 0.0535
DEBUG - 2022-03-01 15:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:01:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:01:03 --> Total execution time: 0.0404
DEBUG - 2022-03-01 15:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:07:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:07:07 --> Total execution time: 0.0465
DEBUG - 2022-03-01 15:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:07:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:07:09 --> Total execution time: 0.0048
DEBUG - 2022-03-01 15:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:12:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:12:28 --> Total execution time: 0.0476
DEBUG - 2022-03-01 15:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:12:34 --> Total execution time: 0.0115
DEBUG - 2022-03-01 15:12:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:12:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:12:43 --> Total execution time: 0.0092
DEBUG - 2022-03-01 15:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:12:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:12:55 --> Total execution time: 0.0130
DEBUG - 2022-03-01 15:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:16:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:16:48 --> Total execution time: 0.0379
DEBUG - 2022-03-01 15:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:17:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:17:24 --> Total execution time: 0.0121
DEBUG - 2022-03-01 15:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:17:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:17:31 --> Total execution time: 0.0095
DEBUG - 2022-03-01 15:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:17:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:17:36 --> Total execution time: 0.0053
DEBUG - 2022-03-01 15:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:17:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:17:50 --> Total execution time: 0.0061
DEBUG - 2022-03-01 15:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:20:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:20:09 --> Total execution time: 0.0388
DEBUG - 2022-03-01 15:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:20:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:20:15 --> Total execution time: 0.0096
DEBUG - 2022-03-01 15:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:20:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:20:16 --> Total execution time: 0.0086
DEBUG - 2022-03-01 15:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:20:27 --> Total execution time: 0.0063
DEBUG - 2022-03-01 15:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:20:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:20:30 --> Total execution time: 0.0063
DEBUG - 2022-03-01 15:20:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:20:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:20:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:20:32 --> Total execution time: 0.0075
DEBUG - 2022-03-01 15:20:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:20:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:20:34 --> Total execution time: 0.0090
DEBUG - 2022-03-01 15:23:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 15:23:01 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /home/dunr4521/public_html/integrity/application/controllers/Data.php 33
DEBUG - 2022-03-01 15:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 15:23:03 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /home/dunr4521/public_html/integrity/application/controllers/Data.php 33
DEBUG - 2022-03-01 15:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 15:23:05 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /home/dunr4521/public_html/integrity/application/controllers/Data.php 33
DEBUG - 2022-03-01 15:23:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:09 --> No URI present. Default controller set.
DEBUG - 2022-03-01 15:23:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:23:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:23:09 --> Total execution time: 0.0225
DEBUG - 2022-03-01 15:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 15:23:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 15:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:10 --> No URI present. Default controller set.
DEBUG - 2022-03-01 15:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:23:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:23:10 --> Total execution time: 0.0032
DEBUG - 2022-03-01 15:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:23:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:23:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:23:13 --> Total execution time: 0.0050
DEBUG - 2022-03-01 15:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 15:23:16 --> Severity: error --> Exception: syntax error, unexpected '$config' (T_VARIABLE) /home/dunr4521/public_html/integrity/application/controllers/Data.php 33
DEBUG - 2022-03-01 15:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:24:46 --> No URI present. Default controller set.
DEBUG - 2022-03-01 15:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:24:46 --> Total execution time: 0.0307
DEBUG - 2022-03-01 15:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:24:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 15:24:47 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 15:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:24:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:24:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:24:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:24:48 --> Total execution time: 0.0047
DEBUG - 2022-03-01 15:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:24:50 --> Total execution time: 0.0092
DEBUG - 2022-03-01 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:25:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:25:14 --> Total execution time: 0.0120
DEBUG - 2022-03-01 15:26:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:26:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:26:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:26:07 --> Total execution time: 0.0086
DEBUG - 2022-03-01 15:26:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:26:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:26:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:26:24 --> Total execution time: 0.0074
DEBUG - 2022-03-01 15:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:26:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:26:27 --> Total execution time: 0.0069
DEBUG - 2022-03-01 15:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:45:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:45:36 --> Total execution time: 0.0431
DEBUG - 2022-03-01 15:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:45:55 --> Total execution time: 0.0060
DEBUG - 2022-03-01 15:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:46:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:46:00 --> Total execution time: 0.0068
DEBUG - 2022-03-01 15:46:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:46:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:46:07 --> Total execution time: 0.0046
DEBUG - 2022-03-01 15:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:46:13 --> Total execution time: 0.0089
DEBUG - 2022-03-01 15:46:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:46:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:46:18 --> Total execution time: 0.0044
DEBUG - 2022-03-01 15:48:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:48:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:48:46 --> Total execution time: 0.0363
DEBUG - 2022-03-01 15:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:49:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:49:03 --> Total execution time: 0.0110
DEBUG - 2022-03-01 15:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:51:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:51:05 --> Total execution time: 0.0332
DEBUG - 2022-03-01 15:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:51:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:51:40 --> Total execution time: 0.0048
DEBUG - 2022-03-01 15:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:51:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:51:41 --> Total execution time: 0.0084
DEBUG - 2022-03-01 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:52:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:52:04 --> Total execution time: 0.0086
DEBUG - 2022-03-01 15:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:52:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:52:06 --> Total execution time: 0.0050
DEBUG - 2022-03-01 15:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:52:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:52:24 --> Total execution time: 0.0111
DEBUG - 2022-03-01 15:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 15:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 15:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 15:55:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 15:55:45 --> Total execution time: 0.0356
DEBUG - 2022-03-01 16:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:00:38 --> No URI present. Default controller set.
DEBUG - 2022-03-01 16:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:00:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:00:38 --> Total execution time: 0.0312
DEBUG - 2022-03-01 16:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:00:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 16:00:38 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-01 16:03:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:03:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 16:03:17 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-03-01 16:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:03:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:03:19 --> Total execution time: 0.0352
DEBUG - 2022-03-01 16:03:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:03:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 16:03:20 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-03-01 16:03:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:03:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:03:22 --> Total execution time: 0.0054
DEBUG - 2022-03-01 16:03:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:03:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 16:03:37 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-03-01 16:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:04:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:04:10 --> Total execution time: 0.0067
DEBUG - 2022-03-01 16:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:04:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 16:04:12 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-03-01 16:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:04:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:04:13 --> Total execution time: 0.0047
DEBUG - 2022-03-01 16:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:05:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:05:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:05:29 --> Total execution time: 0.0359
DEBUG - 2022-03-01 16:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:05:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-01 16:05:32 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-03-01 16:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:05:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:05:33 --> Total execution time: 0.0056
DEBUG - 2022-03-01 16:06:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:06:45 --> Total execution time: 0.0334
DEBUG - 2022-03-01 16:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:06:47 --> Total execution time: 0.0042
DEBUG - 2022-03-01 16:06:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:06:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:06:48 --> Total execution time: 0.0089
DEBUG - 2022-03-01 16:06:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:06:49 --> Total execution time: 0.0035
DEBUG - 2022-03-01 16:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:06:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:06:50 --> Total execution time: 0.0061
DEBUG - 2022-03-01 16:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:07:33 --> Total execution time: 0.0067
DEBUG - 2022-03-01 16:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:10:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:10:22 --> Total execution time: 0.0369
DEBUG - 2022-03-01 16:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:11:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:11:27 --> Total execution time: 0.0109
DEBUG - 2022-03-01 16:11:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:11:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:11:38 --> Total execution time: 0.0048
DEBUG - 2022-03-01 16:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:11:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:11:39 --> Total execution time: 0.0062
DEBUG - 2022-03-01 16:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:11:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:11:49 --> Total execution time: 0.0095
DEBUG - 2022-03-01 16:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:15:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:15:13 --> Total execution time: 0.0421
DEBUG - 2022-03-01 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:15:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:15:15 --> Total execution time: 0.0058
DEBUG - 2022-03-01 16:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:15:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:15:21 --> Total execution time: 0.0108
DEBUG - 2022-03-01 16:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:15:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:15:46 --> Total execution time: 0.0059
DEBUG - 2022-03-01 16:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:15:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:15:47 --> Total execution time: 0.0044
DEBUG - 2022-03-01 16:15:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:15:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:15:49 --> Total execution time: 0.0040
DEBUG - 2022-03-01 16:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:15:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:15:50 --> Total execution time: 0.0055
DEBUG - 2022-03-01 16:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:15:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:15:51 --> Total execution time: 0.0104
DEBUG - 2022-03-01 16:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:16:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:16:01 --> Total execution time: 0.0046
DEBUG - 2022-03-01 16:16:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:16:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:16:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:16:01 --> Total execution time: 0.0048
DEBUG - 2022-03-01 16:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:16:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:16:03 --> Total execution time: 0.0103
DEBUG - 2022-03-01 16:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:16:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:16:23 --> Total execution time: 0.0050
DEBUG - 2022-03-01 16:17:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:17:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:17:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:17:09 --> Total execution time: 0.0066
DEBUG - 2022-03-01 16:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:17:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:17:50 --> Total execution time: 0.0065
DEBUG - 2022-03-01 16:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:17:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:17:53 --> Total execution time: 0.0051
DEBUG - 2022-03-01 16:18:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:18:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:18:15 --> Total execution time: 0.0082
DEBUG - 2022-03-01 16:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:18:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:18:17 --> Total execution time: 0.0104
DEBUG - 2022-03-01 16:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:18:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:18:19 --> Total execution time: 0.0090
DEBUG - 2022-03-01 16:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:18:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:18:21 --> Total execution time: 0.0091
DEBUG - 2022-03-01 16:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:18:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:18:23 --> Total execution time: 0.0100
DEBUG - 2022-03-01 16:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:23:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:23:33 --> Total execution time: 0.0416
DEBUG - 2022-03-01 16:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:27:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:27:00 --> Total execution time: 0.0386
DEBUG - 2022-03-01 16:27:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:27:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:27:03 --> Total execution time: 0.0075
DEBUG - 2022-03-01 16:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:27:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:27:13 --> Total execution time: 0.0078
DEBUG - 2022-03-01 16:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:27:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:27:17 --> Total execution time: 0.0067
DEBUG - 2022-03-01 16:27:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:27:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:27:33 --> Total execution time: 0.0084
DEBUG - 2022-03-01 16:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:27:44 --> Total execution time: 0.0074
DEBUG - 2022-03-01 16:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:28:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:28:10 --> Total execution time: 0.0094
DEBUG - 2022-03-01 16:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:28:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:28:35 --> Total execution time: 0.0093
DEBUG - 2022-03-01 16:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:37:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:37:57 --> Total execution time: 0.0406
DEBUG - 2022-03-01 16:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:38:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:38:01 --> Total execution time: 0.0095
DEBUG - 2022-03-01 16:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:39:08 --> Total execution time: 0.0114
DEBUG - 2022-03-01 16:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:39:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:39:13 --> Total execution time: 0.0080
DEBUG - 2022-03-01 16:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:39:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:39:26 --> Total execution time: 0.0107
DEBUG - 2022-03-01 16:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:39:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:39:38 --> Total execution time: 0.0118
DEBUG - 2022-03-01 16:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:39:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:39:57 --> Total execution time: 0.0098
DEBUG - 2022-03-01 16:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:39:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:39:59 --> Total execution time: 0.0093
DEBUG - 2022-03-01 16:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:40:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:40:01 --> Total execution time: 0.0099
DEBUG - 2022-03-01 16:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:40:03 --> Total execution time: 0.0051
DEBUG - 2022-03-01 16:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:40:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:40:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:40:05 --> Total execution time: 0.0042
DEBUG - 2022-03-01 16:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:40:17 --> Total execution time: 0.0047
DEBUG - 2022-03-01 16:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:40:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:40:24 --> Total execution time: 0.0050
DEBUG - 2022-03-01 16:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:40:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-01 16:40:49 --> Total execution time: 0.0064
DEBUG - 2022-03-01 16:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:40:53 --> Total execution time: 0.0047
DEBUG - 2022-03-01 16:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-01 16:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-01 16:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-01 16:41:07 --> Total execution time: 0.0036
