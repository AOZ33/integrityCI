<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-31 06:20:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 06:20:07 --> No URI present. Default controller set.
DEBUG - 2021-12-31 06:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 06:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 06:20:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 06:20:07 --> Total execution time: 0.0305
DEBUG - 2021-12-31 09:16:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:16:45 --> No URI present. Default controller set.
DEBUG - 2021-12-31 09:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:16:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:16:45 --> Total execution time: 0.0307
DEBUG - 2021-12-31 09:16:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:16:45 --> No URI present. Default controller set.
DEBUG - 2021-12-31 09:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:16:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:16:45 --> Total execution time: 0.0043
DEBUG - 2021-12-31 09:16:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:16:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 09:16:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-31 09:16:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:16:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 09:16:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-31 09:26:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:26:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:26:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:26:22 --> Total execution time: 0.0078
DEBUG - 2021-12-31 09:27:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:27:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:27:07 --> Total execution time: 0.0640
DEBUG - 2021-12-31 09:27:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:27:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:27:11 --> Total execution time: 0.0055
DEBUG - 2021-12-31 09:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:42:22 --> Total execution time: 0.0076
DEBUG - 2021-12-31 09:50:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:50:13 --> No URI present. Default controller set.
DEBUG - 2021-12-31 09:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:50:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:50:13 --> Total execution time: 0.0322
DEBUG - 2021-12-31 09:50:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:50:13 --> No URI present. Default controller set.
DEBUG - 2021-12-31 09:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:50:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:50:13 --> Total execution time: 0.0041
DEBUG - 2021-12-31 09:50:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 09:50:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-31 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:50:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:50:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:50:21 --> Total execution time: 0.0066
DEBUG - 2021-12-31 09:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:50:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:50:23 --> Total execution time: 0.0375
DEBUG - 2021-12-31 09:50:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:50:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:50:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:50:42 --> Total execution time: 0.0061
DEBUG - 2021-12-31 09:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:53:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:53:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:53:55 --> Total execution time: 0.0079
DEBUG - 2021-12-31 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:58:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 09:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 09:58:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 09:58:40 --> Total execution time: 0.0070
DEBUG - 2021-12-31 10:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:03:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:03:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:03:22 --> Total execution time: 0.0075
DEBUG - 2021-12-31 10:07:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:07:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:07:22 --> Total execution time: 0.0074
DEBUG - 2021-12-31 10:07:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:07:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:07:25 --> Total execution time: 0.0413
DEBUG - 2021-12-31 10:09:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:09:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:09:17 --> Total execution time: 0.0336
DEBUG - 2021-12-31 10:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:18:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:18:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:18:50 --> Total execution time: 0.0072
DEBUG - 2021-12-31 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:23:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:23:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:23:51 --> Total execution time: 0.0078
DEBUG - 2021-12-31 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:30:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:30:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:30:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:30:08 --> Total execution time: 0.0070
DEBUG - 2021-12-31 10:34:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:34:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:34:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:34:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:34:38 --> Total execution time: 0.0076
DEBUG - 2021-12-31 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:42:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:42:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:42:05 --> Total execution time: 0.0072
DEBUG - 2021-12-31 10:51:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:51:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:51:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:51:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:51:06 --> Total execution time: 0.0076
DEBUG - 2021-12-31 10:54:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:54:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:54:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 10:54:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 10:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 10:54:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 10:54:56 --> Total execution time: 0.0074
DEBUG - 2021-12-31 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:05:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:05:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:05:28 --> Total execution time: 0.0076
DEBUG - 2021-12-31 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:07:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:07:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:07:10 --> Total execution time: 0.0074
DEBUG - 2021-12-31 11:12:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:12:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:12:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:12:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:12:33 --> Total execution time: 0.0077
DEBUG - 2021-12-31 11:12:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:12:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:12:36 --> Total execution time: 0.0560
DEBUG - 2021-12-31 11:50:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:50:39 --> No URI present. Default controller set.
DEBUG - 2021-12-31 11:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:50:39 --> Total execution time: 0.0311
DEBUG - 2021-12-31 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 11:50:40 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-31 11:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 11:50:40 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-31 11:50:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:50:45 --> Total execution time: 0.0078
DEBUG - 2021-12-31 11:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:50:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-31 11:50:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-31 11:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:50:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:50:55 --> Total execution time: 0.0412
DEBUG - 2021-12-31 11:51:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:51:14 --> Total execution time: 0.0051
DEBUG - 2021-12-31 11:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:51:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:51:19 --> Total execution time: 0.0380
DEBUG - 2021-12-31 11:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:51:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:51:44 --> Total execution time: 0.0057
DEBUG - 2021-12-31 11:52:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:52:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:52:19 --> Total execution time: 0.0331
DEBUG - 2021-12-31 11:52:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 11:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 11:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 11:52:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 11:52:26 --> Total execution time: 0.0396
DEBUG - 2021-12-31 12:27:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 12:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 12:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 12:27:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 12:27:23 --> Total execution time: 0.0347
DEBUG - 2021-12-31 12:27:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 12:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 12:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 12:27:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 12:27:57 --> Total execution time: 0.0664
DEBUG - 2021-12-31 12:59:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 12:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 12:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 12:59:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 12:59:25 --> Total execution time: 0.0346
DEBUG - 2021-12-31 13:05:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:05:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:05:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:05:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:05:14 --> Total execution time: 0.0071
DEBUG - 2021-12-31 13:13:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:13:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:13:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:13:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:13:31 --> Total execution time: 0.0075
DEBUG - 2021-12-31 13:16:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:16:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:16:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:16:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:16:42 --> Total execution time: 0.0079
DEBUG - 2021-12-31 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:28:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:28:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:28:42 --> Total execution time: 0.0076
DEBUG - 2021-12-31 13:35:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:35:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:35:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:35:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:35:34 --> Total execution time: 0.0070
DEBUG - 2021-12-31 13:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:35:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:35:59 --> Total execution time: 0.0398
DEBUG - 2021-12-31 13:45:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:45:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:45:37 --> Total execution time: 0.0336
DEBUG - 2021-12-31 13:53:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:53:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:53:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 13:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 13:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 13:53:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 13:53:43 --> Total execution time: 0.0073
DEBUG - 2021-12-31 14:03:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:03:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:03:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:03:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:03:53 --> Total execution time: 0.0067
DEBUG - 2021-12-31 14:09:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:09:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:09:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:09:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:09:37 --> Total execution time: 0.0072
DEBUG - 2021-12-31 14:13:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:13:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:13:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:13:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:13:43 --> Total execution time: 0.0077
DEBUG - 2021-12-31 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:19:27 --> Total execution time: 0.0076
DEBUG - 2021-12-31 14:19:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:19:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:19:29 --> Total execution time: 0.0420
DEBUG - 2021-12-31 14:25:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:25:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:25:41 --> Total execution time: 0.0337
DEBUG - 2021-12-31 14:37:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:37:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:37:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:37:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:37:39 --> Total execution time: 0.0075
DEBUG - 2021-12-31 14:48:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:48:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:48:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:48:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:48:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:48:18 --> Total execution time: 0.0072
DEBUG - 2021-12-31 14:56:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:56:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 14:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 14:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 14:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 14:56:20 --> Total execution time: 0.0079
DEBUG - 2021-12-31 15:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:02:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:02:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:02:42 --> Total execution time: 0.0070
DEBUG - 2021-12-31 15:05:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:05:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:05:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:05:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:05:18 --> Total execution time: 0.0066
DEBUG - 2021-12-31 15:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:05:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:05:22 --> Total execution time: 0.0473
DEBUG - 2021-12-31 15:11:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:11:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:11:41 --> Total execution time: 0.0337
DEBUG - 2021-12-31 15:17:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:17:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:17:17 --> Total execution time: 0.0071
DEBUG - 2021-12-31 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:21:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:21:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:21:14 --> Total execution time: 0.0067
DEBUG - 2021-12-31 15:25:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:25:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:25:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:25:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:25:55 --> Total execution time: 0.0085
DEBUG - 2021-12-31 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:27:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:27:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:27:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:27:34 --> Total execution time: 0.0071
DEBUG - 2021-12-31 15:32:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:32:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:32:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:32:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:32:05 --> Total execution time: 0.0072
DEBUG - 2021-12-31 15:32:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-31 15:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-31 15:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-31 15:32:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-31 15:32:10 --> Total execution time: 0.0426
