<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-16 16:09:49 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-16 16:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-16 16:09:49 --> No URI present. Default controller set.
DEBUG - 2022-01-16 16:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-16 16:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-16 16:09:49 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-01-16 16:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-16 16:09:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-16 16:09:49 --> Total execution time: 0.0318
DEBUG - 2022-01-16 16:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-16 16:09:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-16 16:09:50 --> 404 Page Not Found: Assets/https:
