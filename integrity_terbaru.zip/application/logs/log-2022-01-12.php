<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-12 10:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:03:24 --> No URI present. Default controller set.
DEBUG - 2022-01-12 10:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:03:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 10:03:24 --> Total execution time: 0.0305
DEBUG - 2022-01-12 10:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-12 10:03:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-12 10:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:03:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 10:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:03:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 10:03:34 --> Total execution time: 0.0037
DEBUG - 2022-01-12 10:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:03:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-12 10:03:34 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-12 10:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:03:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 10:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:03:52 --> Total execution time: 0.0062
DEBUG - 2022-01-12 10:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:03:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 10:03:57 --> Total execution time: 0.1639
DEBUG - 2022-01-12 10:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 10:15:06 --> Total execution time: 0.0332
DEBUG - 2022-01-12 10:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 10:20:10 --> Total execution time: 0.2099
DEBUG - 2022-01-12 10:29:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 10:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 10:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 10:29:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 10:29:17 --> Total execution time: 0.0333
DEBUG - 2022-01-12 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:16:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:16:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:16:54 --> Total execution time: 0.0068
DEBUG - 2022-01-12 11:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:26:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:26:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:26:19 --> Total execution time: 0.0062
DEBUG - 2022-01-12 11:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:31:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:31:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:31:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:31:07 --> Total execution time: 0.0066
DEBUG - 2022-01-12 11:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:36:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:36:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:36:27 --> Total execution time: 0.0064
DEBUG - 2022-01-12 11:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:44:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:44:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:44:00 --> Total execution time: 0.0058
DEBUG - 2022-01-12 11:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:51:24 --> No URI present. Default controller set.
DEBUG - 2022-01-12 11:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:51:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:51:24 --> Total execution time: 0.0325
DEBUG - 2022-01-12 11:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:51:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-12 11:51:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-12 11:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:53:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:53:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:53:23 --> Total execution time: 0.0060
DEBUG - 2022-01-12 11:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:59:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:59:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 11:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 11:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 11:59:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 11:59:02 --> Total execution time: 0.0055
DEBUG - 2022-01-12 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 12:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 12:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 12:03:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 12:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 12:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 12:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 12:03:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 12:03:16 --> Total execution time: 0.0056
DEBUG - 2022-01-12 12:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 12:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 12:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 12:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 12:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 12:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 12:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 12:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 12:30:18 --> Total execution time: 0.0067
DEBUG - 2022-01-12 12:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 12:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 12:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 12:30:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 12:30:21 --> Total execution time: 0.1809
DEBUG - 2022-01-12 13:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:09:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:09:21 --> Total execution time: 0.0352
DEBUG - 2022-01-12 13:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:14:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:14:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:14:12 --> Total execution time: 0.0060
DEBUG - 2022-01-12 13:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:14:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:14:14 --> Total execution time: 0.1704
DEBUG - 2022-01-12 13:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:15:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:15:16 --> Total execution time: 0.0057
DEBUG - 2022-01-12 13:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:21:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:21:44 --> Total execution time: 0.1674
DEBUG - 2022-01-12 13:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:25:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:25:52 --> Total execution time: 0.0332
DEBUG - 2022-01-12 13:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:32:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:32:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:32:04 --> Total execution time: 0.0056
DEBUG - 2022-01-12 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:32:12 --> Total execution time: 0.1295
DEBUG - 2022-01-12 13:33:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:33:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:33:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:33:40 --> Total execution time: 0.0319
DEBUG - 2022-01-12 13:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:33:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:33:41 --> Total execution time: 0.0037
DEBUG - 2022-01-12 13:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:37:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:37:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:37:40 --> Total execution time: 0.0055
DEBUG - 2022-01-12 13:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:41:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:41:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:41:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:41:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:41:33 --> Total execution time: 0.0056
DEBUG - 2022-01-12 13:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:46:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:47:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:47:04 --> Total execution time: 0.0068
DEBUG - 2022-01-12 13:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:51:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:51:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:51:47 --> Total execution time: 0.0059
DEBUG - 2022-01-12 13:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:56:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:56:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:56:33 --> Total execution time: 0.0065
DEBUG - 2022-01-12 13:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:58:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 13:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 13:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 13:58:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 13:58:44 --> Total execution time: 0.0050
DEBUG - 2022-01-12 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:03:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:03:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:03:54 --> Total execution time: 0.0061
DEBUG - 2022-01-12 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:06:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:06:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:06:10 --> Total execution time: 0.0047
DEBUG - 2022-01-12 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:10:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:10:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:10:57 --> Total execution time: 0.0060
DEBUG - 2022-01-12 14:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:15:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:15:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:15:06 --> Total execution time: 0.0059
DEBUG - 2022-01-12 14:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:20:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:20:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:20:11 --> Total execution time: 0.0064
DEBUG - 2022-01-12 14:20:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:20:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:20:15 --> Total execution time: 0.1309
DEBUG - 2022-01-12 14:21:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:21:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:21:44 --> Total execution time: 0.0329
DEBUG - 2022-01-12 14:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:27:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:27:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:27:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:27:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:27:43 --> Total execution time: 0.0061
DEBUG - 2022-01-12 14:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:34:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:34:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:34:50 --> Total execution time: 0.0061
DEBUG - 2022-01-12 14:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:37:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:37:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:37:01 --> Total execution time: 0.0057
DEBUG - 2022-01-12 14:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:40:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:40:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:40:56 --> Total execution time: 0.0062
DEBUG - 2022-01-12 14:46:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:46:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:46:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:46:06 --> Total execution time: 0.0064
DEBUG - 2022-01-12 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:48:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:48:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:48:45 --> Total execution time: 0.0055
DEBUG - 2022-01-12 14:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:56:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:56:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:56:07 --> Total execution time: 0.0054
DEBUG - 2022-01-12 14:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:56:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 14:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 14:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 14:56:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 14:56:36 --> Total execution time: 0.0040
DEBUG - 2022-01-12 15:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:03:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:03:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:03:19 --> Total execution time: 0.0055
DEBUG - 2022-01-12 15:08:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:08:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:08:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:08:25 --> Total execution time: 0.0060
DEBUG - 2022-01-12 15:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:16:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:16:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:16:33 --> Total execution time: 0.0064
DEBUG - 2022-01-12 15:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:21:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:21:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:21:24 --> Total execution time: 0.0066
DEBUG - 2022-01-12 15:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:24:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:24:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:24:37 --> Total execution time: 0.0046
DEBUG - 2022-01-12 15:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:28:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:28:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:28:02 --> Total execution time: 0.0075
DEBUG - 2022-01-12 15:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:54:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:54:54 --> Total execution time: 0.0070
DEBUG - 2022-01-12 15:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:55:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:55:11 --> Total execution time: 0.1425
DEBUG - 2022-01-12 15:56:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 15:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 15:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 15:56:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 15:56:38 --> Total execution time: 0.0323
DEBUG - 2022-01-12 16:01:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:01:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:01:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:01:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:01:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:01:02 --> Total execution time: 0.0065
DEBUG - 2022-01-12 16:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:03:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:03:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:03:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:03:13 --> Total execution time: 0.0050
DEBUG - 2022-01-12 16:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:06:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:06:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:06:42 --> Total execution time: 0.0063
DEBUG - 2022-01-12 16:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:11:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:11:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:11:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:11:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:11:04 --> Total execution time: 0.0057
DEBUG - 2022-01-12 16:11:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:11:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:11:28 --> Total execution time: 0.1658
DEBUG - 2022-01-12 16:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:15:19 --> Total execution time: 0.0338
DEBUG - 2022-01-12 16:15:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:15:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:15:20 --> Total execution time: 0.0037
DEBUG - 2022-01-12 16:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:21:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:21:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:21:01 --> Total execution time: 0.0065
DEBUG - 2022-01-12 16:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:30:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:30:19 --> Total execution time: 0.0065
DEBUG - 2022-01-12 16:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:39:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:39:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:39:44 --> Total execution time: 0.0058
DEBUG - 2022-01-12 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:46:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:46:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:46:53 --> Total execution time: 0.0063
DEBUG - 2022-01-12 16:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:50:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:50:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:50:11 --> Total execution time: 0.0060
DEBUG - 2022-01-12 16:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:50:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:50:17 --> Total execution time: 0.1331
DEBUG - 2022-01-12 16:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:52:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:52:41 --> Total execution time: 0.0316
DEBUG - 2022-01-12 16:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:57:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 16:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 16:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 16:57:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 16:57:31 --> Total execution time: 0.0065
DEBUG - 2022-01-12 17:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:00:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:00:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:00:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:00:17 --> Total execution time: 0.0063
DEBUG - 2022-01-12 17:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:03:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:03:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:03:16 --> Total execution time: 0.0059
DEBUG - 2022-01-12 17:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:10:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:10:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:10:08 --> Total execution time: 0.0058
DEBUG - 2022-01-12 17:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:11:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:11:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:11:46 --> Total execution time: 0.0054
DEBUG - 2022-01-12 17:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:11:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:11:50 --> Total execution time: 0.1790
DEBUG - 2022-01-12 17:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:13:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-12 17:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-12 17:13:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-12 17:13:13 --> Total execution time: 0.0035
DEBUG - 2022-01-12 17:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-12 17:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-12 17:13:17 --> 404 Page Not Found: Assets/https:
