<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-07 03:11:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:29 --> No URI present. Default controller set.
DEBUG - 2021-12-07 03:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:29 --> Total execution time: 0.1188
DEBUG - 2021-12-07 03:11:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:39 --> Total execution time: 0.0316
DEBUG - 2021-12-07 03:11:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:42 --> Total execution time: 0.0424
DEBUG - 2021-12-07 03:11:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:48 --> Total execution time: 0.0420
DEBUG - 2021-12-07 03:11:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:50 --> Total execution time: 0.0438
DEBUG - 2021-12-07 03:11:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:52 --> Total execution time: 0.0446
DEBUG - 2021-12-07 03:11:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:53 --> Total execution time: 0.0501
DEBUG - 2021-12-07 03:11:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:11:57 --> Total execution time: 0.0480
DEBUG - 2021-12-07 03:12:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:12:04 --> Total execution time: 0.0412
DEBUG - 2021-12-07 03:12:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:12:06 --> Total execution time: 0.0422
DEBUG - 2021-12-07 03:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:12:12 --> Total execution time: 0.0487
DEBUG - 2021-12-07 03:12:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:12:14 --> Total execution time: 0.0464
DEBUG - 2021-12-07 03:12:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:12:15 --> Total execution time: 0.0433
DEBUG - 2021-12-07 03:12:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:12:15 --> Total execution time: 0.0397
DEBUG - 2021-12-07 03:12:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:12:16 --> Total execution time: 0.0493
DEBUG - 2021-12-07 03:13:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:13:15 --> Total execution time: 0.0496
DEBUG - 2021-12-07 03:13:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:13:52 --> Total execution time: 0.0417
DEBUG - 2021-12-07 03:14:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 03:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 03:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 03:14:26 --> Total execution time: 0.0409
DEBUG - 2021-12-07 04:06:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:06:07 --> No URI present. Default controller set.
DEBUG - 2021-12-07 04:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:06:07 --> Total execution time: 0.4654
DEBUG - 2021-12-07 04:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:06:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:06:09 --> Total execution time: 0.0956
DEBUG - 2021-12-07 04:06:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:06:11 --> Total execution time: 0.0784
DEBUG - 2021-12-07 04:10:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:10:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:10:46 --> Total execution time: 0.0447
DEBUG - 2021-12-07 04:17:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:17:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:17:05 --> Total execution time: 0.0396
DEBUG - 2021-12-07 04:31:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:31:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:31:18 --> Total execution time: 0.0404
DEBUG - 2021-12-07 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:35:10 --> Total execution time: 0.0416
DEBUG - 2021-12-07 04:38:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:38:38 --> Total execution time: 0.0571
DEBUG - 2021-12-07 04:40:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:40:19 --> Total execution time: 0.0519
DEBUG - 2021-12-07 04:40:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:40:52 --> Total execution time: 0.0442
DEBUG - 2021-12-07 04:42:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:42:49 --> Total execution time: 0.0527
DEBUG - 2021-12-07 04:42:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:42:51 --> Total execution time: 0.0369
DEBUG - 2021-12-07 04:42:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:42:52 --> Total execution time: 0.0490
DEBUG - 2021-12-07 04:44:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:44:03 --> Total execution time: 0.0480
DEBUG - 2021-12-07 04:52:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-07 04:52:53 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-07 04:52:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:52:57 --> Total execution time: 0.0522
DEBUG - 2021-12-07 04:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:53:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:53:08 --> Total execution time: 0.0418
DEBUG - 2021-12-07 04:53:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:53:43 --> Total execution time: 0.0474
DEBUG - 2021-12-07 04:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 04:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 04:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 04:53:46 --> Total execution time: 0.0380
DEBUG - 2021-12-07 06:03:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:03:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:03:28 --> Total execution time: 0.0515
DEBUG - 2021-12-07 06:38:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:38:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:38:01 --> Total execution time: 0.0519
DEBUG - 2021-12-07 06:38:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:38:27 --> Total execution time: 0.0440
DEBUG - 2021-12-07 06:38:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:38:30 --> Total execution time: 0.0481
DEBUG - 2021-12-07 06:39:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:39:45 --> Total execution time: 0.0398
DEBUG - 2021-12-07 06:39:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:39:47 --> Total execution time: 0.0448
DEBUG - 2021-12-07 06:47:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:47:13 --> Total execution time: 0.0266
DEBUG - 2021-12-07 06:47:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:47:14 --> Total execution time: 0.0451
DEBUG - 2021-12-07 06:47:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:47:16 --> Total execution time: 0.0425
DEBUG - 2021-12-07 06:47:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:47:17 --> Total execution time: 0.0440
DEBUG - 2021-12-07 06:47:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:47:50 --> Total execution time: 0.0418
DEBUG - 2021-12-07 06:47:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:47:51 --> Total execution time: 0.0493
DEBUG - 2021-12-07 06:47:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-07 06:47:52 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-07 06:47:52 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-07 06:47:52 --> Total execution time: 0.0489
DEBUG - 2021-12-07 06:48:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-07 06:48:00 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-07 06:48:00 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-07 06:48:00 --> Total execution time: 0.0387
DEBUG - 2021-12-07 06:48:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-07 06:48:01 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-07 06:48:01 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-07 06:48:01 --> Total execution time: 0.0430
DEBUG - 2021-12-07 06:48:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-07 06:48:07 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-07 06:48:07 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-07 06:48:07 --> Total execution time: 0.0263
DEBUG - 2021-12-07 06:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:49:07 --> Total execution time: 0.0431
DEBUG - 2021-12-07 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-07 06:49:17 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\admin\index.php 79
ERROR - 2021-12-07 06:49:17 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\nesnu\application\views\admin\index.php 80
DEBUG - 2021-12-07 06:49:17 --> Total execution time: 0.0400
DEBUG - 2021-12-07 06:49:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-07 06:49:25 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\admin\index.php 79
ERROR - 2021-12-07 06:49:25 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\nesnu\application\views\admin\index.php 80
DEBUG - 2021-12-07 06:49:25 --> Total execution time: 0.0502
DEBUG - 2021-12-07 06:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:49:35 --> Total execution time: 0.0437
DEBUG - 2021-12-07 06:49:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:49:38 --> Total execution time: 0.0459
DEBUG - 2021-12-07 06:49:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:49:39 --> Total execution time: 0.0451
DEBUG - 2021-12-07 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:49:40 --> Total execution time: 0.0430
DEBUG - 2021-12-07 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:49:40 --> Total execution time: 0.0422
DEBUG - 2021-12-07 06:49:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:49:59 --> Total execution time: 0.0483
DEBUG - 2021-12-07 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:01 --> Total execution time: 0.0375
DEBUG - 2021-12-07 06:50:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:03 --> Total execution time: 0.0443
DEBUG - 2021-12-07 06:50:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:03 --> Total execution time: 0.0451
DEBUG - 2021-12-07 06:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:04 --> Total execution time: 0.0388
DEBUG - 2021-12-07 06:50:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:05 --> Total execution time: 0.0460
DEBUG - 2021-12-07 06:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:14 --> Total execution time: 0.0346
DEBUG - 2021-12-07 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:16 --> Total execution time: 0.0350
DEBUG - 2021-12-07 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:16 --> Total execution time: 0.0362
DEBUG - 2021-12-07 06:50:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:18 --> Total execution time: 0.0468
DEBUG - 2021-12-07 06:50:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:26 --> Total execution time: 0.0405
DEBUG - 2021-12-07 06:50:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:27 --> Total execution time: 0.0386
DEBUG - 2021-12-07 06:50:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:28 --> Total execution time: 0.0463
DEBUG - 2021-12-07 06:50:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:32 --> No URI present. Default controller set.
DEBUG - 2021-12-07 06:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:32 --> Total execution time: 0.0412
DEBUG - 2021-12-07 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 06:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 06:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 06:50:33 --> Total execution time: 0.0339
DEBUG - 2021-12-07 07:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 07:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 07:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 07:03:35 --> Total execution time: 0.0351
DEBUG - 2021-12-07 07:15:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 07:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 07:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 07:15:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 07:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 07:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 07:15:46 --> Total execution time: 0.0519
DEBUG - 2021-12-07 08:33:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:33:03 --> Total execution time: 0.0322
DEBUG - 2021-12-07 08:34:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:34:21 --> Total execution time: 0.0479
DEBUG - 2021-12-07 08:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:52:35 --> Total execution time: 0.0388
DEBUG - 2021-12-07 08:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:56:36 --> Total execution time: 0.0475
DEBUG - 2021-12-07 08:57:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:57:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:57:24 --> Total execution time: 0.0351
DEBUG - 2021-12-07 08:57:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:57:30 --> No URI present. Default controller set.
DEBUG - 2021-12-07 08:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:57:30 --> Total execution time: 0.0274
DEBUG - 2021-12-07 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:58:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:58:09 --> Total execution time: 0.0234
DEBUG - 2021-12-07 08:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 08:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 08:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 08:58:28 --> Total execution time: 0.0435
DEBUG - 2021-12-07 09:04:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:04:17 --> Total execution time: 0.0412
DEBUG - 2021-12-07 09:04:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:04:19 --> Total execution time: 0.0452
DEBUG - 2021-12-07 09:04:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:04:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:04:40 --> Total execution time: 0.0419
DEBUG - 2021-12-07 09:04:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:04:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:04:45 --> Total execution time: 0.0433
DEBUG - 2021-12-07 09:04:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:04:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:04:51 --> Total execution time: 0.0240
DEBUG - 2021-12-07 09:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:18:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:18:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:18:37 --> Total execution time: 0.0493
DEBUG - 2021-12-07 09:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:18:45 --> Total execution time: 0.0399
DEBUG - 2021-12-07 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:18:52 --> Total execution time: 0.0240
DEBUG - 2021-12-07 09:19:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:00 --> Total execution time: 0.0687
DEBUG - 2021-12-07 09:19:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:07 --> Total execution time: 0.0465
DEBUG - 2021-12-07 09:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:08 --> Total execution time: 0.0436
DEBUG - 2021-12-07 09:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:09 --> Total execution time: 0.0400
DEBUG - 2021-12-07 09:19:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:19 --> Total execution time: 0.0238
DEBUG - 2021-12-07 09:19:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:21 --> Total execution time: 0.0511
DEBUG - 2021-12-07 09:19:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:31 --> Total execution time: 0.0410
DEBUG - 2021-12-07 09:19:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:37 --> Total execution time: 0.0403
DEBUG - 2021-12-07 09:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:43 --> Total execution time: 0.0585
DEBUG - 2021-12-07 09:19:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:52 --> Total execution time: 0.0559
DEBUG - 2021-12-07 09:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:19:57 --> Total execution time: 0.0416
DEBUG - 2021-12-07 09:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:20:42 --> Total execution time: 0.0413
DEBUG - 2021-12-07 09:20:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:20:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:20:48 --> Total execution time: 0.0416
DEBUG - 2021-12-07 09:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:20:58 --> Total execution time: 0.0533
DEBUG - 2021-12-07 09:21:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:24 --> Total execution time: 0.0417
DEBUG - 2021-12-07 09:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:31 --> Total execution time: 0.0467
DEBUG - 2021-12-07 09:21:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:32 --> Total execution time: 0.0350
DEBUG - 2021-12-07 09:21:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:33 --> Total execution time: 0.0443
DEBUG - 2021-12-07 09:21:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:35 --> Total execution time: 0.0348
DEBUG - 2021-12-07 09:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:36 --> Total execution time: 0.0272
DEBUG - 2021-12-07 09:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:36 --> Total execution time: 0.0399
DEBUG - 2021-12-07 09:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:36 --> Total execution time: 0.0370
DEBUG - 2021-12-07 09:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:21:37 --> Total execution time: 0.0257
DEBUG - 2021-12-07 09:27:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:27:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:27:59 --> Total execution time: 0.0458
DEBUG - 2021-12-07 09:28:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:28:02 --> Total execution time: 0.0493
DEBUG - 2021-12-07 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-07 09:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-07 09:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-07 09:28:11 --> Total execution time: 0.0423
