<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-23 00:47:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 00:47:01 --> No URI present. Default controller set.
DEBUG - 2022-04-23 00:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 00:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-23 00:47:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-23 00:47:01 --> Total execution time: 0.0594
DEBUG - 2022-04-23 02:08:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 02:08:59 --> No URI present. Default controller set.
DEBUG - 2022-04-23 02:08:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 02:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-23 02:08:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-23 02:08:59 --> Total execution time: 0.0425
DEBUG - 2022-04-23 06:46:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 06:46:49 --> No URI present. Default controller set.
DEBUG - 2022-04-23 06:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-23 06:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-23 06:46:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-23 06:46:49 --> Total execution time: 0.0379
DEBUG - 2022-04-23 15:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 15:00:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 15:00:34 --> 404 Page Not Found: Git/config
DEBUG - 2022-04-23 15:00:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 15:00:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 15:00:34 --> 404 Page Not Found: DS_Store/index
DEBUG - 2022-04-23 15:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 15:00:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 15:00:36 --> 404 Page Not Found: Git/config
DEBUG - 2022-04-23 15:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 15:00:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 15:00:38 --> 404 Page Not Found: DS_Store/index
DEBUG - 2022-04-23 15:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 15:00:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 15:00:39 --> 404 Page Not Found: DS_Store/index
DEBUG - 2022-04-23 15:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 15:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 15:00:42 --> 404 Page Not Found: DS_Store/index
DEBUG - 2022-04-23 15:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 15:00:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 15:00:47 --> 404 Page Not Found: Git/config
DEBUG - 2022-04-23 15:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-23 15:00:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-23 15:00:49 --> 404 Page Not Found: Git/config
