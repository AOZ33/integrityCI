<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-08 02:59:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 02:59:10 --> No URI present. Default controller set.
DEBUG - 2021-12-08 02:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 02:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 02:59:10 --> Total execution time: 0.1079
DEBUG - 2021-12-08 02:59:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 02:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 02:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 02:59:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 02:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 02:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 02:59:12 --> Total execution time: 0.0515
DEBUG - 2021-12-08 02:59:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 02:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 03:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 03:00:00 --> Total execution time: 0.0478
DEBUG - 2021-12-08 03:00:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 03:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 03:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 03:00:10 --> Total execution time: 0.0291
DEBUG - 2021-12-08 03:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 03:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 03:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 03:49:35 --> Total execution time: 0.0277
DEBUG - 2021-12-08 03:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 03:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 03:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 03:49:40 --> Total execution time: 0.0400
DEBUG - 2021-12-08 03:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 03:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 03:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 03:51:44 --> Total execution time: 0.0461
DEBUG - 2021-12-08 03:55:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 03:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 03:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 03:55:37 --> Total execution time: 0.0295
DEBUG - 2021-12-08 03:55:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 03:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 03:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 03:55:38 --> Total execution time: 0.0377
DEBUG - 2021-12-08 03:55:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 03:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 03:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 03:55:40 --> Total execution time: 0.0490
DEBUG - 2021-12-08 04:34:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:34:59 --> Total execution time: 0.0608
DEBUG - 2021-12-08 04:35:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:35:46 --> Total execution time: 0.0390
DEBUG - 2021-12-08 04:35:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:35:47 --> Total execution time: 0.0493
DEBUG - 2021-12-08 04:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:45:53 --> Total execution time: 0.0416
DEBUG - 2021-12-08 04:50:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:50:08 --> Total execution time: 0.0321
DEBUG - 2021-12-08 04:50:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:50:29 --> Total execution time: 0.0265
DEBUG - 2021-12-08 04:50:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:50:30 --> Total execution time: 0.0467
DEBUG - 2021-12-08 04:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:51:43 --> Total execution time: 0.0435
DEBUG - 2021-12-08 04:52:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:52:25 --> Total execution time: 0.0414
DEBUG - 2021-12-08 04:53:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:53:09 --> Total execution time: 0.0481
DEBUG - 2021-12-08 04:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:53:52 --> Total execution time: 0.0551
DEBUG - 2021-12-08 04:55:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:55:31 --> Total execution time: 0.0282
DEBUG - 2021-12-08 04:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:55:49 --> Total execution time: 0.0524
DEBUG - 2021-12-08 04:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:56:02 --> Total execution time: 0.0507
DEBUG - 2021-12-08 04:56:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:56:15 --> Total execution time: 0.0276
DEBUG - 2021-12-08 04:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:56:55 --> Total execution time: 0.0483
DEBUG - 2021-12-08 04:57:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:57:07 --> Total execution time: 0.0418
DEBUG - 2021-12-08 04:57:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 04:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 04:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 04:57:45 --> Total execution time: 0.0441
DEBUG - 2021-12-08 05:01:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:01:14 --> Total execution time: 0.0461
DEBUG - 2021-12-08 05:01:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:01:26 --> Total execution time: 0.0384
DEBUG - 2021-12-08 05:01:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:01:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:01:39 --> Total execution time: 0.0487
DEBUG - 2021-12-08 05:03:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:03:20 --> Total execution time: 0.0415
DEBUG - 2021-12-08 05:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:03:38 --> Total execution time: 0.0277
DEBUG - 2021-12-08 05:03:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:03:50 --> Total execution time: 0.0402
DEBUG - 2021-12-08 05:13:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:13:42 --> Total execution time: 0.0504
DEBUG - 2021-12-08 05:13:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:13:44 --> Total execution time: 0.0442
DEBUG - 2021-12-08 05:23:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:23:30 --> Total execution time: 0.0296
DEBUG - 2021-12-08 05:23:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:23:49 --> Total execution time: 0.0376
DEBUG - 2021-12-08 05:24:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:24:30 --> Total execution time: 0.0419
DEBUG - 2021-12-08 05:34:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:34:04 --> Total execution time: 0.0514
DEBUG - 2021-12-08 05:36:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:36:16 --> Total execution time: 0.0474
DEBUG - 2021-12-08 05:44:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 05:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 05:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 05:44:38 --> Total execution time: 0.0535
DEBUG - 2021-12-08 06:40:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:40:14 --> Total execution time: 0.0310
DEBUG - 2021-12-08 06:40:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:40:28 --> Total execution time: 0.0523
DEBUG - 2021-12-08 06:40:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:40:42 --> Total execution time: 0.0454
DEBUG - 2021-12-08 06:41:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:41:19 --> Total execution time: 0.0452
DEBUG - 2021-12-08 06:41:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:41:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:41:25 --> Total execution time: 0.0520
DEBUG - 2021-12-08 06:42:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:42:44 --> Total execution time: 0.0374
DEBUG - 2021-12-08 06:42:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:42:55 --> Total execution time: 0.0291
DEBUG - 2021-12-08 06:43:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:43:03 --> Total execution time: 0.0280
DEBUG - 2021-12-08 06:43:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:43:23 --> Total execution time: 0.0373
DEBUG - 2021-12-08 06:44:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:44:05 --> Total execution time: 0.0463
DEBUG - 2021-12-08 06:44:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:44:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:44:39 --> Total execution time: 0.0410
DEBUG - 2021-12-08 06:45:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:45:36 --> Total execution time: 0.0433
DEBUG - 2021-12-08 06:46:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:46:00 --> Total execution time: 0.0387
DEBUG - 2021-12-08 06:46:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:46:15 --> Total execution time: 0.0471
DEBUG - 2021-12-08 06:46:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:46:27 --> Total execution time: 0.0382
DEBUG - 2021-12-08 06:49:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:49:14 --> Total execution time: 0.0401
DEBUG - 2021-12-08 06:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:49:40 --> Total execution time: 0.0498
DEBUG - 2021-12-08 06:50:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:50:08 --> Total execution time: 0.0520
DEBUG - 2021-12-08 06:51:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:51:12 --> Total execution time: 0.0426
DEBUG - 2021-12-08 06:51:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 06:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 06:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 06:51:53 --> Total execution time: 0.0414
DEBUG - 2021-12-08 07:25:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:25:25 --> Total execution time: 0.0548
DEBUG - 2021-12-08 07:26:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:26:02 --> Total execution time: 0.0305
DEBUG - 2021-12-08 07:26:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:26:34 --> Total execution time: 0.0482
DEBUG - 2021-12-08 07:27:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:27:26 --> Total execution time: 0.0475
DEBUG - 2021-12-08 07:28:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:28:06 --> Total execution time: 0.0278
DEBUG - 2021-12-08 07:28:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:28:20 --> Total execution time: 0.0307
DEBUG - 2021-12-08 07:28:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:28:34 --> Total execution time: 0.0547
DEBUG - 2021-12-08 07:29:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:29:20 --> Total execution time: 0.0475
DEBUG - 2021-12-08 07:29:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:29:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:29:44 --> Total execution time: 0.0497
DEBUG - 2021-12-08 07:36:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:36:04 --> Total execution time: 0.0466
DEBUG - 2021-12-08 07:36:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:36:05 --> Severity: Warning --> Undefined property: Data::$Data_model C:\xampp\htdocs\nesnu\application\controllers\data.php 17
ERROR - 2021-12-08 07:36:05 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\data.php 17
DEBUG - 2021-12-08 07:36:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:36:29 --> Severity: error --> Exception: C:\xampp\htdocs\nesnu\application\models/Data_model.php exists, but doesn't declare class Data_model C:\xampp\htdocs\nesnu\system\core\Loader.php 340
DEBUG - 2021-12-08 07:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:36:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
DEBUG - 2021-12-08 07:36:48 --> Total execution time: 0.0848
DEBUG - 2021-12-08 07:37:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:37:20 --> Total execution time: 0.0371
DEBUG - 2021-12-08 07:37:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:37:20 --> Total execution time: 0.0373
DEBUG - 2021-12-08 07:41:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:41:09 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 32
DEBUG - 2021-12-08 07:41:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:41:19 --> Total execution time: 0.0469
DEBUG - 2021-12-08 07:42:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:42:06 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 32
DEBUG - 2021-12-08 07:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:42:07 --> Total execution time: 0.0436
DEBUG - 2021-12-08 07:42:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:42:08 --> Total execution time: 0.0372
DEBUG - 2021-12-08 07:45:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:45:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:45:12 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 32
DEBUG - 2021-12-08 07:45:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:45:17 --> Total execution time: 0.0528
DEBUG - 2021-12-08 07:46:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:46:10 --> Total execution time: 0.0420
DEBUG - 2021-12-08 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:47:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:47:15 --> Total execution time: 0.0519
DEBUG - 2021-12-08 07:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:47:18 --> Total execution time: 0.0462
DEBUG - 2021-12-08 07:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 83
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 93
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 237
ERROR - 2021-12-08 07:47:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 247
DEBUG - 2021-12-08 07:47:20 --> Total execution time: 0.0857
DEBUG - 2021-12-08 07:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:07 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 07:59:07 --> Total execution time: 0.0807
DEBUG - 2021-12-08 07:59:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:59:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 07:59:31 --> Total execution time: 0.0728
DEBUG - 2021-12-08 07:59:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:59:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:52 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 07:59:52 --> Total execution time: 0.0727
DEBUG - 2021-12-08 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 07:59:54 --> Total execution time: 0.0585
DEBUG - 2021-12-08 07:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 07:59:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 07:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 07:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 07:59:58 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 07:59:58 --> Total execution time: 0.0764
DEBUG - 2021-12-08 08:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 08:00:00 --> Total execution time: 0.0678
DEBUG - 2021-12-08 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:02 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 08:00:02 --> Total execution time: 0.0663
DEBUG - 2021-12-08 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 08:00:03 --> Total execution time: 0.0624
DEBUG - 2021-12-08 08:00:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:00:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined variable $place C:\xampp\htdocs\nesnu\application\views\data\index.php 193
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 266
ERROR - 2021-12-08 08:00:06 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 276
DEBUG - 2021-12-08 08:00:06 --> Total execution time: 0.0611
DEBUG - 2021-12-08 08:00:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:00:32 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
DEBUG - 2021-12-08 08:00:32 --> Total execution time: 0.0524
DEBUG - 2021-12-08 08:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:00:56 --> Total execution time: 0.0379
DEBUG - 2021-12-08 08:00:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:00:57 --> Total execution time: 0.0516
DEBUG - 2021-12-08 08:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:01:45 --> Total execution time: 0.0458
DEBUG - 2021-12-08 08:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:01:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:01:46 --> Total execution time: 0.0400
DEBUG - 2021-12-08 08:01:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:01:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:01:48 --> Total execution time: 0.0456
DEBUG - 2021-12-08 08:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:01:49 --> Total execution time: 0.0413
DEBUG - 2021-12-08 08:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:01:50 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
DEBUG - 2021-12-08 08:01:50 --> Total execution time: 0.0500
DEBUG - 2021-12-08 08:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:00 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
DEBUG - 2021-12-08 08:02:00 --> Total execution time: 0.0609
DEBUG - 2021-12-08 08:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:25 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
DEBUG - 2021-12-08 08:02:25 --> Total execution time: 0.0600
DEBUG - 2021-12-08 08:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 260
ERROR - 2021-12-08 08:02:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 270
DEBUG - 2021-12-08 08:02:48 --> Total execution time: 0.0594
DEBUG - 2021-12-08 08:03:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:03:26 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:03:26 --> Total execution time: 0.0526
DEBUG - 2021-12-08 08:04:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:04:03 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:04:03 --> Total execution time: 0.0551
DEBUG - 2021-12-08 08:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:07:23 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
DEBUG - 2021-12-08 08:07:23 --> Total execution time: 0.0598
DEBUG - 2021-12-08 08:08:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 357
ERROR - 2021-12-08 08:08:11 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 367
DEBUG - 2021-12-08 08:08:11 --> Total execution time: 0.0548
DEBUG - 2021-12-08 08:08:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:08:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:24 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:08:24 --> Total execution time: 0.0609
DEBUG - 2021-12-08 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:08:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:08:37 --> Total execution time: 0.0552
DEBUG - 2021-12-08 08:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:08:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
DEBUG - 2021-12-08 08:08:56 --> Total execution time: 0.0658
DEBUG - 2021-12-08 08:09:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:20 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
DEBUG - 2021-12-08 08:09:20 --> Total execution time: 0.0595
DEBUG - 2021-12-08 08:09:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
DEBUG - 2021-12-08 08:09:28 --> Total execution time: 0.0430
DEBUG - 2021-12-08 08:09:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:09:56 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
DEBUG - 2021-12-08 08:09:56 --> Total execution time: 0.0421
DEBUG - 2021-12-08 08:10:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 352
ERROR - 2021-12-08 08:10:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
DEBUG - 2021-12-08 08:10:12 --> Total execution time: 0.0521
DEBUG - 2021-12-08 08:10:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-08 08:10:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
DEBUG - 2021-12-08 08:10:48 --> Total execution time: 0.0878
DEBUG - 2021-12-08 08:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:11:09 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
DEBUG - 2021-12-08 08:11:09 --> Total execution time: 0.0766
DEBUG - 2021-12-08 08:12:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:12:21 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
DEBUG - 2021-12-08 08:12:21 --> Total execution time: 0.1185
DEBUG - 2021-12-08 08:13:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-08 08:13:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
DEBUG - 2021-12-08 08:13:12 --> Total execution time: 0.0676
DEBUG - 2021-12-08 08:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 402
ERROR - 2021-12-08 08:13:54 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 412
DEBUG - 2021-12-08 08:13:54 --> Total execution time: 0.0649
DEBUG - 2021-12-08 08:14:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:08 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
DEBUG - 2021-12-08 08:14:08 --> Total execution time: 0.0544
DEBUG - 2021-12-08 08:14:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:31 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
DEBUG - 2021-12-08 08:14:31 --> Total execution time: 0.0587
DEBUG - 2021-12-08 08:14:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-08 08:14:38 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
DEBUG - 2021-12-08 08:14:38 --> Total execution time: 0.0430
DEBUG - 2021-12-08 08:14:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:14:53 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:14:53 --> Total execution time: 0.0652
DEBUG - 2021-12-08 08:15:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:15:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:15:28 --> Total execution time: 0.0540
DEBUG - 2021-12-08 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:20:42 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 31
DEBUG - 2021-12-08 08:20:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:20:45 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:20:45 --> Total execution time: 0.0664
DEBUG - 2021-12-08 08:21:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:21:10 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 31
DEBUG - 2021-12-08 08:21:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:21:28 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:21:28 --> Total execution time: 0.0430
DEBUG - 2021-12-08 08:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:22:11 --> Total execution time: 0.0505
DEBUG - 2021-12-08 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:22:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:22:33 --> Total execution time: 0.0430
DEBUG - 2021-12-08 08:22:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:22:35 --> Total execution time: 0.0292
DEBUG - 2021-12-08 08:22:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:37 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:22:37 --> Total execution time: 0.0439
DEBUG - 2021-12-08 08:22:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:22:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:22:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:22:48 --> Total execution time: 0.0574
DEBUG - 2021-12-08 08:23:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:23:07 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 31
DEBUG - 2021-12-08 08:23:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:23:12 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:23:12 --> Total execution time: 0.0659
DEBUG - 2021-12-08 08:24:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:24:53 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 31
DEBUG - 2021-12-08 08:25:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:15 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:25:15 --> Total execution time: 0.0535
DEBUG - 2021-12-08 08:25:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:25:25 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 31
DEBUG - 2021-12-08 08:25:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:27 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:25:27 --> Total execution time: 0.0603
DEBUG - 2021-12-08 08:25:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:25:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "detail" C:\xampp\htdocs\nesnu\application\views\data\index.php 351
ERROR - 2021-12-08 08:25:48 --> Severity: Warning --> Undefined array key "place" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
DEBUG - 2021-12-08 08:25:48 --> Total execution time: 0.0556
DEBUG - 2021-12-08 08:32:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:32:14 --> Total execution time: 0.0382
DEBUG - 2021-12-08 08:32:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:32:56 --> Total execution time: 0.0396
DEBUG - 2021-12-08 08:34:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:34:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:34:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:34:16 --> Total execution time: 0.0418
DEBUG - 2021-12-08 08:34:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:34:46 --> Total execution time: 0.0294
DEBUG - 2021-12-08 08:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:36:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:36:07 --> Total execution time: 0.0404
DEBUG - 2021-12-08 08:36:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:36:21 --> Total execution time: 0.0293
DEBUG - 2021-12-08 08:36:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:36:54 --> Total execution time: 0.0471
DEBUG - 2021-12-08 08:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:37:29 --> Total execution time: 0.0475
DEBUG - 2021-12-08 08:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:37:38 --> Total execution time: 0.0395
DEBUG - 2021-12-08 08:37:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:37:56 --> Total execution time: 0.0383
DEBUG - 2021-12-08 08:38:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:38:48 --> Total execution time: 0.0290
DEBUG - 2021-12-08 08:39:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:39:51 --> Total execution time: 0.0510
DEBUG - 2021-12-08 08:40:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:40:35 --> Total execution time: 0.0461
DEBUG - 2021-12-08 08:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:41:16 --> Total execution time: 0.0434
DEBUG - 2021-12-08 08:41:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:41:21 --> Total execution time: 0.0422
DEBUG - 2021-12-08 08:41:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:41:32 --> Total execution time: 0.0508
DEBUG - 2021-12-08 08:44:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:44:03 --> Total execution time: 0.0522
DEBUG - 2021-12-08 08:44:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:44:04 --> Total execution time: 0.0282
DEBUG - 2021-12-08 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:46:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:46:39 --> Total execution time: 0.0304
DEBUG - 2021-12-08 08:47:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:47:00 --> Total execution time: 0.0367
DEBUG - 2021-12-08 08:47:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:47:02 --> Total execution time: 0.0502
DEBUG - 2021-12-08 08:47:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:47:02 --> Total execution time: 0.0430
DEBUG - 2021-12-08 08:47:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:47:35 --> Total execution time: 0.0515
DEBUG - 2021-12-08 08:47:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:47:36 --> Total execution time: 0.0286
DEBUG - 2021-12-08 08:47:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:47:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:47:49 --> Total execution time: 0.0477
DEBUG - 2021-12-08 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:52:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:52:25 --> Total execution time: 0.0390
DEBUG - 2021-12-08 08:53:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:53:17 --> Total execution time: 0.0426
DEBUG - 2021-12-08 08:57:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:57:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 08:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 08:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 08:57:36 --> Total execution time: 0.0284
DEBUG - 2021-12-08 09:00:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 09:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 09:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 09:00:18 --> Total execution time: 0.0497
DEBUG - 2021-12-08 09:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 09:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 09:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 09:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 09:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 09:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 09:03:34 --> Total execution time: 0.0407
DEBUG - 2021-12-08 09:03:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-08 09:03:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-08 09:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-08 09:03:37 --> Total execution time: 0.0302
