<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-17 03:07:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:40 --> No URI present. Default controller set.
DEBUG - 2021-12-17 03:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:40 --> Total execution time: 0.0663
DEBUG - 2021-12-17 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:41 --> Total execution time: 0.0624
DEBUG - 2021-12-17 03:07:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:43 --> Total execution time: 0.0512
DEBUG - 2021-12-17 03:07:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:43 --> Total execution time: 0.0451
DEBUG - 2021-12-17 03:07:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:45 --> Total execution time: 0.0442
DEBUG - 2021-12-17 03:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:45 --> Total execution time: 0.0457
DEBUG - 2021-12-17 03:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:46 --> Total execution time: 0.0369
DEBUG - 2021-12-17 03:07:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:47 --> Total execution time: 0.0435
DEBUG - 2021-12-17 03:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:48 --> Total execution time: 0.0468
DEBUG - 2021-12-17 03:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:49 --> Total execution time: 0.0447
DEBUG - 2021-12-17 03:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:50 --> Total execution time: 0.0403
DEBUG - 2021-12-17 03:07:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:07:55 --> Total execution time: 0.0265
DEBUG - 2021-12-17 03:08:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:08:16 --> Total execution time: 0.0458
DEBUG - 2021-12-17 03:08:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:08:17 --> Total execution time: 0.0272
DEBUG - 2021-12-17 03:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:08:18 --> Total execution time: 0.0452
DEBUG - 2021-12-17 03:45:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:45:25 --> Total execution time: 0.0467
DEBUG - 2021-12-17 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:45:26 --> Total execution time: 0.0358
DEBUG - 2021-12-17 03:45:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:45:26 --> Total execution time: 0.0430
DEBUG - 2021-12-17 03:45:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:45:27 --> Total execution time: 0.0366
DEBUG - 2021-12-17 03:45:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:45:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:45:28 --> Total execution time: 0.0394
DEBUG - 2021-12-17 03:45:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:45:29 --> Total execution time: 0.0454
DEBUG - 2021-12-17 03:45:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 03:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 03:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 03:45:30 --> Total execution time: 0.0248
DEBUG - 2021-12-17 04:25:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:25:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:25:25 --> Total execution time: 0.0391
DEBUG - 2021-12-17 04:25:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:25:30 --> Total execution time: 0.0446
DEBUG - 2021-12-17 04:25:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:25:30 --> Total execution time: 0.0475
DEBUG - 2021-12-17 04:25:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:25:31 --> Total execution time: 0.0407
DEBUG - 2021-12-17 04:25:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:25:32 --> Total execution time: 0.0601
DEBUG - 2021-12-17 04:25:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:25:33 --> Total execution time: 0.0732
DEBUG - 2021-12-17 04:25:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:25:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:25:33 --> Total execution time: 0.0507
DEBUG - 2021-12-17 04:28:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:28:18 --> Total execution time: 0.0402
DEBUG - 2021-12-17 04:28:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:30:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 79
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 80
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 81
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 82
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 223
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 224
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 225
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 226
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 227
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 228
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 229
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 300
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 301
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 302
ERROR - 2021-12-17 04:30:13 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 303
DEBUG - 2021-12-17 04:30:13 --> Total execution time: 0.0505
DEBUG - 2021-12-17 04:30:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:30:35 --> Total execution time: 0.0455
DEBUG - 2021-12-17 04:35:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:35:12 --> Total execution time: 0.0522
DEBUG - 2021-12-17 04:35:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 183
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 184
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 185
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 186
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 187
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 188
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 189
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 260
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 261
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 262
ERROR - 2021-12-17 04:35:14 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 263
DEBUG - 2021-12-17 04:35:14 --> Total execution time: 0.0527
DEBUG - 2021-12-17 04:35:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 183
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 184
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 185
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 186
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 187
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 188
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 189
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 260
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 261
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 262
ERROR - 2021-12-17 04:35:40 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 263
DEBUG - 2021-12-17 04:35:40 --> Total execution time: 0.0770
DEBUG - 2021-12-17 04:36:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:36:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 183
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 184
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 185
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 186
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 187
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 188
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 189
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 260
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 261
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 262
ERROR - 2021-12-17 04:36:06 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 263
DEBUG - 2021-12-17 04:36:06 --> Total execution time: 0.0336
DEBUG - 2021-12-17 04:36:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 183
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 184
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 185
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 186
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 187
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 188
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 259
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 260
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 261
ERROR - 2021-12-17 04:36:26 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 262
DEBUG - 2021-12-17 04:36:26 --> Total execution time: 0.0509
DEBUG - 2021-12-17 04:36:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:36:31 --> Total execution time: 0.0444
DEBUG - 2021-12-17 04:37:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 04:37:25 --> Total execution time: 0.0426
DEBUG - 2021-12-17 04:37:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 04:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 04:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined variable $appointment C:\xampp\htdocs\nesnu\application\views\editor\index.php 76
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\editor\index.php 76
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 173
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 174
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 175
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 176
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 250
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 251
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 252
ERROR - 2021-12-17 04:37:26 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 253
DEBUG - 2021-12-17 04:37:26 --> Total execution time: 0.0503
DEBUG - 2021-12-17 06:17:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:17:25 --> Total execution time: 0.0315
DEBUG - 2021-12-17 06:30:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:30:56 --> Total execution time: 0.0497
DEBUG - 2021-12-17 06:30:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 176
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 180
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 181
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 253
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 254
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 255
ERROR - 2021-12-17 06:30:58 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 256
DEBUG - 2021-12-17 06:30:58 --> Total execution time: 0.0418
DEBUG - 2021-12-17 06:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 176
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 180
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 181
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 253
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 254
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 255
ERROR - 2021-12-17 06:31:15 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 256
DEBUG - 2021-12-17 06:31:15 --> Total execution time: 0.0321
DEBUG - 2021-12-17 06:31:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined variable $date_ws C:\xampp\htdocs\nesnu\application\views\editor\index.php 144
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 176
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 180
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 181
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 253
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 254
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 255
ERROR - 2021-12-17 06:31:54 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 256
DEBUG - 2021-12-17 06:31:54 --> Total execution time: 0.0339
DEBUG - 2021-12-17 06:32:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 176
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 180
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 181
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 253
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 254
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 255
ERROR - 2021-12-17 06:32:02 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 256
DEBUG - 2021-12-17 06:32:02 --> Total execution time: 0.0499
DEBUG - 2021-12-17 06:41:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined variable $category C:\xampp\htdocs\nesnu\application\views\editor\index.php 111
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined variable $category C:\xampp\htdocs\nesnu\application\views\editor\index.php 112
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 176
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 180
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 181
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 253
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 254
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 255
ERROR - 2021-12-17 06:41:30 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 256
DEBUG - 2021-12-17 06:41:30 --> Total execution time: 0.0577
DEBUG - 2021-12-17 06:41:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 180
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 181
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 183
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 254
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 255
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 256
ERROR - 2021-12-17 06:41:54 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 257
DEBUG - 2021-12-17 06:41:54 --> Total execution time: 0.0541
DEBUG - 2021-12-17 06:42:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:42:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:42:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 176
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 180
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 181
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 253
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 254
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 255
ERROR - 2021-12-17 06:42:44 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 256
DEBUG - 2021-12-17 06:42:44 --> Total execution time: 0.0543
DEBUG - 2021-12-17 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 176
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 177
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 178
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 179
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "photograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 180
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "videograper" C:\xampp\htdocs\nesnu\application\views\editor\index.php 181
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "crew" C:\xampp\htdocs\nesnu\application\views\editor\index.php 182
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "phone" C:\xampp\htdocs\nesnu\application\views\editor\index.php 253
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\editor\index.php 254
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\editor\index.php 255
ERROR - 2021-12-17 06:43:05 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\editor\index.php 256
DEBUG - 2021-12-17 06:43:05 --> Total execution time: 0.0485
DEBUG - 2021-12-17 06:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:56:49 --> Total execution time: 0.0494
DEBUG - 2021-12-17 06:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:56:55 --> Total execution time: 0.0381
DEBUG - 2021-12-17 06:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:56:55 --> Total execution time: 0.0434
DEBUG - 2021-12-17 06:56:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:56:56 --> Total execution time: 0.0441
DEBUG - 2021-12-17 06:59:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:59:27 --> Total execution time: 0.0512
DEBUG - 2021-12-17 06:59:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:59:43 --> Total execution time: 0.0437
DEBUG - 2021-12-17 06:59:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 06:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 06:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 06:59:53 --> Total execution time: 0.0473
DEBUG - 2021-12-17 07:00:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:00:12 --> Total execution time: 0.0387
DEBUG - 2021-12-17 07:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:00:19 --> Total execution time: 0.0499
DEBUG - 2021-12-17 07:01:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:01:20 --> Total execution time: 0.0405
DEBUG - 2021-12-17 07:54:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:54:51 --> Total execution time: 0.0509
DEBUG - 2021-12-17 07:55:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:55:33 --> Total execution time: 0.0400
DEBUG - 2021-12-17 07:55:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:55:51 --> Total execution time: 0.0487
DEBUG - 2021-12-17 07:56:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:56:30 --> Total execution time: 0.0461
DEBUG - 2021-12-17 07:56:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:56:51 --> Total execution time: 0.0390
DEBUG - 2021-12-17 07:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:56:52 --> Total execution time: 0.0426
DEBUG - 2021-12-17 07:57:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:57:02 --> Total execution time: 0.0462
DEBUG - 2021-12-17 07:57:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:57:07 --> Total execution time: 0.0465
DEBUG - 2021-12-17 07:57:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:57:14 --> Total execution time: 0.0395
DEBUG - 2021-12-17 07:57:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:57:25 --> Total execution time: 0.0277
DEBUG - 2021-12-17 07:57:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 07:57:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 07:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 07:57:57 --> Total execution time: 0.0516
DEBUG - 2021-12-17 08:01:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:01:20 --> Total execution time: 0.0477
DEBUG - 2021-12-17 08:01:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:01:31 --> Total execution time: 0.0416
DEBUG - 2021-12-17 08:03:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:03:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:03:30 --> Total execution time: 0.0378
DEBUG - 2021-12-17 08:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:03:33 --> Total execution time: 0.0378
DEBUG - 2021-12-17 08:04:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:04:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:04:22 --> Total execution time: 0.0435
DEBUG - 2021-12-17 08:09:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:09:01 --> Total execution time: 0.0392
DEBUG - 2021-12-17 08:09:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:09:18 --> Total execution time: 0.0275
DEBUG - 2021-12-17 08:14:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:14:56 --> Total execution time: 0.0291
DEBUG - 2021-12-17 08:15:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:15:43 --> Total execution time: 0.0367
DEBUG - 2021-12-17 08:18:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:18:22 --> Total execution time: 0.0390
DEBUG - 2021-12-17 08:23:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:23:36 --> Total execution time: 0.0440
DEBUG - 2021-12-17 08:24:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:24:33 --> Total execution time: 0.0426
DEBUG - 2021-12-17 08:24:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:24:45 --> Total execution time: 0.0386
DEBUG - 2021-12-17 08:25:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:25:14 --> Total execution time: 0.0476
DEBUG - 2021-12-17 08:26:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:26:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:26:01 --> Total execution time: 0.0521
DEBUG - 2021-12-17 08:26:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:26:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:26:03 --> Total execution time: 0.0472
DEBUG - 2021-12-17 08:26:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:26:31 --> Total execution time: 0.0415
DEBUG - 2021-12-17 08:26:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:26:46 --> Total execution time: 0.0455
DEBUG - 2021-12-17 08:26:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:26:46 --> Total execution time: 0.0498
DEBUG - 2021-12-17 08:26:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:26:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:26:53 --> Total execution time: 0.0386
DEBUG - 2021-12-17 08:27:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:27:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:27:18 --> Total execution time: 0.0383
DEBUG - 2021-12-17 08:27:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:27:29 --> Total execution time: 0.0393
DEBUG - 2021-12-17 08:28:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:28:04 --> Total execution time: 0.0419
DEBUG - 2021-12-17 08:28:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:28:49 --> Total execution time: 0.0387
DEBUG - 2021-12-17 08:28:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:28:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:28:59 --> Total execution time: 0.0508
DEBUG - 2021-12-17 08:29:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:29:03 --> Total execution time: 0.0517
DEBUG - 2021-12-17 08:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:29:10 --> Total execution time: 0.0406
DEBUG - 2021-12-17 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:32:32 --> Total execution time: 0.0453
DEBUG - 2021-12-17 08:34:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:34:11 --> Total execution time: 0.0389
DEBUG - 2021-12-17 08:34:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:34:50 --> Total execution time: 0.0482
DEBUG - 2021-12-17 08:51:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:51:17 --> Total execution time: 0.0445
DEBUG - 2021-12-17 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:51:33 --> Total execution time: 0.0517
DEBUG - 2021-12-17 08:51:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:51:53 --> Total execution time: 0.0391
DEBUG - 2021-12-17 08:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:52:26 --> Total execution time: 0.0437
DEBUG - 2021-12-17 08:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:52:39 --> Total execution time: 0.0460
DEBUG - 2021-12-17 08:52:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 08:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 08:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 08:52:51 --> Total execution time: 0.0380
DEBUG - 2021-12-17 09:10:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:10:14 --> Total execution time: 0.0333
DEBUG - 2021-12-17 09:12:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:12:08 --> Total execution time: 0.0405
DEBUG - 2021-12-17 09:13:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:13:21 --> Total execution time: 0.0538
DEBUG - 2021-12-17 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:14:17 --> Total execution time: 0.0400
DEBUG - 2021-12-17 09:14:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:14:37 --> Total execution time: 0.0423
DEBUG - 2021-12-17 09:15:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:15:04 --> Total execution time: 0.0318
DEBUG - 2021-12-17 09:15:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:15:04 --> Total execution time: 0.0490
DEBUG - 2021-12-17 09:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:15:05 --> Total execution time: 0.0401
DEBUG - 2021-12-17 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:15:06 --> Total execution time: 0.0480
DEBUG - 2021-12-17 09:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:15:06 --> Total execution time: 0.0386
DEBUG - 2021-12-17 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:15:40 --> Total execution time: 0.0437
DEBUG - 2021-12-17 09:16:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:16:07 --> Total execution time: 0.0418
DEBUG - 2021-12-17 09:16:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:16:18 --> Total execution time: 0.0402
DEBUG - 2021-12-17 09:16:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:16:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:16:41 --> Total execution time: 0.0443
DEBUG - 2021-12-17 09:17:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:17:06 --> Total execution time: 0.0414
DEBUG - 2021-12-17 09:17:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:17:40 --> Total execution time: 0.0494
DEBUG - 2021-12-17 09:18:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:18:41 --> Total execution time: 0.0423
DEBUG - 2021-12-17 09:18:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:18:55 --> Total execution time: 0.0388
DEBUG - 2021-12-17 09:19:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:19:17 --> Total execution time: 0.0477
DEBUG - 2021-12-17 09:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:19:32 --> Total execution time: 0.0470
DEBUG - 2021-12-17 09:21:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:51 --> Total execution time: 0.0547
DEBUG - 2021-12-17 09:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:54 --> Total execution time: 0.0427
DEBUG - 2021-12-17 09:21:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:56 --> Total execution time: 0.0434
DEBUG - 2021-12-17 09:21:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:57 --> Total execution time: 0.0433
DEBUG - 2021-12-17 09:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:21:59 --> Total execution time: 0.0437
DEBUG - 2021-12-17 09:22:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:00 --> Total execution time: 0.0440
DEBUG - 2021-12-17 09:22:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:02 --> Total execution time: 0.0294
DEBUG - 2021-12-17 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:03 --> Total execution time: 0.0415
DEBUG - 2021-12-17 09:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:05 --> Total execution time: 0.0426
DEBUG - 2021-12-17 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:06 --> Total execution time: 0.0427
DEBUG - 2021-12-17 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:07 --> Total execution time: 0.0544
DEBUG - 2021-12-17 09:22:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:09 --> Total execution time: 0.0294
DEBUG - 2021-12-17 09:22:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:10 --> Total execution time: 0.0280
DEBUG - 2021-12-17 09:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:11 --> Total execution time: 0.0393
DEBUG - 2021-12-17 09:22:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:13 --> Total execution time: 0.0434
DEBUG - 2021-12-17 09:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:15 --> Total execution time: 0.0484
DEBUG - 2021-12-17 09:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:15 --> Total execution time: 0.0486
DEBUG - 2021-12-17 09:22:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:17 --> Total execution time: 0.0417
DEBUG - 2021-12-17 09:22:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:18 --> Total execution time: 0.0488
DEBUG - 2021-12-17 09:22:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:20 --> Total execution time: 0.0446
DEBUG - 2021-12-17 09:22:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:21 --> Total execution time: 0.0441
DEBUG - 2021-12-17 09:22:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:22 --> Total execution time: 0.0427
DEBUG - 2021-12-17 09:22:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:23 --> Total execution time: 0.0423
DEBUG - 2021-12-17 09:22:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:24 --> Total execution time: 0.0469
DEBUG - 2021-12-17 09:22:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:22:25 --> Total execution time: 0.0510
DEBUG - 2021-12-17 09:33:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:33:10 --> Total execution time: 0.0414
DEBUG - 2021-12-17 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-17 09:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-17 09:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-17 09:34:03 --> Total execution time: 0.0392
