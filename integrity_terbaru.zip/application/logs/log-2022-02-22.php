<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-22 00:27:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 00:27:19 --> No URI present. Default controller set.
DEBUG - 2022-02-22 00:27:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 00:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 00:27:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 00:27:19 --> Total execution time: 0.0309
DEBUG - 2022-02-22 02:05:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 02:05:08 --> No URI present. Default controller set.
DEBUG - 2022-02-22 02:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 02:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 02:05:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 02:05:09 --> Total execution time: 0.0309
DEBUG - 2022-02-22 04:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 04:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 04:49:27 --> No URI present. Default controller set.
DEBUG - 2022-02-22 04:49:27 --> No URI present. Default controller set.
DEBUG - 2022-02-22 04:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 04:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 04:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 04:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 04:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 04:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 04:49:27 --> Total execution time: 0.0319
DEBUG - 2022-02-22 04:49:27 --> Total execution time: 0.0319
DEBUG - 2022-02-22 04:49:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 04:49:40 --> No URI present. Default controller set.
DEBUG - 2022-02-22 04:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 04:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 04:49:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 04:49:40 --> Total execution time: 0.0044
DEBUG - 2022-02-22 04:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 04:49:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-22 04:49:42 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-22 09:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 09:56:04 --> No URI present. Default controller set.
DEBUG - 2022-02-22 09:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 09:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 09:56:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 09:56:04 --> Total execution time: 0.0300
DEBUG - 2022-02-22 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 09:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-22 09:56:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-22 10:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:02:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:02:57 --> Total execution time: 0.0064
DEBUG - 2022-02-22 10:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:02:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-22 10:02:59 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1465
DEBUG - 2022-02-22 10:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:03:14 --> Total execution time: 0.0049
DEBUG - 2022-02-22 10:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:03:18 --> Total execution time: 0.0044
DEBUG - 2022-02-22 10:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:03:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:03:19 --> Total execution time: 0.0032
DEBUG - 2022-02-22 10:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:03:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-22 10:03:34 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1465
DEBUG - 2022-02-22 10:03:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:03:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:03:38 --> Total execution time: 0.0038
DEBUG - 2022-02-22 10:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:16:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:16:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:16:36 --> Total execution time: 0.0059
DEBUG - 2022-02-22 10:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:34:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:34:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:34:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:34:28 --> Total execution time: 0.0069
DEBUG - 2022-02-22 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:41:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:41:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:41:34 --> Total execution time: 0.0060
DEBUG - 2022-02-22 10:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:49:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:49:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:49:32 --> Total execution time: 0.0056
DEBUG - 2022-02-22 10:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:54:35 --> Total execution time: 0.0058
DEBUG - 2022-02-22 10:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:57:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 10:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 10:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 10:57:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 10:57:41 --> Total execution time: 0.0061
DEBUG - 2022-02-22 11:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:03:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:03:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:03:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:03:07 --> Total execution time: 0.0058
DEBUG - 2022-02-22 11:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:10:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:10:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:10:54 --> Total execution time: 0.0061
DEBUG - 2022-02-22 11:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:14:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:14:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:14:21 --> Total execution time: 0.0060
DEBUG - 2022-02-22 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:17:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:17:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:17:56 --> Total execution time: 0.0064
DEBUG - 2022-02-22 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:35:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:35:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:35:17 --> Total execution time: 0.0059
DEBUG - 2022-02-22 11:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:39:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:39:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:39:39 --> Total execution time: 0.0062
DEBUG - 2022-02-22 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:49:23 --> Total execution time: 0.0063
DEBUG - 2022-02-22 11:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:54:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:54:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:54:03 --> Total execution time: 0.0061
DEBUG - 2022-02-22 11:58:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:58:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:58:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 11:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 11:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 11:58:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 11:58:56 --> Total execution time: 0.0057
DEBUG - 2022-02-22 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:01:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:01:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:01:52 --> Total execution time: 0.0060
DEBUG - 2022-02-22 12:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:11:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:11:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:11:41 --> Total execution time: 0.0060
DEBUG - 2022-02-22 12:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:19:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:19:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:19:31 --> Total execution time: 0.0057
DEBUG - 2022-02-22 12:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:26:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:26:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:26:50 --> Total execution time: 0.0057
DEBUG - 2022-02-22 12:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:35:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:35:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:35:38 --> Total execution time: 0.0068
DEBUG - 2022-02-22 12:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:40:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:40:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:40:34 --> Total execution time: 0.0058
DEBUG - 2022-02-22 12:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:45:11 --> No URI present. Default controller set.
DEBUG - 2022-02-22 12:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:45:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:45:11 --> Total execution time: 0.0299
DEBUG - 2022-02-22 12:45:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:45:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-22 12:45:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-22 12:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:46:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 12:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 12:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 12:46:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 12:46:19 --> Total execution time: 0.0062
DEBUG - 2022-02-22 13:02:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 13:02:29 --> No URI present. Default controller set.
DEBUG - 2022-02-22 13:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 13:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 13:02:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 13:02:30 --> Total execution time: 0.0305
DEBUG - 2022-02-22 13:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 13:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 13:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 13:38:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 13:38:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 13:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 13:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 13:38:39 --> Total execution time: 0.0052
DEBUG - 2022-02-22 13:38:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 13:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 13:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 13:38:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-22 13:38:42 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-22 13:38:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 13:38:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 13:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 13:38:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 13:38:45 --> Total execution time: 0.0040
DEBUG - 2022-02-22 13:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 13:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 13:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 13:47:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 13:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 13:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 13:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 13:47:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 13:47:03 --> Total execution time: 0.0054
DEBUG - 2022-02-22 14:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:09:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:09:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:09:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:09:35 --> Total execution time: 0.0061
DEBUG - 2022-02-22 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:12:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:12:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:12:03 --> Total execution time: 0.0050
DEBUG - 2022-02-22 14:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:15:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:15:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:15:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:15:29 --> Total execution time: 0.0047
DEBUG - 2022-02-22 14:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:26:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:26:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:26:06 --> Total execution time: 0.0054
DEBUG - 2022-02-22 14:30:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:30:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:30:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:30:26 --> Total execution time: 0.0335
DEBUG - 2022-02-22 14:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:30:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:30:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:30:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:30:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:30:28 --> Total execution time: 0.0038
DEBUG - 2022-02-22 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:33:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:33:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 14:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 14:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 14:33:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 14:33:04 --> Total execution time: 0.0062
DEBUG - 2022-02-22 15:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:11:13 --> No URI present. Default controller set.
DEBUG - 2022-02-22 15:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:11:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:11:13 --> Total execution time: 0.0302
DEBUG - 2022-02-22 15:11:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:11:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-22 15:11:17 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-22 15:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:11:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:11:50 --> Total execution time: 0.0061
DEBUG - 2022-02-22 15:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:11:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-22 15:11:52 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1414
DEBUG - 2022-02-22 15:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:12:03 --> Total execution time: 0.0035
DEBUG - 2022-02-22 15:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:12:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-22 15:12:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1414
DEBUG - 2022-02-22 15:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:12:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:12:18 --> Total execution time: 0.0041
DEBUG - 2022-02-22 15:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:21:00 --> Total execution time: 0.0065
DEBUG - 2022-02-22 15:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:22:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:22:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:22:47 --> Total execution time: 0.0047
DEBUG - 2022-02-22 15:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:24:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:24:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:24:59 --> Total execution time: 0.0054
DEBUG - 2022-02-22 15:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:28:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:28:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:28:20 --> Total execution time: 0.0060
DEBUG - 2022-02-22 15:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:31:13 --> Total execution time: 0.0054
DEBUG - 2022-02-22 15:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:33:19 --> Total execution time: 0.0053
DEBUG - 2022-02-22 15:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:37:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:37:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:37:01 --> Total execution time: 0.0066
DEBUG - 2022-02-22 15:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:39:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:39:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:39:40 --> Total execution time: 0.0053
DEBUG - 2022-02-22 15:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:42:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:42:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:42:00 --> Total execution time: 0.0067
DEBUG - 2022-02-22 15:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:44:57 --> Total execution time: 0.0053
DEBUG - 2022-02-22 15:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:47:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:47:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:47:43 --> Total execution time: 0.0053
DEBUG - 2022-02-22 15:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:48:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:48:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:48:50 --> Total execution time: 0.0041
DEBUG - 2022-02-22 15:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:50:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:50:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:50:26 --> Total execution time: 0.0063
DEBUG - 2022-02-22 15:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:51:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:51:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:51:56 --> Total execution time: 0.0061
DEBUG - 2022-02-22 15:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:53:40 --> Total execution time: 0.0065
DEBUG - 2022-02-22 15:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:54:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:54:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:54:36 --> Total execution time: 0.0041
DEBUG - 2022-02-22 15:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:56:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 15:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 15:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 15:56:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 15:56:50 --> Total execution time: 0.0046
DEBUG - 2022-02-22 16:19:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:19:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:19:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:19:15 --> Total execution time: 0.0076
DEBUG - 2022-02-22 16:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:25:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:25:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:25:01 --> Total execution time: 0.0064
DEBUG - 2022-02-22 16:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:27:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-22 16:27:20 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-22 16:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:28:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:28:18 --> Total execution time: 0.0053
DEBUG - 2022-02-22 16:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:33:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:33:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:33:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:33:00 --> Total execution time: 0.0063
DEBUG - 2022-02-22 16:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:36:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:36:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:36:34 --> Total execution time: 0.0059
DEBUG - 2022-02-22 16:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:38:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:38:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:38:48 --> Total execution time: 0.0061
DEBUG - 2022-02-22 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:38:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:38:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:38:59 --> Total execution time: 0.0041
DEBUG - 2022-02-22 16:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:39:54 --> No URI present. Default controller set.
DEBUG - 2022-02-22 16:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:39:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:39:54 --> Total execution time: 0.0047
DEBUG - 2022-02-22 16:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:41:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:41:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:41:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:41:22 --> Total execution time: 0.0051
DEBUG - 2022-02-22 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:44:37 --> Total execution time: 0.0056
DEBUG - 2022-02-22 16:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:50:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:50:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:50:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:50:05 --> Total execution time: 0.0059
DEBUG - 2022-02-22 16:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:51:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:51:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:51:05 --> Total execution time: 0.0041
DEBUG - 2022-02-22 16:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:52:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:52:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:52:45 --> Total execution time: 0.0049
DEBUG - 2022-02-22 16:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:54:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:54:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:54:45 --> Total execution time: 0.0062
DEBUG - 2022-02-22 16:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:58:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 16:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 16:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 16:58:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 16:58:17 --> Total execution time: 0.0048
DEBUG - 2022-02-22 17:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 17:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 17:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 17:00:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 17:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-22 17:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-22 17:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-22 17:00:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-22 17:00:40 --> Total execution time: 0.0047
