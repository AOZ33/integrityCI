<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-08-05 04:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-05 04:50:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-08-05 04:50:03 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-08-05 04:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-05 04:50:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-08-05 04:50:07 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-08-05 04:50:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:11 --> No URI present. Default controller set.
DEBUG - 2022-08-05 04:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:50:11 --> Total execution time: 0.1051
DEBUG - 2022-08-05 04:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:50:19 --> Total execution time: 0.0867
DEBUG - 2022-08-05 04:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:50:31 --> Total execution time: 0.0905
DEBUG - 2022-08-05 04:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:50:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:50:46 --> Total execution time: 0.0900
DEBUG - 2022-08-05 04:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:51:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:51:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:51:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:51:23 --> Total execution time: 0.0842
DEBUG - 2022-08-05 04:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:51:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:51:25 --> Total execution time: 0.0997
DEBUG - 2022-08-05 04:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:51:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:51:25 --> Total execution time: 0.0920
DEBUG - 2022-08-05 04:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 04:51:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 04:51:25 --> UTF-8 Support Enabled
ERROR - 2022-08-05 04:51:25 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-05 04:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 04:51:25 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 04:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 04:51:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 04:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 04:51:25 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 04:51:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 04:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:51:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:51:28 --> Total execution time: 0.0996
DEBUG - 2022-08-05 04:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:52:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:52:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:52:11 --> Total execution time: 0.0890
DEBUG - 2022-08-05 04:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:52:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:52:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:52:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:52:31 --> Total execution time: 0.1120
DEBUG - 2022-08-05 04:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:52:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:52:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:52:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:52:57 --> Total execution time: 0.0899
DEBUG - 2022-08-05 04:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:53:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:53:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:53:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:53:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:53:03 --> Total execution time: 0.0920
DEBUG - 2022-08-05 04:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:53:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:53:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:53:15 --> Total execution time: 0.0904
DEBUG - 2022-08-05 04:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:54:42 --> Total execution time: 0.1178
DEBUG - 2022-08-05 04:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:54:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:54:48 --> Total execution time: 0.1102
DEBUG - 2022-08-05 04:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:54:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:54:57 --> Total execution time: 0.2269
DEBUG - 2022-08-05 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:01 --> Total execution time: 0.1460
DEBUG - 2022-08-05 04:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:01 --> Total execution time: 0.1652
DEBUG - 2022-08-05 04:55:01 --> Total execution time: 0.1732
DEBUG - 2022-08-05 04:55:01 --> Total execution time: 0.2074
DEBUG - 2022-08-05 04:55:01 --> Total execution time: 0.1952
DEBUG - 2022-08-05 04:55:01 --> Total execution time: 0.2254
DEBUG - 2022-08-05 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 04:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 04:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 04:55:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 04:55:22 --> Total execution time: 0.0913
DEBUG - 2022-08-05 05:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:22:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:22:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:22:22 --> Total execution time: 0.0925
DEBUG - 2022-08-05 05:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:23:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:23:11 --> Total execution time: 0.1076
DEBUG - 2022-08-05 05:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:23:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:23:11 --> Total execution time: 0.1083
DEBUG - 2022-08-05 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:11 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:23:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:23:11 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:23:11 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:23:11 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 05:23:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:23:11 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:23:11 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-05 05:23:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:23:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:23:14 --> Total execution time: 0.0947
DEBUG - 2022-08-05 05:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:23:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:23:15 --> Total execution time: 0.0906
DEBUG - 2022-08-05 05:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:16 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:23:16 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 05:23:16 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:23:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:23:16 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-05 05:23:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:23:16 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:23:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:23:21 --> Total execution time: 0.1224
DEBUG - 2022-08-05 05:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:23:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:23:21 --> Total execution time: 0.0901
DEBUG - 2022-08-05 05:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:23:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:23:23 --> Total execution time: 0.0963
DEBUG - 2022-08-05 05:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:23:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:23:39 --> Total execution time: 0.1279
DEBUG - 2022-08-05 05:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:24:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:24:09 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:24:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:24:09 --> Total execution time: 0.0931
DEBUG - 2022-08-05 05:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:24:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:24:44 --> Total execution time: 0.1095
DEBUG - 2022-08-05 05:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:24:46 --> Total execution time: 0.1292
DEBUG - 2022-08-05 05:31:39 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:31:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:31:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:31:40 --> Total execution time: 0.0891
DEBUG - 2022-08-05 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:31:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:31:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:31:52 --> Total execution time: 0.0910
DEBUG - 2022-08-05 05:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:11 --> Total execution time: 0.1057
DEBUG - 2022-08-05 05:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:16 --> Total execution time: 0.0961
DEBUG - 2022-08-05 05:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:27 --> Total execution time: 0.1504
DEBUG - 2022-08-05 05:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:27 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:32:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:27 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:32:27 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:32:27 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:32:27 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-05 05:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:32:27 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:32:27 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 05:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:29 --> Total execution time: 0.0891
DEBUG - 2022-08-05 05:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:41 --> Total execution time: 0.0903
DEBUG - 2022-08-05 05:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:54 --> Total execution time: 0.1879
DEBUG - 2022-08-05 05:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:32:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:32:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:32:59 --> Total execution time: 0.1031
DEBUG - 2022-08-05 05:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:34:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:34:21 --> Total execution time: 0.1487
DEBUG - 2022-08-05 05:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:34:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:34:30 --> Total execution time: 0.0997
DEBUG - 2022-08-05 05:34:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:34:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:34:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:34:47 --> Total execution time: 0.1251
DEBUG - 2022-08-05 05:34:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:34:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:34:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:34:57 --> Total execution time: 0.0902
DEBUG - 2022-08-05 05:36:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:36:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:36:53 --> Total execution time: 0.1022
DEBUG - 2022-08-05 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:36:54 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-05 05:36:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:36:54 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:36:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:36:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:36:54 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-05 05:36:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:36:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:36:55 --> Total execution time: 0.0932
DEBUG - 2022-08-05 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:08 --> Total execution time: 0.1011
DEBUG - 2022-08-05 05:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:17 --> Total execution time: 0.0922
DEBUG - 2022-08-05 05:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:18 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:37:18 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:18 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:18 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:37:18 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-05 05:37:18 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-05 05:37:18 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:18 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:20 --> Total execution time: 0.1148
DEBUG - 2022-08-05 05:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:23 --> Total execution time: 0.1203
DEBUG - 2022-08-05 05:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:23 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-05 05:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:23 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:37:23 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:23 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:37:23 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:23 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:37:23 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:23 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 05:37:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:23 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:24 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:24 --> Total execution time: 0.1140
DEBUG - 2022-08-05 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:25 --> Total execution time: 0.0896
DEBUG - 2022-08-05 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:25 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:37:25 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:37:25 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:37:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:25 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-05 05:37:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:25 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 05:37:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:28 --> Total execution time: 0.0936
DEBUG - 2022-08-05 05:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:29 --> Total execution time: 0.0903
DEBUG - 2022-08-05 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:30 --> UTF-8 Support Enabled
ERROR - 2022-08-05 05:37:30 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-05 05:37:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:30 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:37:30 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:37:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:37:30 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-05 05:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:31 --> Total execution time: 0.0906
DEBUG - 2022-08-05 05:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:32 --> Total execution time: 0.0828
DEBUG - 2022-08-05 05:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:33 --> Total execution time: 0.0838
DEBUG - 2022-08-05 05:37:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:35 --> Total execution time: 0.0891
DEBUG - 2022-08-05 05:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:37:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:37:38 --> Total execution time: 0.0870
DEBUG - 2022-08-05 05:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:42:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:42:15 --> 404 Page Not Found: Auth/reset-password
DEBUG - 2022-08-05 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:42:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:42:16 --> Total execution time: 0.1039
DEBUG - 2022-08-05 05:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:42:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:42:17 --> Total execution time: 0.0964
DEBUG - 2022-08-05 05:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:42:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:42:25 --> Total execution time: 0.1084
DEBUG - 2022-08-05 05:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:43:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:43:38 --> Total execution time: 0.0966
DEBUG - 2022-08-05 05:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:43:57 --> Total execution time: 0.1047
DEBUG - 2022-08-05 05:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:44:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:44:10 --> Total execution time: 0.0995
DEBUG - 2022-08-05 05:47:45 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:47:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:47:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:47:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:47:45 --> Total execution time: 0.1238
DEBUG - 2022-08-05 05:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:49:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:49:53 --> Total execution time: 0.0974
DEBUG - 2022-08-05 05:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:50:44 --> Total execution time: 0.1442
DEBUG - 2022-08-05 05:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:51:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:51:15 --> Total execution time: 0.0991
DEBUG - 2022-08-05 05:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:51:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:51:22 --> Total execution time: 0.1302
DEBUG - 2022-08-05 05:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:51:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:51:52 --> Total execution time: 0.1061
DEBUG - 2022-08-05 05:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:54:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:54:25 --> Total execution time: 0.1255
DEBUG - 2022-08-05 05:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:54:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:54:52 --> Total execution time: 0.1003
DEBUG - 2022-08-05 05:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:55:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:55:06 --> Total execution time: 0.1652
DEBUG - 2022-08-05 05:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:55:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:55:40 --> Unable to find validation rule: 
ERROR - 2022-08-05 05:55:40 --> Could not find the language line "form_validation_"
DEBUG - 2022-08-05 05:55:40 --> Total execution time: 0.1006
DEBUG - 2022-08-05 05:55:44 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:55:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:55:44 --> Unable to find validation rule: 
ERROR - 2022-08-05 05:55:44 --> Could not find the language line "form_validation_"
DEBUG - 2022-08-05 05:55:44 --> Total execution time: 0.1320
DEBUG - 2022-08-05 05:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:55:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:55:51 --> Unable to find validation rule: 
ERROR - 2022-08-05 05:55:51 --> Could not find the language line "form_validation_"
DEBUG - 2022-08-05 05:55:51 --> Total execution time: 0.1279
DEBUG - 2022-08-05 05:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:56:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:56:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:56:22 --> Total execution time: 0.1057
DEBUG - 2022-08-05 05:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:35 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:56:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:56:35 --> Total execution time: 0.1255
DEBUG - 2022-08-05 05:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:56:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:56:35 --> Total execution time: 0.1390
DEBUG - 2022-08-05 05:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:56:36 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 05:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 05:56:36 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:56:36 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:56:36 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-05 05:56:36 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 05:56:36 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 05:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:56:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:56:41 --> Total execution time: 0.1075
DEBUG - 2022-08-05 05:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:57:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 05:57:28 --> Total execution time: 0.1066
DEBUG - 2022-08-05 05:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 05:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 05:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 05:57:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-05 05:57:37 --> Severity: error --> Exception: Call to a member function post() on null C:\xampp\htdocs\NESNUMOTO\integrity\application\controllers\Auth.php 148
DEBUG - 2022-08-05 06:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:06:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:06:11 --> Total execution time: 0.1433
DEBUG - 2022-08-05 06:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:07:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:07:31 --> Total execution time: 0.1108
DEBUG - 2022-08-05 06:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:08:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:08:07 --> Total execution time: 0.1377
DEBUG - 2022-08-05 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:08:08 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 06:08:08 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 06:08:08 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 06:08:08 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-05 06:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:08:08 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 06:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:08:08 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:08:10 --> 404 Page Not Found: Auth/reset-password
DEBUG - 2022-08-05 06:08:15 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:08:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:08:15 --> Total execution time: 0.1039
DEBUG - 2022-08-05 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:08:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:08:25 --> Total execution time: 0.1209
DEBUG - 2022-08-05 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:25 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:08:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:08:25 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-05 06:08:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:08:25 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 06:08:25 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-05 06:08:25 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:08:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:08:26 --> Total execution time: 0.1271
DEBUG - 2022-08-05 06:08:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:08:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:08:28 --> Total execution time: 0.1112
DEBUG - 2022-08-05 06:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:08:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:08:34 --> Total execution time: 0.1183
DEBUG - 2022-08-05 06:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:08:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:08:46 --> Total execution time: 0.1064
DEBUG - 2022-08-05 06:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:09:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:09:20 --> Total execution time: 0.1378
DEBUG - 2022-08-05 06:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:11:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:11:48 --> Total execution time: 0.1156
DEBUG - 2022-08-05 06:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:11:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:11:51 --> Total execution time: 0.1196
DEBUG - 2022-08-05 06:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:11:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:11:52 --> Total execution time: 0.1062
DEBUG - 2022-08-05 06:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:11:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:11:53 --> Total execution time: 0.0954
DEBUG - 2022-08-05 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:11:54 --> Total execution time: 0.0974
DEBUG - 2022-08-05 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:54 --> UTF-8 Support Enabled
ERROR - 2022-08-05 06:11:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:11:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:11:54 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-05 06:11:54 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-05 06:11:54 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 06:11:54 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:11:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:11:56 --> Total execution time: 0.1315
DEBUG - 2022-08-05 06:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:11:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:11:57 --> Total execution time: 0.0941
DEBUG - 2022-08-05 06:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:11:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:11:58 --> Total execution time: 0.1074
DEBUG - 2022-08-05 06:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:12:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:12:00 --> Total execution time: 0.1009
DEBUG - 2022-08-05 06:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:12:00 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:12:00 --> UTF-8 Support Enabled
ERROR - 2022-08-05 06:12:00 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-05 06:12:00 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:12:00 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 06:12:00 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-05 06:12:00 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 06:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:12:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:12:02 --> Total execution time: 0.1104
DEBUG - 2022-08-05 06:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:13:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:13:28 --> Total execution time: 0.0924
DEBUG - 2022-08-05 06:16:28 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:16:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:16:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:16:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:16:28 --> Total execution time: 0.0940
DEBUG - 2022-08-05 06:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:16:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:16:56 --> Total execution time: 0.1017
DEBUG - 2022-08-05 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:16:58 --> Total execution time: 0.1519
DEBUG - 2022-08-05 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:16:58 --> Total execution time: 0.1312
DEBUG - 2022-08-05 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:16:58 --> Total execution time: 0.1184
DEBUG - 2022-08-05 06:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:16:58 --> Total execution time: 0.1075
DEBUG - 2022-08-05 06:17:36 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:17:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:17:36 --> Total execution time: 0.0974
DEBUG - 2022-08-05 06:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:18:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:18:58 --> Total execution time: 0.0594
DEBUG - 2022-08-05 06:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 06:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 06:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 06:19:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 06:19:02 --> Total execution time: 0.1357
DEBUG - 2022-08-05 08:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:52:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:52:38 --> Total execution time: 0.1292
DEBUG - 2022-08-05 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:52:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:52:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:52:49 --> Total execution time: 0.0854
DEBUG - 2022-08-05 08:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:53:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:53:04 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:53:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:53:04 --> Total execution time: 0.1073
DEBUG - 2022-08-05 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:53:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:53:11 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:53:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:53:11 --> Total execution time: 0.1774
DEBUG - 2022-08-05 08:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:53:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:53:14 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:53:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:53:14 --> Total execution time: 0.1014
DEBUG - 2022-08-05 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:54:16 --> Total execution time: 0.1207
DEBUG - 2022-08-05 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 08:54:16 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 08:54:16 --> 404 Page Not Found: Auth/js
ERROR - 2022-08-05 08:54:16 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 08:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 08:54:16 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 08:54:16 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 08:54:16 --> 404 Page Not Found: Auth/css
DEBUG - 2022-08-05 08:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:54:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:54:18 --> Total execution time: 0.1362
DEBUG - 2022-08-05 08:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:54:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:54:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:54:31 --> Total execution time: 0.1279
DEBUG - 2022-08-05 08:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:54:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:54:48 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:54:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:54:48 --> Total execution time: 0.0875
DEBUG - 2022-08-05 08:55:00 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:55:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:55:01 --> Total execution time: 0.1778
DEBUG - 2022-08-05 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:55:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:55:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:55:03 --> Total execution time: 0.1148
DEBUG - 2022-08-05 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:55:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:55:55 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:55:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:55:56 --> Total execution time: 0.0961
DEBUG - 2022-08-05 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:57:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:57:29 --> Total execution time: 0.1341
DEBUG - 2022-08-05 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:57:29 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 08:57:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 08:57:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 08:57:29 --> 404 Page Not Found: Auth/js
DEBUG - 2022-08-05 08:57:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-08-05 08:57:29 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 08:57:29 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-08-05 08:57:29 --> 404 Page Not Found: Auth/css
ERROR - 2022-08-05 08:57:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-08-05 08:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-05 08:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-05 08:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-05 08:57:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-05 08:57:30 --> Total execution time: 0.1294
