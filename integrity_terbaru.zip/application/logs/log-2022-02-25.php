<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-25 09:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 09:52:17 --> No URI present. Default controller set.
DEBUG - 2022-02-25 09:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 09:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 09:52:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 09:52:17 --> Total execution time: 0.0313
DEBUG - 2022-02-25 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 09:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-25 09:52:18 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-25 09:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 09:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 09:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 09:52:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 09:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 09:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 09:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 09:52:20 --> Total execution time: 0.0057
DEBUG - 2022-02-25 09:52:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 09:52:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 09:52:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 09:52:22 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 09:52:23 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1314
DEBUG - 2022-02-25 09:52:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 09:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 09:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 09:52:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 09:52:25 --> Total execution time: 0.0038
DEBUG - 2022-02-25 10:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:30:34 --> No URI present. Default controller set.
DEBUG - 2022-02-25 10:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:30:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:30:34 --> Total execution time: 0.0307
DEBUG - 2022-02-25 10:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-25 10:30:35 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-25 10:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:30:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:30:42 --> Total execution time: 0.0053
DEBUG - 2022-02-25 10:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:30:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 10:30:48 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1314
DEBUG - 2022-02-25 10:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:30:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:30:50 --> Total execution time: 0.0053
DEBUG - 2022-02-25 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:36:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:36:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:36:43 --> Total execution time: 0.0064
DEBUG - 2022-02-25 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:43:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:43:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:43:01 --> Total execution time: 0.0055
DEBUG - 2022-02-25 10:43:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:43:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 10:43:04 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-25 10:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:44:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:44:05 --> Total execution time: 0.0054
DEBUG - 2022-02-25 10:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:51:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:51:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 10:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 10:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 10:51:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 10:51:00 --> Total execution time: 0.0053
DEBUG - 2022-02-25 11:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:02:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:02:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:02:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:02:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:02:18 --> Total execution time: 0.0053
DEBUG - 2022-02-25 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:06:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:06:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:06:24 --> Total execution time: 0.0059
DEBUG - 2022-02-25 11:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:12:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:12:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:12:14 --> Total execution time: 0.0059
DEBUG - 2022-02-25 11:21:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:21:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 11:21:38 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1301
DEBUG - 2022-02-25 11:24:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:24:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:24:26 --> Total execution time: 0.0318
DEBUG - 2022-02-25 11:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:33:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:33:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 11:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 11:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 11:33:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 11:33:59 --> Total execution time: 0.0054
DEBUG - 2022-02-25 12:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:39:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 12:39:07 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1329
DEBUG - 2022-02-25 12:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:45:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 12:45:47 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1329
DEBUG - 2022-02-25 12:46:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:46:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:46:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:46:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 12:46:50 --> Total execution time: 0.0058
DEBUG - 2022-02-25 12:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:46:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 12:46:54 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1329
DEBUG - 2022-02-25 12:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:46:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 12:46:57 --> Total execution time: 0.0038
DEBUG - 2022-02-25 12:48:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:48:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 12:48:06 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1329
DEBUG - 2022-02-25 12:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:49:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 12:49:04 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1329
DEBUG - 2022-02-25 12:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 12:50:28 --> Total execution time: 0.0327
DEBUG - 2022-02-25 12:50:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:50:31 --> No URI present. Default controller set.
DEBUG - 2022-02-25 12:50:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:50:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 12:50:31 --> Total execution time: 0.0039
DEBUG - 2022-02-25 12:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:50:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-25 12:50:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-25 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:50:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 12:50:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:50:41 --> Total execution time: 0.0034
DEBUG - 2022-02-25 12:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:50:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 12:50:45 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1329
DEBUG - 2022-02-25 12:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:50:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 12:50:47 --> Total execution time: 0.0037
DEBUG - 2022-02-25 12:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:55:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 12:55:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 12:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 12:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 12:55:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 12:55:54 --> Total execution time: 0.0063
DEBUG - 2022-02-25 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 13:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 13:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 13:53:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 13:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 13:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 13:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 13:53:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 13:53:57 --> Total execution time: 0.0065
DEBUG - 2022-02-25 13:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 13:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 13:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 13:56:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 13:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 13:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 13:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 13:56:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 13:56:52 --> Total execution time: 0.0051
DEBUG - 2022-02-25 14:01:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:01:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:01:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:01:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:01:15 --> Total execution time: 0.0059
DEBUG - 2022-02-25 14:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:03:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 14:03:49 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-25 14:03:49 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Nicky & Eva', '', 'Lamaran Paket 1', NULL, '', '', '', '', '', '', '', '', 'video engagement edited 2-3 menit', '', '', 'Jl. Wonosobo No.1 Antapani / Jl. Parakan Mas 7 No.1', '081222332008', 'trianaeva@yahoo.com', '', 'Rp. 2.750.000', '', '', 'Rp. 2.750.000', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2018-05-12', '', '', '', '', '', '')
DEBUG - 2022-02-25 14:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:03:49 --> Total execution time: 0.0046
DEBUG - 2022-02-25 14:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:10:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:10:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:10:34 --> Total execution time: 0.0070
DEBUG - 2022-02-25 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:16:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:16:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:16:52 --> Total execution time: 0.0058
DEBUG - 2022-02-25 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:24:17 --> Total execution time: 0.0052
DEBUG - 2022-02-25 14:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:27:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:27:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:27:34 --> Total execution time: 0.0054
DEBUG - 2022-02-25 14:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:31:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:31:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:31:27 --> Total execution time: 0.0055
DEBUG - 2022-02-25 14:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:39:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:39:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:39:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:39:46 --> Total execution time: 0.0053
DEBUG - 2022-02-25 14:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:48:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 14:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 14:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 14:48:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 14:48:04 --> Total execution time: 0.0058
DEBUG - 2022-02-25 15:30:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 15:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 15:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 15:30:48 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-25 15:30:48 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1338
DEBUG - 2022-02-25 15:30:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 15:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 15:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 15:30:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 15:30:52 --> Total execution time: 0.0045
DEBUG - 2022-02-25 15:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 15:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 15:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 15:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 15:39:08 --> Total execution time: 0.0328
DEBUG - 2022-02-25 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 16:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 16:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 16:52:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 16:52:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 16:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-25 16:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-25 16:52:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-25 16:52:48 --> Total execution time: 0.0040
DEBUG - 2022-02-25 16:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-25 16:52:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-25 16:52:49 --> 404 Page Not Found: Assets/https:
