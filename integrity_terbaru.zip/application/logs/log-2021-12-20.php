<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-20 03:23:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:23:34 --> No URI present. Default controller set.
DEBUG - 2021-12-20 03:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:23:34 --> Total execution time: 0.0597
DEBUG - 2021-12-20 03:23:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:23:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:23:37 --> Total execution time: 0.0525
DEBUG - 2021-12-20 03:24:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:24:39 --> Total execution time: 0.0529
DEBUG - 2021-12-20 03:24:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:24:39 --> Total execution time: 0.0511
DEBUG - 2021-12-20 03:24:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:24:41 --> Total execution time: 0.0406
DEBUG - 2021-12-20 03:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:24:44 --> Total execution time: 0.0462
DEBUG - 2021-12-20 03:24:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:24:44 --> Total execution time: 0.0408
DEBUG - 2021-12-20 03:24:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:24:45 --> Total execution time: 0.0436
DEBUG - 2021-12-20 03:24:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:24:45 --> Total execution time: 0.0379
DEBUG - 2021-12-20 03:43:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:43:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:43:13 --> Total execution time: 0.0474
DEBUG - 2021-12-20 03:43:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:43:34 --> Total execution time: 0.0486
DEBUG - 2021-12-20 03:46:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:46:40 --> Total execution time: 0.0429
DEBUG - 2021-12-20 03:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:56:32 --> Total execution time: 0.0558
DEBUG - 2021-12-20 03:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 03:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 03:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 03:56:35 --> Total execution time: 0.0370
DEBUG - 2021-12-20 04:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:31:27 --> Total execution time: 0.0417
DEBUG - 2021-12-20 04:31:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:31:35 --> No URI present. Default controller set.
DEBUG - 2021-12-20 04:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:31:35 --> Total execution time: 0.0260
DEBUG - 2021-12-20 04:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:31:37 --> Total execution time: 0.0240
DEBUG - 2021-12-20 04:31:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:31:39 --> Total execution time: 0.0363
DEBUG - 2021-12-20 04:31:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:31:41 --> Total execution time: 0.0515
DEBUG - 2021-12-20 04:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:31:43 --> Total execution time: 0.0457
DEBUG - 2021-12-20 04:42:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:42:20 --> Total execution time: 0.0301
DEBUG - 2021-12-20 04:51:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-20 04:51:23 --> Query error: Column 'more' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `20x30`, `25x30`, `30x30`, `video`, `lainnya`, `wedding_book`, `more`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`) VALUES ('Livia D. Y & Barugu A. F Agradriya', 'Livia & Barugu ', '17.000.000 + Akomodasi Transportasi 4.000.000', 'Wedding,Pegajian & Siraman', '4R(10)', '3 in 1', '20RP(4)', '16RP(2)', 'Prewedd Clip 1 menit', '', '', 'Acara,Grup,&Prewedd', '20-30m', 'Free 1 menit (WD Clip)', '', NULL, 'Jl. Pawarengan Rt/Rw 03/05 No. 002 Dawuan Timur Cikampek Karawang 41373', '081222303810', 'liviadeayln@gmail.com', '@liviadeay & baruguieraafa', 'Rp. 21.000.000', 'Rp. 4.200.000', 'Rp. 8.400.000', '', '', '', '', '', '', '2022-01-08', '08:00:00', '16:00:00', '', '', '', '2022-01-07', 'Pengajian & Siraman', '', '', 'Resinda Hotel Karawang', 'Alamat di atas')
DEBUG - 2021-12-20 04:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:52:00 --> Total execution time: 0.0285
DEBUG - 2021-12-20 04:52:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-20 04:52:04 --> Query error: Unknown column 'more' in 'field list' - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `20x30`, `25x30`, `30x30`, `video`, `lainnya`, `wedding_book`, `more`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`) VALUES ('Livia D. Y & Barugu A. F Agradriya', 'Livia & Barugu ', '17.000.000 + Akomodasi Transportasi 4.000.000', 'Wedding,Pegajian & Siraman', '4R(10)', '3 in 1', '20RP(4)', '16RP(2)', 'Prewedd Clip 1 menit', '', '', 'Acara,Grup,&Prewedd', '20-30m', 'Free 1 menit (WD Clip)', '', NULL, 'Jl. Pawarengan Rt/Rw 03/05 No. 002 Dawuan Timur Cikampek Karawang 41373', '081222303810', 'liviadeayln@gmail.com', '@liviadeay & baruguieraafa', 'Rp. 21.000.000', 'Rp. 4.200.000', 'Rp. 8.400.000', '', '', '', '', '', '', '2022-01-08', '08:00:00', '16:00:00', '', '', '', '2022-01-07', 'Pengajian & Siraman', '', '', 'Resinda Hotel Karawang', 'Alamat di atas')
DEBUG - 2021-12-20 04:52:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:52:43 --> Total execution time: 0.0296
DEBUG - 2021-12-20 04:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:53:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-20 04:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-20 04:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-20 04:53:04 --> Total execution time: 0.0479
