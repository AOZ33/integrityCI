<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-25 02:38:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 02:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 02:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 02:38:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-25 02:38:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2021-12-25 02:38:13 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2021-12-25 02:38:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 02:38:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-25 02:38:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-25 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:10:02 --> No URI present. Default controller set.
DEBUG - 2021-12-25 13:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 13:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 13:10:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 13:10:02 --> Total execution time: 0.0308
DEBUG - 2021-12-25 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:10:02 --> No URI present. Default controller set.
DEBUG - 2021-12-25 13:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 13:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 13:10:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 13:10:02 --> Total execution time: 0.0041
DEBUG - 2021-12-25 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-25 13:10:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-25 13:10:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:10:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-25 13:10:02 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-25 13:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 13:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 13:10:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 13:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 13:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 13:10:10 --> Total execution time: 0.0070
DEBUG - 2021-12-25 13:10:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 13:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 13:10:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 13:10:14 --> Total execution time: 0.0156
DEBUG - 2021-12-25 13:11:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 13:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 13:11:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 13:11:19 --> Total execution time: 0.0323
DEBUG - 2021-12-25 13:11:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 13:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 13:11:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-25 13:11:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2021-12-25 13:11:21 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2021-12-25 13:12:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 13:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 13:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 13:12:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 13:12:12 --> Total execution time: 0.0401
DEBUG - 2021-12-25 21:57:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 21:57:55 --> No URI present. Default controller set.
DEBUG - 2021-12-25 21:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-25 21:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-25 21:57:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-25 21:57:55 --> Total execution time: 0.0305
DEBUG - 2021-12-25 21:57:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-25 21:57:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-25 21:57:55 --> 404 Page Not Found: Assets/https:
