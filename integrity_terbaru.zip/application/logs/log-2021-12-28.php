<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-28 10:19:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:19:04 --> No URI present. Default controller set.
DEBUG - 2021-12-28 10:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:19:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:19:04 --> Total execution time: 0.0319
DEBUG - 2021-12-28 10:19:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:19:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-28 10:19:04 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-28 10:19:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:19:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-28 10:19:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-28 10:21:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:21:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:21:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:21:48 --> Total execution time: 0.0079
DEBUG - 2021-12-28 10:21:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:21:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:21:51 --> Total execution time: 0.0209
DEBUG - 2021-12-28 10:34:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:34:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:34:25 --> Total execution time: 0.0349
DEBUG - 2021-12-28 10:41:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:41:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:41:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:41:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:41:08 --> Total execution time: 0.0076
DEBUG - 2021-12-28 10:45:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:45:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:45:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:45:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:45:08 --> Total execution time: 0.0065
DEBUG - 2021-12-28 10:51:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:51:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:51:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:51:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:51:57 --> Total execution time: 0.0078
DEBUG - 2021-12-28 10:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:55:01 --> Total execution time: 0.0071
DEBUG - 2021-12-28 10:58:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:58:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:58:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:58:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:58:51 --> Total execution time: 0.0074
DEBUG - 2021-12-28 10:58:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:58:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:58:53 --> Total execution time: 0.0211
DEBUG - 2021-12-28 10:59:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 10:59:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 10:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 10:59:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 10:59:02 --> Total execution time: 0.0049
DEBUG - 2021-12-28 11:07:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:07:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:07:22 --> Total execution time: 0.0073
DEBUG - 2021-12-28 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:13:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:13:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:13:23 --> Total execution time: 0.0070
DEBUG - 2021-12-28 11:13:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:13:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:13:25 --> Total execution time: 0.0272
DEBUG - 2021-12-28 11:13:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:13:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:13:42 --> Total execution time: 0.0051
DEBUG - 2021-12-28 11:35:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:35:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:35:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:35:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:35:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:35:24 --> Total execution time: 0.0078
DEBUG - 2021-12-28 11:46:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:46:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:46:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:46:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:46:52 --> Total execution time: 0.0083
DEBUG - 2021-12-28 11:48:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:48:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:48:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 11:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 11:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 11:48:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 11:48:26 --> Total execution time: 0.0064
DEBUG - 2021-12-28 13:44:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:44:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:44:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:44:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:44:06 --> Total execution time: 0.0098
DEBUG - 2021-12-28 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:47:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:47:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:47:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:47:32 --> Total execution time: 0.0072
DEBUG - 2021-12-28 13:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:48:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:48:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:48:51 --> Total execution time: 0.0064
DEBUG - 2021-12-28 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:50:44 --> Total execution time: 0.0067
DEBUG - 2021-12-28 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:53:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:53:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:53:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:53:59 --> Total execution time: 0.0069
DEBUG - 2021-12-28 13:54:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 13:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 13:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 13:54:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 13:54:31 --> Total execution time: 0.0562
DEBUG - 2021-12-28 14:00:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 14:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 14:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 14:00:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:00:30 --> Total execution time: 0.0346
DEBUG - 2021-12-28 14:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 14:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 14:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 14:05:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:05:23 --> Total execution time: 0.0339
DEBUG - 2021-12-28 14:13:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 14:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 14:13:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:13:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 14:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 14:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 14:13:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:13:05 --> Total execution time: 0.0073
DEBUG - 2021-12-28 14:20:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 14:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 14:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 14:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:20:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 14:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 14:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 14:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:20:27 --> Total execution time: 0.0074
DEBUG - 2021-12-28 14:45:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 14:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 14:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 14:45:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:45:37 --> Total execution time: 0.0509
DEBUG - 2021-12-28 14:45:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 14:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 14:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 14:45:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 14:45:42 --> Total execution time: 0.0057
DEBUG - 2021-12-28 15:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:04:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:04:20 --> Total execution time: 0.0575
DEBUG - 2021-12-28 15:04:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:04:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:04:25 --> Total execution time: 0.0064
DEBUG - 2021-12-28 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:04:31 --> Total execution time: 0.0211
DEBUG - 2021-12-28 15:05:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:05:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:05:03 --> Total execution time: 0.0322
DEBUG - 2021-12-28 15:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:08:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:08:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:08:54 --> Total execution time: 0.0075
DEBUG - 2021-12-28 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:15:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:15:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:15:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:15:09 --> Total execution time: 0.0072
DEBUG - 2021-12-28 15:20:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:20:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:20:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:20:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:20:52 --> Total execution time: 0.0075
DEBUG - 2021-12-28 15:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:24:18 --> Total execution time: 0.0077
DEBUG - 2021-12-28 15:24:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:24:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:24:21 --> Total execution time: 0.0321
DEBUG - 2021-12-28 15:24:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:24:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:24:26 --> Total execution time: 0.0050
DEBUG - 2021-12-28 15:29:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:29:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:29:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:29:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:29:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:29:35 --> Total execution time: 0.0073
DEBUG - 2021-12-28 15:33:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:33:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:33:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:33:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:33:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:33:38 --> Total execution time: 0.0076
DEBUG - 2021-12-28 15:33:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:33:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:33:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:33:49 --> Total execution time: 0.0235
DEBUG - 2021-12-28 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:34:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:34:24 --> Total execution time: 0.0317
DEBUG - 2021-12-28 15:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:39:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:39:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:39:41 --> Total execution time: 0.0081
DEBUG - 2021-12-28 15:44:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:44:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:44:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:44:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:44:47 --> Total execution time: 0.0077
DEBUG - 2021-12-28 15:44:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-28 15:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-28 15:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-28 15:44:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-28 15:44:58 --> Total execution time: 0.0259
