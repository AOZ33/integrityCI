<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-26 17:39:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-26 17:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-26 17:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-26 17:39:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2021-12-26 17:39:45 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2021-12-26 17:39:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-26 17:39:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-26 17:39:45 --> 404 Page Not Found: Faviconico/index
