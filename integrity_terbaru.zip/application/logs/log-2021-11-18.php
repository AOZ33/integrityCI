<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-18 03:55:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:55:54 --> No URI present. Default controller set.
DEBUG - 2021-11-18 03:55:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:55:55 --> Total execution time: 0.4475
DEBUG - 2021-11-18 03:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:55:56 --> Total execution time: 0.1040
DEBUG - 2021-11-18 03:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:55:58 --> Total execution time: 0.0528
DEBUG - 2021-11-18 03:56:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:56:00 --> Total execution time: 0.0741
DEBUG - 2021-11-18 03:56:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:56:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:56:05 --> Total execution time: 0.0422
DEBUG - 2021-11-18 03:56:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:56:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:56:12 --> Total execution time: 0.0391
DEBUG - 2021-11-18 03:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 03:56:36 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-18 03:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-18 03:56:36 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-18 03:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-18 03:56:36 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 152
ERROR - 2021-11-18 03:56:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 152
DEBUG - 2021-11-18 03:56:36 --> Total execution time: 0.0840
DEBUG - 2021-11-18 03:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 03:56:38 --> Total execution time: 0.0569
DEBUG - 2021-11-18 03:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 03:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 03:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 03:57:53 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-18 03:57:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-18 03:57:53 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-18 03:57:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-18 03:57:53 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 152
ERROR - 2021-11-18 03:57:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 152
DEBUG - 2021-11-18 03:57:53 --> Total execution time: 0.0443
DEBUG - 2021-11-18 04:16:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:16:20 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\nesnu\application\views\package\index.php 51
ERROR - 2021-11-18 04:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 51
ERROR - 2021-11-18 04:16:20 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\nesnu\application\views\package\index.php 105
ERROR - 2021-11-18 04:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 105
ERROR - 2021-11-18 04:16:20 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\nesnu\application\views\package\index.php 160
ERROR - 2021-11-18 04:16:20 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 160
DEBUG - 2021-11-18 04:16:20 --> Total execution time: 0.0554
DEBUG - 2021-11-18 04:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:17:43 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\nesnu\application\views\package\index.php 51
ERROR - 2021-11-18 04:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 51
ERROR - 2021-11-18 04:17:43 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\nesnu\application\views\package\index.php 105
ERROR - 2021-11-18 04:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 105
ERROR - 2021-11-18 04:17:43 --> Severity: Notice --> Undefined variable: package C:\xampp\htdocs\nesnu\application\views\package\index.php 160
ERROR - 2021-11-18 04:17:43 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 160
DEBUG - 2021-11-18 04:17:43 --> Total execution time: 0.0320
DEBUG - 2021-11-18 04:20:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:20:05 --> Total execution time: 0.0378
DEBUG - 2021-11-18 04:20:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:20:33 --> Total execution time: 0.0442
DEBUG - 2021-11-18 04:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:23:46 --> Total execution time: 0.0468
DEBUG - 2021-11-18 04:31:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:31:26 --> Query error: Unknown column 'videograper' in 'field list' - Invalid query: INSERT INTO `package` (`name`, `description`, `price`, `photograper`, `videograper`, `editor`, `crew`) VALUES ('Paket 1', 'wgjkawdkgawdkgawdkauwgdakwdguwdkguawdkuagwdkuagwdkauwgdakwudgawkdugawdkugawdug', '1000000', 'Adi', 'Udil', NULL, 'rafi')
DEBUG - 2021-11-18 04:32:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:32:22 --> Total execution time: 0.0514
DEBUG - 2021-11-18 04:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:32:25 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `package` (`name`, `description`, `price`, `photograper`, `videograper`, `editor`, `crew`) VALUES ('Paket 1', 'wgjkawdkgawdkgawdkauwgdakwdguwdkguawdkuagwdkuagwdkauwgdakwudgawkdugawdkugawdug', '1000000', 'Adi', 'Udil', NULL, 'rafi')
DEBUG - 2021-11-18 04:33:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:33:11 --> Total execution time: 0.0375
DEBUG - 2021-11-18 04:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:33:12 --> Total execution time: 0.0443
DEBUG - 2021-11-18 04:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:33:12 --> Total execution time: 0.0407
DEBUG - 2021-11-18 04:33:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:33:13 --> Total execution time: 0.0365
DEBUG - 2021-11-18 04:33:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:33:27 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `package` (`name`, `description`, `price`, `photograper`, `videograper`, `editor`, `crew`) VALUES ('Paket 1', 'wgjkawdkgawdkgawdkauwgdakwdguwdkguawdkuagwdkuagwdkauwgdakwudgawkdugawdkugawdug', '1000000', 'Adi', 'Udil', NULL, 'rafi')
DEBUG - 2021-11-18 04:34:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:34:36 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\package\index.php 186
ERROR - 2021-11-18 04:34:36 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\package\index.php 186
DEBUG - 2021-11-18 04:34:36 --> Total execution time: 0.0448
DEBUG - 2021-11-18 04:34:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:34:37 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\package\index.php 186
ERROR - 2021-11-18 04:34:37 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\package\index.php 186
DEBUG - 2021-11-18 04:34:37 --> Total execution time: 0.0493
DEBUG - 2021-11-18 04:35:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:35:45 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\package\index.php 186
ERROR - 2021-11-18 04:35:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\package\index.php 186
DEBUG - 2021-11-18 04:35:45 --> Total execution time: 0.0445
DEBUG - 2021-11-18 04:38:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:38:38 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `package` (`name`, `description`, `price`, `photograper`, `videograper`, `editor`, `crew`) VALUES ('Paket 1', '', '', '', '', NULL, '')
DEBUG - 2021-11-18 04:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:38:41 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\package\index.php 186
ERROR - 2021-11-18 04:38:41 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\package\index.php 186
DEBUG - 2021-11-18 04:38:41 --> Total execution time: 0.0411
DEBUG - 2021-11-18 04:41:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:41:40 --> Severity: Notice --> Undefined index: editopr C:\xampp\htdocs\nesnu\application\views\package\index.php 128
ERROR - 2021-11-18 04:41:40 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\package\index.php 214
ERROR - 2021-11-18 04:41:40 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\package\index.php 214
DEBUG - 2021-11-18 04:41:40 --> Total execution time: 0.0457
DEBUG - 2021-11-18 04:41:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:41:52 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\package\index.php 214
ERROR - 2021-11-18 04:41:52 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\package\index.php 214
DEBUG - 2021-11-18 04:41:52 --> Total execution time: 0.0453
DEBUG - 2021-11-18 04:42:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:42:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:42:04 --> Severity: Notice --> Undefined variable: cr C:\xampp\htdocs\nesnu\application\views\package\index.php 214
ERROR - 2021-11-18 04:42:04 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\package\index.php 214
DEBUG - 2021-11-18 04:42:04 --> Total execution time: 0.0409
DEBUG - 2021-11-18 04:43:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:43:06 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `package` (`name`, `description`, `price`, `photograper`, `videograper`, `editor`, `crew`) VALUES ('Pkt 2', 'fhlkefhklslo;fdkls;afdsjklfhadks;jfhdskfhadsklfhjds', '2000000', 'Danu', 'Tio', NULL, 'Asri')
DEBUG - 2021-11-18 04:43:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:43:11 --> Total execution time: 0.0381
DEBUG - 2021-11-18 04:43:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:43:15 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `package` (`name`, `description`, `price`, `photograper`, `videograper`, `editor`, `crew`) VALUES ('Pkt 2', 'fhlkefhklslo;fdkls;afdsjklfhadks;jfhdskfhadsklfhjds', '2000000', 'Danu', 'Tio', NULL, 'Asri')
DEBUG - 2021-11-18 04:43:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:43:16 --> Total execution time: 0.0366
DEBUG - 2021-11-18 04:43:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 04:43:37 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `package` (`name`, `description`, `price`, `photograper`, `videograper`, `editor`, `crew`) VALUES ('Pkt 2', 'fhlkefhklslo;fdkls;afdsjklfhadks;jfhdskfhadsklfhjds', '2000000', 'Danu', 'Tio', NULL, 'Asri')
DEBUG - 2021-11-18 04:43:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:43:39 --> Total execution time: 0.0391
DEBUG - 2021-11-18 04:43:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:43:40 --> Total execution time: 0.0364
DEBUG - 2021-11-18 04:43:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:43:40 --> Total execution time: 0.0475
DEBUG - 2021-11-18 04:43:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:43:41 --> Total execution time: 0.0435
DEBUG - 2021-11-18 04:44:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:00 --> Total execution time: 0.0431
DEBUG - 2021-11-18 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:06 --> Total execution time: 0.0434
DEBUG - 2021-11-18 04:44:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:12 --> Total execution time: 0.0409
DEBUG - 2021-11-18 04:44:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:14 --> Total execution time: 0.0429
DEBUG - 2021-11-18 04:44:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:15 --> Total execution time: 0.0399
DEBUG - 2021-11-18 04:44:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:15 --> Total execution time: 0.0377
DEBUG - 2021-11-18 04:44:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:16 --> Total execution time: 0.0349
DEBUG - 2021-11-18 04:44:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 04:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 04:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 04:44:20 --> Total execution time: 0.0376
DEBUG - 2021-11-18 05:06:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:06:54 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:06:54 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 05:06:57 --> Total execution time: 0.0524
DEBUG - 2021-11-18 05:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:06:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:06:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:06:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:06:57 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 05:06:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 05:14:57 --> Total execution time: 0.0420
DEBUG - 2021-11-18 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:14:57 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 05:14:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 05:14:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:14:57 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 05:14:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:14:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:14:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:14:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:14:58 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:14:58 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:16:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:16:26 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:16:26 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:16:27 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:16:27 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:16:27 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:16:27 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:16:27 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:16:27 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:18:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:18:04 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:18:04 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:12 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:12 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:12 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:12 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:12 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:12 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:12 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:12 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:13 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:13 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:13 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:13 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:13 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:13 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:13 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:13 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:25:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:25:13 --> Severity: Notice --> Undefined property: Appointment::$Appointment_model C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
ERROR - 2021-11-18 05:25:13 --> Severity: error --> Exception: Call to a member function getAllAppointment() on null C:\xampp\htdocs\nesnu\application\controllers\appointment.php 10
DEBUG - 2021-11-18 05:26:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:26:45 --> Severity: Notice --> Undefined variable: appointmet C:\xampp\htdocs\nesnu\application\views\appointment\index.php 48
ERROR - 2021-11-18 05:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\appointment\index.php 48
ERROR - 2021-11-18 05:26:45 --> Severity: Notice --> Undefined variable: appointmet C:\xampp\htdocs\nesnu\application\views\appointment\index.php 113
ERROR - 2021-11-18 05:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\appointment\index.php 113
ERROR - 2021-11-18 05:26:45 --> Severity: Notice --> Undefined variable: appointmet C:\xampp\htdocs\nesnu\application\views\appointment\index.php 175
ERROR - 2021-11-18 05:26:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\appointment\index.php 175
DEBUG - 2021-11-18 05:26:45 --> Total execution time: 0.0308
DEBUG - 2021-11-18 05:26:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:26:45 --> UTF-8 Support Enabled
ERROR - 2021-11-18 05:26:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:26:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:26:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:26:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:26:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:26:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:27:05 --> Severity: Notice --> Undefined variable: appointmet C:\xampp\htdocs\nesnu\application\views\appointment\index.php 113
ERROR - 2021-11-18 05:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\appointment\index.php 113
ERROR - 2021-11-18 05:27:05 --> Severity: Notice --> Undefined variable: appointmet C:\xampp\htdocs\nesnu\application\views\appointment\index.php 175
ERROR - 2021-11-18 05:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\appointment\index.php 175
DEBUG - 2021-11-18 05:27:05 --> Total execution time: 0.0395
DEBUG - 2021-11-18 05:27:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:05 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 05:27:05 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:05 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:27:16 --> Severity: Notice --> Undefined variable: appointmet C:\xampp\htdocs\nesnu\application\views\appointment\index.php 175
ERROR - 2021-11-18 05:27:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\appointment\index.php 175
DEBUG - 2021-11-18 05:27:16 --> Total execution time: 0.0407
DEBUG - 2021-11-18 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 05:27:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:16 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 05:27:17 --> Severity: Notice --> Undefined variable: appointmet C:\xampp\htdocs\nesnu\application\views\appointment\index.php 175
ERROR - 2021-11-18 05:27:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\appointment\index.php 175
DEBUG - 2021-11-18 05:27:17 --> Total execution time: 0.0402
DEBUG - 2021-11-18 05:27:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:17 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 05:27:27 --> Total execution time: 0.0412
DEBUG - 2021-11-18 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:27 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 05:27:27 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:27:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:27:27 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:28:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 05:28:38 --> Total execution time: 0.0435
DEBUG - 2021-11-18 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:28:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:28:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:28:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:28:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 05:28:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 05:29:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 05:29:11 --> Total execution time: 0.0387
DEBUG - 2021-11-18 05:29:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 05:29:30 --> Total execution time: 0.0512
DEBUG - 2021-11-18 05:30:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 05:30:20 --> Total execution time: 0.0523
DEBUG - 2021-11-18 05:30:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 05:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 05:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 05:30:51 --> Total execution time: 0.0482
DEBUG - 2021-11-18 07:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:31 --> 404 Page Not Found: Package/index.html
DEBUG - 2021-11-18 07:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 07:19:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 07:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:40 --> No URI present. Default controller set.
DEBUG - 2021-11-18 07:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:40 --> Total execution time: 0.0275
DEBUG - 2021-11-18 07:19:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:42 --> Total execution time: 0.0500
DEBUG - 2021-11-18 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:43 --> Total execution time: 0.0381
DEBUG - 2021-11-18 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:43 --> Total execution time: 0.0270
DEBUG - 2021-11-18 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:43 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:19:43 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:43 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:43 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:44 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:44 --> Total execution time: 0.0467
DEBUG - 2021-11-18 07:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:45 --> Total execution time: 0.0448
DEBUG - 2021-11-18 07:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:45 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:19:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:45 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:45 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:45 --> Total execution time: 0.0505
DEBUG - 2021-11-18 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:46 --> Total execution time: 0.0462
DEBUG - 2021-11-18 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 07:19:46 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:46 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:46 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:47 --> Total execution time: 0.0449
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:47 --> Total execution time: 0.0459
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:47 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:48 --> Total execution time: 0.0434
DEBUG - 2021-11-18 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:48 --> Total execution time: 0.0411
DEBUG - 2021-11-18 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:48 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:19:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 07:19:48 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:48 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:49 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:49 --> Total execution time: 0.0376
DEBUG - 2021-11-18 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:50 --> Total execution time: 0.0482
DEBUG - 2021-11-18 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:50 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:19:50 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 07:19:50 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:50 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:50 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:51 --> Total execution time: 0.0400
DEBUG - 2021-11-18 07:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:51 --> Total execution time: 0.0367
DEBUG - 2021-11-18 07:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:51 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:19:51 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:51 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:51 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:51 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:52 --> Total execution time: 0.0386
DEBUG - 2021-11-18 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:54 --> Total execution time: 0.0466
DEBUG - 2021-11-18 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 07:19:54 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:54 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:56 --> Total execution time: 0.0499
DEBUG - 2021-11-18 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:19:57 --> Total execution time: 0.0416
DEBUG - 2021-11-18 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:57 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:19:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 07:19:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:57 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:19:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:19:57 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:20:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:20:20 --> Total execution time: 0.0410
DEBUG - 2021-11-18 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:21:33 --> Total execution time: 0.0468
DEBUG - 2021-11-18 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:21:33 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:21:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:21:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:21:33 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:21:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:21:33 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:21:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:21:38 --> Total execution time: 0.0429
DEBUG - 2021-11-18 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:21:54 --> Total execution time: 0.0514
DEBUG - 2021-11-18 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:21:54 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:21:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:21:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:21:54 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:21:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:21:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:21:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:21:57 --> Total execution time: 0.0308
DEBUG - 2021-11-18 07:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:21:58 --> Total execution time: 0.0425
DEBUG - 2021-11-18 07:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:05 --> Total execution time: 0.0440
DEBUG - 2021-11-18 07:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:05 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:22:05 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:05 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:05 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:22:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:05 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:06 --> Total execution time: 0.0450
DEBUG - 2021-11-18 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:06 --> Total execution time: 0.0416
DEBUG - 2021-11-18 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:06 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:06 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:06 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:07 --> Total execution time: 0.0378
DEBUG - 2021-11-18 07:22:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:08 --> Total execution time: 0.0409
DEBUG - 2021-11-18 07:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:09 --> Total execution time: 0.0282
DEBUG - 2021-11-18 07:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:09 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:22:09 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:09 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:09 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:09 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:10 --> Total execution time: 0.0378
DEBUG - 2021-11-18 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:10 --> Total execution time: 0.0406
DEBUG - 2021-11-18 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:11 --> Total execution time: 0.0376
DEBUG - 2021-11-18 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:11 --> 404 Page Not Found: Assets/js
ERROR - 2021-11-18 07:22:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 07:22:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:11 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:22:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:22:11 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:22:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:12 --> Total execution time: 0.0577
DEBUG - 2021-11-18 07:22:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:22:30 --> Total execution time: 0.0454
DEBUG - 2021-11-18 07:32:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:32:22 --> Total execution time: 0.0479
DEBUG - 2021-11-18 07:32:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:32:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:32:22 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:32:23 --> Total execution time: 0.0410
DEBUG - 2021-11-18 07:32:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:32:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:32:23 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:33:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:33:54 --> Total execution time: 0.0300
DEBUG - 2021-11-18 07:33:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:33:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:33:54 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:37:38 --> Total execution time: 0.0380
DEBUG - 2021-11-18 07:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:37:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
ERROR - 2021-11-18 07:37:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:37:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:37:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:37:38 --> 404 Page Not Found: Assets/bootstrap-datepicker
DEBUG - 2021-11-18 07:40:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:40:06 --> Total execution time: 0.0401
DEBUG - 2021-11-18 07:43:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:43:11 --> Total execution time: 0.0471
DEBUG - 2021-11-18 07:43:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:43:44 --> Total execution time: 0.0271
DEBUG - 2021-11-18 07:44:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:44:26 --> Total execution time: 0.0626
DEBUG - 2021-11-18 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:47:40 --> Total execution time: 0.0423
DEBUG - 2021-11-18 07:47:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:47:41 --> Total execution time: 0.0425
DEBUG - 2021-11-18 07:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:48:36 --> Total execution time: 0.0406
DEBUG - 2021-11-18 07:49:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:49:56 --> Total execution time: 0.0394
DEBUG - 2021-11-18 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:49:58 --> Total execution time: 0.0264
DEBUG - 2021-11-18 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:49:58 --> Total execution time: 0.0457
DEBUG - 2021-11-18 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:49:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:49:59 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 07:49:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:49:59 --> Total execution time: 0.0385
DEBUG - 2021-11-18 07:50:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:50:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:50:03 --> 404 Page Not Found: Appointmet/add
DEBUG - 2021-11-18 07:50:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:50:05 --> Total execution time: 0.0448
DEBUG - 2021-11-18 07:50:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:50:34 --> Total execution time: 0.0470
DEBUG - 2021-11-18 07:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:50:37 --> 404 Page Not Found: Appointmet/add
DEBUG - 2021-11-18 07:50:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:50:39 --> Total execution time: 0.0398
DEBUG - 2021-11-18 07:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:51:01 --> Total execution time: 0.0269
DEBUG - 2021-11-18 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:51:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:51:12 --> 404 Page Not Found: Appointmet/add
DEBUG - 2021-11-18 07:51:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:51:14 --> Total execution time: 0.0451
DEBUG - 2021-11-18 07:54:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:54:34 --> Total execution time: 0.0291
DEBUG - 2021-11-18 07:55:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:55:09 --> Total execution time: 0.0373
DEBUG - 2021-11-18 07:55:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:55:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:55:27 --> Total execution time: 0.0278
DEBUG - 2021-11-18 07:55:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:55:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 07:55:40 --> 404 Page Not Found: Appointmet/add
DEBUG - 2021-11-18 07:55:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:55:42 --> Total execution time: 0.0601
DEBUG - 2021-11-18 07:56:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:56:16 --> Total execution time: 0.0271
DEBUG - 2021-11-18 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:56:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:56:20 --> Total execution time: 0.0413
DEBUG - 2021-11-18 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:56:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 07:56:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 07:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 07:56:28 --> Total execution time: 0.0408
DEBUG - 2021-11-18 08:09:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:09:40 --> Total execution time: 0.0466
DEBUG - 2021-11-18 08:11:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:11:01 --> Total execution time: 0.0487
DEBUG - 2021-11-18 08:21:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:21:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:21:44 --> Total execution time: 0.0393
DEBUG - 2021-11-18 08:23:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:23:01 --> Total execution time: 0.0416
DEBUG - 2021-11-18 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:30:05 --> Total execution time: 0.0519
DEBUG - 2021-11-18 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:30:05 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-11-18 08:30:05 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:30:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:30:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:30:05 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:31:03 --> Total execution time: 0.0442
DEBUG - 2021-11-18 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:31:03 --> 404 Page Not Found: Assets/vendor
ERROR - 2021-11-18 08:31:03 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:31:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:31:03 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:32:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:32:05 --> No URI present. Default controller set.
DEBUG - 2021-11-18 08:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:32:05 --> Total execution time: 0.0410
DEBUG - 2021-11-18 08:32:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:32:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:32:06 --> Total execution time: 0.0417
DEBUG - 2021-11-18 08:32:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:32:07 --> Total execution time: 0.0423
DEBUG - 2021-11-18 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:32:08 --> Total execution time: 0.0490
DEBUG - 2021-11-18 08:32:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:32:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:32:08 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:36:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:36:25 --> Total execution time: 0.0387
DEBUG - 2021-11-18 08:36:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:36:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:36:25 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:36:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:36:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:36:27 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:37:08 --> Total execution time: 0.0501
DEBUG - 2021-11-18 08:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:37:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:37:08 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:37:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:37:45 --> Total execution time: 0.0498
DEBUG - 2021-11-18 08:37:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:37:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 08:37:45 --> 404 Page Not Found: Assets/vendor
DEBUG - 2021-11-18 08:40:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:40:56 --> Total execution time: 0.0275
DEBUG - 2021-11-18 08:42:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:42:03 --> Total execution time: 0.0469
DEBUG - 2021-11-18 08:47:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:47:34 --> Total execution time: 0.0376
DEBUG - 2021-11-18 08:54:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:54:41 --> Total execution time: 0.0525
DEBUG - 2021-11-18 08:56:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:56:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:56:04 --> Total execution time: 0.0404
DEBUG - 2021-11-18 08:56:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 08:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 08:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 08:56:22 --> Total execution time: 0.0370
DEBUG - 2021-11-18 09:01:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:01:17 --> Total execution time: 0.0293
DEBUG - 2021-11-18 09:09:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:09:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:09:24 --> Total execution time: 0.0464
DEBUG - 2021-11-18 09:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:09:42 --> Total execution time: 0.0305
DEBUG - 2021-11-18 09:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:10:18 --> Total execution time: 0.0452
DEBUG - 2021-11-18 09:11:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:11:07 --> Total execution time: 0.0404
DEBUG - 2021-11-18 09:11:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:11:39 --> Total execution time: 0.0467
DEBUG - 2021-11-18 09:12:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:12:26 --> Total execution time: 0.0529
DEBUG - 2021-11-18 09:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:13:40 --> Total execution time: 0.0512
DEBUG - 2021-11-18 09:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:35 --> No URI present. Default controller set.
DEBUG - 2021-11-18 09:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:35 --> Total execution time: 0.0463
DEBUG - 2021-11-18 09:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:36 --> Total execution time: 0.0247
DEBUG - 2021-11-18 09:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:38 --> Total execution time: 0.0370
DEBUG - 2021-11-18 09:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:38 --> Total execution time: 0.0266
DEBUG - 2021-11-18 09:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:15:38 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:39 --> Total execution time: 0.0264
DEBUG - 2021-11-18 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:40 --> Total execution time: 0.0437
DEBUG - 2021-11-18 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:15:40 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:40 --> Total execution time: 0.0490
DEBUG - 2021-11-18 09:15:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:41 --> Total execution time: 0.0265
DEBUG - 2021-11-18 09:15:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:15:41 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:15:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:41 --> Total execution time: 0.0465
DEBUG - 2021-11-18 09:15:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:42 --> Total execution time: 0.0480
DEBUG - 2021-11-18 09:15:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:15:42 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:15:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:15:42 --> Total execution time: 0.0474
DEBUG - 2021-11-18 09:16:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:16:43 --> Total execution time: 0.0271
DEBUG - 2021-11-18 09:16:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:16:53 --> Total execution time: 0.0442
DEBUG - 2021-11-18 09:17:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:17:29 --> Total execution time: 0.0465
DEBUG - 2021-11-18 09:17:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:17:35 --> Total execution time: 0.0469
DEBUG - 2021-11-18 09:17:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:17:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:17:37 --> Total execution time: 0.0357
DEBUG - 2021-11-18 09:18:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:12 --> Total execution time: 0.0420
DEBUG - 2021-11-18 09:18:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:13 --> Total execution time: 0.0305
DEBUG - 2021-11-18 09:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:19 --> Total execution time: 0.0402
DEBUG - 2021-11-18 09:18:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:24 --> Total execution time: 0.0455
DEBUG - 2021-11-18 09:18:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:18:24 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:18:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:35 --> Total execution time: 0.0418
DEBUG - 2021-11-18 09:18:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:18:35 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:18:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:40 --> Total execution time: 0.0437
DEBUG - 2021-11-18 09:18:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:18:40 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:45 --> Total execution time: 0.0429
DEBUG - 2021-11-18 09:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:18:45 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:18:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:46 --> Total execution time: 0.0392
DEBUG - 2021-11-18 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:52 --> Total execution time: 0.0426
DEBUG - 2021-11-18 09:18:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:18:55 --> Total execution time: 0.0419
DEBUG - 2021-11-18 09:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:19:30 --> Total execution time: 0.0403
DEBUG - 2021-11-18 09:20:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:20 --> Total execution time: 0.0329
DEBUG - 2021-11-18 09:20:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:23 --> Total execution time: 0.0298
DEBUG - 2021-11-18 09:20:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:24 --> Total execution time: 0.0373
DEBUG - 2021-11-18 09:20:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:20:24 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:20:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:20:24 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:20:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:25 --> Total execution time: 0.0488
DEBUG - 2021-11-18 09:20:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:47 --> Total execution time: 0.0227
DEBUG - 2021-11-18 09:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:20:49 --> Total execution time: 0.0426
DEBUG - 2021-11-18 09:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 09:22:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 09:22:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 09:22:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 09:22:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 09:22:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 09:22:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:39 --> No URI present. Default controller set.
DEBUG - 2021-11-18 09:22:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:39 --> Total execution time: 0.0253
DEBUG - 2021-11-18 09:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:40 --> Total execution time: 0.0426
DEBUG - 2021-11-18 09:22:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:41 --> Total execution time: 0.0549
DEBUG - 2021-11-18 09:22:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:41 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:42 --> Total execution time: 0.0408
DEBUG - 2021-11-18 09:22:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:42 --> Total execution time: 0.0466
DEBUG - 2021-11-18 09:22:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:43 --> Total execution time: 0.0390
DEBUG - 2021-11-18 09:22:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:43 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:43 --> Total execution time: 0.0439
DEBUG - 2021-11-18 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:44 --> Total execution time: 0.0381
DEBUG - 2021-11-18 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:44 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:44 --> Total execution time: 0.0471
DEBUG - 2021-11-18 09:22:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:45 --> Total execution time: 0.0460
DEBUG - 2021-11-18 09:22:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:45 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:46 --> Total execution time: 0.0430
DEBUG - 2021-11-18 09:22:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:46 --> Total execution time: 0.0470
DEBUG - 2021-11-18 09:22:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:46 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:47 --> Total execution time: 0.0514
DEBUG - 2021-11-18 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:48 --> Total execution time: 0.0387
DEBUG - 2021-11-18 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:48 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:48 --> Total execution time: 0.0393
DEBUG - 2021-11-18 09:22:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:49 --> Total execution time: 0.0275
DEBUG - 2021-11-18 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:49 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:49 --> Total execution time: 0.0411
DEBUG - 2021-11-18 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:49 --> Total execution time: 0.0409
DEBUG - 2021-11-18 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:49 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:49 --> Total execution time: 0.0263
DEBUG - 2021-11-18 09:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:50 --> Total execution time: 0.0424
DEBUG - 2021-11-18 09:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:50 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:50 --> Total execution time: 0.0458
DEBUG - 2021-11-18 09:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:51 --> Total execution time: 0.0602
DEBUG - 2021-11-18 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:51 --> Total execution time: 0.0259
DEBUG - 2021-11-18 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:51 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:51 --> Total execution time: 0.0416
DEBUG - 2021-11-18 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:51 --> Total execution time: 0.0466
DEBUG - 2021-11-18 09:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:51 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:52 --> Total execution time: 0.0396
DEBUG - 2021-11-18 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:52 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:52 --> Total execution time: 0.0285
DEBUG - 2021-11-18 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:53 --> Total execution time: 0.0437
DEBUG - 2021-11-18 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:53 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:53 --> Total execution time: 0.0274
DEBUG - 2021-11-18 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:53 --> Total execution time: 0.0386
DEBUG - 2021-11-18 09:22:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:53 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:54 --> Total execution time: 0.0490
DEBUG - 2021-11-18 09:22:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:54 --> Total execution time: 0.0392
DEBUG - 2021-11-18 09:22:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:55 --> Total execution time: 0.0491
DEBUG - 2021-11-18 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:55 --> Total execution time: 0.0435
DEBUG - 2021-11-18 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:55 --> Total execution time: 0.0378
DEBUG - 2021-11-18 09:22:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:56 --> Total execution time: 0.0410
DEBUG - 2021-11-18 09:22:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:56 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:56 --> Total execution time: 0.0421
DEBUG - 2021-11-18 09:22:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:57 --> Total execution time: 0.0423
DEBUG - 2021-11-18 09:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:22:57 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:22:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:22:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:22:57 --> Total execution time: 0.0476
DEBUG - 2021-11-18 09:23:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:23:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:23:00 --> Total execution time: 0.0411
DEBUG - 2021-11-18 09:23:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:23:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:23:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:23:07 --> Total execution time: 0.0420
DEBUG - 2021-11-18 09:23:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:23:10 --> Total execution time: 0.0478
DEBUG - 2021-11-18 09:23:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:23:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:23:10 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:23:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:23:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:23:11 --> Total execution time: 0.0269
DEBUG - 2021-11-18 09:36:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:36:15 --> Total execution time: 0.0531
DEBUG - 2021-11-18 09:36:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:36:17 --> Total execution time: 0.0414
DEBUG - 2021-11-18 09:38:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:38:51 --> Total execution time: 0.0505
DEBUG - 2021-11-18 09:39:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:39:17 --> Total execution time: 0.0505
DEBUG - 2021-11-18 09:39:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:39:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:39:46 --> Total execution time: 0.0441
DEBUG - 2021-11-18 09:41:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:41:10 --> Total execution time: 0.0454
DEBUG - 2021-11-18 09:44:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:44:59 --> Total execution time: 0.0296
DEBUG - 2021-11-18 09:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:48:53 --> Total execution time: 0.0284
DEBUG - 2021-11-18 09:49:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:49:06 --> Total execution time: 0.0433
DEBUG - 2021-11-18 09:49:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:49:14 --> Total execution time: 0.0384
DEBUG - 2021-11-18 09:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:49:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:49:24 --> Total execution time: 0.0465
DEBUG - 2021-11-18 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:49:27 --> Total execution time: 0.0271
DEBUG - 2021-11-18 09:49:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:49:35 --> Total execution time: 0.0439
DEBUG - 2021-11-18 09:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:49:36 --> Total execution time: 0.0456
DEBUG - 2021-11-18 09:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:49:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:49:36 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:52:18 --> Total execution time: 0.0288
DEBUG - 2021-11-18 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:52:18 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:52:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:52:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 09:52:18 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 09:52:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:52:21 --> Total execution time: 0.0526
DEBUG - 2021-11-18 09:53:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:53:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:53:50 --> Total execution time: 0.0272
DEBUG - 2021-11-18 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:54:16 --> Total execution time: 0.0500
DEBUG - 2021-11-18 09:56:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:56:30 --> Total execution time: 0.0372
DEBUG - 2021-11-18 09:58:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 09:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 09:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 09:58:48 --> Total execution time: 0.0453
DEBUG - 2021-11-18 10:16:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:16:06 --> Total execution time: 0.0460
DEBUG - 2021-11-18 10:16:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:16:14 --> Total execution time: 0.0651
DEBUG - 2021-11-18 10:17:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:17:26 --> Total execution time: 0.2284
DEBUG - 2021-11-18 10:17:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 10:17:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 10:17:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:17:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 10:17:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:17:28 --> Total execution time: 0.0465
DEBUG - 2021-11-18 10:17:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:17:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 10:17:28 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 10:17:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:17:29 --> Total execution time: 0.0528
DEBUG - 2021-11-18 10:18:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:18:29 --> Total execution time: 0.0403
DEBUG - 2021-11-18 10:30:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 10:30:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 10:30:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-18 10:30:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-18 10:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:52 --> No URI present. Default controller set.
DEBUG - 2021-11-18 10:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:30:52 --> Total execution time: 0.0418
DEBUG - 2021-11-18 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:30:53 --> Total execution time: 0.0379
DEBUG - 2021-11-18 10:30:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:30:54 --> Total execution time: 0.0390
DEBUG - 2021-11-18 10:30:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-18 10:30:54 --> 404 Page Not Found: Assets/js
DEBUG - 2021-11-18 10:30:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:30:55 --> Total execution time: 0.0428
DEBUG - 2021-11-18 10:30:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:30:59 --> Total execution time: 0.0393
DEBUG - 2021-11-18 10:31:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-18 10:31:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-18 10:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-18 10:31:50 --> Total execution time: 0.0513
