<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-15 09:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 09:21:53 --> No URI present. Default controller set.
DEBUG - 2022-02-15 09:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 09:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 09:21:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 09:21:53 --> Total execution time: 0.0307
DEBUG - 2022-02-15 09:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 09:21:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-15 09:21:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-15 09:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 09:21:54 --> No URI present. Default controller set.
DEBUG - 2022-02-15 09:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 09:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 09:21:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 09:21:54 --> Total execution time: 0.0034
DEBUG - 2022-02-15 09:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 09:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 09:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 09:26:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 09:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 09:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 09:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 09:26:33 --> Total execution time: 0.0055
DEBUG - 2022-02-15 09:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 09:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 09:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 09:26:35 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-15 09:26:35 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1612
DEBUG - 2022-02-15 09:26:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 09:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 09:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 09:26:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 09:26:39 --> Total execution time: 0.0048
DEBUG - 2022-02-15 10:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:10:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:10:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:10:35 --> Total execution time: 0.0066
DEBUG - 2022-02-15 10:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:21:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:21:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:21:11 --> Total execution time: 0.0061
DEBUG - 2022-02-15 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:23:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:23:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:23:52 --> Total execution time: 0.0054
DEBUG - 2022-02-15 10:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:30:30 --> Total execution time: 0.0066
DEBUG - 2022-02-15 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:34:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:34:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:34:39 --> Total execution time: 0.0069
DEBUG - 2022-02-15 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:49:59 --> Total execution time: 0.0066
DEBUG - 2022-02-15 10:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:53:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:53:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:53:13 --> Total execution time: 0.0055
DEBUG - 2022-02-15 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 10:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 10:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 10:56:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 10:56:18 --> Total execution time: 0.0060
DEBUG - 2022-02-15 11:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:00:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:00:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:00:42 --> Total execution time: 0.0062
DEBUG - 2022-02-15 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:08:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:08:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:08:35 --> Total execution time: 0.0056
DEBUG - 2022-02-15 11:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:14:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:14:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:14:06 --> Total execution time: 0.0062
DEBUG - 2022-02-15 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:17:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:17:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:17:10 --> Total execution time: 0.0056
DEBUG - 2022-02-15 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:20:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:20:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:20:54 --> Total execution time: 0.0059
DEBUG - 2022-02-15 11:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:23:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-15 11:23:02 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-15 11:23:02 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Rahmila & M. Resya (Pameran)', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', 'Jl. Hasan Saputra IV No.10 Turangga Bandung', '0813', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-02-15 11:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:23:02 --> Total execution time: 0.0046
DEBUG - 2022-02-15 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:27:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:27:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:27:48 --> Total execution time: 0.0060
DEBUG - 2022-02-15 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:36:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:36:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:36:47 --> Total execution time: 0.0057
DEBUG - 2022-02-15 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:41:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:41:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:41:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:41:57 --> Total execution time: 0.0065
DEBUG - 2022-02-15 11:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:49:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:49:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:49:20 --> Total execution time: 0.0061
DEBUG - 2022-02-15 11:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:51:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 11:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 11:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 11:51:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 11:51:58 --> Total execution time: 0.0055
DEBUG - 2022-02-15 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:06:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:06:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:06:36 --> Total execution time: 0.0061
DEBUG - 2022-02-15 12:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:08:52 --> No URI present. Default controller set.
DEBUG - 2022-02-15 12:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:08:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:08:53 --> Total execution time: 0.0302
DEBUG - 2022-02-15 12:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:08:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-15 12:08:53 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-15 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:09:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:09:10 --> Total execution time: 0.0042
DEBUG - 2022-02-15 12:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:09:11 --> No URI present. Default controller set.
DEBUG - 2022-02-15 12:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:09:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:09:11 --> Total execution time: 0.0040
DEBUG - 2022-02-15 12:09:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:09:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-15 12:09:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-15 12:09:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:09:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-15 12:09:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1612
DEBUG - 2022-02-15 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:09:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:09:28 --> Total execution time: 0.0057
DEBUG - 2022-02-15 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:14:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:14:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:14:27 --> Total execution time: 0.0066
DEBUG - 2022-02-15 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:15:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:15:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:15:12 --> Total execution time: 0.0046
DEBUG - 2022-02-15 12:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:18:38 --> Total execution time: 0.0058
DEBUG - 2022-02-15 12:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:19:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:19:13 --> Total execution time: 0.0054
DEBUG - 2022-02-15 12:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:24:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:24:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:24:27 --> Total execution time: 0.0069
DEBUG - 2022-02-15 12:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:27:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:27:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:27:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:27:45 --> Total execution time: 0.0063
DEBUG - 2022-02-15 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:31:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:31:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:31:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:31:27 --> Total execution time: 0.0060
DEBUG - 2022-02-15 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 12:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 12:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 12:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 12:32:51 --> Total execution time: 0.0062
DEBUG - 2022-02-15 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:32:11 --> Total execution time: 0.0066
DEBUG - 2022-02-15 13:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:32:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-15 13:32:20 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1612
DEBUG - 2022-02-15 13:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:32:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:32:37 --> Total execution time: 0.0048
DEBUG - 2022-02-15 13:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:32:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-15 13:32:41 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1612
DEBUG - 2022-02-15 13:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:32:42 --> Total execution time: 0.0038
DEBUG - 2022-02-15 13:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:39:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:39:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:39:13 --> Total execution time: 0.0055
DEBUG - 2022-02-15 13:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:43:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:43:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:43:56 --> Total execution time: 0.0057
DEBUG - 2022-02-15 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:52:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:52:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:52:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:52:20 --> Total execution time: 0.0062
DEBUG - 2022-02-15 13:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:56:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 13:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 13:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 13:56:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 13:56:42 --> Total execution time: 0.0057
DEBUG - 2022-02-15 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:01:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:01:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:01:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:01:19 --> Total execution time: 0.0058
DEBUG - 2022-02-15 14:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:03:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:03:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:03:36 --> Total execution time: 0.0050
DEBUG - 2022-02-15 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:19:00 --> Total execution time: 0.0073
DEBUG - 2022-02-15 14:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:22:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:22:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:22:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:22:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:22:13 --> Total execution time: 0.0059
DEBUG - 2022-02-15 14:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:26:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:26:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:26:05 --> Total execution time: 0.0059
DEBUG - 2022-02-15 14:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:29:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:29:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:29:13 --> Total execution time: 0.0062
DEBUG - 2022-02-15 14:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:31:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:31:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:31:09 --> Total execution time: 0.0059
DEBUG - 2022-02-15 14:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:35:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:35:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:35:41 --> Total execution time: 0.0056
DEBUG - 2022-02-15 14:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:41:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:41:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:41:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:41:39 --> Total execution time: 0.0052
DEBUG - 2022-02-15 14:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:41:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:41:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:41:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:41:48 --> Total execution time: 0.0040
DEBUG - 2022-02-15 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:44:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:44:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:44:13 --> Total execution time: 0.0067
DEBUG - 2022-02-15 14:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:44:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:44:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:44:43 --> Total execution time: 0.0045
DEBUG - 2022-02-15 14:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:46:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:46:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:46:36 --> Total execution time: 0.0052
DEBUG - 2022-02-15 14:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:52:40 --> Total execution time: 0.0066
DEBUG - 2022-02-15 14:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:54:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:54:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:54:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:54:19 --> Total execution time: 0.0056
DEBUG - 2022-02-15 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:58:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 14:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 14:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 14:58:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 14:58:14 --> Total execution time: 0.0059
DEBUG - 2022-02-15 15:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:06:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:06:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:06:10 --> Total execution time: 0.0067
DEBUG - 2022-02-15 15:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:35:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:35:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:35:52 --> Total execution time: 0.0069
DEBUG - 2022-02-15 15:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:35:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:35:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:35:55 --> Total execution time: 0.0045
DEBUG - 2022-02-15 15:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:39:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:39:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:39:27 --> Total execution time: 0.0058
DEBUG - 2022-02-15 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:40:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:40:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:40:02 --> Total execution time: 0.0053
DEBUG - 2022-02-15 15:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:42:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:42:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:42:30 --> Total execution time: 0.0054
DEBUG - 2022-02-15 15:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:44:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:44:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:44:34 --> Total execution time: 0.0067
DEBUG - 2022-02-15 15:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:47:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:47:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:47:02 --> Total execution time: 0.0056
DEBUG - 2022-02-15 15:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:47:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:47:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:47:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:47:53 --> Total execution time: 0.0041
DEBUG - 2022-02-15 15:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:54:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:54:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:54:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:54:22 --> Total execution time: 0.0058
DEBUG - 2022-02-15 15:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:59:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:59:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 15:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 15:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 15:59:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 15:59:09 --> Total execution time: 0.0056
DEBUG - 2022-02-15 16:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:26:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:26:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:26:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:26:48 --> Total execution time: 0.0079
DEBUG - 2022-02-15 16:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:30:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:30:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:30:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:30:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:30:01 --> Total execution time: 0.0055
DEBUG - 2022-02-15 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:34:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:34:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:34:11 --> Total execution time: 0.0059
DEBUG - 2022-02-15 16:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:37:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:37:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:37:17 --> Total execution time: 0.0049
DEBUG - 2022-02-15 16:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:40:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:40:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:40:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:40:17 --> Total execution time: 0.0053
DEBUG - 2022-02-15 16:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:44:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:44:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:44:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:44:51 --> Total execution time: 0.0057
DEBUG - 2022-02-15 16:51:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:51:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:51:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:51:49 --> Total execution time: 0.0066
DEBUG - 2022-02-15 16:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:56:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 16:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 16:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 16:56:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 16:56:55 --> Total execution time: 0.0059
DEBUG - 2022-02-15 17:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:00:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:00:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:00:51 --> Total execution time: 0.0070
DEBUG - 2022-02-15 17:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:01:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:01:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:01:09 --> Total execution time: 0.0040
DEBUG - 2022-02-15 17:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:03:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:03:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:03:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:03:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:03:45 --> Total execution time: 0.0048
DEBUG - 2022-02-15 17:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:05:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:05:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:05:35 --> Total execution time: 0.0057
DEBUG - 2022-02-15 17:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:06:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:06:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:06:53 --> Total execution time: 0.0054
DEBUG - 2022-02-15 17:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:06:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:06:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:06:55 --> Total execution time: 0.0035
DEBUG - 2022-02-15 17:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:10:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:10:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:10:08 --> Total execution time: 0.0051
DEBUG - 2022-02-15 17:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:12:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:12:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:12:09 --> Total execution time: 0.0054
DEBUG - 2022-02-15 17:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:15:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:15:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:15:44 --> Total execution time: 0.0048
DEBUG - 2022-02-15 17:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:20:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:20:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:20:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:20:39 --> Total execution time: 0.0066
DEBUG - 2022-02-15 17:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:21:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:21:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:21:23 --> Total execution time: 0.0049
DEBUG - 2022-02-15 17:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:25:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:25:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:25:24 --> Total execution time: 0.0065
DEBUG - 2022-02-15 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:31:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:31:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:31:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:31:49 --> Total execution time: 0.0057
DEBUG - 2022-02-15 17:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:32:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:32:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:32:53 --> Total execution time: 0.0048
DEBUG - 2022-02-15 17:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:35:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:35:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:35:59 --> Total execution time: 0.0065
DEBUG - 2022-02-15 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:39:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:39:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:39:49 --> Total execution time: 0.0055
DEBUG - 2022-02-15 17:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:42:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:42:03 --> Total execution time: 0.0051
DEBUG - 2022-02-15 17:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:45:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:45:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:45:22 --> Total execution time: 0.0054
DEBUG - 2022-02-15 17:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:48:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 17:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 17:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 17:48:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 17:48:54 --> Total execution time: 0.0061
DEBUG - 2022-02-15 18:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 18:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 18:05:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 18:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 18:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 18:05:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 18:05:12 --> Total execution time: 0.0055
DEBUG - 2022-02-15 18:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 18:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 18:09:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 18:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 18:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 18:09:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 18:09:08 --> Total execution time: 0.0056
DEBUG - 2022-02-15 18:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 18:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 18:18:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 18:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 18:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 18:18:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 18:18:51 --> Total execution time: 0.0058
DEBUG - 2022-02-15 18:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 18:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 18:20:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 18:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 18:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 18:20:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 18:20:53 --> Total execution time: 0.0030
DEBUG - 2022-02-15 18:20:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 18:20:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-15 18:20:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-15 23:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 23:20:11 --> No URI present. Default controller set.
DEBUG - 2022-02-15 23:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 23:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 23:20:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 23:20:11 --> Total execution time: 0.0304
DEBUG - 2022-02-15 23:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 23:20:12 --> No URI present. Default controller set.
DEBUG - 2022-02-15 23:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 23:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 23:20:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 23:20:12 --> Total execution time: 0.0030
DEBUG - 2022-02-15 23:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 23:20:12 --> No URI present. Default controller set.
DEBUG - 2022-02-15 23:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-15 23:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-15 23:20:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-15 23:20:12 --> Total execution time: 0.0028
DEBUG - 2022-02-15 23:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-15 23:20:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-15 23:20:13 --> 404 Page Not Found: Faviconpng/index
