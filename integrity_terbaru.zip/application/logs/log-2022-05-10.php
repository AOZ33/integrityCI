<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-10 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:02:59 --> No URI present. Default controller set.
DEBUG - 2022-05-10 04:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 04:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 04:02:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 04:02:59 --> Total execution time: 0.0486
DEBUG - 2022-05-10 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 04:02:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-10 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 04:02:59 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-10 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 04:02:59 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-10 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 04:02:59 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-10 04:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:02:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 04:02:59 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-10 04:03:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 04:03:00 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-10 04:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 04:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 04:03:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 04:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 04:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 04:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 04:03:01 --> Total execution time: 0.0125
DEBUG - 2022-05-10 05:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:24:45 --> Total execution time: 0.0404
DEBUG - 2022-05-10 05:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:20 --> No URI present. Default controller set.
DEBUG - 2022-05-10 05:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:25:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:25:20 --> Total execution time: 0.0029
DEBUG - 2022-05-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:52 --> No URI present. Default controller set.
DEBUG - 2022-05-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:25:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:25:52 --> Total execution time: 0.0016
DEBUG - 2022-05-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:25:52 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:25:52 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:25:52 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:25:52 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:25:52 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:25:52 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-10 05:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:25:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-10 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:25:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-10 05:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:32 --> No URI present. Default controller set.
DEBUG - 2022-05-10 05:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:26:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:26:32 --> Total execution time: 0.0025
DEBUG - 2022-05-10 05:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:26:32 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-10 05:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:26:32 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-10 05:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:26:32 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-10 05:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:26:32 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-10 05:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:26:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-10 05:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:26:33 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-10 05:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:26:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:26:52 --> Total execution time: 0.0029
DEBUG - 2022-05-10 05:26:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:26:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:26:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-10 05:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:34:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:34:05 --> Total execution time: 0.0841
DEBUG - 2022-05-10 05:34:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:34:22 --> Total execution time: 0.0071
DEBUG - 2022-05-10 05:34:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:34:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:34:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:34:50 --> Total execution time: 0.0150
DEBUG - 2022-05-10 05:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:34:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 05:34:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-10 05:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:34:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:34:55 --> Total execution time: 0.0041
DEBUG - 2022-05-10 05:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:41:13 --> Total execution time: 0.0415
DEBUG - 2022-05-10 05:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:41:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:41:15 --> Total execution time: 0.0136
DEBUG - 2022-05-10 05:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:41:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:41:27 --> Total execution time: 0.0162
DEBUG - 2022-05-10 05:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 05:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 05:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 05:41:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 05:41:42 --> Total execution time: 0.0217
DEBUG - 2022-05-10 06:23:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:23:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:23:48 --> Total execution time: 0.0424
DEBUG - 2022-05-10 06:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:24:33 --> No URI present. Default controller set.
DEBUG - 2022-05-10 06:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:24:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:25:00 --> No URI present. Default controller set.
DEBUG - 2022-05-10 06:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:25:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:25:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:25:00 --> Total execution time: 0.0091
DEBUG - 2022-05-10 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:25:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:25:14 --> Total execution time: 0.0038
DEBUG - 2022-05-10 06:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:25:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 06:25:14 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-10 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:28:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:28:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:28:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:28:08 --> Total execution time: 0.0058
DEBUG - 2022-05-10 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:28:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:28:19 --> Total execution time: 0.0035
DEBUG - 2022-05-10 06:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:28:25 --> Total execution time: 0.0288
DEBUG - 2022-05-10 06:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:28:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:28:28 --> Total execution time: 0.0232
DEBUG - 2022-05-10 06:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:42:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:42:24 --> Total execution time: 0.0432
DEBUG - 2022-05-10 06:52:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:52:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:52:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:52:50 --> Total execution time: 0.0473
DEBUG - 2022-05-10 06:52:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:52:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:52:59 --> Total execution time: 0.0056
DEBUG - 2022-05-10 06:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:53:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:53:15 --> Total execution time: 0.0056
DEBUG - 2022-05-10 06:59:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:59:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:59:17 --> Total execution time: 0.0614
DEBUG - 2022-05-10 06:59:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:59:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:59:23 --> Total execution time: 0.0039
DEBUG - 2022-05-10 06:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:59:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:59:27 --> Total execution time: 0.0025
DEBUG - 2022-05-10 06:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 06:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 06:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 06:59:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 06:59:31 --> Total execution time: 0.0196
DEBUG - 2022-05-10 07:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:00:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:00:07 --> Total execution time: 0.0221
DEBUG - 2022-05-10 07:00:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:00:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:00:11 --> Total execution time: 0.0054
DEBUG - 2022-05-10 07:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:00:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:00:12 --> Total execution time: 0.0031
DEBUG - 2022-05-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:05:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:05:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:05:15 --> Total execution time: 0.0108
DEBUG - 2022-05-10 07:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:05:21 --> Total execution time: 0.0194
DEBUG - 2022-05-10 07:05:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:05:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:05:26 --> Total execution time: 0.0164
DEBUG - 2022-05-10 07:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:05:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:05:35 --> Total execution time: 0.0033
DEBUG - 2022-05-10 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:30 --> No URI present. Default controller set.
DEBUG - 2022-05-10 07:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:59:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:59:30 --> Total execution time: 0.0438
DEBUG - 2022-05-10 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 07:59:30 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-10 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 07:59:30 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-10 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 07:59:30 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-10 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 07:59:30 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-10 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 07:59:30 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-10 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 07:59:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-10 07:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:59:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 07:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 07:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 07:59:52 --> Total execution time: 0.0033
DEBUG - 2022-05-10 07:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 07:59:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 07:59:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-10 08:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:00:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:00:26 --> Total execution time: 0.0157
DEBUG - 2022-05-10 08:00:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:00:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:00:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:00:46 --> Total execution time: 0.0062
DEBUG - 2022-05-10 08:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:00:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:00:51 --> Total execution time: 0.0065
DEBUG - 2022-05-10 08:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:01:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:01:22 --> Total execution time: 0.0185
DEBUG - 2022-05-10 08:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-10 08:05:06 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-10 08:05:06 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Aisyah Shabrina & M Rifki Naufal', '2022-05-07', '2022-05-07', '2022-05-10', '2022-05-20', NULL, 'PHOTO', 'Prewedd (30X60)\r\nAkad (30X60)\r\nResepsi (30X60)\r\n\r\nPembesaran uk. 16Rp (2)')
DEBUG - 2022-05-10 08:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:05:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:05:06 --> Total execution time: 0.0032
DEBUG - 2022-05-10 08:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:05:19 --> Total execution time: 0.0061
DEBUG - 2022-05-10 08:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:05:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:05:44 --> Total execution time: 0.0031
DEBUG - 2022-05-10 08:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:08:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:08:07 --> Total execution time: 0.0098
DEBUG - 2022-05-10 08:08:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:08:12 --> Total execution time: 0.0049
DEBUG - 2022-05-10 08:08:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:08:19 --> Total execution time: 0.0035
DEBUG - 2022-05-10 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:08:53 --> Total execution time: 0.0053
DEBUG - 2022-05-10 08:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:09:44 --> Total execution time: 0.0040
DEBUG - 2022-05-10 08:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-10 08:11:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-05-10 08:11:11 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-05-10 08:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-10 08:11:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-05-10 08:11:16 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-05-10 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:18 --> No URI present. Default controller set.
DEBUG - 2022-05-10 08:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:11:18 --> Total execution time: 0.0022
DEBUG - 2022-05-10 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 08:11:18 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-10 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 08:11:18 --> 404 Page Not Found: Js/jquery.min.js
ERROR - 2022-05-10 08:11:18 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-10 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-10 08:11:18 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-05-10 08:11:18 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-10 08:11:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:19 --> No URI present. Default controller set.
DEBUG - 2022-05-10 08:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:11:19 --> Total execution time: 0.0025
DEBUG - 2022-05-10 08:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:11:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:20 --> Total execution time: 0.0033
DEBUG - 2022-05-10 08:11:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:11:22 --> Total execution time: 0.0071
DEBUG - 2022-05-10 08:11:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:11:28 --> Total execution time: 0.0039
DEBUG - 2022-05-10 08:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:11:45 --> Total execution time: 0.0193
DEBUG - 2022-05-10 08:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:11:52 --> Total execution time: 0.0040
DEBUG - 2022-05-10 08:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:11:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:11:56 --> Total execution time: 0.0033
DEBUG - 2022-05-10 08:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:12:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:12:27 --> Total execution time: 0.0032
DEBUG - 2022-05-10 08:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:13:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:13:38 --> Total execution time: 0.0072
DEBUG - 2022-05-10 08:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:14:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:14:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:14:03 --> Total execution time: 0.0037
DEBUG - 2022-05-10 08:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:14:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:14:14 --> Total execution time: 0.0031
DEBUG - 2022-05-10 08:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:15:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:15:48 --> Total execution time: 0.0058
DEBUG - 2022-05-10 08:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:19:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:19:50 --> Total execution time: 0.0560
DEBUG - 2022-05-10 08:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:20:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:20:03 --> Total execution time: 0.0088
DEBUG - 2022-05-10 08:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:20:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:20:10 --> Total execution time: 0.0207
DEBUG - 2022-05-10 08:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:20:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:20:17 --> Total execution time: 0.0028
DEBUG - 2022-05-10 08:20:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:20:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:20:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:20:42 --> Total execution time: 0.0048
DEBUG - 2022-05-10 08:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:22:02 --> Total execution time: 0.0057
DEBUG - 2022-05-10 08:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:22:07 --> Total execution time: 0.0049
DEBUG - 2022-05-10 08:22:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:22:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:22:19 --> Total execution time: 0.0060
DEBUG - 2022-05-10 08:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:22:27 --> Total execution time: 0.0029
DEBUG - 2022-05-10 08:22:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:22:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:22:46 --> Total execution time: 0.0076
DEBUG - 2022-05-10 08:22:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:22:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:22:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:22:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:22:54 --> Total execution time: 0.0030
DEBUG - 2022-05-10 08:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:24:03 --> Total execution time: 0.0099
DEBUG - 2022-05-10 08:24:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:08 --> Total execution time: 0.0061
DEBUG - 2022-05-10 08:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:21 --> Total execution time: 0.0032
DEBUG - 2022-05-10 08:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:30 --> Total execution time: 0.0026
DEBUG - 2022-05-10 08:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:41 --> Total execution time: 0.0032
DEBUG - 2022-05-10 08:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:24:46 --> Total execution time: 0.0037
DEBUG - 2022-05-10 08:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:24:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:24:54 --> Total execution time: 0.0229
DEBUG - 2022-05-10 08:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:25:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:25:22 --> Total execution time: 0.0049
DEBUG - 2022-05-10 08:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:26:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:26:16 --> Total execution time: 0.0062
DEBUG - 2022-05-10 08:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:26:22 --> Total execution time: 0.0039
DEBUG - 2022-05-10 08:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:27:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:27:08 --> Total execution time: 0.0078
DEBUG - 2022-05-10 08:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:27:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:27:16 --> Total execution time: 0.0041
DEBUG - 2022-05-10 08:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:28:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:28:32 --> Total execution time: 0.0056
DEBUG - 2022-05-10 08:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:28:41 --> Total execution time: 0.0054
DEBUG - 2022-05-10 08:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:28:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:28:50 --> Total execution time: 0.0037
DEBUG - 2022-05-10 08:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:29:15 --> Total execution time: 0.0043
DEBUG - 2022-05-10 08:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:29:22 --> Total execution time: 0.0043
DEBUG - 2022-05-10 08:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:29:28 --> Total execution time: 0.0043
DEBUG - 2022-05-10 08:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:29:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:29:34 --> Total execution time: 0.0033
DEBUG - 2022-05-10 08:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:29:38 --> Total execution time: 0.0055
DEBUG - 2022-05-10 08:29:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:29:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:29:43 --> Total execution time: 0.0063
DEBUG - 2022-05-10 08:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:30:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:30:00 --> Total execution time: 0.0059
DEBUG - 2022-05-10 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:30:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:30:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:30:50 --> Total execution time: 0.0053
DEBUG - 2022-05-10 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:32:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:32:09 --> Total execution time: 0.0038
DEBUG - 2022-05-10 08:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:32:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:32:15 --> Total execution time: 0.0037
DEBUG - 2022-05-10 08:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:32:31 --> Total execution time: 0.0047
DEBUG - 2022-05-10 08:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:32:34 --> Total execution time: 0.0083
DEBUG - 2022-05-10 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:33:02 --> Total execution time: 0.0107
DEBUG - 2022-05-10 08:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:33:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:33:25 --> Total execution time: 0.0241
DEBUG - 2022-05-10 08:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:33:34 --> Total execution time: 0.0080
DEBUG - 2022-05-10 08:34:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:34:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:34:14 --> Total execution time: 0.0076
DEBUG - 2022-05-10 08:34:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:34:19 --> Total execution time: 0.0033
DEBUG - 2022-05-10 08:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:34:39 --> Total execution time: 0.0029
DEBUG - 2022-05-10 08:34:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:34:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:34:49 --> Total execution time: 0.0033
DEBUG - 2022-05-10 08:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:34:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:34:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:34:53 --> Total execution time: 0.0030
DEBUG - 2022-05-10 08:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:35:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:35:07 --> Total execution time: 0.0058
DEBUG - 2022-05-10 08:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:35:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:35:45 --> Total execution time: 0.0059
DEBUG - 2022-05-10 08:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:36:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:36:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-10 08:36:21 --> Total execution time: 0.0050
DEBUG - 2022-05-10 08:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:36:25 --> Total execution time: 0.0034
DEBUG - 2022-05-10 08:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-10 08:36:47 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 83
DEBUG - 2022-05-10 08:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:36:47 --> Total execution time: 0.0024
DEBUG - 2022-05-10 08:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:37:19 --> Total execution time: 0.0040
DEBUG - 2022-05-10 08:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:37:38 --> Total execution time: 0.0036
DEBUG - 2022-05-10 08:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:38:15 --> Total execution time: 0.0045
DEBUG - 2022-05-10 08:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:38:18 --> Total execution time: 0.0031
DEBUG - 2022-05-10 08:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:38:38 --> Total execution time: 0.0059
DEBUG - 2022-05-10 08:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:38:40 --> Total execution time: 0.0026
DEBUG - 2022-05-10 08:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:39:05 --> Total execution time: 0.0044
DEBUG - 2022-05-10 08:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:40:02 --> Total execution time: 0.0041
DEBUG - 2022-05-10 08:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-10 08:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-10 08:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-10 08:40:12 --> Total execution time: 0.0028
