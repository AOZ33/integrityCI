<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-08-01 04:21:30 --> UTF-8 Support Enabled
DEBUG - 2022-08-01 04:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-01 04:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-01 04:21:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-08-01 04:21:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-08-01 04:21:30 --> Severity: error --> Exception: Call to a member function result_array() on bool C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-08-01 04:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-08-01 04:21:49 --> No URI present. Default controller set.
DEBUG - 2022-08-01 04:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-01 04:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-01 04:21:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-01 04:21:49 --> Total execution time: 0.1160
DEBUG - 2022-08-01 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-01 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-01 04:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-01 04:21:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-08-01 04:21:56 --> UTF-8 Support Enabled
DEBUG - 2022-08-01 04:21:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-08-01 04:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-08-01 04:21:56 --> Total execution time: 0.1357
