<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-19 08:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 08:53:33 --> No URI present. Default controller set.
DEBUG - 2022-02-19 08:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 08:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 08:53:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 08:53:33 --> Total execution time: 0.0308
DEBUG - 2022-02-19 13:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:07:12 --> No URI present. Default controller set.
DEBUG - 2022-02-19 13:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:07:12 --> Total execution time: 0.0297
DEBUG - 2022-02-19 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:07:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-19 13:07:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-19 13:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:07:22 --> Total execution time: 0.0043
DEBUG - 2022-02-19 13:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:07:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-19 13:07:27 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-19 13:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:07:29 --> Total execution time: 0.0040
DEBUG - 2022-02-19 13:25:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:25:43 --> No URI present. Default controller set.
DEBUG - 2022-02-19 13:25:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:25:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:25:43 --> Total execution time: 0.0319
DEBUG - 2022-02-19 13:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:25:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-19 13:25:44 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-19 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:30:41 --> No URI present. Default controller set.
DEBUG - 2022-02-19 13:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:30:41 --> Total execution time: 0.0323
DEBUG - 2022-02-19 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-19 13:30:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-19 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:30:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:30:51 --> Total execution time: 0.0038
DEBUG - 2022-02-19 13:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:31:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-19 13:31:02 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-19 13:31:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:31:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:31:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:31:13 --> Total execution time: 0.0046
DEBUG - 2022-02-19 13:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 13:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 13:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 13:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 13:41:29 --> Total execution time: 0.0055
DEBUG - 2022-02-19 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:05:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:05:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:05:05 --> Total execution time: 0.0053
DEBUG - 2022-02-19 14:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:29:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:29:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:29:10 --> Total execution time: 0.0062
DEBUG - 2022-02-19 14:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:33:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:33:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:33:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:33:50 --> Total execution time: 0.0058
DEBUG - 2022-02-19 14:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:44:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:44:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:44:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:44:53 --> Total execution time: 0.0058
DEBUG - 2022-02-19 14:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:49:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 14:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 14:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 14:49:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 14:49:51 --> Total execution time: 0.0057
DEBUG - 2022-02-19 15:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:07:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:07:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:07:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:07:52 --> Total execution time: 0.0068
DEBUG - 2022-02-19 15:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:13:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:13:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:13:11 --> Total execution time: 0.0054
DEBUG - 2022-02-19 15:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:16:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:16:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:16:49 --> Total execution time: 0.0049
DEBUG - 2022-02-19 15:25:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:25:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:25:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:25:15 --> Total execution time: 0.0060
DEBUG - 2022-02-19 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:41:38 --> Total execution time: 0.0058
DEBUG - 2022-02-19 15:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:45:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:45:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:45:46 --> Total execution time: 0.0049
DEBUG - 2022-02-19 15:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 15:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 15:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 15:50:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 15:50:39 --> Total execution time: 0.0056
DEBUG - 2022-02-19 16:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 16:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 16:01:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 16:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 16:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 16:01:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 16:01:32 --> Total execution time: 0.0069
DEBUG - 2022-02-19 16:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 16:05:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 16:05:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 16:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 16:05:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 16:05:13 --> Total execution time: 0.0050
DEBUG - 2022-02-19 16:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 16:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 16:09:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 16:09:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 16:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 16:09:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 16:09:18 --> Total execution time: 0.0051
DEBUG - 2022-02-19 16:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 16:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 16:09:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 16:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 16:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 16:09:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 16:09:39 --> Total execution time: 0.0032
DEBUG - 2022-02-19 16:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 16:09:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-19 16:09:39 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-19 21:08:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 21:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 21:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 21:08:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-19 21:08:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-19 21:08:27 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-19 21:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 21:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 21:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 21:42:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-19 21:42:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-19 21:42:03 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-19 21:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 21:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 21:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-19 21:49:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-19 21:49:43 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-19 22:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 22:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 22:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 22:41:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-19 22:41:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-19 22:41:38 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-19 22:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-19 22:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-19 22:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-19 22:45:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-19 22:45:05 --> Total execution time: 0.0305
