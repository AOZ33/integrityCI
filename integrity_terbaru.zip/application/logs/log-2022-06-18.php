<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-06-18 03:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-06-18 03:34:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-06-18 03:34:26 --> 404 Page Not Found: Wp-loginphp/index
