<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-26 09:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 09:25:22 --> No URI present. Default controller set.
DEBUG - 2022-01-26 09:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 09:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 09:25:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 09:25:22 --> Total execution time: 0.0305
DEBUG - 2022-01-26 09:25:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 09:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-26 09:25:22 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-26 09:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 09:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 09:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 09:34:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 09:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 09:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 09:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 09:34:12 --> Total execution time: 0.0068
DEBUG - 2022-01-26 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 09:34:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-26 09:34:21 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 124581016 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-26 09:36:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 09:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 09:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 09:36:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 09:36:47 --> Total execution time: 0.0323
DEBUG - 2022-01-26 10:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:20:59 --> Total execution time: 0.0069
DEBUG - 2022-01-26 10:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:30:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:30:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:30:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:30:36 --> Total execution time: 0.0058
DEBUG - 2022-01-26 10:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:38:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:38:04 --> Total execution time: 0.0059
DEBUG - 2022-01-26 10:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:42:02 --> Total execution time: 0.0061
DEBUG - 2022-01-26 10:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:48:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 10:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 10:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 10:48:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 10:48:05 --> Total execution time: 0.0061
DEBUG - 2022-01-26 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 11:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 11:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 11:11:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:11:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 11:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 11:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 11:11:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:11:06 --> Total execution time: 0.0067
DEBUG - 2022-01-26 11:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 11:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 11:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 11:24:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:24:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 11:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 11:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 11:24:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:24:24 --> Total execution time: 0.0058
DEBUG - 2022-01-26 11:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 11:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 11:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 11:28:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 11:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 11:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 11:28:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:28:35 --> Total execution time: 0.0058
DEBUG - 2022-01-26 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 11:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 11:44:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 11:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 11:44:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 11:44:58 --> Total execution time: 0.0059
DEBUG - 2022-01-26 12:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 12:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 12:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 12:25:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 12:25:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 12:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 12:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 12:25:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 12:25:16 --> Total execution time: 0.0063
DEBUG - 2022-01-26 13:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 13:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 13:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 13:45:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 13:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 13:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 13:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 13:45:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 13:45:23 --> Total execution time: 0.0068
DEBUG - 2022-01-26 13:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 13:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 13:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 13:48:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 13:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 13:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 13:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 13:48:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 13:48:28 --> Total execution time: 0.0057
DEBUG - 2022-01-26 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 13:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 13:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 13:54:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 13:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 13:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 13:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 13:54:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 13:54:01 --> Total execution time: 0.0061
DEBUG - 2022-01-26 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:11:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:11:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:11:55 --> Total execution time: 0.0064
DEBUG - 2022-01-26 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:20:01 --> Total execution time: 0.0069
DEBUG - 2022-01-26 14:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:24:50 --> Total execution time: 0.0063
DEBUG - 2022-01-26 14:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:29:58 --> Total execution time: 0.0051
DEBUG - 2022-01-26 14:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:34:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:34:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:34:59 --> Total execution time: 0.0065
DEBUG - 2022-01-26 14:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:44:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:44:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:44:23 --> Total execution time: 0.0067
DEBUG - 2022-01-26 14:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:46:13 --> Total execution time: 0.0052
DEBUG - 2022-01-26 14:49:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:49:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:49:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:49:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:49:15 --> Total execution time: 0.0049
DEBUG - 2022-01-26 14:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:53:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:53:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:53:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:53:44 --> Total execution time: 0.0057
DEBUG - 2022-01-26 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:57:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:57:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:57:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:57:55 --> Total execution time: 0.0072
DEBUG - 2022-01-26 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:59:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 14:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 14:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 14:59:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 14:59:18 --> Total execution time: 0.0058
DEBUG - 2022-01-26 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:10:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:10:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:10:45 --> Total execution time: 0.0062
DEBUG - 2022-01-26 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:15:42 --> Total execution time: 0.0060
DEBUG - 2022-01-26 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:17:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:17:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:17:18 --> Total execution time: 0.0051
DEBUG - 2022-01-26 15:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:26:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:26:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:26:13 --> Total execution time: 0.0070
DEBUG - 2022-01-26 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:32:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:32:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:32:22 --> Total execution time: 0.0061
DEBUG - 2022-01-26 15:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:44:32 --> Total execution time: 0.0067
DEBUG - 2022-01-26 15:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:48:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 15:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 15:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 15:48:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 15:48:57 --> Total execution time: 0.0061
DEBUG - 2022-01-26 16:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:05:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:05:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:05:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:05:46 --> Total execution time: 0.0061
DEBUG - 2022-01-26 16:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:08:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:08:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:08:37 --> Total execution time: 0.0058
DEBUG - 2022-01-26 16:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:12:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:12:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:12:42 --> Total execution time: 0.0061
DEBUG - 2022-01-26 16:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:15:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:15:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:15:59 --> Total execution time: 0.0055
DEBUG - 2022-01-26 16:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:30:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:30:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:30:04 --> Total execution time: 0.0062
DEBUG - 2022-01-26 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:33:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:33:19 --> Total execution time: 0.0050
DEBUG - 2022-01-26 16:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:40:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:40:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:40:31 --> Total execution time: 0.0065
DEBUG - 2022-01-26 16:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:43:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:43:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:43:40 --> Total execution time: 0.0067
DEBUG - 2022-01-26 16:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:50:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:50:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:50:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:50:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:50:21 --> Total execution time: 0.0059
DEBUG - 2022-01-26 16:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:54:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:54:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:54:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:54:03 --> Total execution time: 0.0064
DEBUG - 2022-01-26 16:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:57:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 16:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 16:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 16:57:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 16:57:32 --> Total execution time: 0.0049
DEBUG - 2022-01-26 17:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 17:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 17:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 17:00:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 17:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 17:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 17:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 17:00:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 17:00:16 --> Total execution time: 0.0049
DEBUG - 2022-01-26 17:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 17:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 17:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 17:01:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 17:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 17:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 17:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 17:01:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 17:01:58 --> Total execution time: 0.0056
DEBUG - 2022-01-26 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 17:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 17:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 17:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 17:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 17:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 17:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 17:03:11 --> Total execution time: 0.0052
DEBUG - 2022-01-26 17:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 17:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 17:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 17:05:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 17:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-26 17:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-26 17:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-26 17:05:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-26 17:05:19 --> Total execution time: 0.0054
