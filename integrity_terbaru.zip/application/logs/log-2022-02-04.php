<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-04 09:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:11:54 --> No URI present. Default controller set.
DEBUG - 2022-02-04 09:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:11:54 --> Total execution time: 0.0308
DEBUG - 2022-02-04 09:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:11:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-04 09:11:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-04 09:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:11:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:11:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:11:59 --> Total execution time: 0.0029
DEBUG - 2022-02-04 09:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:12:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-04 09:12:00 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-04 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:12:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:12:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:12:06 --> Total execution time: 0.0056
DEBUG - 2022-02-04 09:12:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:12:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-04 09:12:08 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 154348248 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-04 09:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:12:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:12:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:12:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:12:13 --> Total execution time: 3.1684
DEBUG - 2022-02-04 09:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:37:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:37:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:37:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:37:44 --> Total execution time: 0.0073
DEBUG - 2022-02-04 09:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:43:35 --> Total execution time: 0.0061
DEBUG - 2022-02-04 09:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:49:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 09:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 09:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 09:49:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 09:49:13 --> Total execution time: 0.0058
DEBUG - 2022-02-04 10:04:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:04:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-04 10:04:17 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-04 10:04:17 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Tia & Kukuh', '', 'Lamaran 5.75jt + PW.Only 5.5jt ', NULL, '4R(10)', 'Single', '20RP(2)', '', '', 'Lamaran & Prewedd', '', '', '2-3m', 'Edit 90 Photo Lamaran', '', 'Jl. Ahmad Yani 730 Komp. Puri Tirta Kencana I / 21 Bandung', '081326826300', 'noviatara.dwi@gmail.com', '', 'Rp. 11.250.000', 'Rp. 1.300.000', 'Rp. 1.100.000', 'Rp. 8.850.000', '2019-06-30', '10:00', 'Jl. Ahmad Yani 730 Komp. Puri Tirta Kencana I / 21 Bandung', '2019-07-01', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2019-04-09', '2019-05-18', '2019-07-08', '', '', '', '', '', '')
DEBUG - 2022-02-04 10:04:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:04:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:04:18 --> Total execution time: 0.0066
DEBUG - 2022-02-04 10:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:09:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:09:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:09:29 --> Total execution time: 0.0055
DEBUG - 2022-02-04 10:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:13:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:13:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:13:38 --> Total execution time: 0.0065
DEBUG - 2022-02-04 10:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:15:42 --> Total execution time: 0.0050
DEBUG - 2022-02-04 10:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:18:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:18:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:18:01 --> Total execution time: 0.0054
DEBUG - 2022-02-04 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:25:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:25:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:25:46 --> Total execution time: 0.0063
DEBUG - 2022-02-04 10:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:36:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:36:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:36:08 --> Total execution time: 0.0062
DEBUG - 2022-02-04 10:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:39:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-04 10:39:04 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-04 10:39:04 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Amanda & M. Garin', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', 'Jl. Bukit Dago Selatan no.7', '08221852', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-02-04 10:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:39:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:39:04 --> Total execution time: 0.0061
DEBUG - 2022-02-04 10:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:43:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 10:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 10:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 10:43:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 10:43:28 --> Total execution time: 0.0064
DEBUG - 2022-02-04 11:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 11:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 11:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 11:01:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 11:01:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 11:01:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 11:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 11:01:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 11:01:04 --> Total execution time: 0.0072
DEBUG - 2022-02-04 11:12:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 11:12:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 11:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 11:12:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 11:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 11:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 11:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 11:12:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 11:12:14 --> Total execution time: 0.0060
DEBUG - 2022-02-04 11:27:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 11:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 11:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 11:27:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 11:27:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 11:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 11:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 11:27:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 11:27:07 --> Total execution time: 0.0061
DEBUG - 2022-02-04 13:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:19:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:19:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:19:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:19:50 --> Total execution time: 0.0071
DEBUG - 2022-02-04 13:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:23:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:23:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:23:57 --> Total execution time: 0.0053
DEBUG - 2022-02-04 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:29:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:29:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:29:05 --> Total execution time: 0.0061
DEBUG - 2022-02-04 13:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:33:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:33:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:33:09 --> Total execution time: 0.0052
DEBUG - 2022-02-04 13:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:38:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 13:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 13:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 13:38:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 13:38:48 --> Total execution time: 0.0059
DEBUG - 2022-02-04 14:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:30:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:30:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:30:34 --> Total execution time: 0.0072
DEBUG - 2022-02-04 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:33:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:33:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:33:21 --> Total execution time: 0.0057
DEBUG - 2022-02-04 14:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:36:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:36:16 --> Total execution time: 0.0063
DEBUG - 2022-02-04 14:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:44:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:44:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:44:12 --> Total execution time: 0.0054
DEBUG - 2022-02-04 14:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:52:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:52:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:52:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:52:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:52:14 --> Total execution time: 0.0064
DEBUG - 2022-02-04 14:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:56:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:56:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 14:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 14:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 14:56:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 14:56:38 --> Total execution time: 0.0063
DEBUG - 2022-02-04 15:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:03:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:03:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:03:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:03:25 --> Total execution time: 0.0072
DEBUG - 2022-02-04 15:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:07:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:07:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:07:06 --> Total execution time: 0.0061
DEBUG - 2022-02-04 15:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:13:59 --> Total execution time: 0.0055
DEBUG - 2022-02-04 15:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:31:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:31:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:31:52 --> Total execution time: 0.0065
DEBUG - 2022-02-04 15:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:33:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:33:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:33:42 --> Total execution time: 0.0050
DEBUG - 2022-02-04 15:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:40:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:40:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:40:29 --> Total execution time: 0.0056
DEBUG - 2022-02-04 15:44:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:44:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:44:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:44:47 --> Total execution time: 0.0082
DEBUG - 2022-02-04 15:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:55:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:55:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:55:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:55:53 --> Total execution time: 0.0058
DEBUG - 2022-02-04 15:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:59:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 15:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 15:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 15:59:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 15:59:38 --> Total execution time: 0.0054
DEBUG - 2022-02-04 16:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 16:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 16:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 16:04:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 16:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 16:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 16:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 16:04:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 16:04:29 --> Total execution time: 0.0061
DEBUG - 2022-02-04 16:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 16:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 16:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 16:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 16:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 16:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 16:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 16:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 16:10:24 --> Total execution time: 0.0067
DEBUG - 2022-02-04 16:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 16:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 16:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 16:54:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 16:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 16:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 16:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 16:54:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 16:54:12 --> Total execution time: 0.0069
DEBUG - 2022-02-04 16:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 16:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 16:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 16:56:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 16:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 16:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 16:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 16:56:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 16:56:13 --> Total execution time: 0.0060
DEBUG - 2022-02-04 17:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 17:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 17:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 17:00:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 17:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 17:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 17:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 17:00:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 17:00:35 --> Total execution time: 0.0068
DEBUG - 2022-02-04 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 17:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 17:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 17:04:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 17:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 17:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 17:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 17:04:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 17:04:41 --> Total execution time: 0.0065
DEBUG - 2022-02-04 17:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 17:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 17:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 17:06:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 17:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-04 17:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-04 17:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-04 17:06:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-04 17:06:19 --> Total execution time: 0.0050
