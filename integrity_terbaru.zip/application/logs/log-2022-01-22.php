<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-22 00:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-22 00:20:23 --> No URI present. Default controller set.
DEBUG - 2022-01-22 00:20:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-22 00:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-22 00:20:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-22 00:20:23 --> Total execution time: 0.0303
DEBUG - 2022-01-22 00:20:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-22 00:20:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-22 00:20:23 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-22 00:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-22 00:20:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-22 00:20:24 --> 404 Page Not Found: Robotstxt/index
