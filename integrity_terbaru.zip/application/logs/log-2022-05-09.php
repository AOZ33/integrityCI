<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-09 03:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:56 --> No URI present. Default controller set.
DEBUG - 2022-05-09 03:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:30:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:30:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 03:30:56 --> Total execution time: 0.0388
DEBUG - 2022-05-09 03:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:30:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-09 03:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:30:56 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-09 03:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:30:56 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-09 03:30:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:30:56 --> UTF-8 Support Enabled
ERROR - 2022-05-09 03:30:56 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-09 03:30:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:30:56 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-09 03:30:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:30:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-09 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:30:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 03:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:30:58 --> Total execution time: 0.0084
DEBUG - 2022-05-09 03:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:30:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 03:30:59 --> Total execution time: 0.0018
DEBUG - 2022-05-09 03:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:31:01 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-09 03:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:31:01 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-09 03:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:31:02 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-09 03:31:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:31:02 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-09 03:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:31:03 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-09 03:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 03:31:06 --> Total execution time: 0.0349
DEBUG - 2022-05-09 03:31:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:31:06 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-05-09 03:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:16 --> Total execution time: 0.0043
DEBUG - 2022-05-09 03:31:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:16 --> Total execution time: 0.0471
DEBUG - 2022-05-09 03:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:19 --> Total execution time: 0.0412
DEBUG - 2022-05-09 03:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:19 --> Total execution time: 0.0394
DEBUG - 2022-05-09 03:31:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:20 --> Total execution time: 0.0444
DEBUG - 2022-05-09 03:31:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:20 --> Total execution time: 0.0474
DEBUG - 2022-05-09 03:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:21 --> Total execution time: 0.0406
DEBUG - 2022-05-09 03:31:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:22 --> Total execution time: 0.0445
DEBUG - 2022-05-09 03:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 03:31:23 --> Total execution time: 0.0240
DEBUG - 2022-05-09 03:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:31:23 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-05-09 03:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:25 --> Total execution time: 0.0021
DEBUG - 2022-05-09 03:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:25 --> Total execution time: 0.0613
DEBUG - 2022-05-09 03:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:28 --> Total execution time: 0.0523
DEBUG - 2022-05-09 03:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:28 --> Total execution time: 0.0451
DEBUG - 2022-05-09 03:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:29 --> Total execution time: 0.0487
DEBUG - 2022-05-09 03:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:29 --> Total execution time: 0.0467
DEBUG - 2022-05-09 03:31:29 --> Total execution time: 0.0616
DEBUG - 2022-05-09 03:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:30 --> Total execution time: 0.0449
DEBUG - 2022-05-09 03:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:31:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 03:31:55 --> Total execution time: 0.0246
DEBUG - 2022-05-09 03:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:31:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 03:31:55 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-05-09 03:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:32:04 --> Total execution time: 0.0029
DEBUG - 2022-05-09 03:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:32:04 --> Total execution time: 0.0541
DEBUG - 2022-05-09 03:32:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:32:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:32:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 03:32:04 --> Total execution time: 0.0239
DEBUG - 2022-05-09 03:40:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 03:40:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 03:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 03:40:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 03:40:31 --> Total execution time: 0.0641
DEBUG - 2022-05-09 04:27:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:27:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:27:01 --> Total execution time: 0.0433
DEBUG - 2022-05-09 04:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:27:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:27:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 04:27:06 --> Total execution time: 0.0039
DEBUG - 2022-05-09 04:27:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:27:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 04:27:06 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-09 04:27:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:27:10 --> Total execution time: 0.0036
DEBUG - 2022-05-09 04:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:27:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 04:27:12 --> Total execution time: 0.0256
DEBUG - 2022-05-09 04:27:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:27:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:27:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 04:27:15 --> Total execution time: 0.0201
DEBUG - 2022-05-09 04:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:40:23 --> Total execution time: 0.0528
DEBUG - 2022-05-09 04:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:40:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 04:40:29 --> Total execution time: 0.0119
DEBUG - 2022-05-09 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:43:48 --> No URI present. Default controller set.
DEBUG - 2022-05-09 04:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:43:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 04:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 04:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 04:43:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-09 04:43:48 --> Total execution time: 0.0131
DEBUG - 2022-05-09 04:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 04:43:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-09 04:43:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-09 06:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 06:56:33 --> Total execution time: 0.0427
DEBUG - 2022-05-09 06:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 06:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 06:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 06:56:33 --> Total execution time: 0.0520
DEBUG - 2022-05-09 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 08:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 08:46:46 --> Total execution time: 0.1077
DEBUG - 2022-05-09 08:46:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-09 08:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-09 08:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-09 08:46:47 --> Total execution time: 0.1660
DEBUG - 2022-05-09 08:46:47 --> Total execution time: 0.0717
