<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-16 09:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:30:35 --> No URI present. Default controller set.
DEBUG - 2022-03-16 09:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:30:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:30:35 --> Total execution time: 0.0301
DEBUG - 2022-03-16 09:30:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:30:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-16 09:30:35 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-16 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:30:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:30:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:30:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:30:37 --> Total execution time: 0.0068
DEBUG - 2022-03-16 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:34:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:34:21 --> Total execution time: 0.0404
DEBUG - 2022-03-16 09:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:37:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:37:05 --> Total execution time: 0.0070
DEBUG - 2022-03-16 09:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:44:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:44:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:44:28 --> Total execution time: 0.0064
DEBUG - 2022-03-16 09:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:45:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:45:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:45:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:45:52 --> Total execution time: 0.0057
DEBUG - 2022-03-16 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:47:25 --> Total execution time: 0.0057
DEBUG - 2022-03-16 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:50:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:50:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:50:50 --> Total execution time: 0.0070
DEBUG - 2022-03-16 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:59:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:59:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 09:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 09:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 09:59:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 09:59:43 --> Total execution time: 0.0061
DEBUG - 2022-03-16 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 10:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 10:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 10:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 10:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 10:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 10:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 10:27:31 --> Total execution time: 0.0069
DEBUG - 2022-03-16 10:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 10:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 10:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 10:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 10:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 10:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 10:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 10:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 10:59:42 --> Total execution time: 0.0080
DEBUG - 2022-03-16 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 11:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 11:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 11:12:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 11:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 11:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 11:12:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:12:59 --> Total execution time: 0.0159
DEBUG - 2022-03-16 11:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 11:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 11:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 11:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 11:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 11:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 11:34:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:34:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 11:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 11:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 11:34:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 11:34:06 --> Total execution time: 0.0071
DEBUG - 2022-03-16 12:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 12:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 12:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 12:57:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 12:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 12:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 12:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 12:57:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 12:57:22 --> Total execution time: 0.0077
DEBUG - 2022-03-16 13:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:14:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:14:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:14:42 --> Total execution time: 0.0074
DEBUG - 2022-03-16 13:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:21:26 --> Total execution time: 0.0064
DEBUG - 2022-03-16 13:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:27:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:27:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:27:25 --> Total execution time: 0.0065
DEBUG - 2022-03-16 13:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:34:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:34:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:34:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:34:03 --> Total execution time: 0.0064
DEBUG - 2022-03-16 13:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:37:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:37:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:37:50 --> Total execution time: 0.0065
DEBUG - 2022-03-16 13:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:43:47 --> No URI present. Default controller set.
DEBUG - 2022-03-16 13:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:43:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:43:47 --> Total execution time: 0.0330
DEBUG - 2022-03-16 13:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:43:47 --> UTF-8 Support Enabled
ERROR - 2022-03-16 13:43:47 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-16 13:43:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-16 13:43:47 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-16 13:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:43:48 --> No URI present. Default controller set.
DEBUG - 2022-03-16 13:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:43:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:43:48 --> Total execution time: 0.0041
DEBUG - 2022-03-16 13:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-16 13:43:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-16 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:43:53 --> Total execution time: 0.0055
DEBUG - 2022-03-16 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:43:57 --> Total execution time: 0.0043
DEBUG - 2022-03-16 13:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-16 13:43:57 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-16 13:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:44:02 --> Total execution time: 0.0044
DEBUG - 2022-03-16 13:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:44:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:44:05 --> Total execution time: 0.0117
DEBUG - 2022-03-16 13:44:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:44:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:44:34 --> Total execution time: 0.0077
DEBUG - 2022-03-16 13:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:44:37 --> Total execution time: 0.0068
DEBUG - 2022-03-16 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:46:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:46:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:46:40 --> Total execution time: 0.0030
DEBUG - 2022-03-16 13:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:46:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-16 13:46:40 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-16 13:46:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:46:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:46:42 --> Total execution time: 0.0032
DEBUG - 2022-03-16 13:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:46:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-16 13:46:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-16 13:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:49:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:49:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:49:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:49:01 --> Total execution time: 0.0062
DEBUG - 2022-03-16 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:51:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 13:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 13:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 13:51:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 13:51:13 --> Total execution time: 0.0058
DEBUG - 2022-03-16 14:00:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:00:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:00:26 --> Total execution time: 0.0404
DEBUG - 2022-03-16 14:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:00:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:00:33 --> Total execution time: 0.0102
DEBUG - 2022-03-16 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:00:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:00:41 --> Total execution time: 0.0048
DEBUG - 2022-03-16 14:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:07:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:07:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:07:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:07:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:07:09 --> Total execution time: 0.0064
DEBUG - 2022-03-16 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:10:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:10:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:10:04 --> Total execution time: 0.0063
DEBUG - 2022-03-16 14:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:15:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:15:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:15:05 --> Total execution time: 0.0068
DEBUG - 2022-03-16 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:21:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:21:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:21:33 --> Total execution time: 0.0069
DEBUG - 2022-03-16 14:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:25:08 --> No URI present. Default controller set.
DEBUG - 2022-03-16 14:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:25:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:25:08 --> Total execution time: 0.0308
DEBUG - 2022-03-16 14:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:25:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-16 14:25:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-16 14:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:28:24 --> Total execution time: 0.0062
DEBUG - 2022-03-16 14:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:34:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:34:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:34:52 --> Total execution time: 0.0080
DEBUG - 2022-03-16 14:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:41:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:41:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:41:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:41:31 --> Total execution time: 0.0059
DEBUG - 2022-03-16 14:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:46:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:46:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 14:46:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 14:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 14:46:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 14:46:10 --> Total execution time: 0.0064
DEBUG - 2022-03-16 15:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:01:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:01:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:01:53 --> Total execution time: 0.0064
DEBUG - 2022-03-16 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:06:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:06:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:06:42 --> Total execution time: 0.0066
DEBUG - 2022-03-16 15:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:19:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:19:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:19:53 --> Total execution time: 0.0061
DEBUG - 2022-03-16 15:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:23:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:23:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:23:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:23:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:23:40 --> Total execution time: 0.0071
DEBUG - 2022-03-16 15:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:28:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:28:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:28:45 --> Total execution time: 0.0064
DEBUG - 2022-03-16 15:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:29:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:29:07 --> Total execution time: 0.0139
DEBUG - 2022-03-16 15:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:29:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:29:11 --> Total execution time: 0.0100
DEBUG - 2022-03-16 15:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:29:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:29:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:29:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:29:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:29:27 --> Total execution time: 0.0087
DEBUG - 2022-03-16 15:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:29:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:29:30 --> Total execution time: 0.0103
DEBUG - 2022-03-16 15:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:29:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:29:33 --> Total execution time: 0.0046
DEBUG - 2022-03-16 15:29:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:29:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:29:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:29:49 --> Total execution time: 0.0085
DEBUG - 2022-03-16 15:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:29:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:29:50 --> Total execution time: 0.0041
DEBUG - 2022-03-16 15:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:36:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:36:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:36:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:36:12 --> Total execution time: 0.0060
DEBUG - 2022-03-16 15:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:39:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:39:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:39:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:39:16 --> Total execution time: 0.0047
DEBUG - 2022-03-16 15:43:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:43:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:43:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:43:44 --> Total execution time: 0.0070
DEBUG - 2022-03-16 15:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:46:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:46:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:46:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:46:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:46:30 --> Total execution time: 0.0054
DEBUG - 2022-03-16 15:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:48:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:48:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 15:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 15:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 15:48:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 15:48:31 --> Total execution time: 0.0056
DEBUG - 2022-03-16 16:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:13:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:13:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:13:26 --> Total execution time: 0.0084
DEBUG - 2022-03-16 16:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:18:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:18:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:18:00 --> Total execution time: 0.0068
DEBUG - 2022-03-16 16:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:21:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:21:26 --> Total execution time: 0.0047
DEBUG - 2022-03-16 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:24:17 --> Total execution time: 0.0042
DEBUG - 2022-03-16 16:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:28:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:28:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:28:12 --> Total execution time: 0.0060
DEBUG - 2022-03-16 16:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-16 16:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-16 16:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-16 16:30:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:30:19 --> Total execution time: 0.0398
DEBUG - 2022-03-16 16:30:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-16 16:30:19 --> Total execution time: 0.0269
