<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-15 04:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:01:31 --> No URI present. Default controller set.
DEBUG - 2022-07-15 04:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 04:01:31 --> Total execution time: 0.1546
DEBUG - 2022-07-15 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 04:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:22 --> Total execution time: 0.1459
DEBUG - 2022-07-15 04:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:28 --> Total execution time: 0.1469
DEBUG - 2022-07-15 04:55:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:31 --> Total execution time: 0.1791
DEBUG - 2022-07-15 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:33 --> Total execution time: 0.1291
DEBUG - 2022-07-15 04:55:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:35 --> Total execution time: 0.1414
DEBUG - 2022-07-15 04:55:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:37 --> Total execution time: 0.1951
DEBUG - 2022-07-15 04:55:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:40 --> Total execution time: 0.1459
DEBUG - 2022-07-15 04:55:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 04:55:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 04:55:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 04:55:41 --> Total execution time: 0.1379
DEBUG - 2022-07-15 05:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 05:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 05:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 05:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 05:16:14 --> Total execution time: 0.2233
DEBUG - 2022-07-15 05:16:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 05:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 05:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 05:16:19 --> Total execution time: 0.1221
DEBUG - 2022-07-15 05:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 05:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 05:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 05:16:22 --> Total execution time: 0.1115
DEBUG - 2022-07-15 05:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 05:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 05:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 05:16:24 --> Total execution time: 0.1204
DEBUG - 2022-07-15 05:16:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 05:16:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 05:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 05:16:28 --> Total execution time: 0.1392
DEBUG - 2022-07-15 06:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:37:31 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-07-15 06:37:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-07-15 06:37:31 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-07-15 06:37:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-07-15 06:37:34 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-07-15 06:37:34 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-07-15 06:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-07-15 06:37:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-07-15 06:37:36 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-07-15 06:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-07-15 06:37:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-07-15 06:37:37 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-07-15 06:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-07-15 06:37:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-07-15 06:37:38 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-07-15 06:37:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-07-15 06:37:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-07-15 06:37:53 --> Severity: error --> Exception: Call to a member function result_array() on boolean C:\xampp\htdocs\NESNUMOTO\integrity\application\views\templates\sidebar.php 23
DEBUG - 2022-07-15 06:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:38:27 --> No URI present. Default controller set.
DEBUG - 2022-07-15 06:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 06:38:28 --> Total execution time: 0.1367
DEBUG - 2022-07-15 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:38:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:38:35 --> Total execution time: 0.1554
DEBUG - 2022-07-15 06:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:38:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 06:38:37 --> Total execution time: 0.1972
DEBUG - 2022-07-15 06:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:38:59 --> Total execution time: 0.1268
DEBUG - 2022-07-15 06:39:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:39:01 --> Total execution time: 0.1326
DEBUG - 2022-07-15 06:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:39:08 --> Total execution time: 0.1229
DEBUG - 2022-07-15 06:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 06:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 06:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 06:39:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 06:39:20 --> Total execution time: 0.1740
DEBUG - 2022-07-15 08:52:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 08:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 08:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 08:52:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 08:52:09 --> Total execution time: 0.2008
DEBUG - 2022-07-15 10:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 10:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 10:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 10:05:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 10:05:16 --> Total execution time: 0.2297
DEBUG - 2022-07-15 10:05:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-15 10:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-15 10:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-15 10:05:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-15 10:05:21 --> Total execution time: 0.1307
