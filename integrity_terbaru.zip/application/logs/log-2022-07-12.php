<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-12 06:38:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:38:27 --> No URI present. Default controller set.
DEBUG - 2022-07-12 06:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 06:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 06:38:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 06:38:29 --> Total execution time: 2.0911
DEBUG - 2022-07-12 06:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 06:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:38:29 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-07-12 06:38:29 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 06:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 06:38:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:38:29 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-07-12 06:38:29 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:43:21 --> No URI present. Default controller set.
DEBUG - 2022-07-12 06:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 06:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 06:43:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 06:43:21 --> Total execution time: 0.1100
DEBUG - 2022-07-12 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:43:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:43:21 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:44:54 --> No URI present. Default controller set.
DEBUG - 2022-07-12 06:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 06:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 06:44:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 06:44:54 --> Total execution time: 0.0660
DEBUG - 2022-07-12 06:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:44:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:44:54 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 06:45:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:45:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:45:57 --> 404 Page Not Found: Auth/login.php
DEBUG - 2022-07-12 06:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:46:45 --> 404 Page Not Found: Login/index
DEBUG - 2022-07-12 06:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:47:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:47:00 --> 404 Page Not Found: Auth/login
DEBUG - 2022-07-12 06:48:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 06:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 06:48:40 --> Total execution time: 0.0870
DEBUG - 2022-07-12 06:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:50:38 --> No URI present. Default controller set.
DEBUG - 2022-07-12 06:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 06:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 06:50:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 06:50:38 --> Total execution time: 0.1230
DEBUG - 2022-07-12 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:50:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:50:39 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:50:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:50:39 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-12 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:50:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:50:39 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 06:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 06:50:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 06:50:39 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 09:00:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:00:39 --> No URI present. Default controller set.
DEBUG - 2022-07-12 09:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 09:00:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 09:00:40 --> Total execution time: 1.0481
DEBUG - 2022-07-12 09:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:00:41 --> 404 Page Not Found: Js/main.js
ERROR - 2022-07-12 09:00:41 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 09:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:00:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:00:41 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-07-12 09:00:41 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 09:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:10 --> No URI present. Default controller set.
DEBUG - 2022-07-12 09:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 09:28:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 09:28:11 --> Total execution time: 0.2420
DEBUG - 2022-07-12 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:28:11 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-12 09:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:28:11 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 09:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:28:11 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 09:28:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:28:12 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 09:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 09:28:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 09:28:49 --> Total execution time: 0.1360
DEBUG - 2022-07-12 09:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:28:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 09:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:28:50 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-12 09:28:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:28:50 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 09:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:28:50 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 09:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 09:42:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 09:42:48 --> Total execution time: 0.2780
DEBUG - 2022-07-12 09:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:42:48 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 09:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:42:48 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-07-12 09:42:48 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-12 09:42:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:42:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 09:43:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 09:43:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 09:43:27 --> Total execution time: 0.2250
DEBUG - 2022-07-12 09:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:43:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:43:28 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 09:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:43:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:43:28 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-07-12 09:43:28 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-12 09:43:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:43:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:43:28 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 09:47:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 09:47:40 --> Total execution time: 0.0680
DEBUG - 2022-07-12 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:47:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:47:40 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 09:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:47:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:47:40 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 09:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:47:41 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-12 09:47:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:47:41 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 09:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 09:50:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 09:50:08 --> Total execution time: 0.1990
DEBUG - 2022-07-12 09:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:50:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:50:08 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 09:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:50:09 --> UTF-8 Support Enabled
ERROR - 2022-07-12 09:50:09 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 09:50:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:50:09 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-12 09:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:50:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:50:09 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 09:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 09:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 09:51:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 09:51:56 --> Total execution time: 0.0910
DEBUG - 2022-07-12 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:51:57 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-12 09:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:51:57 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:51:57 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-12 09:51:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 09:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 09:51:57 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:03:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:03:32 --> Total execution time: 0.0940
DEBUG - 2022-07-12 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:03:32 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 10:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:03:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:03:32 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-07-12 10:03:32 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 10:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:06:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:06:53 --> Total execution time: 0.0930
DEBUG - 2022-07-12 10:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:06:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:06:53 --> 404 Page Not Found: Assets/core
DEBUG - 2022-07-12 10:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:06:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:06:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:06:53 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 10:06:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:06:54 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-12 10:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:07:12 --> Total execution time: 0.1930
DEBUG - 2022-07-12 10:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:07:13 --> 404 Page Not Found: Assets/core
ERROR - 2022-07-12 10:07:13 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 10:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:08:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:08:31 --> Total execution time: 0.1160
DEBUG - 2022-07-12 10:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:08:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:08:32 --> 404 Page Not Found: Assets/js
DEBUG - 2022-07-12 10:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:08:32 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 10:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:13:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:13:10 --> Total execution time: 0.0920
DEBUG - 2022-07-12 10:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:13:10 --> 404 Page Not Found: Assets/js
DEBUG - 2022-07-12 10:13:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:13:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:13:10 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:14:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:14:52 --> Total execution time: 0.0690
DEBUG - 2022-07-12 10:14:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 10:14:52 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-12 10:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:17:17 --> Total execution time: 0.0770
DEBUG - 2022-07-12 10:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:17:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:17:24 --> Total execution time: 0.0660
DEBUG - 2022-07-12 10:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:18:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:18:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:18:51 --> Total execution time: 0.0710
DEBUG - 2022-07-12 10:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:19:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:19:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:19:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:19:45 --> Total execution time: 0.0680
DEBUG - 2022-07-12 10:20:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:20:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:20:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:20:08 --> Total execution time: 0.0860
DEBUG - 2022-07-12 10:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:24:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:24:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:24:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:24:20 --> Total execution time: 0.0580
DEBUG - 2022-07-12 10:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:28:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:28:25 --> Total execution time: 0.0860
DEBUG - 2022-07-12 10:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:28:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:28:36 --> Unable to find validation rule: valid_password
ERROR - 2022-07-12 10:28:36 --> Could not find the language line "form_validation_valid_password"
DEBUG - 2022-07-12 10:28:36 --> Total execution time: 0.0760
DEBUG - 2022-07-12 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:33:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:33:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:33:33 --> Total execution time: 0.0790
DEBUG - 2022-07-12 10:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:37:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:37:46 --> Total execution time: 0.3310
DEBUG - 2022-07-12 10:38:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:38:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:38:53 --> Total execution time: 0.7500
DEBUG - 2022-07-12 10:39:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:39:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:39:11 --> Total execution time: 0.3930
DEBUG - 2022-07-12 10:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:39:28 --> Total execution time: 0.1530
DEBUG - 2022-07-12 10:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:39:42 --> Total execution time: 0.2350
DEBUG - 2022-07-12 10:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:40:02 --> Total execution time: 0.1630
DEBUG - 2022-07-12 10:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:40:21 --> Total execution time: 0.1300
DEBUG - 2022-07-12 10:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:40:34 --> Total execution time: 0.1690
DEBUG - 2022-07-12 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:40:51 --> Total execution time: 0.1300
DEBUG - 2022-07-12 10:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:40:52 --> Total execution time: 0.3750
DEBUG - 2022-07-12 10:41:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:41:03 --> Total execution time: 0.0900
DEBUG - 2022-07-12 10:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:41:07 --> Total execution time: 0.1110
DEBUG - 2022-07-12 10:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:41:08 --> Total execution time: 0.2840
DEBUG - 2022-07-12 10:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:41:19 --> Total execution time: 0.0830
DEBUG - 2022-07-12 10:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:41:30 --> Total execution time: 0.1980
DEBUG - 2022-07-12 10:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:41:52 --> Total execution time: 0.1600
DEBUG - 2022-07-12 10:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:00 --> Total execution time: 0.0850
DEBUG - 2022-07-12 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:15 --> Total execution time: 0.1260
DEBUG - 2022-07-12 10:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:24 --> Total execution time: 0.0600
DEBUG - 2022-07-12 10:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:25 --> Total execution time: 0.4240
DEBUG - 2022-07-12 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:28 --> Total execution time: 0.2520
DEBUG - 2022-07-12 10:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:29 --> Total execution time: 0.2690
DEBUG - 2022-07-12 10:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:29 --> Total execution time: 0.3550
DEBUG - 2022-07-12 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:30 --> Total execution time: 0.2110
DEBUG - 2022-07-12 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:30 --> Total execution time: 0.2220
DEBUG - 2022-07-12 10:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:30 --> Total execution time: 0.1860
DEBUG - 2022-07-12 10:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:31 --> Total execution time: 0.2770
DEBUG - 2022-07-12 10:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:31 --> Total execution time: 0.2440
DEBUG - 2022-07-12 10:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:51 --> Total execution time: 0.0800
DEBUG - 2022-07-12 10:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:42:59 --> Total execution time: 0.0870
DEBUG - 2022-07-12 10:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:44:31 --> Total execution time: 0.1440
DEBUG - 2022-07-12 10:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:45:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:45:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:45:37 --> Total execution time: 0.0830
DEBUG - 2022-07-12 10:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:45:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:45:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:45:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:45:48 --> Total execution time: 0.0720
DEBUG - 2022-07-12 10:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:47:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:47:33 --> Total execution time: 0.0740
DEBUG - 2022-07-12 10:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:47:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:47:39 --> Total execution time: 0.0670
DEBUG - 2022-07-12 10:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:47:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:47:55 --> Total execution time: 0.0900
DEBUG - 2022-07-12 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:48:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:48:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:48:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:48:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:48:28 --> Total execution time: 0.0990
DEBUG - 2022-07-12 10:48:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:48:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:48:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:48:39 --> Total execution time: 0.1690
DEBUG - 2022-07-12 10:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:48:46 --> Total execution time: 0.0840
DEBUG - 2022-07-12 10:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:48:56 --> Total execution time: 0.0750
DEBUG - 2022-07-12 10:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:49:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:49:03 --> Total execution time: 0.1010
DEBUG - 2022-07-12 10:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:49:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:49:07 --> Total execution time: 0.0910
DEBUG - 2022-07-12 10:56:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:56:31 --> Total execution time: 0.0870
DEBUG - 2022-07-12 10:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:56:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:56:44 --> Total execution time: 0.1750
DEBUG - 2022-07-12 10:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:57:06 --> Total execution time: 0.0740
DEBUG - 2022-07-12 10:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:57:21 --> Total execution time: 0.2220
DEBUG - 2022-07-12 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:57:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:57:25 --> Total execution time: 0.1460
DEBUG - 2022-07-12 10:58:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:58:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:58:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:58:02 --> Total execution time: 0.1510
DEBUG - 2022-07-12 10:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:58:15 --> Total execution time: 0.1690
DEBUG - 2022-07-12 10:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:58:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:58:39 --> Total execution time: 0.1050
DEBUG - 2022-07-12 10:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:58:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 10:58:42 --> Total execution time: 0.1430
DEBUG - 2022-07-12 10:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:59:46 --> Total execution time: 0.0990
DEBUG - 2022-07-12 10:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 10:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 10:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 10:59:54 --> Total execution time: 0.1210
DEBUG - 2022-07-12 11:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:00:00 --> Total execution time: 0.1470
DEBUG - 2022-07-12 11:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:00:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:00:15 --> Total execution time: 0.0990
DEBUG - 2022-07-12 11:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:00:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:00:23 --> Total execution time: 0.0990
DEBUG - 2022-07-12 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:01:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:01:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:01:32 --> Total execution time: 0.0710
DEBUG - 2022-07-12 11:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:01:54 --> Total execution time: 0.1190
DEBUG - 2022-07-12 11:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:02:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:02:08 --> Total execution time: 0.1390
DEBUG - 2022-07-12 11:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:02:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:02:11 --> Total execution time: 0.0990
DEBUG - 2022-07-12 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:22:21 --> No URI present. Default controller set.
DEBUG - 2022-07-12 11:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:22:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:22:21 --> Total execution time: 0.1239
DEBUG - 2022-07-12 11:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:22:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 11:22:29 --> 404 Page Not Found: NESNUMOTO/integrity
DEBUG - 2022-07-12 11:22:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:22:32 --> No URI present. Default controller set.
DEBUG - 2022-07-12 11:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:22:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:22:32 --> Total execution time: 0.1661
DEBUG - 2022-07-12 11:22:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:22:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 11:22:42 --> 404 Page Not Found: NESNUMOTO/integrity
DEBUG - 2022-07-12 11:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:23:29 --> No URI present. Default controller set.
DEBUG - 2022-07-12 11:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:23:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:23:29 --> Total execution time: 0.1157
DEBUG - 2022-07-12 11:23:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:23:49 --> No URI present. Default controller set.
DEBUG - 2022-07-12 11:23:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:23:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:23:49 --> Total execution time: 0.0915
DEBUG - 2022-07-12 11:23:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:23:56 --> No URI present. Default controller set.
DEBUG - 2022-07-12 11:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:23:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:23:56 --> Total execution time: 0.1091
DEBUG - 2022-07-12 11:24:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:24:03 --> No URI present. Default controller set.
DEBUG - 2022-07-12 11:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:24:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:24:03 --> Total execution time: 0.1091
DEBUG - 2022-07-12 11:24:18 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:24:18 --> No URI present. Default controller set.
DEBUG - 2022-07-12 11:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:24:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:24:18 --> Total execution time: 0.1086
DEBUG - 2022-07-12 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:24:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:24:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:24:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:24:28 --> Total execution time: 0.1217
DEBUG - 2022-07-12 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:24:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:24:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:24:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:24:37 --> Total execution time: 0.0927
DEBUG - 2022-07-12 11:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:42:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:42:56 --> Total execution time: 0.0659
DEBUG - 2022-07-12 11:42:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:42:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:42:57 --> Total execution time: 0.0905
DEBUG - 2022-07-12 11:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:10 --> Total execution time: 0.0618
DEBUG - 2022-07-12 11:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:10 --> Total execution time: 0.0460
DEBUG - 2022-07-12 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:11 --> Total execution time: 0.0657
DEBUG - 2022-07-12 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:11 --> Total execution time: 0.0669
DEBUG - 2022-07-12 11:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:11 --> Total execution time: 0.0681
DEBUG - 2022-07-12 11:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:48 --> Total execution time: 0.0571
DEBUG - 2022-07-12 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:49 --> Total execution time: 0.0518
DEBUG - 2022-07-12 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:49 --> Total execution time: 0.0603
DEBUG - 2022-07-12 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:49 --> Total execution time: 0.0663
DEBUG - 2022-07-12 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:49 --> Total execution time: 0.0751
DEBUG - 2022-07-12 11:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:49 --> Total execution time: 0.0801
DEBUG - 2022-07-12 11:43:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:43:57 --> Total execution time: 0.0958
DEBUG - 2022-07-12 11:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:06 --> Total execution time: 0.1151
DEBUG - 2022-07-12 11:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:10 --> Total execution time: 0.0918
DEBUG - 2022-07-12 11:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:10 --> Total execution time: 0.0706
DEBUG - 2022-07-12 11:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:11 --> Total execution time: 0.1038
DEBUG - 2022-07-12 11:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:11 --> Total execution time: 0.0780
DEBUG - 2022-07-12 11:44:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:11 --> Total execution time: 0.0698
DEBUG - 2022-07-12 11:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:22 --> Total execution time: 0.0957
DEBUG - 2022-07-12 11:44:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:23 --> Total execution time: 0.1036
DEBUG - 2022-07-12 11:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:32 --> Total execution time: 0.1365
DEBUG - 2022-07-12 11:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:44:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:44:48 --> Total execution time: 0.1143
DEBUG - 2022-07-12 11:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:46:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:46:00 --> Total execution time: 0.0468
DEBUG - 2022-07-12 11:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:46:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 11:46:00 --> 404 Page Not Found: Assets/img
DEBUG - 2022-07-12 11:46:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:46:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:46:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:46:02 --> Total execution time: 0.1040
DEBUG - 2022-07-12 11:46:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:46:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:46:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:46:09 --> Total execution time: 0.1159
DEBUG - 2022-07-12 11:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:48:47 --> Total execution time: 0.1059
DEBUG - 2022-07-12 11:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:48:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:48:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:48:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:48:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:48:49 --> Total execution time: 0.0931
DEBUG - 2022-07-12 11:48:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:48:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 11:48:50 --> 404 Page Not Found: Assets/img
DEBUG - 2022-07-12 11:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:48:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:48:52 --> Total execution time: 0.1127
DEBUG - 2022-07-12 11:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:49:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:49:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:49:04 --> Total execution time: 0.1234
DEBUG - 2022-07-12 11:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:51:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:51:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:51:16 --> Total execution time: 0.0950
DEBUG - 2022-07-12 11:51:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 11:51:16 --> 404 Page Not Found: Assets/img
DEBUG - 2022-07-12 11:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:51:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:51:21 --> Total execution time: 0.1200
DEBUG - 2022-07-12 11:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:51:41 --> Total execution time: 0.1250
DEBUG - 2022-07-12 11:51:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:51:42 --> Total execution time: 0.1482
DEBUG - 2022-07-12 11:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:51:57 --> Total execution time: 0.1284
DEBUG - 2022-07-12 11:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:51:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:51:58 --> Total execution time: 0.0895
DEBUG - 2022-07-12 11:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:00 --> Total execution time: 0.1145
DEBUG - 2022-07-12 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:02 --> Total execution time: 0.1899
DEBUG - 2022-07-12 11:52:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:05 --> Total execution time: 0.1221
DEBUG - 2022-07-12 11:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:08 --> Total execution time: 0.2211
DEBUG - 2022-07-12 11:52:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:11 --> Total execution time: 0.1101
DEBUG - 2022-07-12 11:52:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:43 --> Total execution time: 0.1033
DEBUG - 2022-07-12 11:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:44 --> Total execution time: 0.1088
DEBUG - 2022-07-12 11:52:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:45 --> Total execution time: 0.1344
DEBUG - 2022-07-12 11:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:45 --> Total execution time: 0.1212
DEBUG - 2022-07-12 11:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:45 --> Total execution time: 0.1368
DEBUG - 2022-07-12 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:52:53 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:52:53 --> Total execution time: 0.1082
DEBUG - 2022-07-12 11:56:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:05 --> Total execution time: 0.0969
DEBUG - 2022-07-12 11:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-12 11:56:05 --> 404 Page Not Found: Integrity/assets
DEBUG - 2022-07-12 11:56:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:06 --> Total execution time: 0.1081
DEBUG - 2022-07-12 11:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:07 --> Total execution time: 0.1743
DEBUG - 2022-07-12 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:08 --> Total execution time: 0.1640
DEBUG - 2022-07-12 11:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:08 --> Total execution time: 0.0990
DEBUG - 2022-07-12 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:09 --> Total execution time: 0.1114
DEBUG - 2022-07-12 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:09 --> Total execution time: 0.1069
DEBUG - 2022-07-12 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:09 --> Total execution time: 0.0930
DEBUG - 2022-07-12 11:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:09 --> Total execution time: 0.1028
DEBUG - 2022-07-12 11:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:19 --> Total execution time: 0.1015
DEBUG - 2022-07-12 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:20 --> Total execution time: 0.1254
DEBUG - 2022-07-12 11:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:20 --> Total execution time: 0.1205
DEBUG - 2022-07-12 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:20 --> Total execution time: 0.1382
DEBUG - 2022-07-12 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:20 --> Total execution time: 0.1163
DEBUG - 2022-07-12 11:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:20 --> Total execution time: 0.1014
DEBUG - 2022-07-12 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:26 --> Total execution time: 0.0935
DEBUG - 2022-07-12 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:26 --> Total execution time: 0.0910
DEBUG - 2022-07-12 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:26 --> Total execution time: 0.1135
DEBUG - 2022-07-12 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:27 --> Total execution time: 0.1199
DEBUG - 2022-07-12 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:27 --> Total execution time: 0.1278
DEBUG - 2022-07-12 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:27 --> Total execution time: 0.1109
DEBUG - 2022-07-12 11:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:27 --> Total execution time: 0.1054
DEBUG - 2022-07-12 11:56:36 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:36 --> Total execution time: 0.1024
DEBUG - 2022-07-12 11:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:40 --> Total execution time: 0.1147
DEBUG - 2022-07-12 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:55 --> Total execution time: 0.0906
DEBUG - 2022-07-12 11:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:56 --> Total execution time: 0.0958
DEBUG - 2022-07-12 11:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:56 --> Total execution time: 0.1148
DEBUG - 2022-07-12 11:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:56 --> Total execution time: 0.0986
DEBUG - 2022-07-12 11:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:56:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:56:56 --> Total execution time: 0.0906
DEBUG - 2022-07-12 11:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:57:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:57:19 --> Total execution time: 0.1021
DEBUG - 2022-07-12 11:58:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:58:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:58:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:58:39 --> Total execution time: 0.0959
DEBUG - 2022-07-12 11:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:58:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:58:40 --> Total execution time: 0.1058
DEBUG - 2022-07-12 11:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:58:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:58:54 --> Total execution time: 0.1199
DEBUG - 2022-07-12 11:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:59:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:59:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:59:01 --> Total execution time: 0.2120
DEBUG - 2022-07-12 11:59:01 --> Total execution time: 0.2126
DEBUG - 2022-07-12 11:59:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:59:04 --> Total execution time: 0.1307
DEBUG - 2022-07-12 11:59:39 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:59:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 11:59:39 --> Total execution time: 0.1285
DEBUG - 2022-07-12 11:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:59:42 --> Total execution time: 0.1608
DEBUG - 2022-07-12 11:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 11:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 11:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 11:59:44 --> Total execution time: 0.1329
DEBUG - 2022-07-12 12:00:21 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 12:00:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 12:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 12:00:21 --> Total execution time: 0.1183
DEBUG - 2022-07-12 12:00:24 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 12:00:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 12:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 12:00:24 --> Total execution time: 0.1988
DEBUG - 2022-07-12 12:00:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 12:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 12:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 12:00:28 --> Total execution time: 0.1156
DEBUG - 2022-07-12 12:00:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 12:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 12:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 12:00:44 --> Total execution time: 0.1217
DEBUG - 2022-07-12 12:02:00 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 12:02:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 12:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 12:02:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 12:02:00 --> Total execution time: 0.1945
DEBUG - 2022-07-12 12:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 12:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 12:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 12:02:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 12:02:04 --> Total execution time: 0.1777
DEBUG - 2022-07-12 12:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 12:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 12:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 12:02:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 12:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-07-12 12:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-12 12:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-12 12:02:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-12 12:02:15 --> Total execution time: 0.0933
