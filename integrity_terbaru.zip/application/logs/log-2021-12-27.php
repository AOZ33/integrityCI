<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-27 10:23:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:23:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:23:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-27 10:23:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2021-12-27 10:23:52 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2021-12-27 10:23:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:23:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-27 10:23:57 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-27 10:24:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:24:38 --> No URI present. Default controller set.
DEBUG - 2021-12-27 10:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:24:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:24:38 --> Total execution time: 0.0305
DEBUG - 2021-12-27 10:24:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:24:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-27 10:24:38 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-27 10:24:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:24:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:24:51 --> Total execution time: 0.0075
DEBUG - 2021-12-27 10:24:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:24:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:24:54 --> Total execution time: 0.0064
DEBUG - 2021-12-27 10:24:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:24:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:24:55 --> Total execution time: 0.0141
DEBUG - 2021-12-27 10:34:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:34:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:34:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:34:37 --> Total execution time: 0.0455
DEBUG - 2021-12-27 10:37:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:37:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:37:22 --> Total execution time: 0.0458
DEBUG - 2021-12-27 10:37:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:37:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:37:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:37:33 --> Total execution time: 0.0131
DEBUG - 2021-12-27 10:37:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:37:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:37:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:37:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:37:44 --> Total execution time: 0.0157
DEBUG - 2021-12-27 10:37:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:37:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:37:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:37:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:37:57 --> Total execution time: 0.0115
DEBUG - 2021-12-27 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:38:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:38:12 --> Total execution time: 0.0148
DEBUG - 2021-12-27 10:39:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:39:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:39:00 --> Total execution time: 0.0419
DEBUG - 2021-12-27 10:39:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:39:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:39:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:39:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:39:10 --> Total execution time: 0.0125
DEBUG - 2021-12-27 10:39:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:39:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:39:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:39:56 --> Total execution time: 0.0410
DEBUG - 2021-12-27 10:40:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:40:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:40:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:40:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:40:05 --> Total execution time: 0.0123
DEBUG - 2021-12-27 10:40:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:40:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:40:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:40:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:40:25 --> Total execution time: 0.0157
DEBUG - 2021-12-27 10:40:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:40:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:40:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:40:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:40:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:40:37 --> Total execution time: 0.0129
DEBUG - 2021-12-27 10:40:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:40:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:40:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:40:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:40:52 --> Total execution time: 0.0142
DEBUG - 2021-12-27 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:16 --> Total execution time: 0.0128
DEBUG - 2021-12-27 10:41:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:28 --> Total execution time: 0.0127
DEBUG - 2021-12-27 10:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:38 --> Total execution time: 0.0119
DEBUG - 2021-12-27 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:48 --> Total execution time: 0.0128
DEBUG - 2021-12-27 10:41:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:41:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:41:58 --> Total execution time: 0.0123
DEBUG - 2021-12-27 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:42:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:42:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:42:08 --> Total execution time: 0.0133
DEBUG - 2021-12-27 10:42:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:42:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:42:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:42:32 --> Total execution time: 0.0124
DEBUG - 2021-12-27 10:42:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:42:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:42:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:42:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:42:52 --> Total execution time: 0.0153
DEBUG - 2021-12-27 10:43:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:43:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:43:07 --> Total execution time: 0.0159
DEBUG - 2021-12-27 10:43:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:43:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:43:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:43:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:43:29 --> Total execution time: 0.0158
DEBUG - 2021-12-27 10:43:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:43:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:43:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:43:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:43:49 --> Total execution time: 0.0129
DEBUG - 2021-12-27 10:46:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:46:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:46:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:46:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:46:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:46:26 --> Total execution time: 0.0161
DEBUG - 2021-12-27 10:47:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:47:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:47:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:47:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:47:47 --> Total execution time: 0.0153
DEBUG - 2021-12-27 10:51:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:51:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:51:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:51:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:51:22 --> Total execution time: 0.0172
DEBUG - 2021-12-27 10:51:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:51:30 --> Total execution time: 0.0065
DEBUG - 2021-12-27 10:51:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:51:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:51:52 --> Total execution time: 0.0063
DEBUG - 2021-12-27 10:51:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:51:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:51:59 --> Total execution time: 0.0120
DEBUG - 2021-12-27 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:52:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:52:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:52:26 --> Total execution time: 0.0121
DEBUG - 2021-12-27 10:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:52:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:52:40 --> Total execution time: 0.0161
DEBUG - 2021-12-27 10:52:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:52:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:52:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:52:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:52:53 --> Total execution time: 0.0159
DEBUG - 2021-12-27 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:53:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:53:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:53:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:53:13 --> Total execution time: 0.0125
DEBUG - 2021-12-27 10:53:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:53:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:53:41 --> Total execution time: 0.0155
DEBUG - 2021-12-27 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:53:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:53:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:53:52 --> Total execution time: 0.0130
DEBUG - 2021-12-27 10:54:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:54:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:54:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:54:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:54:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:54:02 --> Total execution time: 0.0127
DEBUG - 2021-12-27 10:54:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:54:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:54:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:54:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:54:15 --> Total execution time: 0.0132
DEBUG - 2021-12-27 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:56:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:56:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:56:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:56:23 --> Total execution time: 0.0151
DEBUG - 2021-12-27 10:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:56:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:56:39 --> Total execution time: 0.0132
DEBUG - 2021-12-27 10:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:56:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:56:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:56:49 --> Total execution time: 0.0155
DEBUG - 2021-12-27 10:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:57:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:57:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:57:00 --> Total execution time: 0.0129
DEBUG - 2021-12-27 10:57:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:57:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:57:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 10:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 10:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 10:57:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 10:57:17 --> Total execution time: 0.0131
DEBUG - 2021-12-27 11:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:02:28 --> Total execution time: 0.0333
DEBUG - 2021-12-27 11:03:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:03:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:03:28 --> Total execution time: 0.0421
DEBUG - 2021-12-27 11:09:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:09:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:09:18 --> Total execution time: 0.0353
DEBUG - 2021-12-27 11:10:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:10:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:10:58 --> Total execution time: 0.0068
DEBUG - 2021-12-27 11:13:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:13:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:13:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:13:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:13:26 --> Total execution time: 0.0074
DEBUG - 2021-12-27 11:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:20:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:20:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:20:19 --> Total execution time: 0.0083
DEBUG - 2021-12-27 11:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:20:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:20:22 --> Total execution time: 0.0153
DEBUG - 2021-12-27 11:26:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:26:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:26:42 --> Total execution time: 0.0438
DEBUG - 2021-12-27 11:27:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:27:47 --> Total execution time: 0.0420
DEBUG - 2021-12-27 11:29:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:29:58 --> Total execution time: 0.0421
DEBUG - 2021-12-27 11:30:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:30:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:30:55 --> Total execution time: 0.0415
DEBUG - 2021-12-27 11:31:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:31:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:31:34 --> Total execution time: 0.0323
DEBUG - 2021-12-27 11:31:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:31:58 --> Total execution time: 0.0073
DEBUG - 2021-12-27 11:32:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:32:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:32:21 --> Total execution time: 0.0053
DEBUG - 2021-12-27 11:32:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:32:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:32:23 --> Total execution time: 0.0154
DEBUG - 2021-12-27 11:32:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:32:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:32:25 --> Total execution time: 0.0050
DEBUG - 2021-12-27 11:32:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 11:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 11:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 11:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 11:32:42 --> Total execution time: 0.0140
DEBUG - 2021-12-27 12:38:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 12:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 12:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 12:38:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 12:38:47 --> Total execution time: 0.0346
DEBUG - 2021-12-27 12:39:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 12:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 12:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 12:39:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 12:39:15 --> Total execution time: 0.0158
DEBUG - 2021-12-27 13:32:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:32:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:32:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:32:19 --> Total execution time: 0.0345
DEBUG - 2021-12-27 13:34:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:34:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:34:13 --> Total execution time: 0.0444
DEBUG - 2021-12-27 13:34:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:34:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:34:22 --> Total execution time: 0.0056
DEBUG - 2021-12-27 13:38:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:38:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:38:25 --> Total execution time: 0.0077
DEBUG - 2021-12-27 13:38:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:38:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:38:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:38:28 --> Total execution time: 0.0154
DEBUG - 2021-12-27 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:39:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:39:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:39:04 --> Total execution time: 0.0168
DEBUG - 2021-12-27 13:39:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:39:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:39:21 --> Total execution time: 0.0056
DEBUG - 2021-12-27 13:42:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:42:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:42:15 --> Total execution time: 0.0334
DEBUG - 2021-12-27 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:47:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:47:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:47:21 --> Total execution time: 0.0071
DEBUG - 2021-12-27 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:50:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:50:44 --> Total execution time: 0.0068
DEBUG - 2021-12-27 13:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:55:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 13:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 13:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 13:55:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 13:55:02 --> Total execution time: 0.0077
DEBUG - 2021-12-27 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:01:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:01:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:01:41 --> Total execution time: 0.0077
DEBUG - 2021-12-27 14:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:01:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:01:50 --> Total execution time: 0.0149
DEBUG - 2021-12-27 14:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:01:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:01:53 --> Total execution time: 0.0050
DEBUG - 2021-12-27 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:06:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:06:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:06:04 --> Total execution time: 0.0075
DEBUG - 2021-12-27 14:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:09:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:09:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:09:14 --> Total execution time: 0.0070
DEBUG - 2021-12-27 14:11:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:11:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:11:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:11:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:11:45 --> Total execution time: 0.0075
DEBUG - 2021-12-27 14:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:12:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:12:03 --> Total execution time: 0.0166
DEBUG - 2021-12-27 14:14:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:14:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:14:00 --> Total execution time: 0.0345
DEBUG - 2021-12-27 14:17:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:17:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:17:17 --> Total execution time: 0.0079
DEBUG - 2021-12-27 14:19:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:19:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:19:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:19:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:19:23 --> Total execution time: 0.0064
DEBUG - 2021-12-27 14:19:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:19:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:19:31 --> Total execution time: 0.0168
DEBUG - 2021-12-27 14:19:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:19:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:19:38 --> Total execution time: 0.0054
DEBUG - 2021-12-27 14:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:23:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:23:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:23:53 --> Total execution time: 0.0078
DEBUG - 2021-12-27 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:28:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:28:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:28:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:28:30 --> Total execution time: 0.0073
DEBUG - 2021-12-27 14:32:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:32:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:32:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:32:51 --> Total execution time: 0.0068
DEBUG - 2021-12-27 14:32:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:32:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:32:53 --> Total execution time: 0.0174
DEBUG - 2021-12-27 14:34:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:34:58 --> Total execution time: 0.0333
DEBUG - 2021-12-27 14:35:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:35:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:35:51 --> Total execution time: 0.0448
DEBUG - 2021-12-27 14:36:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:36:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:36:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:36:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:36:18 --> Total execution time: 0.0153
DEBUG - 2021-12-27 14:37:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:37:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:37:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:37:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:37:19 --> Total execution time: 0.0179
DEBUG - 2021-12-27 14:38:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:38:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:38:50 --> Total execution time: 0.0339
DEBUG - 2021-12-27 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:44:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:44:16 --> Total execution time: 0.0080
DEBUG - 2021-12-27 14:47:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:47:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:47:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:47:35 --> Total execution time: 0.0074
DEBUG - 2021-12-27 14:50:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:50:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:50:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:50:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:50:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:50:10 --> Total execution time: 0.0073
DEBUG - 2021-12-27 14:50:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:50:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:50:19 --> Total execution time: 0.0181
DEBUG - 2021-12-27 14:50:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:50:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:50:22 --> Total execution time: 0.0053
DEBUG - 2021-12-27 14:56:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:56:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:56:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:56:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:56:29 --> Total execution time: 0.0076
DEBUG - 2021-12-27 14:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 14:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 14:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 14:56:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 14:56:32 --> Total execution time: 0.0181
DEBUG - 2021-12-27 16:23:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 16:23:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 16:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 16:23:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 16:23:42 --> Total execution time: 0.0477
DEBUG - 2021-12-27 17:12:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:12:32 --> No URI present. Default controller set.
DEBUG - 2021-12-27 17:12:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:12:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:12:32 --> Total execution time: 0.0316
DEBUG - 2021-12-27 17:12:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:12:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-27 17:12:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-27 17:12:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:12:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-27 17:12:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-27 17:12:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:12:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:12:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:12:41 --> Total execution time: 0.0080
DEBUG - 2021-12-27 17:12:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:12:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:12:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:12:48 --> Total execution time: 0.0188
DEBUG - 2021-12-27 17:12:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:12:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:12:49 --> Total execution time: 0.0055
DEBUG - 2021-12-27 17:13:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:13:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:13:16 --> Total execution time: 0.0164
DEBUG - 2021-12-27 17:13:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:13:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:13:31 --> Total execution time: 0.0054
DEBUG - 2021-12-27 17:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:21:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:21:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:21:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:21:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:21:37 --> Total execution time: 0.0076
DEBUG - 2021-12-27 17:26:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:26:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:26:10 --> Total execution time: 0.0345
DEBUG - 2021-12-27 17:26:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:26:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:26:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:26:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:26:14 --> Total execution time: 0.0047
DEBUG - 2021-12-27 17:26:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:26:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:26:17 --> Total execution time: 0.0346
DEBUG - 2021-12-27 17:26:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:26:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:26:25 --> Total execution time: 0.0050
DEBUG - 2021-12-27 17:28:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:28:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:28:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:28:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:28:46 --> Total execution time: 0.0069
DEBUG - 2021-12-27 17:33:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:33:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:33:50 --> Total execution time: 0.0341
DEBUG - 2021-12-27 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:34:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:34:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:34:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:34:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:34:28 --> Total execution time: 0.0071
DEBUG - 2021-12-27 17:37:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:37:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:37:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:37:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:37:45 --> Total execution time: 0.0076
DEBUG - 2021-12-27 17:37:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-27 17:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-27 17:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-27 17:37:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-27 17:37:59 --> Total execution time: 0.0200
