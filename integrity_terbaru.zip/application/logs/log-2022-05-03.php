<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-03 14:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:54:16 --> No URI present. Default controller set.
DEBUG - 2022-05-03 14:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-03 14:54:16 --> Total execution time: 0.0483
DEBUG - 2022-05-03 14:54:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 14:54:18 --> No URI present. Default controller set.
DEBUG - 2022-05-03 14:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 14:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 14:54:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-03 14:54:18 --> Total execution time: 0.0013
DEBUG - 2022-05-03 21:21:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-03 21:21:17 --> No URI present. Default controller set.
DEBUG - 2022-05-03 21:21:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-03 21:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-03 21:21:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-03 21:21:17 --> Total execution time: 0.0369
