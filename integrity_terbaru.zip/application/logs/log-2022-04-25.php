<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-25 02:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:48:37 --> No URI present. Default controller set.
DEBUG - 2022-04-25 02:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 02:48:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 02:48:37 --> Total execution time: 0.0582
DEBUG - 2022-04-25 02:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:48 --> No URI present. Default controller set.
DEBUG - 2022-04-25 02:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 02:56:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 02:56:49 --> Total execution time: 0.0406
DEBUG - 2022-04-25 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:56:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-25 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:56:49 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-25 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:56:49 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-25 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:56:49 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-25 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:56:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-25 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:56:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-25 02:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 02:56:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 02:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 02:56:50 --> Total execution time: 0.0090
DEBUG - 2022-04-25 02:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 02:56:52 --> Total execution time: 0.0046
DEBUG - 2022-04-25 02:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 02:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:56:52 --> 404 Page Not Found: Scripts/fullcalendar
ERROR - 2022-04-25 02:56:52 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 02:56:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 02:56:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 02:56:52 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:56:16 --> Total execution time: 0.0495
DEBUG - 2022-04-25 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:16 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:16 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:16 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 03:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:56:17 --> Total execution time: 0.0032
DEBUG - 2022-04-25 03:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:17 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:17 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:17 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 03:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:56:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:56:18 --> Total execution time: 0.0021
DEBUG - 2022-04-25 03:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:18 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:18 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:18 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 03:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:56:26 --> Total execution time: 0.0030
DEBUG - 2022-04-25 03:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:26 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:26 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:26 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 03:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:56:27 --> Total execution time: 0.0026
DEBUG - 2022-04-25 03:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:27 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:27 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 03:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:56:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:56:27 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 03:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:57:17 --> Total execution time: 0.0073
DEBUG - 2022-04-25 03:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 03:58:47 --> Unable to load the requested class: Index
DEBUG - 2022-04-25 03:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:59:05 --> Total execution time: 0.0026
DEBUG - 2022-04-25 03:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:59:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:59:05 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 03:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:59:25 --> Total execution time: 0.0022
DEBUG - 2022-04-25 03:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:59:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:59:25 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 03:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 03:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 03:59:26 --> Total execution time: 0.0021
DEBUG - 2022-04-25 03:59:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 03:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 03:59:26 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 04:05:14 --> Severity: error --> Exception: Call to undefined method Calendar_Model::getcalendar() /home/nsnmt.com/integrity/application/controllers/Calendar.php 11
DEBUG - 2022-04-25 04:09:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:50 --> Total execution time: 0.0054
DEBUG - 2022-04-25 04:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:51 --> Total execution time: 0.0014
DEBUG - 2022-04-25 04:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:52 --> Total execution time: 0.0013
DEBUG - 2022-04-25 04:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:54 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:54 --> Total execution time: 0.0018
DEBUG - 2022-04-25 04:09:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:54 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:55 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:09:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:55 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:58 --> Total execution time: 0.0022
DEBUG - 2022-04-25 04:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:59 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:09:59 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:10:00 --> Total execution time: 0.0020
DEBUG - 2022-04-25 04:10:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:10:00 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 04:17:57 --> Severity: error --> Exception: Call to undefined method Calendar_Model::getcalendar() /home/nsnmt.com/integrity/application/controllers/Calendar.php 11
DEBUG - 2022-04-25 04:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:18:27 --> Total execution time: 0.0093
DEBUG - 2022-04-25 04:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:27 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 04:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:27 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 04:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:27 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:18:33 --> Total execution time: 0.0032
DEBUG - 2022-04-25 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:33 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:33 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:33 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:18:33 --> Total execution time: 0.0023
DEBUG - 2022-04-25 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:33 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:33 --> 404 Page Not Found: Scripts/fullcalendar
DEBUG - 2022-04-25 04:18:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:18:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:18:34 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:20:09 --> Total execution time: 0.0456
DEBUG - 2022-04-25 04:20:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:20:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:20:09 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:23:15 --> Total execution time: 0.0471
DEBUG - 2022-04-25 04:23:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:23:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:23:15 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:23:32 --> Total execution time: 0.0032
DEBUG - 2022-04-25 04:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:23:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:23:33 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:24:41 --> Total execution time: 0.0542
DEBUG - 2022-04-25 04:24:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 04:24:43 --> Severity: Warning --> A non-numeric value encountered /home/nsnmt.com/integrity/system/libraries/Calendar.php 437
DEBUG - 2022-04-25 04:24:43 --> Total execution time: 0.0026
DEBUG - 2022-04-25 04:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:24:45 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:23 --> Total execution time: 0.0031
DEBUG - 2022-04-25 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:23 --> Total execution time: 0.0018
DEBUG - 2022-04-25 04:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:23 --> Total execution time: 0.0021
DEBUG - 2022-04-25 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:26 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:29 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:26:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:29 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:30 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:31 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:26:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:26:31 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:11 --> Total execution time: 0.0439
DEBUG - 2022-04-25 04:28:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:11 --> Total execution time: 0.0020
DEBUG - 2022-04-25 04:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:19 --> Total execution time: 0.0019
DEBUG - 2022-04-25 04:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:19 --> Total execution time: 0.0018
DEBUG - 2022-04-25 04:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:20 --> Total execution time: 0.0022
DEBUG - 2022-04-25 04:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:20 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:20 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:21 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:22 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:22 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:23 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:23 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:23 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:24 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:24 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:25 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:25 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:26 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:26 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:26 --> Total execution time: 0.0021
DEBUG - 2022-04-25 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:26 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:26 --> Total execution time: 0.0022
DEBUG - 2022-04-25 04:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:27 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:27 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:27 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:28 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:28 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:28 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:28 --> Total execution time: 0.0019
DEBUG - 2022-04-25 04:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:29 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:29 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:29 --> Total execution time: 0.0018
DEBUG - 2022-04-25 04:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:30 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:30 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:30 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:31 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:31 --> Total execution time: 0.0018
DEBUG - 2022-04-25 04:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:31 --> Total execution time: 0.0023
DEBUG - 2022-04-25 04:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:32 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:32 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:33 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:33 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:34 --> Total execution time: 0.0021
DEBUG - 2022-04-25 04:28:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:34 --> Total execution time: 0.0019
DEBUG - 2022-04-25 04:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:35 --> Total execution time: 0.0023
DEBUG - 2022-04-25 04:28:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:35 --> Total execution time: 0.0018
DEBUG - 2022-04-25 04:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:36 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:36 --> Total execution time: 0.0018
DEBUG - 2022-04-25 04:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:37 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:37 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:45 --> Total execution time: 0.0015
DEBUG - 2022-04-25 04:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:45 --> Total execution time: 0.0020
DEBUG - 2022-04-25 04:28:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:46 --> Total execution time: 0.0017
DEBUG - 2022-04-25 04:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 04:28:48 --> Severity: Warning --> A non-numeric value encountered /home/nsnmt.com/integrity/system/libraries/Calendar.php 437
DEBUG - 2022-04-25 04:28:48 --> Total execution time: 0.0022
DEBUG - 2022-04-25 04:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:28:54 --> Total execution time: 0.0021
DEBUG - 2022-04-25 04:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 04:34:36 --> Severity: error --> Exception: Call to undefined method Calendar_Model::get_calendar_data() /home/nsnmt.com/integrity/application/models/Calendar_model.php 64
DEBUG - 2022-04-25 04:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 04:35:12 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: SELECT `date_w`, `place_w`
FROM `appointment`
WHERE `date` LIKE '2019-03%' ESCAPE '!'
ERROR - 2022-04-25 04:35:12 --> Severity: error --> Exception: Call to a member function result() on bool /home/nsnmt.com/integrity/application/models/Calendar_model.php 72
DEBUG - 2022-04-25 04:35:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 04:35:59 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: SELECT `date_w`, `place_w`
FROM `appointment`
WHERE `date` LIKE '2019-03%' ESCAPE '!'
DEBUG - 2022-04-25 04:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 04:39:04 --> Query error: Unknown column 'date' in 'where clause' - Invalid query: SELECT `date_w`, `place_w`
FROM `appointment`
WHERE `date` LIKE '2019-03%' ESCAPE '!'
DEBUG - 2022-04-25 04:49:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:49:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:49:37 --> Total execution time: 0.0016
DEBUG - 2022-04-25 04:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:50:26 --> Total execution time: 0.0046
DEBUG - 2022-04-25 04:50:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:50:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:50:26 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:50:49 --> Total execution time: 0.0036
DEBUG - 2022-04-25 04:50:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:50:49 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:51:20 --> Total execution time: 0.0038
DEBUG - 2022-04-25 04:51:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:51:47 --> Total execution time: 0.0031
DEBUG - 2022-04-25 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:52:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:52:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 04:52:26 --> Total execution time: 0.0022
DEBUG - 2022-04-25 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:52:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-25 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:52:26 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-25 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:52:26 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-25 04:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:52:26 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-25 04:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:52:26 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-25 04:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:52:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 04:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:52:28 --> Total execution time: 0.0048
DEBUG - 2022-04-25 04:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:52:30 --> Total execution time: 0.0027
DEBUG - 2022-04-25 04:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:55:07 --> Total execution time: 0.0043
DEBUG - 2022-04-25 04:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:55:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:55:07 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:55:09 --> Total execution time: 0.0029
DEBUG - 2022-04-25 04:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 04:55:09 --> 404 Page Not Found: Assets/img
DEBUG - 2022-04-25 04:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:55:34 --> Total execution time: 0.0032
DEBUG - 2022-04-25 04:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:56:22 --> Total execution time: 0.0025
DEBUG - 2022-04-25 04:56:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:56:42 --> Total execution time: 0.0020
DEBUG - 2022-04-25 04:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:57:23 --> Total execution time: 0.0039
DEBUG - 2022-04-25 04:57:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:57:24 --> Total execution time: 0.0024
DEBUG - 2022-04-25 04:58:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:58:22 --> Total execution time: 0.0047
DEBUG - 2022-04-25 04:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:58:24 --> Total execution time: 0.0019
DEBUG - 2022-04-25 04:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:58:24 --> Total execution time: 0.0024
DEBUG - 2022-04-25 04:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:58:25 --> Total execution time: 0.0028
DEBUG - 2022-04-25 04:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:58:25 --> Total execution time: 0.0024
DEBUG - 2022-04-25 04:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:58:26 --> Total execution time: 0.0020
DEBUG - 2022-04-25 04:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:58:26 --> Total execution time: 0.0025
DEBUG - 2022-04-25 04:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:58:26 --> Total execution time: 0.0019
DEBUG - 2022-04-25 04:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:59:05 --> Total execution time: 0.0027
DEBUG - 2022-04-25 04:59:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 04:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 04:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 04:59:28 --> Total execution time: 0.0028
DEBUG - 2022-04-25 05:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:00:16 --> Total execution time: 0.0026
DEBUG - 2022-04-25 05:00:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:00:36 --> Total execution time: 0.0022
DEBUG - 2022-04-25 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:02:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:02:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 05:02:05 --> Total execution time: 0.0022
DEBUG - 2022-04-25 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:02:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-25 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:02:05 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-25 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:02:05 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-25 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:02:05 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-25 05:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 05:02:05 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-25 05:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:02:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 05:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:02:06 --> Total execution time: 0.0036
DEBUG - 2022-04-25 05:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:02:11 --> Total execution time: 0.0082
DEBUG - 2022-04-25 05:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:02:13 --> Total execution time: 0.0040
DEBUG - 2022-04-25 05:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:04:24 --> Total execution time: 0.0064
DEBUG - 2022-04-25 05:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:05:09 --> Total execution time: 0.0033
DEBUG - 2022-04-25 05:06:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:06:22 --> Total execution time: 0.0416
DEBUG - 2022-04-25 05:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:08:14 --> Total execution time: 0.0035
DEBUG - 2022-04-25 05:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:08:58 --> Total execution time: 0.0038
DEBUG - 2022-04-25 05:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:00 --> Total execution time: 0.0021
DEBUG - 2022-04-25 05:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:01 --> Total execution time: 0.0022
DEBUG - 2022-04-25 05:09:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:01 --> Total execution time: 0.0030
DEBUG - 2022-04-25 05:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:02 --> Total execution time: 0.0030
DEBUG - 2022-04-25 05:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:02 --> Total execution time: 0.0021
DEBUG - 2022-04-25 05:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:02 --> Total execution time: 0.0024
DEBUG - 2022-04-25 05:09:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:02 --> Total execution time: 0.0021
DEBUG - 2022-04-25 05:09:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:04 --> Total execution time: 0.0026
DEBUG - 2022-04-25 05:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:06 --> Total execution time: 0.0061
DEBUG - 2022-04-25 05:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:08 --> Total execution time: 0.0022
DEBUG - 2022-04-25 05:09:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:09:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:09:41 --> Total execution time: 0.0023
DEBUG - 2022-04-25 05:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:10:16 --> Total execution time: 0.0023
DEBUG - 2022-04-25 05:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:10:54 --> Total execution time: 0.0022
DEBUG - 2022-04-25 05:11:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:11:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:11:02 --> Total execution time: 0.0023
DEBUG - 2022-04-25 05:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:12:02 --> Total execution time: 0.0029
DEBUG - 2022-04-25 05:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:13:35 --> Total execution time: 0.0385
DEBUG - 2022-04-25 05:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:15:08 --> Total execution time: 0.0027
DEBUG - 2022-04-25 05:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:15:10 --> Total execution time: 0.0084
DEBUG - 2022-04-25 05:15:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:15:12 --> Total execution time: 0.0016
DEBUG - 2022-04-25 05:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:16:09 --> Total execution time: 0.0024
DEBUG - 2022-04-25 05:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:16:10 --> Total execution time: 0.0030
DEBUG - 2022-04-25 05:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:16:13 --> Total execution time: 0.0017
DEBUG - 2022-04-25 05:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:16:59 --> Total execution time: 0.0016
DEBUG - 2022-04-25 05:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:17:02 --> Total execution time: 0.0032
DEBUG - 2022-04-25 05:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:17:05 --> Total execution time: 0.0021
DEBUG - 2022-04-25 05:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:17:30 --> Total execution time: 0.0019
DEBUG - 2022-04-25 05:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:18:02 --> Total execution time: 0.0037
DEBUG - 2022-04-25 05:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:19:10 --> Total execution time: 0.0367
DEBUG - 2022-04-25 05:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:19:35 --> Total execution time: 0.0015
DEBUG - 2022-04-25 05:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:20:06 --> Total execution time: 0.0019
DEBUG - 2022-04-25 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:20:22 --> Total execution time: 0.0016
DEBUG - 2022-04-25 05:21:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:21:04 --> Total execution time: 0.0080
DEBUG - 2022-04-25 05:21:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:21:39 --> Total execution time: 0.0030
DEBUG - 2022-04-25 05:21:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:21:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:21:47 --> Total execution time: 0.0029
DEBUG - 2022-04-25 05:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:21:49 --> Total execution time: 0.0077
DEBUG - 2022-04-25 05:21:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:21:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:21:51 --> Total execution time: 0.0030
DEBUG - 2022-04-25 05:24:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:24:36 --> Total execution time: 0.0411
DEBUG - 2022-04-25 05:35:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:35:38 --> Total execution time: 0.0575
DEBUG - 2022-04-25 05:36:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:36:54 --> Total execution time: 0.0017
DEBUG - 2022-04-25 05:37:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:37:40 --> Total execution time: 0.0084
DEBUG - 2022-04-25 05:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:37:42 --> Total execution time: 0.0015
DEBUG - 2022-04-25 05:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:39:02 --> Total execution time: 0.0407
DEBUG - 2022-04-25 05:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 05:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 05:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 05:40:07 --> Total execution time: 0.0034
DEBUG - 2022-04-25 07:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:11:59 --> Total execution time: 0.0640
DEBUG - 2022-04-25 07:12:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:12:30 --> Total execution time: 0.0035
DEBUG - 2022-04-25 07:23:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:23:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:23:23 --> Total execution time: 0.0396
DEBUG - 2022-04-25 07:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:23:29 --> Total execution time: 0.0030
DEBUG - 2022-04-25 07:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:23:29 --> Total execution time: 0.0016
DEBUG - 2022-04-25 07:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:23:33 --> Total execution time: 0.0027
DEBUG - 2022-04-25 07:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:23:34 --> Total execution time: 0.0014
DEBUG - 2022-04-25 07:23:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:23:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:23:38 --> Total execution time: 0.0025
DEBUG - 2022-04-25 07:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:23:51 --> Total execution time: 0.0027
DEBUG - 2022-04-25 07:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:27:34 --> Severity: error --> Exception: Call to undefined function dd() /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:28:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:28:23 --> Total execution time: 0.0082
DEBUG - 2022-04-25 07:28:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:28:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:28:39 --> Total execution time: 0.0028
DEBUG - 2022-04-25 07:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:28:41 --> Severity: error --> Exception: Function name must be a string /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:29:37 --> Severity: error --> Exception: Function name must be a string /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:29:38 --> Total execution time: 0.0024
DEBUG - 2022-04-25 07:29:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:29:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:29:40 --> Severity: error --> Exception: Function name must be a string /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:30:32 --> Severity: error --> Exception: Function name must be a string /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:30:40 --> Severity: error --> Exception: Function name must be a string /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:30:40 --> Severity: error --> Exception: Function name must be a string /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:30:40 --> Severity: error --> Exception: Function name must be a string /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:30:41 --> Total execution time: 0.0029
DEBUG - 2022-04-25 07:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:30:42 --> Severity: error --> Exception: Function name must be a string /home/nsnmt.com/integrity/application/views/calendar/index.php 31
DEBUG - 2022-04-25 07:31:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:31:58 --> Total execution time: 0.0368
DEBUG - 2022-04-25 07:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:33:51 --> Total execution time: 0.0028
DEBUG - 2022-04-25 07:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:35:45 --> Total execution time: 0.0399
DEBUG - 2022-04-25 07:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:35:47 --> Total execution time: 0.0017
DEBUG - 2022-04-25 07:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:35:48 --> Total execution time: 0.0017
DEBUG - 2022-04-25 07:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:35:50 --> Total execution time: 0.0013
DEBUG - 2022-04-25 07:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:35:51 --> Total execution time: 0.0016
DEBUG - 2022-04-25 07:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:35:55 --> Total execution time: 0.0018
DEBUG - 2022-04-25 07:36:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:36:36 --> Total execution time: 0.0478
DEBUG - 2022-04-25 07:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:37:07 --> Total execution time: 0.0013
DEBUG - 2022-04-25 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:37:49 --> Total execution time: 0.0035
DEBUG - 2022-04-25 07:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:38:01 --> Total execution time: 0.0078
DEBUG - 2022-04-25 07:40:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:40:35 --> Total execution time: 0.0417
DEBUG - 2022-04-25 07:40:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:40:37 --> Total execution time: 0.0020
DEBUG - 2022-04-25 07:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:40:59 --> Total execution time: 0.0027
DEBUG - 2022-04-25 07:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-25 07:42:01 --> Severity: error --> Exception: Call to undefined function var_dumb() /home/nsnmt.com/integrity/application/controllers/Calendar.php 17
DEBUG - 2022-04-25 07:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:42:03 --> Total execution time: 0.0013
DEBUG - 2022-04-25 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:42:43 --> Total execution time: 0.0017
DEBUG - 2022-04-25 07:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:42:47 --> Total execution time: 0.0474
DEBUG - 2022-04-25 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:43:46 --> Total execution time: 0.0024
DEBUG - 2022-04-25 07:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:44:57 --> Total execution time: 0.0029
DEBUG - 2022-04-25 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:47:40 --> Total execution time: 0.0379
DEBUG - 2022-04-25 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:47:41 --> Total execution time: 0.0531
DEBUG - 2022-04-25 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:55:57 --> Total execution time: 0.0912
DEBUG - 2022-04-25 07:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:55:57 --> Total execution time: 0.0473
DEBUG - 2022-04-25 07:55:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:55:58 --> Total execution time: 0.0436
DEBUG - 2022-04-25 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:59:50 --> Total execution time: 0.0387
DEBUG - 2022-04-25 07:59:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 07:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 07:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 07:59:50 --> Total execution time: 0.0465
DEBUG - 2022-04-25 08:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:00:00 --> Total execution time: 0.0512
DEBUG - 2022-04-25 08:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:00:01 --> Total execution time: 0.0620
DEBUG - 2022-04-25 08:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:00:03 --> Total execution time: 0.0778
DEBUG - 2022-04-25 08:00:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:00:59 --> Total execution time: 0.0068
DEBUG - 2022-04-25 08:01:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:01:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:01:03 --> Total execution time: 0.0147
DEBUG - 2022-04-25 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:01:15 --> Total execution time: 0.0018
DEBUG - 2022-04-25 08:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:01:15 --> Total execution time: 0.0522
DEBUG - 2022-04-25 08:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:01:18 --> Total execution time: 0.0462
DEBUG - 2022-04-25 08:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:01:31 --> Total execution time: 0.0039
DEBUG - 2022-04-25 08:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:22 --> Total execution time: 0.0368
DEBUG - 2022-04-25 08:32:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:22 --> Total execution time: 0.0450
DEBUG - 2022-04-25 08:32:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:25 --> Total execution time: 0.0509
DEBUG - 2022-04-25 08:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:26 --> Total execution time: 0.0469
DEBUG - 2022-04-25 08:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:27 --> Total execution time: 0.0444
DEBUG - 2022-04-25 08:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:28 --> Total execution time: 0.0528
DEBUG - 2022-04-25 08:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:30 --> Total execution time: 0.0464
DEBUG - 2022-04-25 08:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:31 --> Total execution time: 0.0586
DEBUG - 2022-04-25 08:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:32 --> Total execution time: 0.0412
DEBUG - 2022-04-25 08:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:33 --> Total execution time: 0.0445
DEBUG - 2022-04-25 08:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:33 --> Total execution time: 0.0467
DEBUG - 2022-04-25 08:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:34 --> Total execution time: 0.0434
DEBUG - 2022-04-25 08:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:34 --> Total execution time: 0.0496
DEBUG - 2022-04-25 08:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:34 --> Total execution time: 0.0476
DEBUG - 2022-04-25 08:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:35 --> Total execution time: 0.0407
DEBUG - 2022-04-25 08:32:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:35 --> Total execution time: 0.0554
DEBUG - 2022-04-25 08:32:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:36 --> Total execution time: 0.0457
DEBUG - 2022-04-25 08:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:37 --> Total execution time: 0.0491
DEBUG - 2022-04-25 08:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:50 --> Total execution time: 0.0460
DEBUG - 2022-04-25 08:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:51 --> Total execution time: 0.0456
DEBUG - 2022-04-25 08:32:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:32:52 --> Total execution time: 0.0472
DEBUG - 2022-04-25 08:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:33:02 --> Total execution time: 0.0544
DEBUG - 2022-04-25 08:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:33:03 --> Total execution time: 0.0499
DEBUG - 2022-04-25 08:33:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:33:05 --> Total execution time: 0.0463
DEBUG - 2022-04-25 08:33:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:33:06 --> Total execution time: 0.0412
DEBUG - 2022-04-25 08:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:33:14 --> Total execution time: 0.0663
DEBUG - 2022-04-25 08:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:40:26 --> Total execution time: 0.0942
DEBUG - 2022-04-25 08:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:40:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:40:32 --> Total execution time: 0.0157
DEBUG - 2022-04-25 08:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:40:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:40:49 --> Total execution time: 0.0170
DEBUG - 2022-04-25 08:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:40:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:40:56 --> Total execution time: 0.0176
DEBUG - 2022-04-25 08:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:42:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:42:17 --> Total execution time: 0.0554
DEBUG - 2022-04-25 08:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:42:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:42:25 --> Total execution time: 0.0166
DEBUG - 2022-04-25 08:42:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:42:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:42:31 --> Total execution time: 0.0133
DEBUG - 2022-04-25 08:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:42:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:42:51 --> Total execution time: 0.0179
DEBUG - 2022-04-25 08:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:42:58 --> Total execution time: 0.0017
DEBUG - 2022-04-25 08:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:42:58 --> Total execution time: 0.0575
DEBUG - 2022-04-25 08:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:00 --> Total execution time: 0.0491
DEBUG - 2022-04-25 08:43:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:00 --> Total execution time: 0.0439
DEBUG - 2022-04-25 08:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:01 --> Total execution time: 0.0464
DEBUG - 2022-04-25 08:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:43:12 --> Total execution time: 0.0041
DEBUG - 2022-04-25 08:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:35 --> Total execution time: 0.0015
DEBUG - 2022-04-25 08:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:35 --> Total execution time: 0.0418
DEBUG - 2022-04-25 08:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:37 --> Total execution time: 0.0466
DEBUG - 2022-04-25 08:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:38 --> Total execution time: 0.0453
DEBUG - 2022-04-25 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:39 --> Total execution time: 0.0423
DEBUG - 2022-04-25 08:43:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:39 --> Total execution time: 0.0387
DEBUG - 2022-04-25 08:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:40 --> Total execution time: 0.0575
DEBUG - 2022-04-25 08:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:43:57 --> Total execution time: 0.0473
DEBUG - 2022-04-25 08:44:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:44:03 --> Total execution time: 0.0063
DEBUG - 2022-04-25 08:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:19 --> Total execution time: 0.0029
DEBUG - 2022-04-25 08:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:19 --> Total execution time: 0.0434
DEBUG - 2022-04-25 08:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:22 --> Total execution time: 0.0607
DEBUG - 2022-04-25 08:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:22 --> Total execution time: 0.0454
DEBUG - 2022-04-25 08:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:44:26 --> Total execution time: 0.0060
DEBUG - 2022-04-25 08:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:44:32 --> Total execution time: 0.0168
DEBUG - 2022-04-25 08:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:44:47 --> Total execution time: 0.0257
DEBUG - 2022-04-25 08:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:59 --> Total execution time: 0.0014
DEBUG - 2022-04-25 08:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:44:59 --> Total execution time: 0.0471
DEBUG - 2022-04-25 08:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:45:00 --> Total execution time: 0.0468
DEBUG - 2022-04-25 08:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:45:01 --> Total execution time: 0.0422
DEBUG - 2022-04-25 08:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:45:04 --> Total execution time: 0.0446
DEBUG - 2022-04-25 08:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:45:05 --> Total execution time: 0.0421
DEBUG - 2022-04-25 08:45:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:45:06 --> Total execution time: 0.0425
DEBUG - 2022-04-25 08:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:45:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 08:45:14 --> Total execution time: 0.0038
DEBUG - 2022-04-25 08:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:48:02 --> Total execution time: 0.0437
DEBUG - 2022-04-25 08:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 08:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 08:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 08:48:02 --> Total execution time: 0.0552
DEBUG - 2022-04-25 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:40 --> No URI present. Default controller set.
DEBUG - 2022-04-25 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 09:58:40 --> Total execution time: 0.0523
DEBUG - 2022-04-25 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 09:58:40 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-25 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:40 --> UTF-8 Support Enabled
ERROR - 2022-04-25 09:58:40 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-25 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 09:58:40 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-25 09:58:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 09:58:40 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-25 09:58:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 09:58:40 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-25 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 09:58:40 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-25 09:58:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:40 --> No URI present. Default controller set.
DEBUG - 2022-04-25 09:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 09:58:40 --> Total execution time: 0.0016
DEBUG - 2022-04-25 09:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 09:58:41 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-25 09:58:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-25 09:58:41 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-25 09:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 09:58:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:48 --> Total execution time: 0.0086
DEBUG - 2022-04-25 09:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:51 --> Total execution time: 0.0034
DEBUG - 2022-04-25 09:58:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:52 --> Total execution time: 0.0512
DEBUG - 2022-04-25 09:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:57 --> Total execution time: 0.0548
DEBUG - 2022-04-25 09:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:58 --> Total execution time: 0.0583
DEBUG - 2022-04-25 09:58:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:58:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:58:59 --> Total execution time: 0.0469
DEBUG - 2022-04-25 09:59:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:51 --> Total execution time: 0.0501
DEBUG - 2022-04-25 09:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:52 --> Total execution time: 0.0491
DEBUG - 2022-04-25 09:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:53 --> Total execution time: 0.0476
DEBUG - 2022-04-25 09:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:55 --> Total execution time: 0.0476
DEBUG - 2022-04-25 09:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:55 --> Total execution time: 0.0424
DEBUG - 2022-04-25 09:59:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:55 --> Total execution time: 0.0457
DEBUG - 2022-04-25 09:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:57 --> Total execution time: 0.0419
DEBUG - 2022-04-25 09:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:57 --> Total execution time: 0.0579
DEBUG - 2022-04-25 09:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:57 --> Total execution time: 0.0441
DEBUG - 2022-04-25 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:58 --> Total execution time: 0.0435
DEBUG - 2022-04-25 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:58 --> Total execution time: 0.0429
DEBUG - 2022-04-25 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:58 --> Total execution time: 0.0426
DEBUG - 2022-04-25 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:58 --> Total execution time: 0.0462
DEBUG - 2022-04-25 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:58 --> Total execution time: 0.0437
DEBUG - 2022-04-25 09:59:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:59 --> Total execution time: 0.0482
DEBUG - 2022-04-25 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:59 --> Total execution time: 0.0406
DEBUG - 2022-04-25 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:59 --> Total execution time: 0.0469
DEBUG - 2022-04-25 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:59 --> Total execution time: 0.0587
DEBUG - 2022-04-25 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:59 --> Total execution time: 0.0529
DEBUG - 2022-04-25 09:59:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 09:59:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 09:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 09:59:59 --> Total execution time: 0.0472
DEBUG - 2022-04-25 10:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:00:00 --> Total execution time: 0.0394
DEBUG - 2022-04-25 10:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:00:00 --> Total execution time: 0.0528
DEBUG - 2022-04-25 10:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:00:00 --> Total execution time: 0.0446
DEBUG - 2022-04-25 10:00:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:00:00 --> Total execution time: 0.0463
DEBUG - 2022-04-25 10:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:00:01 --> Total execution time: 0.0591
DEBUG - 2022-04-25 10:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:00:01 --> Total execution time: 0.0595
DEBUG - 2022-04-25 10:00:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:00:04 --> Total execution time: 0.0451
DEBUG - 2022-04-25 10:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:00:53 --> Total execution time: 0.0462
DEBUG - 2022-04-25 10:01:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:01:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:01:26 --> Total execution time: 0.0618
DEBUG - 2022-04-25 10:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:02:09 --> Total execution time: 0.0514
DEBUG - 2022-04-25 10:02:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 10:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 10:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 10:02:10 --> Total execution time: 0.0409
DEBUG - 2022-04-25 23:50:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-25 23:50:36 --> No URI present. Default controller set.
DEBUG - 2022-04-25 23:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-25 23:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-25 23:50:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-25 23:50:36 --> Total execution time: 0.0434
