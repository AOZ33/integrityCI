<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-18 00:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 00:48:51 --> No URI present. Default controller set.
DEBUG - 2022-03-18 00:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 00:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 00:48:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 00:48:51 --> Total execution time: 0.0318
DEBUG - 2022-03-18 06:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 06:50:52 --> No URI present. Default controller set.
DEBUG - 2022-03-18 06:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 06:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 06:50:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 06:50:52 --> Total execution time: 0.0301
DEBUG - 2022-03-18 06:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 06:50:58 --> No URI present. Default controller set.
DEBUG - 2022-03-18 06:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 06:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 06:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 06:50:58 --> Total execution time: 0.0034
DEBUG - 2022-03-18 06:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 06:51:05 --> No URI present. Default controller set.
DEBUG - 2022-03-18 06:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 06:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 06:51:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 06:51:05 --> Total execution time: 0.0038
DEBUG - 2022-03-18 06:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 06:51:05 --> No URI present. Default controller set.
DEBUG - 2022-03-18 06:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 06:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 06:51:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 06:51:05 --> Total execution time: 0.0040
DEBUG - 2022-03-18 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 07:32:34 --> No URI present. Default controller set.
DEBUG - 2022-03-18 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 07:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 07:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 07:32:34 --> Total execution time: 0.0298
DEBUG - 2022-03-18 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 07:32:34 --> No URI present. Default controller set.
DEBUG - 2022-03-18 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 07:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 07:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 07:32:34 --> Total execution time: 0.0030
DEBUG - 2022-03-18 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 07:32:34 --> No URI present. Default controller set.
DEBUG - 2022-03-18 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 07:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 07:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 07:32:34 --> Total execution time: 0.0033
DEBUG - 2022-03-18 07:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 07:32:47 --> No URI present. Default controller set.
DEBUG - 2022-03-18 07:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 07:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 07:32:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 07:32:47 --> Total execution time: 0.0038
DEBUG - 2022-03-18 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:17 --> No URI present. Default controller set.
DEBUG - 2022-03-18 09:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 09:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 09:37:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 09:37:17 --> Total execution time: 0.0298
DEBUG - 2022-03-18 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 09:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 09:37:17 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-03-18 09:37:17 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-18 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 09:37:17 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-18 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 09:37:17 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-18 09:37:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 09:37:17 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-18 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 09:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 09:37:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 09:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 09:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 09:37:22 --> Total execution time: 0.0069
DEBUG - 2022-03-18 09:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 09:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 09:37:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 09:37:25 --> Total execution time: 0.0124
DEBUG - 2022-03-18 09:37:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 09:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 09:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 09:37:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 09:37:36 --> Total execution time: 0.0044
DEBUG - 2022-03-18 10:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:31:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:31:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:31:40 --> Total execution time: 0.0066
DEBUG - 2022-03-18 10:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:35:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:35:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:35:18 --> Total execution time: 0.0051
DEBUG - 2022-03-18 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:36:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:36:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:36:29 --> Total execution time: 0.0039
DEBUG - 2022-03-18 10:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:39:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:39:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:39:58 --> Total execution time: 0.0055
DEBUG - 2022-03-18 10:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:43:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:43:35 --> Total execution time: 0.0069
DEBUG - 2022-03-18 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:48:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:48:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 10:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 10:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 10:48:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 10:48:27 --> Total execution time: 0.0069
DEBUG - 2022-03-18 11:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:11:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:11:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:11:25 --> Total execution time: 0.0074
DEBUG - 2022-03-18 11:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:15:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:15:19 --> Total execution time: 0.0074
DEBUG - 2022-03-18 11:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:22:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:22:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:22:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:22:06 --> Total execution time: 0.0073
DEBUG - 2022-03-18 11:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:26:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:26:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:26:20 --> Total execution time: 0.0064
DEBUG - 2022-03-18 11:32:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:32:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:32:16 --> Total execution time: 0.0353
DEBUG - 2022-03-18 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:35:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:35:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:35:46 --> Total execution time: 0.0053
DEBUG - 2022-03-18 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:38:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:38:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:38:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:38:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:38:30 --> Total execution time: 0.0064
DEBUG - 2022-03-18 11:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 11:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 11:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 11:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 11:42:32 --> Total execution time: 0.0061
DEBUG - 2022-03-18 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:42:54 --> No URI present. Default controller set.
DEBUG - 2022-03-18 12:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:42:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-18 12:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:42:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:42:54 --> Total execution time: 0.0311
DEBUG - 2022-03-18 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:42:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-18 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:42:54 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-18 12:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:42:54 --> UTF-8 Support Enabled
ERROR - 2022-03-18 12:42:54 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-18 12:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:42:54 --> UTF-8 Support Enabled
ERROR - 2022-03-18 12:42:54 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-18 12:42:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:42:54 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-18 12:43:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:43:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:43:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:43:02 --> Total execution time: 0.0066
DEBUG - 2022-03-18 12:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:43:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:43:05 --> Total execution time: 0.0119
DEBUG - 2022-03-18 12:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:43:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:43:51 --> Total execution time: 0.0092
DEBUG - 2022-03-18 12:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:43:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:43:52 --> Total execution time: 0.0059
DEBUG - 2022-03-18 12:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:43:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:43:54 --> Total execution time: 0.0104
DEBUG - 2022-03-18 12:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:44:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:44:02 --> Total execution time: 0.0052
DEBUG - 2022-03-18 12:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:44:16 --> Total execution time: 0.0053
DEBUG - 2022-03-18 12:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:44:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:44:26 --> Total execution time: 0.0036
DEBUG - 2022-03-18 12:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:44:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-18 12:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:44:33 --> 404 Page Not Found: Auth/forgot-password.html
DEBUG - 2022-03-18 12:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:44:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:44:35 --> Total execution time: 0.0029
DEBUG - 2022-03-18 12:44:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:44:38 --> Total execution time: 0.0040
DEBUG - 2022-03-18 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:44:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:44:59 --> Total execution time: 0.0041
DEBUG - 2022-03-18 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:44:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:44:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-18 12:45:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:09 --> Total execution time: 0.0039
DEBUG - 2022-03-18 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-18 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:09 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-18 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:09 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-18 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:09 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-18 12:45:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:09 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-18 12:45:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:15 --> Total execution time: 0.0039
DEBUG - 2022-03-18 12:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:20 --> 404 Page Not Found: User/editrole
DEBUG - 2022-03-18 12:45:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:22 --> Total execution time: 0.0049
DEBUG - 2022-03-18 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:27 --> Total execution time: 0.0029
DEBUG - 2022-03-18 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:27 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-18 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:27 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-18 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:27 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-03-18 12:45:27 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-18 12:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:27 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-18 12:45:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:32 --> Total execution time: 0.0046
DEBUG - 2022-03-18 12:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:32 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-18 12:45:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:35 --> Total execution time: 0.0060
DEBUG - 2022-03-18 12:45:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:37 --> Total execution time: 0.0064
DEBUG - 2022-03-18 12:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:40 --> Total execution time: 0.0053
DEBUG - 2022-03-18 12:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:42 --> Total execution time: 0.0037
DEBUG - 2022-03-18 12:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:43 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-18 12:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:46 --> Total execution time: 0.0025
DEBUG - 2022-03-18 12:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:46 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-18 12:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:46 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-18 12:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:46 --> UTF-8 Support Enabled
ERROR - 2022-03-18 12:45:46 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-18 12:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:46 --> UTF-8 Support Enabled
ERROR - 2022-03-18 12:45:46 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-18 12:45:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-18 12:45:46 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-18 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 12:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 12:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 12:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 12:45:50 --> Total execution time: 0.0038
DEBUG - 2022-03-18 13:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:02:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:02:59 --> Total execution time: 0.0429
DEBUG - 2022-03-18 13:03:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:03:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:03:04 --> Total execution time: 0.0097
DEBUG - 2022-03-18 13:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:03:11 --> Total execution time: 0.0047
DEBUG - 2022-03-18 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:05:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:05:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:05:09 --> Total execution time: 0.0041
DEBUG - 2022-03-18 13:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:23:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:23:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:23:12 --> Total execution time: 0.0058
DEBUG - 2022-03-18 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:26:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:26:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:26:35 --> Total execution time: 0.0071
DEBUG - 2022-03-18 13:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:49:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:49:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 13:49:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 13:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 13:49:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 13:49:55 --> Total execution time: 0.0075
DEBUG - 2022-03-18 14:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:03:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:03:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:03:14 --> Total execution time: 0.0071
DEBUG - 2022-03-18 14:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:08:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:08:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:08:22 --> Total execution time: 0.0063
DEBUG - 2022-03-18 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:15:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:15:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:15:08 --> Total execution time: 0.0063
DEBUG - 2022-03-18 14:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:19:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:19:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:19:08 --> Total execution time: 0.0058
DEBUG - 2022-03-18 14:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:23:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:23:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:23:36 --> Total execution time: 0.0064
DEBUG - 2022-03-18 14:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:24:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:24:07 --> Total execution time: 0.0132
DEBUG - 2022-03-18 14:24:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:24:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:24:12 --> Total execution time: 0.0041
DEBUG - 2022-03-18 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:27:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:27:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:27:24 --> Total execution time: 0.0056
DEBUG - 2022-03-18 14:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:43:57 --> Total execution time: 0.0403
DEBUG - 2022-03-18 14:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:44:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:44:01 --> Total execution time: 0.0094
DEBUG - 2022-03-18 14:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:44:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:44:05 --> Total execution time: 0.0050
DEBUG - 2022-03-18 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:45:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:45:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:45:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:45:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:45:21 --> Total execution time: 0.0043
DEBUG - 2022-03-18 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:47:25 --> Total execution time: 0.0047
DEBUG - 2022-03-18 14:49:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:49:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:49:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:49:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:49:43 --> Total execution time: 0.0053
DEBUG - 2022-03-18 14:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:57:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:57:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:57:07 --> Total execution time: 0.0150
DEBUG - 2022-03-18 14:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 14:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 14:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 14:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 14:59:42 --> Total execution time: 0.0060
DEBUG - 2022-03-18 15:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:08:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:08:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:08:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:08:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:08:35 --> Total execution time: 0.0065
DEBUG - 2022-03-18 15:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:10:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:10:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:10:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:10:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:10:12 --> Total execution time: 0.0040
DEBUG - 2022-03-18 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:14:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:14:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:14:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:14:07 --> Total execution time: 0.0052
DEBUG - 2022-03-18 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:16:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:16:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:16:24 --> Total execution time: 0.0044
DEBUG - 2022-03-18 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:19:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:19:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:19:58 --> Total execution time: 0.0052
DEBUG - 2022-03-18 15:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:22:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:22:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:22:07 --> Total execution time: 0.0037
DEBUG - 2022-03-18 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:25:03 --> Total execution time: 0.0067
DEBUG - 2022-03-18 15:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:27:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:27:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:27:24 --> Total execution time: 0.0049
DEBUG - 2022-03-18 15:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:30:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:30:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:30:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:30:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:30:06 --> Total execution time: 0.0057
DEBUG - 2022-03-18 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:32:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:32:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:32:43 --> Total execution time: 0.0054
DEBUG - 2022-03-18 15:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:35:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:35:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:35:22 --> Total execution time: 0.0050
DEBUG - 2022-03-18 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:37:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:37:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:37:05 --> Total execution time: 0.0049
DEBUG - 2022-03-18 15:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:37:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:37:10 --> Total execution time: 0.0126
DEBUG - 2022-03-18 15:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 15:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 15:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 15:49:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 15:49:50 --> Total execution time: 0.0369
DEBUG - 2022-03-18 16:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:03:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:03:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:03:26 --> Total execution time: 0.0070
DEBUG - 2022-03-18 16:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:05:21 --> Total execution time: 0.0049
DEBUG - 2022-03-18 16:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:08:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:08:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:08:07 --> Total execution time: 0.0047
DEBUG - 2022-03-18 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:10:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:10:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:10:33 --> Total execution time: 0.0058
DEBUG - 2022-03-18 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:12:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:12:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:12:46 --> Total execution time: 0.0055
DEBUG - 2022-03-18 16:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:14:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:14:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:14:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:14:36 --> Total execution time: 0.0051
DEBUG - 2022-03-18 16:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:20:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:20:11 --> Total execution time: 0.0073
DEBUG - 2022-03-18 16:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:20:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:20:13 --> Total execution time: 0.0146
DEBUG - 2022-03-18 16:20:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:20:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:20:19 --> Total execution time: 0.0040
DEBUG - 2022-03-18 16:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:23:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:23:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:23:16 --> Total execution time: 0.0047
DEBUG - 2022-03-18 16:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:26:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:26:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:26:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:26:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:26:51 --> Total execution time: 0.0054
DEBUG - 2022-03-18 16:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:31:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:31:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:31:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:31:36 --> Total execution time: 0.0053
DEBUG - 2022-03-18 16:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:35:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:35:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:35:54 --> Total execution time: 0.0069
DEBUG - 2022-03-18 16:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:39:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:39:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:39:33 --> Total execution time: 0.0054
DEBUG - 2022-03-18 16:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:39:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:39:37 --> Total execution time: 0.0122
DEBUG - 2022-03-18 16:39:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-18 16:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-18 16:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-18 16:39:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-18 16:39:39 --> Total execution time: 0.0046
