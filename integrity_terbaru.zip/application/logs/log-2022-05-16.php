<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-16 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:10 --> No URI present. Default controller set.
DEBUG - 2022-05-16 04:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:35:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:35:10 --> Total execution time: 0.0452
DEBUG - 2022-05-16 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-16 04:35:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-16 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-16 04:35:10 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-16 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:35:10 --> UTF-8 Support Enabled
ERROR - 2022-05-16 04:35:10 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-16 04:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-16 04:35:10 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-16 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-16 04:35:10 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-16 04:35:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-16 04:35:10 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-16 04:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:35:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:35:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:35:29 --> Total execution time: 0.0090
DEBUG - 2022-05-16 04:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-16 04:35:30 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-16 04:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:35:41 --> Total execution time: 0.0092
DEBUG - 2022-05-16 04:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:35:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:35:47 --> Total execution time: 0.0159
DEBUG - 2022-05-16 04:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:36:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:36:05 --> Total execution time: 0.0219
DEBUG - 2022-05-16 04:36:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:36:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:36:15 --> Total execution time: 0.0199
DEBUG - 2022-05-16 04:36:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:36:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:36:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:36:18 --> Total execution time: 0.0078
DEBUG - 2022-05-16 04:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:36:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:36:27 --> Total execution time: 0.0167
DEBUG - 2022-05-16 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:36:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:36:33 --> Total execution time: 0.0220
DEBUG - 2022-05-16 04:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:36:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:36:51 --> Total execution time: 0.0057
DEBUG - 2022-05-16 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:36:59 --> Total execution time: 0.0165
DEBUG - 2022-05-16 04:37:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:37:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:37:05 --> Total execution time: 0.0086
DEBUG - 2022-05-16 04:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:37:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:37:16 --> Total execution time: 0.0031
DEBUG - 2022-05-16 04:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:37:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:37:22 --> Total execution time: 0.0072
DEBUG - 2022-05-16 04:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:37:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:37:26 --> Total execution time: 0.0253
DEBUG - 2022-05-16 04:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:37:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:37:38 --> Total execution time: 0.0181
DEBUG - 2022-05-16 04:37:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-16 04:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-16 04:37:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-16 04:37:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-16 04:37:52 --> Total execution time: 0.0229
