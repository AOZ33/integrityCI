<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-09 20:24:23 --> UTF-8 Support Enabled
DEBUG - 2022-01-09 20:24:23 --> No URI present. Default controller set.
DEBUG - 2022-01-09 20:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-09 20:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-09 20:24:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-09 20:24:23 --> Total execution time: 0.0314
