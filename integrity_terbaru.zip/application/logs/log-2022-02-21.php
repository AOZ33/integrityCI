<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-21 00:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 00:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 00:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 00:28:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-21 00:28:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-21 00:28:24 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-21 09:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 09:33:21 --> No URI present. Default controller set.
DEBUG - 2022-02-21 09:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 09:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 09:33:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 09:33:21 --> Total execution time: 0.0303
DEBUG - 2022-02-21 09:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 09:33:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 09:33:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 09:36:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 09:36:08 --> No URI present. Default controller set.
DEBUG - 2022-02-21 09:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 09:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 09:36:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 09:36:08 --> Total execution time: 0.0314
DEBUG - 2022-02-21 09:36:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 09:36:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 09:36:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:24:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:24:49 --> Total execution time: 0.0067
DEBUG - 2022-02-21 10:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:24:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-21 10:24:53 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-21 10:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:25:08 --> Total execution time: 0.0046
DEBUG - 2022-02-21 10:25:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:25:35 --> No URI present. Default controller set.
DEBUG - 2022-02-21 10:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:25:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:25:35 --> Total execution time: 0.0055
DEBUG - 2022-02-21 10:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:25:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 10:25:36 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 10:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:25:36 --> No URI present. Default controller set.
DEBUG - 2022-02-21 10:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:25:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:25:36 --> Total execution time: 0.0033
DEBUG - 2022-02-21 10:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:25:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:25:44 --> Total execution time: 0.0037
DEBUG - 2022-02-21 10:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:25:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-21 10:25:46 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-21 10:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:25:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:25:47 --> Total execution time: 0.0042
DEBUG - 2022-02-21 10:48:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:48:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:48:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:48:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:48:48 --> Total execution time: 0.0066
DEBUG - 2022-02-21 10:51:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:51:55 --> No URI present. Default controller set.
DEBUG - 2022-02-21 10:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 10:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 10:51:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 10:51:55 --> Total execution time: 0.0299
DEBUG - 2022-02-21 10:51:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 10:51:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 10:51:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 11:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:00:07 --> No URI present. Default controller set.
DEBUG - 2022-02-21 11:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 11:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 11:00:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 11:00:07 --> Total execution time: 0.0306
DEBUG - 2022-02-21 11:00:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:00:09 --> No URI present. Default controller set.
DEBUG - 2022-02-21 11:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 11:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 11:00:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 11:00:09 --> Total execution time: 0.0029
DEBUG - 2022-02-21 11:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:00:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 11:00:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 11:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 11:23:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 11:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 11:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 11:23:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 11:23:58 --> Total execution time: 0.0059
DEBUG - 2022-02-21 11:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 11:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 11:52:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 11:52:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 11:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 11:52:06 --> Total execution time: 0.0053
DEBUG - 2022-02-21 11:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 11:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 11:52:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-21 11:52:17 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-21 11:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 11:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 11:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 11:57:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 11:57:06 --> Total execution time: 0.0328
DEBUG - 2022-02-21 13:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 13:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 13:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 13:00:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 13:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 13:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 13:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 13:00:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 13:00:23 --> Total execution time: 0.0070
DEBUG - 2022-02-21 13:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 13:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 13:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 13:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 13:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 13:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 13:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 13:08:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 13:08:04 --> Total execution time: 0.0057
DEBUG - 2022-02-21 13:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 13:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 13:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 13:16:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 13:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 13:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 13:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 13:16:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 13:16:40 --> Total execution time: 0.0054
DEBUG - 2022-02-21 13:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 13:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 13:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 13:51:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 13:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 13:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 13:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 13:51:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 13:51:54 --> Total execution time: 0.0067
DEBUG - 2022-02-21 14:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:18:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:18:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:18:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:18:08 --> Total execution time: 0.0061
DEBUG - 2022-02-21 14:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:21:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:21:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:21:55 --> Total execution time: 0.0051
DEBUG - 2022-02-21 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:27:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:27:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:27:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:27:41 --> Total execution time: 0.0059
DEBUG - 2022-02-21 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:32:39 --> Total execution time: 0.0063
DEBUG - 2022-02-21 14:38:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:38:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:38:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:38:07 --> Total execution time: 0.0060
DEBUG - 2022-02-21 14:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:46:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:46:14 --> Total execution time: 0.0059
DEBUG - 2022-02-21 14:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:50:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:50:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:50:56 --> Total execution time: 0.0064
DEBUG - 2022-02-21 14:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 14:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 14:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 14:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 14:55:16 --> Total execution time: 0.0061
DEBUG - 2022-02-21 15:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:01:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:01:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:01:10 --> Total execution time: 0.0056
DEBUG - 2022-02-21 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:04:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:04:31 --> Total execution time: 0.0061
DEBUG - 2022-02-21 15:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:09:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:09:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:09:51 --> Total execution time: 0.0060
DEBUG - 2022-02-21 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:15:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:15:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:15:40 --> Total execution time: 0.0053
DEBUG - 2022-02-21 15:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:26:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:26:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:26:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:26:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:26:05 --> Total execution time: 0.0061
DEBUG - 2022-02-21 15:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:31:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:31:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:31:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:31:08 --> Total execution time: 0.0060
DEBUG - 2022-02-21 15:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:43:15 --> Total execution time: 0.0057
DEBUG - 2022-02-21 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:49:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:49:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:49:59 --> Total execution time: 0.0059
DEBUG - 2022-02-21 15:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:53:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:53:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:53:08 --> Total execution time: 0.0056
DEBUG - 2022-02-21 15:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:55:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:55:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:55:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:55:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:55:42 --> Total execution time: 0.0057
DEBUG - 2022-02-21 15:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 15:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 15:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 15:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 15:58:15 --> Total execution time: 0.0063
DEBUG - 2022-02-21 16:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 16:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 16:06:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 16:06:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 16:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 16:06:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 16:06:26 --> Total execution time: 0.0064
DEBUG - 2022-02-21 16:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:14:21 --> No URI present. Default controller set.
DEBUG - 2022-02-21 16:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 16:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 16:14:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 16:14:21 --> Total execution time: 0.0301
DEBUG - 2022-02-21 16:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:14:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 16:14:22 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 16:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:14:43 --> No URI present. Default controller set.
DEBUG - 2022-02-21 16:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 16:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 16:14:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 16:14:43 --> Total execution time: 0.0038
DEBUG - 2022-02-21 16:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:39:28 --> No URI present. Default controller set.
DEBUG - 2022-02-21 16:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 16:39:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 16:39:28 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-02-21 16:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 16:39:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 16:39:28 --> Total execution time: 0.0309
DEBUG - 2022-02-21 16:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:39:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 16:39:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 16:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:41:47 --> No URI present. Default controller set.
DEBUG - 2022-02-21 16:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 16:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 16:41:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 16:41:47 --> Total execution time: 0.0309
DEBUG - 2022-02-21 16:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:42:54 --> No URI present. Default controller set.
DEBUG - 2022-02-21 16:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 16:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 16:42:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 16:42:54 --> Total execution time: 0.0045
DEBUG - 2022-02-21 16:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:42:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 16:42:55 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 16:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 16:54:57 --> No URI present. Default controller set.
DEBUG - 2022-02-21 16:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 16:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 16:54:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 16:54:57 --> Total execution time: 0.0300
DEBUG - 2022-02-21 17:11:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 17:11:15 --> No URI present. Default controller set.
DEBUG - 2022-02-21 17:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 17:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 17:11:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 17:11:15 --> Total execution time: 0.0305
DEBUG - 2022-02-21 17:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 17:30:16 --> No URI present. Default controller set.
DEBUG - 2022-02-21 17:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 17:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 17:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 17:30:16 --> Total execution time: 0.0312
DEBUG - 2022-02-21 17:30:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 17:30:18 --> No URI present. Default controller set.
DEBUG - 2022-02-21 17:30:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 17:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 17:30:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 17:30:18 --> Total execution time: 0.0033
DEBUG - 2022-02-21 17:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 17:33:52 --> No URI present. Default controller set.
DEBUG - 2022-02-21 17:33:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 17:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 17:33:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 17:33:52 --> Total execution time: 0.0297
DEBUG - 2022-02-21 18:09:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 18:09:52 --> No URI present. Default controller set.
DEBUG - 2022-02-21 18:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 18:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 18:09:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 18:09:53 --> Total execution time: 0.0301
DEBUG - 2022-02-21 18:09:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 18:09:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-21 18:09:53 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-21 18:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 18:15:41 --> No URI present. Default controller set.
DEBUG - 2022-02-21 18:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 18:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 18:15:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 18:15:41 --> Total execution time: 0.0300
DEBUG - 2022-02-21 18:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-21 18:15:48 --> No URI present. Default controller set.
DEBUG - 2022-02-21 18:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-21 18:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-21 18:15:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-21 18:15:48 --> Total execution time: 0.0030
