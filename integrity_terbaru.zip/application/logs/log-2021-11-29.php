<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-29 04:00:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:00:06 --> No URI present. Default controller set.
DEBUG - 2021-11-29 04:00:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 04:00:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'admin_nesnu' C:\xampp\htdocs\nesnu\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-11-29 04:00:06 --> Unable to connect to the database
DEBUG - 2021-11-29 04:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:08:38 --> No URI present. Default controller set.
DEBUG - 2021-11-29 04:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:08:38 --> Total execution time: 0.0447
DEBUG - 2021-11-29 04:08:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:08:40 --> Total execution time: 0.0502
DEBUG - 2021-11-29 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:09:47 --> Total execution time: 0.0561
DEBUG - 2021-11-29 04:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 04:09:51 --> Query error: Table 'admin_nesnu.user_menu' doesn't exist - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 2
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
DEBUG - 2021-11-29 04:10:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:10:01 --> Total execution time: 0.0450
DEBUG - 2021-11-29 04:33:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:33:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:33:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:33:00 --> Total execution time: 0.0257
DEBUG - 2021-11-29 04:33:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 04:33:06 --> Query error: Table 'admin_nesnu.customer' doesn't exist - Invalid query: SELECT *
FROM `customer`
DEBUG - 2021-11-29 04:33:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:33:10 --> Total execution time: 0.0393
DEBUG - 2021-11-29 04:42:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:42:21 --> Total execution time: 0.0500
DEBUG - 2021-11-29 04:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:42:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 04:42:22 --> 404 Page Not Found: Client/index
DEBUG - 2021-11-29 04:42:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:42:24 --> Total execution time: 0.0401
DEBUG - 2021-11-29 04:43:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 04:43:32 --> Total execution time: 0.0362
DEBUG - 2021-11-29 04:43:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 04:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 04:43:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 04:43:33 --> Severity: error --> Exception: Unable to locate the model you have specified: Client_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-11-29 05:07:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 05:07:22 --> Severity: error --> Exception: C:\xampp\htdocs\nesnu\application\models/Client_model.php exists, but doesn't declare class Client_model C:\xampp\htdocs\nesnu\system\core\Loader.php 340
DEBUG - 2021-11-29 05:08:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:08:11 --> Total execution time: 0.0880
DEBUG - 2021-11-29 05:08:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:08:13 --> Total execution time: 0.0476
DEBUG - 2021-11-29 05:08:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:08:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:08:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 05:08:27 --> Query error: Table 'admin_nesnu.package' doesn't exist - Invalid query: SELECT *
FROM `package`
DEBUG - 2021-11-29 05:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:08:29 --> Total execution time: 0.0512
DEBUG - 2021-11-29 05:09:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:09:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:09:57 --> Total execution time: 0.0455
DEBUG - 2021-11-29 05:09:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 05:09:58 --> Query error: Table 'admin_nesnu.appointment' doesn't exist - Invalid query: SELECT *
FROM `appointment`
DEBUG - 2021-11-29 05:09:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:09:59 --> Total execution time: 0.0476
DEBUG - 2021-11-29 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:15:53 --> Total execution time: 0.0516
DEBUG - 2021-11-29 05:16:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:16:38 --> Total execution time: 0.0424
DEBUG - 2021-11-29 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:18:05 --> Total execution time: 0.0428
DEBUG - 2021-11-29 05:18:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:18:31 --> Total execution time: 0.0393
DEBUG - 2021-11-29 05:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:19:39 --> Total execution time: 0.0514
DEBUG - 2021-11-29 05:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 05:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 05:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 05:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 05:24:00 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 143
ERROR - 2021-11-29 05:24:00 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 184
ERROR - 2021-11-29 05:24:00 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 184
DEBUG - 2021-11-29 05:24:00 --> Total execution time: 0.0441
DEBUG - 2021-11-29 06:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:05:46 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:05:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:05:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
DEBUG - 2021-11-29 06:05:46 --> Total execution time: 0.0548
DEBUG - 2021-11-29 06:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:07:10 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:07:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:07:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
DEBUG - 2021-11-29 06:07:10 --> Total execution time: 0.0545
DEBUG - 2021-11-29 06:07:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:07:45 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:07:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:07:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:07:45 --> Total execution time: 0.0409
DEBUG - 2021-11-29 06:08:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:08:28 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:08:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:08:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:08:28 --> Total execution time: 0.0318
DEBUG - 2021-11-29 06:09:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:09:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:09:56 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:09:56 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:09:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:09:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:09:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:09:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:09:56 --> Total execution time: 0.0451
DEBUG - 2021-11-29 06:10:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:10:37 --> Total execution time: 0.0530
DEBUG - 2021-11-29 06:18:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:18:08 --> Total execution time: 0.0437
DEBUG - 2021-11-29 06:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:18:18 --> Total execution time: 0.0507
DEBUG - 2021-11-29 06:18:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:20 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:20 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:20 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:20 --> Total execution time: 0.0315
DEBUG - 2021-11-29 06:18:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:18:28 --> Total execution time: 0.0477
DEBUG - 2021-11-29 06:18:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:28 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:28 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:28 --> Total execution time: 0.0414
DEBUG - 2021-11-29 06:18:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 06:18:29 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 06:18:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:31 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:31 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:31 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:31 --> Total execution time: 0.0491
DEBUG - 2021-11-29 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:32 --> Total execution time: 0.0504
DEBUG - 2021-11-29 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:18:32 --> Total execution time: 0.0479
DEBUG - 2021-11-29 06:18:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:33 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:33 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:33 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:33 --> Total execution time: 0.0489
DEBUG - 2021-11-29 06:18:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:18:34 --> Total execution time: 0.0386
DEBUG - 2021-11-29 06:18:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:34 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:34 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:34 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:34 --> Total execution time: 0.0496
DEBUG - 2021-11-29 06:18:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:18:36 --> Total execution time: 0.0375
DEBUG - 2021-11-29 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:38 --> Total execution time: 0.0445
DEBUG - 2021-11-29 06:18:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:44 --> Total execution time: 0.0317
DEBUG - 2021-11-29 06:18:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:18:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 200
ERROR - 2021-11-29 06:18:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 200
DEBUG - 2021-11-29 06:18:46 --> Total execution time: 0.0528
DEBUG - 2021-11-29 06:19:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:19:01 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:01 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:01 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:01 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:19:01 --> Total execution time: 0.0565
DEBUG - 2021-11-29 06:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:19:08 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:08 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:08 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:08 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:08 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:19:08 --> Total execution time: 0.0310
DEBUG - 2021-11-29 06:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:19:11 --> Total execution time: 0.0523
DEBUG - 2021-11-29 06:19:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:19:12 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:12 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:19:12 --> Total execution time: 0.0443
DEBUG - 2021-11-29 06:19:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:19:15 --> Total execution time: 0.0285
DEBUG - 2021-11-29 06:19:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:19:17 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:17 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:17 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:17 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:19:17 --> Total execution time: 0.0476
DEBUG - 2021-11-29 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:19:25 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:25 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:25 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:25 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:19:25 --> Total execution time: 0.0531
DEBUG - 2021-11-29 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:19:25 --> Total execution time: 0.0476
DEBUG - 2021-11-29 06:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:19:26 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:26 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:19:26 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:26 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:19:26 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:19:26 --> Total execution time: 0.0499
DEBUG - 2021-11-29 06:20:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:20:01 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:20:01 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:20:01 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:01 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:01 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:20:01 --> Total execution time: 0.0325
DEBUG - 2021-11-29 06:20:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:20:04 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:20:04 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:20:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:04 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:04 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:20:04 --> Total execution time: 0.0477
DEBUG - 2021-11-29 06:20:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:20:44 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:20:44 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:20:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:20:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:20:44 --> Total execution time: 0.0443
DEBUG - 2021-11-29 06:22:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:22:14 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\client\index.php 116
ERROR - 2021-11-29 06:22:14 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 192
ERROR - 2021-11-29 06:22:14 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 192
ERROR - 2021-11-29 06:22:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 233
ERROR - 2021-11-29 06:22:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 233
ERROR - 2021-11-29 06:22:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 233
ERROR - 2021-11-29 06:22:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 233
DEBUG - 2021-11-29 06:22:14 --> Total execution time: 0.0356
DEBUG - 2021-11-29 06:22:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:22:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:22:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:44 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
DEBUG - 2021-11-29 06:22:44 --> Total execution time: 0.0402
DEBUG - 2021-11-29 06:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
DEBUG - 2021-11-29 06:22:49 --> Total execution time: 0.0429
DEBUG - 2021-11-29 06:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
DEBUG - 2021-11-29 06:22:49 --> Total execution time: 0.0469
DEBUG - 2021-11-29 06:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
DEBUG - 2021-11-29 06:22:49 --> Total execution time: 0.0448
DEBUG - 2021-11-29 06:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:22:50 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:50 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 196
ERROR - 2021-11-29 06:22:50 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 196
DEBUG - 2021-11-29 06:22:50 --> Total execution time: 0.0306
DEBUG - 2021-11-29 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:22:59 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:22:59 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:22:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:22:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:22:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:22:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
DEBUG - 2021-11-29 06:22:59 --> Total execution time: 0.0552
DEBUG - 2021-11-29 06:23:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:23:25 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:23:25 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:23:25 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:23:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:23:25 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:23:25 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
DEBUG - 2021-11-29 06:23:25 --> Total execution time: 0.0482
DEBUG - 2021-11-29 06:23:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:23:51 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:23:51 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:23:51 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:23:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:23:51 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:23:51 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:23:51 --> Total execution time: 0.0520
DEBUG - 2021-11-29 06:23:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:23:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:23:53 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:23:53 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:23:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:23:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:23:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:23:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:23:53 --> Total execution time: 0.0341
DEBUG - 2021-11-29 06:24:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:24:13 --> No URI present. Default controller set.
DEBUG - 2021-11-29 06:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:24:13 --> Total execution time: 0.0568
DEBUG - 2021-11-29 06:24:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:24:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:24:18 --> Total execution time: 0.0758
DEBUG - 2021-11-29 06:24:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:24:21 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:24:21 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:24:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:24:21 --> Total execution time: 0.0514
DEBUG - 2021-11-29 06:24:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:24:24 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:24:24 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:24:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:24:24 --> Total execution time: 0.0501
DEBUG - 2021-11-29 06:24:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:24:40 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:24:40 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:24:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:40 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:24:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:24:40 --> Total execution time: 0.0357
DEBUG - 2021-11-29 06:25:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:25:11 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:25:11 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:25:11 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:11 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:11 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:25:11 --> Total execution time: 0.0505
DEBUG - 2021-11-29 06:25:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:25:53 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:25:53 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:25:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:25:53 --> Total execution time: 0.0570
DEBUG - 2021-11-29 06:25:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:25:58 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:25:58 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:25:58 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:58 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:25:58 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:25:58 --> Total execution time: 0.0509
DEBUG - 2021-11-29 06:26:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:26:52 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:26:52 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:26:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:26:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:26:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:26:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:26:52 --> Total execution time: 0.0561
DEBUG - 2021-11-29 06:27:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:27:07 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:27:07 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:27:07 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:27:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:27:07 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:27:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:27:07 --> Total execution time: 0.0329
DEBUG - 2021-11-29 06:27:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:27:10 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:27:10 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:27:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:27:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:27:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:27:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:27:10 --> Total execution time: 0.0472
DEBUG - 2021-11-29 06:27:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:27:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:27:31 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:27:31 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:27:31 --> Total execution time: 0.0510
DEBUG - 2021-11-29 06:27:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:27:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:27:33 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:27:33 --> Total execution time: 0.0437
DEBUG - 2021-11-29 06:28:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:28:19 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:28:19 --> Total execution time: 0.0440
DEBUG - 2021-11-29 06:28:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:28:22 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:28:22 --> Total execution time: 0.0533
DEBUG - 2021-11-29 06:28:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:28:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:28:35 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:28:35 --> Total execution time: 0.0311
DEBUG - 2021-11-29 06:29:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:29:00 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:29:00 --> Total execution time: 0.0467
DEBUG - 2021-11-29 06:29:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:29:14 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:29:14 --> Total execution time: 0.0304
DEBUG - 2021-11-29 06:29:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:29:23 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:29:23 --> Total execution time: 0.0535
DEBUG - 2021-11-29 06:30:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:30:50 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:30:50 --> Total execution time: 0.0413
DEBUG - 2021-11-29 06:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:30:52 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:30:52 --> Total execution time: 0.0401
DEBUG - 2021-11-29 06:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:30:53 --> Total execution time: 0.0438
DEBUG - 2021-11-29 06:30:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:30:55 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:30:55 --> Total execution time: 0.0289
DEBUG - 2021-11-29 06:31:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:31:24 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:31:24 --> Total execution time: 0.0541
DEBUG - 2021-11-29 06:31:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:31:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:31:27 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:31:27 --> Total execution time: 0.0530
DEBUG - 2021-11-29 06:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:31:32 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:31:32 --> Total execution time: 0.0421
DEBUG - 2021-11-29 06:31:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:31:35 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:31:35 --> Total execution time: 0.0545
DEBUG - 2021-11-29 06:31:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:31:40 --> Total execution time: 0.0434
DEBUG - 2021-11-29 06:31:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:31:40 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:31:40 --> Total execution time: 0.0453
DEBUG - 2021-11-29 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:31:41 --> Total execution time: 0.0529
DEBUG - 2021-11-29 06:31:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:31:41 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:31:41 --> Total execution time: 0.0405
DEBUG - 2021-11-29 06:32:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:32:59 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:32:59 --> Total execution time: 0.0566
DEBUG - 2021-11-29 06:33:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:33:01 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:33:01 --> Total execution time: 0.0471
DEBUG - 2021-11-29 06:33:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:33:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:33:06 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:33:06 --> Total execution time: 0.0548
DEBUG - 2021-11-29 06:34:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:34:55 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:34:55 --> Total execution time: 0.0308
DEBUG - 2021-11-29 06:34:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:34:57 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:34:57 --> Total execution time: 0.0391
DEBUG - 2021-11-29 06:34:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:34:58 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:34:58 --> Total execution time: 0.0478
DEBUG - 2021-11-29 06:35:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:35:38 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:35:38 --> Total execution time: 0.0528
DEBUG - 2021-11-29 06:35:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:35:40 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:35:40 --> Total execution time: 0.0501
DEBUG - 2021-11-29 06:35:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:35:43 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:35:43 --> Total execution time: 0.0447
DEBUG - 2021-11-29 06:35:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:35:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:35:58 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:35:58 --> Total execution time: 0.0410
DEBUG - 2021-11-29 06:36:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:36:01 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:36:01 --> Total execution time: 0.0299
DEBUG - 2021-11-29 06:36:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:36:32 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:36:32 --> Total execution time: 0.0490
DEBUG - 2021-11-29 06:36:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:36:48 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:36:48 --> Total execution time: 0.0493
DEBUG - 2021-11-29 06:37:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:37:15 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:37:15 --> Total execution time: 0.0307
DEBUG - 2021-11-29 06:37:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:37:51 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:37:51 --> Total execution time: 0.0411
DEBUG - 2021-11-29 06:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:38:08 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:38:08 --> Total execution time: 0.0525
DEBUG - 2021-11-29 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:38:34 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:38:34 --> Total execution time: 0.0441
DEBUG - 2021-11-29 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:38:34 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:38:34 --> Total execution time: 0.0507
DEBUG - 2021-11-29 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:38:34 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:38:34 --> Total execution time: 0.0281
DEBUG - 2021-11-29 06:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:38:34 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:38:34 --> Total execution time: 0.0473
DEBUG - 2021-11-29 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:38:35 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:38:35 --> Total execution time: 0.0299
DEBUG - 2021-11-29 06:38:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:38:35 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
DEBUG - 2021-11-29 06:38:35 --> Total execution time: 0.0418
DEBUG - 2021-11-29 06:39:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:39:02 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:39:02 --> Total execution time: 0.0526
DEBUG - 2021-11-29 06:39:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:39:08 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:39:08 --> Total execution time: 0.0475
DEBUG - 2021-11-29 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:39:37 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:39:37 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:39:37 --> Total execution time: 0.0307
DEBUG - 2021-11-29 06:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:39:40 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:39:40 --> Total execution time: 0.0292
DEBUG - 2021-11-29 06:40:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:40:06 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:40:06 --> Total execution time: 0.0507
DEBUG - 2021-11-29 06:40:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:40:11 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
DEBUG - 2021-11-29 06:40:11 --> Total execution time: 0.0510
DEBUG - 2021-11-29 06:40:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:40:40 --> Severity: Warning --> Undefined variable $ct C:\xampp\htdocs\nesnu\application\views\client\index.php 34
ERROR - 2021-11-29 06:40:40 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 34
ERROR - 2021-11-29 06:40:40 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:40:40 --> Total execution time: 0.0448
DEBUG - 2021-11-29 06:41:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:41:06 --> Severity: Warning --> Undefined variable $ct C:\xampp\htdocs\nesnu\application\views\client\index.php 34
ERROR - 2021-11-29 06:41:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 34
ERROR - 2021-11-29 06:41:06 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:41:06 --> Total execution time: 0.0432
DEBUG - 2021-11-29 06:41:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:41:15 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:41:15 --> Total execution time: 0.0398
DEBUG - 2021-11-29 06:41:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:41:22 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:41:22 --> Total execution time: 0.0534
DEBUG - 2021-11-29 06:41:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:41:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:41:45 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:41:45 --> Total execution time: 0.0297
DEBUG - 2021-11-29 06:41:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:41:50 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:41:50 --> Total execution time: 0.0484
DEBUG - 2021-11-29 06:42:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:42:13 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:42:13 --> Total execution time: 0.0445
DEBUG - 2021-11-29 06:42:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:42:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:42:21 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:42:21 --> Total execution time: 0.0548
DEBUG - 2021-11-29 06:42:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:42:24 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:42:24 --> Total execution time: 0.0418
DEBUG - 2021-11-29 06:42:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:42:59 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
DEBUG - 2021-11-29 06:42:59 --> Total execution time: 0.0471
DEBUG - 2021-11-29 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:43:10 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 143
ERROR - 2021-11-29 06:43:10 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 184
ERROR - 2021-11-29 06:43:10 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 184
DEBUG - 2021-11-29 06:43:10 --> Total execution time: 0.0432
DEBUG - 2021-11-29 06:43:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:43:32 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 143
ERROR - 2021-11-29 06:43:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 184
ERROR - 2021-11-29 06:43:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 184
DEBUG - 2021-11-29 06:43:32 --> Total execution time: 0.0497
DEBUG - 2021-11-29 06:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 06:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:43:56 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 143
ERROR - 2021-11-29 06:43:56 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 143
ERROR - 2021-11-29 06:43:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 184
ERROR - 2021-11-29 06:43:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 184
ERROR - 2021-11-29 06:43:56 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 184
ERROR - 2021-11-29 06:43:56 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 184
DEBUG - 2021-11-29 06:43:56 --> Total execution time: 0.0452
DEBUG - 2021-11-29 06:47:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:47:19 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:47:19 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:47:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:47:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:47:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:47:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
DEBUG - 2021-11-29 06:47:19 --> Total execution time: 0.0531
DEBUG - 2021-11-29 06:47:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:47:47 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:47:47 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 145
ERROR - 2021-11-29 06:47:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:47:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:47:47 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 186
ERROR - 2021-11-29 06:47:47 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 186
DEBUG - 2021-11-29 06:47:47 --> Total execution time: 0.0497
DEBUG - 2021-11-29 06:48:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:48:13 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:48:13 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:48:13 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:48:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:48:13 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:48:13 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:48:13 --> Total execution time: 0.0545
DEBUG - 2021-11-29 06:48:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:48:32 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:48:32 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:48:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:48:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:48:32 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:48:32 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:48:32 --> Total execution time: 0.0333
DEBUG - 2021-11-29 06:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:49:27 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:49:27 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:49:27 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:27 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:27 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:49:27 --> Total execution time: 0.0535
DEBUG - 2021-11-29 06:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:49:45 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:49:45 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:49:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:45 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:49:45 --> Total execution time: 0.0431
DEBUG - 2021-11-29 06:49:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:49:53 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:49:53 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:49:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:49:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:49:53 --> Total execution time: 0.0521
DEBUG - 2021-11-29 06:50:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:50:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:50:05 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:05 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:05 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:05 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:50:05 --> Total execution time: 0.0325
DEBUG - 2021-11-29 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:50:16 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:16 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:50:16 --> Total execution time: 0.0451
DEBUG - 2021-11-29 06:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:50:24 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:24 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:24 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:24 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:50:24 --> Total execution time: 0.0568
DEBUG - 2021-11-29 06:50:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:50:30 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:30 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:30 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:30 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:30 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:50:30 --> Total execution time: 0.0427
DEBUG - 2021-11-29 06:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:50:36 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:36 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:50:36 --> Total execution time: 0.0322
DEBUG - 2021-11-29 06:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:50:49 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:49 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 146
ERROR - 2021-11-29 06:50:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 187
ERROR - 2021-11-29 06:50:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 187
DEBUG - 2021-11-29 06:50:49 --> Total execution time: 0.0480
DEBUG - 2021-11-29 06:51:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:51:14 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
ERROR - 2021-11-29 06:51:14 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
ERROR - 2021-11-29 06:51:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:51:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:51:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:51:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 188
DEBUG - 2021-11-29 06:51:14 --> Total execution time: 0.0471
DEBUG - 2021-11-29 06:54:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:54:54 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
ERROR - 2021-11-29 06:54:54 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
ERROR - 2021-11-29 06:54:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:54:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:54:54 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:54:54 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 188
DEBUG - 2021-11-29 06:54:54 --> Total execution time: 0.0510
DEBUG - 2021-11-29 06:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:55:12 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
ERROR - 2021-11-29 06:55:12 --> Severity: Warning --> Undefined variable $telephone C:\xampp\htdocs\nesnu\application\views\client\index.php 147
ERROR - 2021-11-29 06:55:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:55:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:55:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 188
ERROR - 2021-11-29 06:55:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 188
DEBUG - 2021-11-29 06:55:12 --> Total execution time: 0.0478
DEBUG - 2021-11-29 06:58:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:58:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:58:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:58:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:58:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 06:58:46 --> Total execution time: 0.0513
DEBUG - 2021-11-29 06:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:59:06 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:59:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:59:06 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:59:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 06:59:06 --> Total execution time: 0.0547
DEBUG - 2021-11-29 06:59:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 06:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 06:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 06:59:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:59:53 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 06:59:53 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 06:59:53 --> Total execution time: 0.0467
DEBUG - 2021-11-29 07:01:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:01:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:01:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:01:12 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:01:12 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:01:12 --> Total execution time: 0.0501
DEBUG - 2021-11-29 07:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:01:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:01:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:01:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:01:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:01:52 --> Total execution time: 0.0308
DEBUG - 2021-11-29 07:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:02:06 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:02:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:02:06 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:02:06 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:02:06 --> Total execution time: 0.0445
DEBUG - 2021-11-29 07:02:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:02:09 --> Total execution time: 0.0514
DEBUG - 2021-11-29 07:02:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:02:13 --> Total execution time: 0.0464
DEBUG - 2021-11-29 07:11:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:11:59 --> Total execution time: 0.0311
DEBUG - 2021-11-29 07:11:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:11:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:11:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:11:59 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:11:59 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:11:59 --> Total execution time: 0.0314
DEBUG - 2021-11-29 07:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:12:00 --> Total execution time: 0.0434
DEBUG - 2021-11-29 07:13:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:13:15 --> Total execution time: 0.0479
DEBUG - 2021-11-29 07:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:13:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:13:17 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:13:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:13:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:13:57 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:13:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:13:58 --> Total execution time: 0.0391
DEBUG - 2021-11-29 07:13:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:13:58 --> Total execution time: 0.0285
DEBUG - 2021-11-29 07:13:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:13:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:13:59 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:14:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:14:00 --> Total execution time: 0.0381
DEBUG - 2021-11-29 07:14:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:14:02 --> Total execution time: 0.0484
DEBUG - 2021-11-29 07:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:14:18 --> Total execution time: 0.0429
DEBUG - 2021-11-29 07:14:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:14:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:14:19 --> Total execution time: 0.0322
DEBUG - 2021-11-29 07:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:14:20 --> Total execution time: 0.0282
DEBUG - 2021-11-29 07:14:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:14:21 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:14:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:14:22 --> Total execution time: 0.0554
DEBUG - 2021-11-29 07:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:14:36 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:14:40 --> Total execution time: 0.0452
DEBUG - 2021-11-29 07:14:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:14:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:41 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:41 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:14:41 --> Total execution time: 0.0553
DEBUG - 2021-11-29 07:14:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:14:43 --> Total execution time: 0.0528
DEBUG - 2021-11-29 07:14:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:14:43 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:43 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:14:43 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:14:43 --> Total execution time: 0.0538
DEBUG - 2021-11-29 07:14:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:14:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:14:44 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:15:35 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:15:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:15:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:15:36 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:15:36 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:15:36 --> Total execution time: 0.0414
DEBUG - 2021-11-29 07:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:15:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:15:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:15:38 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:15:38 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:15:38 --> Total execution time: 0.0429
DEBUG - 2021-11-29 07:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:15:39 --> Total execution time: 0.0411
DEBUG - 2021-11-29 07:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:15:39 --> Total execution time: 0.0473
DEBUG - 2021-11-29 07:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:15:40 --> Total execution time: 0.0279
DEBUG - 2021-11-29 07:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:15:40 --> Total execution time: 0.0384
DEBUG - 2021-11-29 07:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:15:40 --> Total execution time: 0.0431
DEBUG - 2021-11-29 07:15:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:15:48 --> Total execution time: 0.0418
DEBUG - 2021-11-29 07:15:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:15:48 --> Total execution time: 0.0409
DEBUG - 2021-11-29 07:16:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:03 --> Total execution time: 0.0426
DEBUG - 2021-11-29 07:16:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:04 --> Total execution time: 0.0473
DEBUG - 2021-11-29 07:16:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:04 --> Total execution time: 0.0372
DEBUG - 2021-11-29 07:16:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:04 --> Total execution time: 0.0451
DEBUG - 2021-11-29 07:16:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:04 --> Total execution time: 0.0413
DEBUG - 2021-11-29 07:16:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:04 --> Total execution time: 0.0418
DEBUG - 2021-11-29 07:16:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:04 --> Total execution time: 0.0377
DEBUG - 2021-11-29 07:16:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:05 --> Total execution time: 0.0523
DEBUG - 2021-11-29 07:16:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:16:07 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:16:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:08 --> Total execution time: 0.0480
DEBUG - 2021-11-29 07:16:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:15 --> No URI present. Default controller set.
DEBUG - 2021-11-29 07:16:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:15 --> Total execution time: 0.0276
DEBUG - 2021-11-29 07:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:16 --> Total execution time: 0.0378
DEBUG - 2021-11-29 07:16:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:16:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:16:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:16:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:16:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:16:18 --> Total execution time: 0.0476
DEBUG - 2021-11-29 07:16:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:16:18 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:16:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:16:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:16:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:16:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:16:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:16:19 --> Total execution time: 0.0551
DEBUG - 2021-11-29 07:16:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:20 --> Total execution time: 0.0273
DEBUG - 2021-11-29 07:16:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:23 --> Total execution time: 0.0535
DEBUG - 2021-11-29 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:24 --> Total execution time: 0.0271
DEBUG - 2021-11-29 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:24 --> Total execution time: 0.0395
DEBUG - 2021-11-29 07:16:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:24 --> Total execution time: 0.0456
DEBUG - 2021-11-29 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:25 --> Total execution time: 0.0374
DEBUG - 2021-11-29 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:25 --> Total execution time: 0.0488
DEBUG - 2021-11-29 07:16:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:25 --> Total execution time: 0.0471
DEBUG - 2021-11-29 07:16:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:16:26 --> Total execution time: 0.0499
DEBUG - 2021-11-29 07:17:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:17:03 --> Total execution time: 0.0438
DEBUG - 2021-11-29 07:17:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:17:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:17:03 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:17:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:17:05 --> Total execution time: 0.0413
DEBUG - 2021-11-29 07:17:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:17:06 --> Total execution time: 0.0480
DEBUG - 2021-11-29 07:20:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:20:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:20:45 --> 404 Page Not Found: Appointment/index
DEBUG - 2021-11-29 07:20:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:20:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:46 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:46 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:20:46 --> Total execution time: 0.0495
DEBUG - 2021-11-29 07:20:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:20:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:20:47 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:20:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:20:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:20:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:48 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:48 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:20:48 --> Total execution time: 0.0423
DEBUG - 2021-11-29 07:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:20:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:49 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:49 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:20:49 --> Total execution time: 0.0460
DEBUG - 2021-11-29 07:20:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:20:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:20:50 --> 404 Page Not Found: Appointment/index
DEBUG - 2021-11-29 07:20:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:20:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:52 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:20:52 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:20:52 --> Total execution time: 0.0489
DEBUG - 2021-11-29 07:20:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:20:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:20:53 --> 404 Page Not Found: Data/index
DEBUG - 2021-11-29 07:21:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:21:13 --> Total execution time: 0.0382
DEBUG - 2021-11-29 07:21:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:21:14 --> Total execution time: 0.0511
DEBUG - 2021-11-29 07:21:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:21:15 --> Total execution time: 0.0456
DEBUG - 2021-11-29 07:21:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:21:15 --> Total execution time: 0.0449
DEBUG - 2021-11-29 07:31:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:31:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:31:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:31:18 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:31:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:31:18 --> Total execution time: 0.0482
DEBUG - 2021-11-29 07:31:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:31:19 --> Total execution time: 0.0280
DEBUG - 2021-11-29 07:31:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:31:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 07:31:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:31:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:31:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 07:31:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 07:31:19 --> Total execution time: 0.0551
DEBUG - 2021-11-29 07:31:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-29 07:31:19 --> 404 Page Not Found: Appointment/index
DEBUG - 2021-11-29 07:32:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:32:03 --> Total execution time: 0.0437
DEBUG - 2021-11-29 07:36:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:36:22 --> Total execution time: 0.0508
DEBUG - 2021-11-29 07:46:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:46:38 --> Total execution time: 0.0303
DEBUG - 2021-11-29 07:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:47:01 --> Total execution time: 0.0512
DEBUG - 2021-11-29 07:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:47:21 --> Total execution time: 0.0293
DEBUG - 2021-11-29 07:47:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:47:37 --> Total execution time: 0.0526
DEBUG - 2021-11-29 07:47:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:47:44 --> Total execution time: 0.0461
DEBUG - 2021-11-29 07:48:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:48:11 --> Total execution time: 0.0477
DEBUG - 2021-11-29 07:48:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:48:17 --> Total execution time: 0.0457
DEBUG - 2021-11-29 07:49:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:49:21 --> Total execution time: 0.0483
DEBUG - 2021-11-29 07:49:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:49:58 --> Total execution time: 0.0439
DEBUG - 2021-11-29 07:50:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 07:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 07:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 07:50:42 --> Total execution time: 0.0475
DEBUG - 2021-11-29 08:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:07:58 --> Total execution time: 0.0307
DEBUG - 2021-11-29 08:36:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:36:52 --> Total execution time: 0.0557
DEBUG - 2021-11-29 08:38:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:38:47 --> Total execution time: 0.0454
DEBUG - 2021-11-29 08:40:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:40:46 --> Total execution time: 0.0471
DEBUG - 2021-11-29 08:40:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:40:56 --> Total execution time: 0.0494
DEBUG - 2021-11-29 08:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:41:36 --> Total execution time: 0.0453
DEBUG - 2021-11-29 08:41:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:41:56 --> Total execution time: 0.0479
DEBUG - 2021-11-29 08:42:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:42:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:42:06 --> Total execution time: 0.0485
DEBUG - 2021-11-29 08:42:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:42:10 --> Total execution time: 0.0446
DEBUG - 2021-11-29 08:42:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:42:58 --> Total execution time: 0.0425
DEBUG - 2021-11-29 08:43:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:43:41 --> Total execution time: 0.0275
DEBUG - 2021-11-29 08:43:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:43:56 --> Total execution time: 0.0440
DEBUG - 2021-11-29 08:44:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:44:09 --> Total execution time: 0.0514
DEBUG - 2021-11-29 08:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:44:40 --> Total execution time: 0.0292
DEBUG - 2021-11-29 08:46:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:46:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:46:09 --> Total execution time: 0.0376
DEBUG - 2021-11-29 08:46:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:46:15 --> Total execution time: 0.0481
DEBUG - 2021-11-29 08:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:46:19 --> Total execution time: 0.0299
DEBUG - 2021-11-29 08:47:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:47:13 --> Total execution time: 0.0447
DEBUG - 2021-11-29 08:47:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 08:47:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:14 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:14 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 08:47:14 --> Total execution time: 0.0409
DEBUG - 2021-11-29 08:47:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 08:47:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:16 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:16 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 08:47:16 --> Total execution time: 0.0511
DEBUG - 2021-11-29 08:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:47:18 --> Total execution time: 0.0477
DEBUG - 2021-11-29 08:47:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:47:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 08:47:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:19 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:19 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 08:47:19 --> Total execution time: 0.0427
DEBUG - 2021-11-29 08:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 08:47:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:21 --> Severity: Warning --> Undefined variable $cr C:\xampp\htdocs\nesnu\application\views\client\index.php 203
ERROR - 2021-11-29 08:47:21 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\client\index.php 203
DEBUG - 2021-11-29 08:47:21 --> Total execution time: 0.0467
DEBUG - 2021-11-29 08:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:47:21 --> Total execution time: 0.0387
DEBUG - 2021-11-29 08:48:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:48:37 --> Total execution time: 0.0290
DEBUG - 2021-11-29 08:49:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:49:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:49:14 --> Total execution time: 0.0507
DEBUG - 2021-11-29 08:49:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:49:32 --> Total execution time: 0.0439
DEBUG - 2021-11-29 08:49:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:49:43 --> Total execution time: 0.0448
DEBUG - 2021-11-29 08:51:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:51:04 --> Total execution time: 0.0474
DEBUG - 2021-11-29 08:51:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:51:32 --> Total execution time: 0.0506
DEBUG - 2021-11-29 08:51:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:51:48 --> Total execution time: 0.0472
DEBUG - 2021-11-29 08:51:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 08:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 08:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 08:51:53 --> Total execution time: 0.0382
DEBUG - 2021-11-29 09:02:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:02:46 --> Total execution time: 0.0524
DEBUG - 2021-11-29 09:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 09:03:11 --> Query error: Column 'price' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `detail`, `more`, `price`, `date`, `place`) VALUES ('Farhan', 'After ', 'Paket 1', 'Akad_&_Resepsi', 'Video', 'Ahmad, Raffi', NULL, NULL, NULL)
DEBUG - 2021-11-29 09:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:04:54 --> Total execution time: 0.0398
DEBUG - 2021-11-29 09:04:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:04:55 --> Total execution time: 0.0462
DEBUG - 2021-11-29 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:05:16 --> Total execution time: 0.0265
DEBUG - 2021-11-29 09:08:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:08:07 --> Total execution time: 0.0415
DEBUG - 2021-11-29 09:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:08:51 --> Total execution time: 0.0445
DEBUG - 2021-11-29 09:09:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:09:59 --> Total execution time: 0.0507
DEBUG - 2021-11-29 09:19:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:19:21 --> Total execution time: 0.0473
DEBUG - 2021-11-29 09:20:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:20:15 --> Total execution time: 0.0479
DEBUG - 2021-11-29 09:20:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:20:45 --> Total execution time: 0.0434
DEBUG - 2021-11-29 09:26:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:26:20 --> Total execution time: 0.0459
DEBUG - 2021-11-29 09:26:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:26:45 --> Total execution time: 0.0490
DEBUG - 2021-11-29 09:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:27:39 --> Total execution time: 0.0431
DEBUG - 2021-11-29 09:27:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:27:44 --> Total execution time: 0.0470
DEBUG - 2021-11-29 09:28:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:28:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:28:14 --> Total execution time: 0.0452
DEBUG - 2021-11-29 09:29:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:29:03 --> Total execution time: 0.0507
DEBUG - 2021-11-29 09:42:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:42:47 --> Total execution time: 0.0441
DEBUG - 2021-11-29 09:46:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:46:14 --> Total execution time: 0.0292
DEBUG - 2021-11-29 09:46:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:46:29 --> Total execution time: 0.0277
DEBUG - 2021-11-29 09:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:46:45 --> Total execution time: 0.0434
DEBUG - 2021-11-29 09:47:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:47:06 --> Total execution time: 0.0424
DEBUG - 2021-11-29 09:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:47:18 --> Total execution time: 0.0420
DEBUG - 2021-11-29 09:59:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 09:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 09:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 09:59:23 --> Total execution time: 0.0464
DEBUG - 2021-11-29 10:00:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:00:18 --> Total execution time: 0.0288
DEBUG - 2021-11-29 10:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:00:56 --> Total execution time: 0.0408
DEBUG - 2021-11-29 10:01:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:01:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:01:03 --> Total execution time: 0.0279
DEBUG - 2021-11-29 10:01:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:01:12 --> Total execution time: 0.0291
DEBUG - 2021-11-29 10:02:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 10:02:31 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1471
ERROR - 2021-11-29 10:02:31 --> Severity: Warning --> Array to string conversion C:\xampp\htdocs\nesnu\system\database\DB_driver.php 1471
ERROR - 2021-11-29 10:02:31 --> Query error: Unknown column 'Array' in 'field list' - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `detail`, `more`, `price`, `date`, `place`) VALUES ('Farhan', 'After ', 'Paket 1', Array, Array, 'Ahmad,Raffi', 'Rp. 2.750.000', '2021-11-10', 'Braga')
DEBUG - 2021-11-29 10:06:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:06:45 --> Total execution time: 0.0488
DEBUG - 2021-11-29 10:06:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:06:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:06:45 --> Total execution time: 0.0416
DEBUG - 2021-11-29 10:06:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:06:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:06:46 --> Total execution time: 0.0471
DEBUG - 2021-11-29 10:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:38:59 --> Total execution time: 0.0296
DEBUG - 2021-11-29 10:39:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:39:02 --> Total execution time: 0.0417
DEBUG - 2021-11-29 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:39:02 --> Total execution time: 0.0277
DEBUG - 2021-11-29 10:40:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 10:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 10:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 10:40:19 --> Total execution time: 0.0415
DEBUG - 2021-11-29 11:01:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 11:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 11:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 11:01:13 --> Total execution time: 0.0543
DEBUG - 2021-11-29 11:01:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 11:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 11:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 11:01:37 --> Severity: error --> Exception: implode(): Argument #2 ($array) must be of type ?array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 33
DEBUG - 2021-11-29 11:57:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 11:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 11:57:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 11:57:36 --> Total execution time: 0.0494
DEBUG - 2021-11-29 11:57:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 11:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 11:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 11:57:37 --> Total execution time: 0.0508
DEBUG - 2021-11-29 12:00:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 12:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 12:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 12:00:38 --> Severity: Warning --> Undefined variable $description C:\xampp\htdocs\nesnu\application\views\appointment\index.php 26
ERROR - 2021-11-29 12:00:38 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 26
DEBUG - 2021-11-29 12:01:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 12:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 12:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 12:01:29 --> Severity: Warning --> Undefined variable $description C:\xampp\htdocs\nesnu\application\views\appointment\index.php 27
ERROR - 2021-11-29 12:01:29 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 27
DEBUG - 2021-11-29 12:01:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 12:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 12:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-29 12:01:29 --> Severity: Warning --> Undefined variable $description C:\xampp\htdocs\nesnu\application\views\appointment\index.php 27
ERROR - 2021-11-29 12:01:29 --> Severity: error --> Exception: Call to a member function result() on null C:\xampp\htdocs\nesnu\application\views\appointment\index.php 27
DEBUG - 2021-11-29 12:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 12:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 12:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 12:01:52 --> Total execution time: 0.0280
DEBUG - 2021-11-29 12:04:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-29 12:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-29 12:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-29 12:04:02 --> Total execution time: 0.0293
