<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-31 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:47:28 --> No URI present. Default controller set.
DEBUG - 2022-01-31 09:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:47:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 09:47:28 --> Total execution time: 0.0318
DEBUG - 2022-01-31 09:47:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:47:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-31 09:47:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-31 09:47:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:47:29 --> No URI present. Default controller set.
DEBUG - 2022-01-31 09:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:47:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 09:47:29 --> Total execution time: 0.0037
DEBUG - 2022-01-31 09:48:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:48:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 09:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:48:13 --> Total execution time: 0.0057
DEBUG - 2022-01-31 09:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:48:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-31 09:48:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 139764208 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-01-31 09:48:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:48:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 09:48:17 --> Total execution time: 0.0044
DEBUG - 2022-01-31 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 09:54:20 --> Total execution time: 0.0059
DEBUG - 2022-01-31 09:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:57:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 09:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 09:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 09:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 09:57:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 09:57:21 --> Total execution time: 0.0048
DEBUG - 2022-01-31 10:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:04:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:04:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:04:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:04:21 --> Total execution time: 0.0061
DEBUG - 2022-01-31 10:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:07:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:07:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:07:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:07:17 --> Total execution time: 0.0054
DEBUG - 2022-01-31 10:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:14:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:14:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:14:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:14:59 --> Total execution time: 0.0060
DEBUG - 2022-01-31 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:28:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:28:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:28:47 --> Total execution time: 0.0066
DEBUG - 2022-01-31 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:40:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:40:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:40:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:40:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:40:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:40:40 --> Total execution time: 0.0061
DEBUG - 2022-01-31 10:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:42:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:42:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:42:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:42:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:42:39 --> Total execution time: 0.0055
DEBUG - 2022-01-31 10:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:49:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:49:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:49:50 --> Total execution time: 0.0060
DEBUG - 2022-01-31 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:56:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:56:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 10:56:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 10:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 10:56:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 10:56:40 --> Total execution time: 0.0063
DEBUG - 2022-01-31 11:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-01-31 11:04:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-01-31 11:04:12 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-01-31 11:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 11:40:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 11:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 11:40:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 11:40:10 --> Total execution time: 0.0063
DEBUG - 2022-01-31 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 11:43:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 11:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 11:43:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 11:43:22 --> Total execution time: 0.0059
DEBUG - 2022-01-31 11:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 11:49:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 11:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 11:49:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 11:49:46 --> Total execution time: 0.0058
DEBUG - 2022-01-31 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 11:55:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 11:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 11:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 11:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 11:55:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 11:55:17 --> Total execution time: 0.0062
DEBUG - 2022-01-31 12:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 12:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 12:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 12:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 12:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 12:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 12:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 12:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 12:06:18 --> Total execution time: 0.0060
DEBUG - 2022-01-31 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 12:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 12:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 12:16:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 12:16:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 12:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 12:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 12:16:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 12:16:09 --> Total execution time: 0.0060
DEBUG - 2022-01-31 13:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:33:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:33:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:33:34 --> Total execution time: 0.0061
DEBUG - 2022-01-31 13:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:43:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:43:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:43:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:43:30 --> Total execution time: 0.0059
DEBUG - 2022-01-31 13:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:49:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:49:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:49:34 --> Total execution time: 0.0063
DEBUG - 2022-01-31 13:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:52:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:52:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:52:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:52:38 --> Total execution time: 0.0058
DEBUG - 2022-01-31 13:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:55:04 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-31 13:55:04 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-31 13:55:04 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Niputu Pratista & Daniel Hasana', '', '', NULL, '', '', '', '', '', '', '', '', '', '', '', 'Jakarta', '081', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-01-31 13:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:55:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:55:04 --> Total execution time: 0.0052
DEBUG - 2022-01-31 13:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:59:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 13:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 13:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 13:59:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 13:59:44 --> Total execution time: 0.0063
DEBUG - 2022-01-31 14:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:03:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:03:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:03:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:03:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:03:12 --> Total execution time: 0.0052
DEBUG - 2022-01-31 14:22:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:22:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:22:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:22:17 --> Total execution time: 0.0064
DEBUG - 2022-01-31 14:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:31:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:31:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:31:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:31:55 --> Total execution time: 0.0060
DEBUG - 2022-01-31 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:35:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:35:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:35:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:35:39 --> Total execution time: 0.0049
DEBUG - 2022-01-31 14:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:41:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:41:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:41:10 --> Total execution time: 0.0054
DEBUG - 2022-01-31 14:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:46:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:46:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:46:16 --> Total execution time: 0.0063
DEBUG - 2022-01-31 14:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:58:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 14:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 14:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 14:58:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 14:58:17 --> Total execution time: 0.0059
DEBUG - 2022-01-31 15:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 15:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 15:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 15:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 15:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 15:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 15:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:25:21 --> Total execution time: 0.0060
DEBUG - 2022-01-31 15:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 15:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 15:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 15:47:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:47:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 15:47:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 15:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 15:47:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:47:04 --> Total execution time: 0.0061
DEBUG - 2022-01-31 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 15:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 15:51:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:51:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 15:51:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 15:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 15:51:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:51:07 --> Total execution time: 0.0048
DEBUG - 2022-01-31 15:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 15:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 15:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 15:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 15:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 15:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 15:54:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 15:54:53 --> Total execution time: 0.0063
DEBUG - 2022-01-31 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:24:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:24:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:24:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:24:56 --> Total execution time: 0.0070
DEBUG - 2022-01-31 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:27:47 --> Total execution time: 0.0050
DEBUG - 2022-01-31 16:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:37:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:37:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:37:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:37:45 --> Total execution time: 0.0067
DEBUG - 2022-01-31 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:47:25 --> Total execution time: 0.0070
DEBUG - 2022-01-31 16:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:57:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-31 16:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-31 16:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-31 16:57:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-31 16:57:56 --> Total execution time: 0.0060
