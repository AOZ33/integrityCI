<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-16 03:25:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:25:40 --> No URI present. Default controller set.
DEBUG - 2021-12-16 03:25:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:25:40 --> Total execution time: 0.1304
DEBUG - 2021-12-16 03:25:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:25:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:25:42 --> Total execution time: 0.0796
DEBUG - 2021-12-16 03:25:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:25:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-16 03:25:45 --> 404 Page Not Found: Prewedding/index
DEBUG - 2021-12-16 03:25:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:25:46 --> Total execution time: 0.0466
DEBUG - 2021-12-16 03:25:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:25:47 --> Total execution time: 0.0625
DEBUG - 2021-12-16 03:48:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:48:23 --> Total execution time: 0.0389
DEBUG - 2021-12-16 03:48:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:48:41 --> Total execution time: 0.0624
DEBUG - 2021-12-16 03:49:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:49:09 --> Total execution time: 0.0403
DEBUG - 2021-12-16 03:50:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:50:45 --> Total execution time: 0.0291
DEBUG - 2021-12-16 03:51:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:51:48 --> Total execution time: 0.0414
DEBUG - 2021-12-16 03:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:52:26 --> Total execution time: 0.0349
DEBUG - 2021-12-16 03:52:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:52:27 --> Total execution time: 0.0495
DEBUG - 2021-12-16 03:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:52:28 --> Total execution time: 0.0276
DEBUG - 2021-12-16 03:52:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:52:29 --> Total execution time: 0.0314
DEBUG - 2021-12-16 03:52:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:52:30 --> Total execution time: 0.0374
DEBUG - 2021-12-16 03:52:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:52:42 --> Total execution time: 0.0490
DEBUG - 2021-12-16 03:52:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:52:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:52:44 --> Total execution time: 0.0441
DEBUG - 2021-12-16 03:56:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 03:56:17 --> Query error: Unknown column 'date_m' in 'field list' - Invalid query: INSERT INTO `acara` (`name`, `date_l`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Dita. A & Yudi', NULL, '2021-12-15', '2021-12-31', 'Rogen,Djodi', 'PHOTO', 'dgsgfhddgh')
DEBUG - 2021-12-16 03:57:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:57:45 --> Total execution time: 0.0482
DEBUG - 2021-12-16 03:57:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 03:57:47 --> Total execution time: 0.0488
DEBUG - 2021-12-16 03:57:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 03:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 03:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 03:57:59 --> Query error: Unknown column 'date_w' in 'field list' - Invalid query: INSERT INTO `acara` (`name`, `date_w`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Dita. A & Yudi', '2015-02-01', '2021-12-15', '2021-12-31', 'Rogen,Djodi', 'PHOTO', 'sdasdasd')
DEBUG - 2021-12-16 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:00:03 --> Total execution time: 0.0483
DEBUG - 2021-12-16 04:00:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:00:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:00:04 --> Total execution time: 0.0295
DEBUG - 2021-12-16 04:00:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:00:17 --> Query error: Unknown column 'date_w' in 'field list' - Invalid query: INSERT INTO `acara` (`name`, `date_w`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Dita. A & Yudi', NULL, '2021-12-13', '2021-12-31', 'Rogen', 'PHOTO', 'dsadasd')
DEBUG - 2021-12-16 04:01:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:01:09 --> Total execution time: 0.0438
DEBUG - 2021-12-16 04:01:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:01:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:01:10 --> Total execution time: 0.0435
DEBUG - 2021-12-16 04:01:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:01:19 --> Query error: Unknown column 'editor' in 'field list' - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Dita. A & Yudi', NULL, '2021-12-07', '2021-12-31', 'Rogen', 'PHOTO', 'dadsasd')
DEBUG - 2021-12-16 04:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:03:40 --> Total execution time: 0.0510
DEBUG - 2021-12-16 04:03:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:03:41 --> Total execution time: 0.0445
DEBUG - 2021-12-16 04:04:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:04:02 --> Query error: Column 'date_w' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Dita. A & Yudi', NULL, '2021-12-07', '2021-12-31', 'Djodi', 'PHOTO', 'dsadasd')
DEBUG - 2021-12-16 04:04:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:04:19 --> Total execution time: 0.0554
DEBUG - 2021-12-16 04:04:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:04:21 --> Total execution time: 0.0288
DEBUG - 2021-12-16 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:04:29 --> Total execution time: 0.0462
DEBUG - 2021-12-16 04:09:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:09:33 --> Total execution time: 0.0413
DEBUG - 2021-12-16 04:10:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:10:49 --> Total execution time: 0.0471
DEBUG - 2021-12-16 04:10:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:10:53 --> Total execution time: 0.0464
DEBUG - 2021-12-16 04:10:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:10:53 --> Total execution time: 0.0391
DEBUG - 2021-12-16 04:30:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:30:13 --> Total execution time: 0.0470
DEBUG - 2021-12-16 04:30:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:30:15 --> Severity: error --> Exception: Unable to locate the model you have specified: Prewedding_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-16 04:30:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:30:51 --> Total execution time: 0.0486
DEBUG - 2021-12-16 04:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:30:52 --> Severity: error --> Exception: Unable to locate the model you have specified: Prewedding_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-16 04:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:30:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Prewedding_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-16 04:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:30:53 --> Severity: error --> Exception: Unable to locate the model you have specified: Prewedding_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-16 04:31:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined array key "place_l" C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 56
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined array key "place_l" C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 56
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined array key "place_l" C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 56
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined array key "place_l" C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 56
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:31:44 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
DEBUG - 2021-12-16 04:31:44 --> Total execution time: 0.0574
DEBUG - 2021-12-16 04:32:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined array key "place_l" C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 56
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined array key "place_l" C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 56
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined array key "place_l" C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 56
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined array key "place_l" C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 56
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:02 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
DEBUG - 2021-12-16 04:32:02 --> Total execution time: 0.0710
DEBUG - 2021-12-16 04:32:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:32:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 62
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 64
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 65
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
ERROR - 2021-12-16 04:32:07 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 66
DEBUG - 2021-12-16 04:32:07 --> Total execution time: 0.0816
DEBUG - 2021-12-16 04:32:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:32:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 59
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 60
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Undefined variable $ap C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
ERROR - 2021-12-16 04:32:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 61
DEBUG - 2021-12-16 04:32:23 --> Total execution time: 0.0657
DEBUG - 2021-12-16 04:32:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:32:44 --> Total execution time: 0.0492
DEBUG - 2021-12-16 04:36:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:36:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:36:40 --> Severity: error --> Exception: Cannot access offset of type string on string C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 75
DEBUG - 2021-12-16 04:36:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:36:42 --> Total execution time: 0.0400
DEBUG - 2021-12-16 04:36:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:36:43 --> Total execution time: 0.0449
DEBUG - 2021-12-16 04:36:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:36:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:36:45 --> Severity: error --> Exception: Cannot access offset of type string on string C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 75
DEBUG - 2021-12-16 04:37:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:37:37 --> Severity: error --> Exception: Cannot access offset of type string on string C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 75
DEBUG - 2021-12-16 04:38:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:38:38 --> Total execution time: 0.0478
DEBUG - 2021-12-16 04:39:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:39:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:39:01 --> Severity: Warning --> Undefined variable $appointment C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 74
ERROR - 2021-12-16 04:39:01 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 74
DEBUG - 2021-12-16 04:39:01 --> Total execution time: 0.0420
DEBUG - 2021-12-16 04:39:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:39:09 --> Severity: error --> Exception: Cannot access offset of type string on string C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 75
DEBUG - 2021-12-16 04:39:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 04:39:14 --> Total execution time: 0.0512
DEBUG - 2021-12-16 04:39:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:39:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:39:17 --> Severity: error --> Exception: Cannot access offset of type string on string C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 75
DEBUG - 2021-12-16 04:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:39:35 --> Severity: Warning --> Undefined variable $appointment C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 74
ERROR - 2021-12-16 04:39:35 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 74
DEBUG - 2021-12-16 04:39:36 --> Total execution time: 0.0455
DEBUG - 2021-12-16 04:40:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 04:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 04:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 04:40:46 --> Severity: Warning --> Undefined variable $appointment C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 74
ERROR - 2021-12-16 04:40:46 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\prewedding\index.php 74
DEBUG - 2021-12-16 04:40:46 --> Total execution time: 0.0419
DEBUG - 2021-12-16 05:05:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 05:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 05:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 05:05:04 --> Total execution time: 0.0280
DEBUG - 2021-12-16 05:05:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 05:05:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 05:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 05:05:38 --> Total execution time: 0.0493
DEBUG - 2021-12-16 07:01:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 07:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 07:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 07:01:17 --> Total execution time: 0.0466
DEBUG - 2021-12-16 07:42:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 07:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 07:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 07:42:43 --> Total execution time: 0.0461
DEBUG - 2021-12-16 07:42:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 07:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 07:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 07:42:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 07:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 07:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 07:42:48 --> Total execution time: 0.0290
DEBUG - 2021-12-16 07:42:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 07:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 07:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 07:42:50 --> Total execution time: 0.0262
DEBUG - 2021-12-16 07:43:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 07:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 07:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 07:43:08 --> Total execution time: 0.0493
DEBUG - 2021-12-16 07:43:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 07:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 07:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 07:43:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 07:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 07:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 07:43:11 --> Total execution time: 0.0270
DEBUG - 2021-12-16 08:00:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:00:38 --> Total execution time: 0.0409
DEBUG - 2021-12-16 08:05:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:05:06 --> Total execution time: 0.0522
DEBUG - 2021-12-16 08:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:05:19 --> Total execution time: 0.0498
DEBUG - 2021-12-16 08:05:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:05:37 --> Total execution time: 0.0256
DEBUG - 2021-12-16 08:06:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:06:19 --> Total execution time: 0.0396
DEBUG - 2021-12-16 08:07:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:07:23 --> Total execution time: 0.0397
DEBUG - 2021-12-16 08:07:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:07:51 --> Total execution time: 0.0451
DEBUG - 2021-12-16 08:08:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:08:05 --> Total execution time: 0.0504
DEBUG - 2021-12-16 08:14:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:14:06 --> Total execution time: 0.0459
DEBUG - 2021-12-16 08:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:15:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-16 08:15:05 --> 404 Page Not Found: Preweding/spk_edit
DEBUG - 2021-12-16 08:15:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:15:07 --> Total execution time: 0.0369
DEBUG - 2021-12-16 08:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:40:22 --> Total execution time: 0.0435
DEBUG - 2021-12-16 08:40:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:40:48 --> Total execution time: 0.0465
DEBUG - 2021-12-16 08:45:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:45:45 --> Total execution time: 0.0285
DEBUG - 2021-12-16 08:49:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:49:29 --> Total execution time: 0.0268
DEBUG - 2021-12-16 08:49:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:49:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-16 08:49:39 --> 404 Page Not Found: Preweding/spk_edit
DEBUG - 2021-12-16 08:49:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:49:54 --> Total execution time: 0.0261
DEBUG - 2021-12-16 08:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:49:54 --> Total execution time: 0.0487
DEBUG - 2021-12-16 08:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 08:50:04 --> Severity: Warning --> Undefined property: Prewedding::$Spk_model C:\xampp\htdocs\nesnu\application\controllers\prewedding.php 46
ERROR - 2021-12-16 08:50:04 --> Severity: error --> Exception: Call to a member function spk_prewed() on null C:\xampp\htdocs\nesnu\application\controllers\prewedding.php 46
DEBUG - 2021-12-16 08:50:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:50:58 --> Total execution time: 0.0484
DEBUG - 2021-12-16 08:51:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:51:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:51:04 --> Total execution time: 0.0458
DEBUG - 2021-12-16 08:51:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 08:51:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 08:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 08:51:10 --> Total execution time: 0.0449
DEBUG - 2021-12-16 09:30:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:30:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:30:36 --> Total execution time: 0.0399
DEBUG - 2021-12-16 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:30:41 --> Total execution time: 0.0443
DEBUG - 2021-12-16 09:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:30:42 --> Total execution time: 0.0490
DEBUG - 2021-12-16 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:41:09 --> Total execution time: 0.0576
DEBUG - 2021-12-16 09:43:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:43:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:43:38 --> Total execution time: 0.0307
DEBUG - 2021-12-16 09:43:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:43:40 --> Total execution time: 0.0436
DEBUG - 2021-12-16 09:44:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:44:51 --> Total execution time: 0.0413
DEBUG - 2021-12-16 09:45:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:45:45 --> Total execution time: 0.0433
DEBUG - 2021-12-16 09:45:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:45:46 --> Total execution time: 0.0518
DEBUG - 2021-12-16 09:46:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:46:25 --> Total execution time: 0.0309
DEBUG - 2021-12-16 09:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:47:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:47:08 --> Total execution time: 0.0436
DEBUG - 2021-12-16 09:47:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:47:34 --> Total execution time: 0.0297
DEBUG - 2021-12-16 09:48:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:03 --> Total execution time: 0.0303
DEBUG - 2021-12-16 09:48:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:23 --> Total execution time: 0.0393
DEBUG - 2021-12-16 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:27 --> Total execution time: 0.0438
DEBUG - 2021-12-16 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:29 --> Total execution time: 0.0365
DEBUG - 2021-12-16 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:48:31 --> Total execution time: 0.0568
DEBUG - 2021-12-16 09:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:53:34 --> Total execution time: 0.0524
DEBUG - 2021-12-16 09:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:53:36 --> Total execution time: 0.0525
DEBUG - 2021-12-16 09:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:56:08 --> Total execution time: 0.0257
DEBUG - 2021-12-16 09:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:56:08 --> Total execution time: 0.0388
DEBUG - 2021-12-16 09:56:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:56:11 --> Total execution time: 0.0360
DEBUG - 2021-12-16 09:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:56:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:56:57 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
DEBUG - 2021-12-16 09:56:57 --> Total execution time: 0.0553
DEBUG - 2021-12-16 09:57:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:57:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:57:07 --> Total execution time: 0.0452
DEBUG - 2021-12-16 09:57:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:57:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:57:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:57:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:57:11 --> Total execution time: 0.0386
DEBUG - 2021-12-16 09:57:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:57:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 299
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 300
ERROR - 2021-12-16 09:57:12 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 301
DEBUG - 2021-12-16 09:57:12 --> Total execution time: 0.0763
DEBUG - 2021-12-16 09:59:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:59:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:59:05 --> Total execution time: 0.0459
DEBUG - 2021-12-16 09:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 09:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 09:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 09:59:07 --> Total execution time: 0.0465
DEBUG - 2021-12-16 10:00:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:00:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:00:38 --> Total execution time: 0.0489
DEBUG - 2021-12-16 10:00:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 56
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 57
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 78
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 79
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 222
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 223
ERROR - 2021-12-16 10:00:39 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
DEBUG - 2021-12-16 10:00:39 --> Total execution time: 0.0624
DEBUG - 2021-12-16 10:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 81
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 82
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 81
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 82
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 81
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 82
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 81
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 82
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 80
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 81
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 82
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 224
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:00:56 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
DEBUG - 2021-12-16 10:00:56 --> Total execution time: 0.0548
DEBUG - 2021-12-16 10:03:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:03:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\wedding\index.php 113
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\wedding\index.php 114
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\wedding\index.php 121
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\wedding\index.php 113
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\wedding\index.php 114
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\wedding\index.php 121
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\wedding\index.php 113
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\wedding\index.php 114
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\wedding\index.php 121
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\wedding\index.php 113
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\wedding\index.php 114
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\wedding\index.php 121
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\wedding\index.php 113
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\wedding\index.php 114
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\wedding\index.php 121
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 227
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 227
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 227
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 227
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 225
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 226
ERROR - 2021-12-16 10:03:17 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\wedding\index.php 227
DEBUG - 2021-12-16 10:03:17 --> Total execution time: 0.0434
DEBUG - 2021-12-16 10:05:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:46 --> Total execution time: 0.0477
DEBUG - 2021-12-16 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:52 --> Total execution time: 0.0430
DEBUG - 2021-12-16 10:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:54 --> Total execution time: 0.0426
DEBUG - 2021-12-16 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:56 --> Total execution time: 0.0426
DEBUG - 2021-12-16 10:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:05:58 --> Total execution time: 0.0255
DEBUG - 2021-12-16 10:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 10:06:04 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\wedding.php 28
DEBUG - 2021-12-16 10:06:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:06:06 --> Total execution time: 0.0422
DEBUG - 2021-12-16 10:06:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-16 10:06:13 --> Query error: Unknown column 'date' in 'field list' - Invalid query: UPDATE `wedding` SET `name` = 'Fanie & Graha', `phone` = '082126036382', `date` = NULL, `place_p` = NULL, `w_prewed` = NULL, `photograper` = 'Ardi', `videograper` = 'Gian', `crew` = 'Kewong', `note` = 'sdasdasd'
WHERE `id` = '5'
DEBUG - 2021-12-16 10:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:07:01 --> Total execution time: 0.0268
DEBUG - 2021-12-16 10:07:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:07:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-16 10:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-16 10:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-16 10:07:07 --> Total execution time: 0.0438
