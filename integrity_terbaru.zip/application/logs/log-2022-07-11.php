<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-11 15:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 15:36:44 --> No URI present. Default controller set.
DEBUG - 2022-07-11 15:36:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 15:36:44 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 15:36:44 --> Unable to connect to the database
DEBUG - 2022-07-11 15:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 15:36:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 15:36:45 --> Total execution time: 0.7390
DEBUG - 2022-07-11 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 15:36:45 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 15:36:45 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 15:36:45 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 15:36:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 15:36:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 15:36:45 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 15:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 15:42:13 --> No URI present. Default controller set.
DEBUG - 2022-07-11 15:42:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 15:42:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 15:42:13 --> Unable to connect to the database
DEBUG - 2022-07-11 15:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 15:42:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 15:42:13 --> Total execution time: 0.0671
DEBUG - 2022-07-11 16:03:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:03:55 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:03:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:03:55 --> Severity: error --> Exception: Call to a member function library() on null D:\xampp\htdocs\integrity\application\controllers\Auth.php 9
DEBUG - 2022-07-11 16:03:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:03:57 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:03:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:03:57 --> Severity: error --> Exception: Call to a member function library() on null D:\xampp\htdocs\integrity\application\controllers\Auth.php 9
DEBUG - 2022-07-11 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:06 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:06 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:06 --> Total execution time: 0.0406
DEBUG - 2022-07-11 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:06 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:06 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:06 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:06 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:07 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:07 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:07 --> Total execution time: 0.0402
DEBUG - 2022-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:07 --> 404 Page Not Found: Js/jquery.min.js
ERROR - 2022-07-11 16:04:07 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:07 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:07 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:07 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:07 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:07 --> Total execution time: 0.0421
DEBUG - 2022-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:07 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:07 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:07 --> Total execution time: 0.0507
DEBUG - 2022-07-11 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:07 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:07 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:07 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:07 --> Total execution time: 0.0473
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-07-11 16:04:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:08 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:04:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:08 --> Total execution time: 0.0852
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:08 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:08 --> Total execution time: 0.0391
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:04:08 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:08 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:08 --> Total execution time: 0.0786
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:04:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:08 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:04:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:04:43 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:04:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:04:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:04:43 --> Unable to connect to the database
DEBUG - 2022-07-11 16:04:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:04:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:04:43 --> Total execution time: 0.0419
DEBUG - 2022-07-11 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:08:26 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:08:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:08:26 --> Unable to connect to the database
DEBUG - 2022-07-11 16:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:08:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:08:26 --> Total execution time: 0.0548
DEBUG - 2022-07-11 16:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:13:13 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:13:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'root'@'localhost' (using password: YES) D:\xampp\htdocs\integrity\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2022-07-11 16:13:13 --> Unable to connect to the database
DEBUG - 2022-07-11 16:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:13:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:13:13 --> Total execution time: 0.0421
DEBUG - 2022-07-11 16:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:13:13 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:13:13 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:13:13 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:13:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:13:13 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:32:28 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:32:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:32:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:32:28 --> Total execution time: 0.3484
DEBUG - 2022-07-11 16:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:32:28 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:32:28 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:32:28 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:32:28 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:32:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:32:28 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:33:08 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:08 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:33:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:33:08 --> Total execution time: 0.0713
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Localhost/integrity
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:09 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:09 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:10 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:30 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:33:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:33:30 --> Total execution time: 0.0582
DEBUG - 2022-07-11 16:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:30 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:31 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:32 --> 404 Page Not Found: Localhost/integrity
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:33:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:33:48 --> Total execution time: 0.1468
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:48 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:49 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:33:49 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:33:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:33:49 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:55 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:38:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:38:56 --> Total execution time: 0.0382
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Js/bootstrap.min.js
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:56 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:38:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:38:59 --> Total execution time: 0.0385
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Localhost/assets
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Js/jquery.min.js
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:38:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:38:59 --> 404 Page Not Found: Localhost/assets
DEBUG - 2022-07-11 16:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:40:02 --> No URI present. Default controller set.
DEBUG - 2022-07-11 16:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:40:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:40:02 --> Total execution time: 0.0694
DEBUG - 2022-07-11 16:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:40:02 --> UTF-8 Support Enabled
ERROR - 2022-07-11 16:40:02 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 16:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:40:02 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 16:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:40:02 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 16:40:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 16:40:02 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 16:40:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:40:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:40:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:40:14 --> Total execution time: 0.5776
DEBUG - 2022-07-11 16:40:26 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:40:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:40:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:40:26 --> Total execution time: 0.1329
DEBUG - 2022-07-11 16:40:32 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:40:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:40:33 --> Total execution time: 0.4800
DEBUG - 2022-07-11 16:58:45 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:58:45 --> Total execution time: 0.1155
DEBUG - 2022-07-11 16:58:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:58:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:58:46 --> Total execution time: 0.2761
DEBUG - 2022-07-11 16:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:58:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 16:58:51 --> Total execution time: 0.1957
DEBUG - 2022-07-11 16:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:58:59 --> Total execution time: 0.2084
DEBUG - 2022-07-11 16:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 16:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 16:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 16:59:06 --> Total execution time: 0.2076
DEBUG - 2022-07-11 17:08:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:08:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 17:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 17:08:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 17:08:48 --> Total execution time: 0.1298
DEBUG - 2022-07-11 17:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 17:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 17:08:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 17:08:50 --> Total execution time: 0.0579
DEBUG - 2022-07-11 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 17:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 17:09:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 17:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 17:09:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 17:09:13 --> Total execution time: 0.0381
DEBUG - 2022-07-11 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 17:09:13 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-07-11 17:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 17:09:13 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-07-11 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 17:09:13 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-07-11 17:09:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-11 17:09:13 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-07-11 17:09:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 17:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 17:09:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-11 17:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-11 17:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-11 17:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-11 17:09:34 --> Total execution time: 0.2619
