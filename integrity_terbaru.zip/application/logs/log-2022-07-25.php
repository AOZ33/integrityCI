<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-25 05:00:57 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:00:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:00:57 --> Total execution time: 0.1616
DEBUG - 2022-07-25 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:36:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:36:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:36:29 --> Total execution time: 0.1324
DEBUG - 2022-07-25 05:36:29 --> Total execution time: 0.1118
DEBUG - 2022-07-25 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:36:29 --> UTF-8 Support Enabled
ERROR - 2022-07-25 05:36:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-25 05:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-25 05:36:29 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-25 05:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-25 05:36:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-25 05:36:29 --> UTF-8 Support Enabled
ERROR - 2022-07-25 05:36:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-25 05:36:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-25 05:36:29 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-25 05:36:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-25 05:36:29 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-25 05:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:36:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:36:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:36:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:36:34 --> Total execution time: 0.1060
DEBUG - 2022-07-25 05:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:13 --> Total execution time: 0.1270
DEBUG - 2022-07-25 05:45:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:29 --> Total execution time: 0.1405
DEBUG - 2022-07-25 05:45:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:34 --> Total execution time: 0.1524
DEBUG - 2022-07-25 05:45:42 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:42 --> Total execution time: 0.1304
DEBUG - 2022-07-25 05:45:43 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:43 --> Total execution time: 0.1098
DEBUG - 2022-07-25 05:45:46 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:46 --> Total execution time: 0.1322
DEBUG - 2022-07-25 05:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:48 --> Total execution time: 0.1795
DEBUG - 2022-07-25 05:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:45:50 --> Total execution time: 0.1686
DEBUG - 2022-07-25 05:45:54 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:45:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:45:54 --> Total execution time: 0.1057
DEBUG - 2022-07-25 05:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:46:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:46:29 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 05:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 05:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 05:46:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 05:46:29 --> Total execution time: 0.0958
DEBUG - 2022-07-25 07:45:44 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 07:45:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 07:45:45 --> Total execution time: 0.1159
DEBUG - 2022-07-25 07:45:48 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 07:45:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 07:45:48 --> Total execution time: 0.1012
DEBUG - 2022-07-25 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 07:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 07:45:55 --> Total execution time: 0.0948
DEBUG - 2022-07-25 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:45:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-25 07:45:56 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-25 07:45:56 --> 404 Page Not Found: Auth/css
DEBUG - 2022-07-25 07:45:56 --> UTF-8 Support Enabled
ERROR - 2022-07-25 07:45:56 --> 404 Page Not Found: Auth/js
DEBUG - 2022-07-25 07:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-25 07:45:56 --> 404 Page Not Found: Auth/vendor
ERROR - 2022-07-25 07:45:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-25 07:45:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-07-25 07:45:56 --> 404 Page Not Found: Auth/vendor
DEBUG - 2022-07-25 07:46:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:46:34 --> No URI present. Default controller set.
DEBUG - 2022-07-25 07:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 07:46:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 07:46:34 --> Total execution time: 0.1246
DEBUG - 2022-07-25 07:48:23 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:48:23 --> No URI present. Default controller set.
DEBUG - 2022-07-25 07:48:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 07:48:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 07:48:23 --> Total execution time: 0.2270
DEBUG - 2022-07-25 07:48:33 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:48:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 07:48:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-25 07:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-07-25 07:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-25 07:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-25 07:48:34 --> Total execution time: 0.1011
