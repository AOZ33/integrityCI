<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-17 03:10:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:21 --> No URI present. Default controller set.
DEBUG - 2021-11-17 03:10:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:21 --> Total execution time: 0.1466
DEBUG - 2021-11-17 03:10:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:23 --> Total execution time: 0.0578
DEBUG - 2021-11-17 03:10:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:25 --> Total execution time: 0.0546
DEBUG - 2021-11-17 03:10:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:26 --> Total execution time: 0.0461
DEBUG - 2021-11-17 03:10:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:27 --> Total execution time: 0.0461
DEBUG - 2021-11-17 03:10:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:29 --> Total execution time: 0.0390
DEBUG - 2021-11-17 03:10:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:30 --> Total execution time: 0.0374
DEBUG - 2021-11-17 03:10:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:10:32 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:10:32 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:10:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:10:38 --> Total execution time: 0.0366
DEBUG - 2021-11-17 03:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:13:54 --> Total execution time: 0.0403
DEBUG - 2021-11-17 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:13:55 --> Total execution time: 0.0571
DEBUG - 2021-11-17 03:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:13:55 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:13:55 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:14:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 03:14:11 --> Total execution time: 0.0443
DEBUG - 2021-11-17 03:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:16 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:41:16 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:41:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:19 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:41:19 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:41:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:41:20 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:41:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:41:20 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:41:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:41:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:20 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:41:20 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:41:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:41:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:21 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:41:21 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:41:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:23 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:41:23 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 03:41:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 03:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 03:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 03:41:29 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 03:41:29 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:01:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:01:22 --> No URI present. Default controller set.
DEBUG - 2021-11-17 04:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:01:22 --> Total execution time: 0.0288
DEBUG - 2021-11-17 04:01:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:01:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:01:24 --> Total execution time: 0.0258
DEBUG - 2021-11-17 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:01:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:01:25 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:02:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:12 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:02:12 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:02:48 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:02:48 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:02:48 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: id C:\xampp\htdocs\nesnu\application\views\customer\index.php 52
ERROR - 2021-11-17 04:02:48 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:02:48 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:08:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:08:06 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:08:06 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:10:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:10:37 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:10:37 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:10:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:10:38 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
ERROR - 2021-11-17 04:10:38 --> Severity: error --> Exception: Call to a member function result_array() on null C:\xampp\htdocs\nesnu\application\views\customer\index.php 97
DEBUG - 2021-11-17 04:12:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:12:08 --> Total execution time: 0.0464
DEBUG - 2021-11-17 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:15:04 --> Total execution time: 0.0434
DEBUG - 2021-11-17 04:15:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:15:26 --> Query error: Table 'admin_nesnu.orang' doesn't exist - Invalid query: UPDATE `orang` SET `name` = 'Ade lala', `telephone` = '089764321123', `email` = 'ade@gmail.com'
WHERE `id` = '12'
DEBUG - 2021-11-17 04:15:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:15:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:15:52 --> Total execution time: 0.0420
DEBUG - 2021-11-17 04:15:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:15:55 --> Total execution time: 0.0443
DEBUG - 2021-11-17 04:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:16:02 --> Total execution time: 0.0320
DEBUG - 2021-11-17 04:18:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:18:15 --> Total execution time: 0.0402
DEBUG - 2021-11-17 04:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:18:50 --> Total execution time: 0.0408
DEBUG - 2021-11-17 04:18:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:18:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:18:57 --> Total execution time: 0.0544
DEBUG - 2021-11-17 04:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:20:38 --> Total execution time: 0.0470
DEBUG - 2021-11-17 04:21:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:21:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:21:32 --> Total execution time: 0.0575
DEBUG - 2021-11-17 04:26:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:26:59 --> Total execution time: 0.0387
DEBUG - 2021-11-17 04:27:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:27:03 --> Severity: error --> Exception: Too few arguments to function Customer::hapus(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 04:30:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:30:39 --> Total execution time: 0.0449
DEBUG - 2021-11-17 04:30:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:30:40 --> Total execution time: 0.0517
DEBUG - 2021-11-17 04:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:31:37 --> Total execution time: 0.0502
DEBUG - 2021-11-17 04:33:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:33:10 --> Total execution time: 0.0485
DEBUG - 2021-11-17 04:33:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:33:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:33:20 --> Total execution time: 0.0462
DEBUG - 2021-11-17 04:33:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:33:34 --> Total execution time: 0.0383
DEBUG - 2021-11-17 04:33:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:33:41 --> Total execution time: 0.0463
DEBUG - 2021-11-17 04:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:34:41 --> Total execution time: 0.0522
DEBUG - 2021-11-17 04:38:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:38:13 --> Total execution time: 0.0503
DEBUG - 2021-11-17 04:38:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:38:20 --> Severity: error --> Exception: Too few arguments to function Customer::hapus(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 04:39:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:39:34 --> Total execution time: 0.0462
DEBUG - 2021-11-17 04:39:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:39:36 --> Total execution time: 0.0467
DEBUG - 2021-11-17 04:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:39:41 --> Severity: error --> Exception: Too few arguments to function Customer::hapus(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 04:43:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:43:17 --> Total execution time: 0.0451
DEBUG - 2021-11-17 04:43:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:43:17 --> Total execution time: 0.0461
DEBUG - 2021-11-17 04:43:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:43:21 --> Severity: error --> Exception: Too few arguments to function Customer::hapus(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 04:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:46:19 --> Total execution time: 0.0665
DEBUG - 2021-11-17 04:46:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:46:20 --> Total execution time: 0.0467
DEBUG - 2021-11-17 04:46:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:46:21 --> Total execution time: 0.0512
DEBUG - 2021-11-17 04:46:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:46:23 --> Severity: error --> Exception: Too few arguments to function Customer::hapus(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 04:48:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:48:07 --> Total execution time: 0.0283
DEBUG - 2021-11-17 04:48:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:48:08 --> Total execution time: 0.0379
DEBUG - 2021-11-17 04:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:48:10 --> Severity: error --> Exception: Too few arguments to function Customer::hapus(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 04:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:33 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:34 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
DEBUG - 2021-11-17 04:53:34 --> Total execution time: 0.0932
DEBUG - 2021-11-17 04:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:53:35 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
DEBUG - 2021-11-17 04:53:35 --> Total execution time: 0.0920
DEBUG - 2021-11-17 04:54:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:54:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:54:18 --> Total execution time: 0.0290
DEBUG - 2021-11-17 04:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:54:20 --> Severity: error --> Exception: Too few arguments to function Customer::hapus(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 04:56:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:24 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
DEBUG - 2021-11-17 04:56:24 --> Total execution time: 0.0833
DEBUG - 2021-11-17 04:56:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:56:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
ERROR - 2021-11-17 04:56:25 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\customer\index.php 168
DEBUG - 2021-11-17 04:56:25 --> Total execution time: 0.0900
DEBUG - 2021-11-17 04:56:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:56:47 --> Total execution time: 0.0502
DEBUG - 2021-11-17 04:56:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:56:49 --> Severity: error --> Exception: Too few arguments to function Customer::hapus_data(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 04:59:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:59:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:59:40 --> Total execution time: 0.0601
DEBUG - 2021-11-17 04:59:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 04:59:41 --> Total execution time: 0.0386
DEBUG - 2021-11-17 04:59:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 04:59:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 04:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 04:59:43 --> Severity: error --> Exception: Too few arguments to function Customer::hapus_data(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\customer.php 50
DEBUG - 2021-11-17 05:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:08:56 --> Total execution time: 0.0432
DEBUG - 2021-11-17 05:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:08:56 --> Total execution time: 0.0520
DEBUG - 2021-11-17 05:09:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:09:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:09:04 --> Total execution time: 0.0446
DEBUG - 2021-11-17 05:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:09:36 --> Total execution time: 0.0450
DEBUG - 2021-11-17 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:11:10 --> Total execution time: 0.0512
DEBUG - 2021-11-17 05:11:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:11:23 --> Total execution time: 0.0376
DEBUG - 2021-11-17 05:11:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:11:30 --> Total execution time: 0.0501
DEBUG - 2021-11-17 05:11:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:11:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:11:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:11:36 --> Total execution time: 0.0408
DEBUG - 2021-11-17 05:11:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:11:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:11:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:11:42 --> Total execution time: 0.0419
DEBUG - 2021-11-17 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:12:00 --> Total execution time: 0.0409
DEBUG - 2021-11-17 05:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:12:22 --> Total execution time: 0.0271
DEBUG - 2021-11-17 05:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:13:40 --> Total execution time: 0.0278
DEBUG - 2021-11-17 05:13:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:13:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:13:51 --> Total execution time: 0.0370
DEBUG - 2021-11-17 05:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:14:13 --> Total execution time: 0.0389
DEBUG - 2021-11-17 05:14:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:14:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:14:17 --> Total execution time: 0.0415
DEBUG - 2021-11-17 05:15:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:15:18 --> Total execution time: 0.0415
DEBUG - 2021-11-17 05:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:18:53 --> Total execution time: 0.0452
DEBUG - 2021-11-17 05:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 05:19:54 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-17 05:19:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-17 05:19:54 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-17 05:19:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-17 05:19:54 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 152
ERROR - 2021-11-17 05:19:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 152
DEBUG - 2021-11-17 05:19:54 --> Total execution time: 0.0476
DEBUG - 2021-11-17 05:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:45:53 --> Total execution time: 0.0478
DEBUG - 2021-11-17 05:45:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:45:56 --> Total execution time: 0.0523
DEBUG - 2021-11-17 05:46:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:46:25 --> Total execution time: 0.0431
DEBUG - 2021-11-17 05:47:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:47:23 --> Total execution time: 0.0520
DEBUG - 2021-11-17 05:47:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 05:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 05:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 05:47:25 --> Total execution time: 0.0484
DEBUG - 2021-11-17 06:03:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:03:41 --> Total execution time: 0.0310
DEBUG - 2021-11-17 06:03:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:03:43 --> Total execution time: 0.0431
DEBUG - 2021-11-17 06:05:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:05:43 --> Total execution time: 0.0373
DEBUG - 2021-11-17 06:05:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:05:44 --> Total execution time: 0.0378
DEBUG - 2021-11-17 06:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:05:45 --> Total execution time: 0.0394
DEBUG - 2021-11-17 06:05:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:05:51 --> Total execution time: 0.0482
DEBUG - 2021-11-17 06:07:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:07:55 --> Total execution time: 0.0525
DEBUG - 2021-11-17 06:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:07:58 --> Total execution time: 0.0430
DEBUG - 2021-11-17 06:11:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:11:10 --> Total execution time: 0.0422
DEBUG - 2021-11-17 06:11:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:11:10 --> Total execution time: 0.0479
DEBUG - 2021-11-17 06:11:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:11:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:11:12 --> Total execution time: 0.0422
DEBUG - 2021-11-17 06:19:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:19:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:19:28 --> Total execution time: 0.0462
DEBUG - 2021-11-17 06:19:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:19:30 --> Total execution time: 0.0362
DEBUG - 2021-11-17 06:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:19:32 --> Total execution time: 0.0374
DEBUG - 2021-11-17 06:20:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:20:56 --> Total execution time: 0.0478
DEBUG - 2021-11-17 06:20:57 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:20:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:20:57 --> Total execution time: 0.0429
DEBUG - 2021-11-17 06:43:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:43:05 --> Total execution time: 0.0455
DEBUG - 2021-11-17 06:43:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:43:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:43:06 --> Total execution time: 0.0501
DEBUG - 2021-11-17 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:43:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:43:10 --> Total execution time: 0.0278
DEBUG - 2021-11-17 06:43:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:43:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:43:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:43:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:43:28 --> Total execution time: 0.0431
DEBUG - 2021-11-17 06:44:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:44:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:44:09 --> Total execution time: 0.0426
DEBUG - 2021-11-17 06:44:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:44:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 06:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 06:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 06:44:13 --> Total execution time: 0.0280
DEBUG - 2021-11-17 08:18:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:18:44 --> No URI present. Default controller set.
DEBUG - 2021-11-17 08:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:18:44 --> Total execution time: 0.0486
DEBUG - 2021-11-17 08:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:18:45 --> Total execution time: 0.0403
DEBUG - 2021-11-17 08:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:18:50 --> Total execution time: 0.0271
DEBUG - 2021-11-17 08:18:51 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:18:51 --> Total execution time: 0.0493
DEBUG - 2021-11-17 08:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:19:11 --> Total execution time: 0.0405
DEBUG - 2021-11-17 08:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:19:22 --> Total execution time: 0.0412
DEBUG - 2021-11-17 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:19:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:19:25 --> Total execution time: 0.0407
DEBUG - 2021-11-17 08:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 08:19:27 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-17 08:19:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-17 08:19:27 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-17 08:19:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-17 08:19:27 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 152
ERROR - 2021-11-17 08:19:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 152
DEBUG - 2021-11-17 08:19:27 --> Total execution time: 0.0391
DEBUG - 2021-11-17 08:19:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:19:29 --> Total execution time: 0.0455
DEBUG - 2021-11-17 08:19:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:19:31 --> Total execution time: 0.0432
DEBUG - 2021-11-17 08:20:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 08:20:45 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-17 08:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-17 08:20:45 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-17 08:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-17 08:20:45 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 152
ERROR - 2021-11-17 08:20:45 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 152
DEBUG - 2021-11-17 08:20:45 --> Total execution time: 0.0420
DEBUG - 2021-11-17 08:21:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-17 08:21:26 --> Total execution time: 0.0423
DEBUG - 2021-11-17 08:21:28 --> UTF-8 Support Enabled
DEBUG - 2021-11-17 08:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-17 08:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-17 08:21:28 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-17 08:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 47
ERROR - 2021-11-17 08:21:28 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-17 08:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 97
ERROR - 2021-11-17 08:21:28 --> Severity: Notice --> Undefined variable: customer C:\xampp\htdocs\nesnu\application\views\package\index.php 152
ERROR - 2021-11-17 08:21:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 152
DEBUG - 2021-11-17 08:21:28 --> Total execution time: 0.0443
