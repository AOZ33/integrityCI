<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-01 00:39:44 --> UTF-8 Support Enabled
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-01 00:39:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:39:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-01 00:39:44 --> 404 Page Not Found: Robotstxt/index
ERROR - 2022-01-01 00:39:44 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-01-01 00:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:39:48 --> No URI present. Default controller set.
DEBUG - 2022-01-01 00:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:39:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 00:39:48 --> Total execution time: 0.0240
DEBUG - 2022-01-01 00:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:39:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-01 00:39:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-01 00:39:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:39:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-01 00:39:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-01 00:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:41:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 00:41:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:41:17 --> Total execution time: 0.0079
DEBUG - 2022-01-01 00:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:52:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 00:52:07 --> Total execution time: 0.0739
DEBUG - 2022-01-01 00:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:52:51 --> Total execution time: 0.0335
DEBUG - 2022-01-01 00:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-01 00:52:55 --> Total execution time: 0.0418
DEBUG - 2022-01-01 00:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:53:13 --> Total execution time: 0.0058
DEBUG - 2022-01-01 00:53:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:53:16 --> Total execution time: 0.0058
DEBUG - 2022-01-01 00:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-01 00:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-01 00:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-01 00:53:33 --> Total execution time: 0.0337
