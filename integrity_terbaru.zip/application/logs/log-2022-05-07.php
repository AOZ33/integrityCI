<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-07 19:51:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 19:51:05 --> No URI present. Default controller set.
DEBUG - 2022-05-07 19:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 19:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-07 19:51:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-07 19:51:05 --> Total execution time: 0.0569
DEBUG - 2022-05-07 19:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-07 19:51:06 --> No URI present. Default controller set.
DEBUG - 2022-05-07 19:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-07 19:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-07 19:51:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-07 19:51:06 --> Total execution time: 0.0024
