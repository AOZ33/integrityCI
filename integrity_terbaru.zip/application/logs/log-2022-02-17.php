<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-17 08:04:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 08:04:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-17 08:04:25 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-02-17 08:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 08:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 08:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 08:04:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 08:04:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-17 08:04:26 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-17 08:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 08:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 08:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 08:18:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 08:18:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-17 08:18:43 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-17 09:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:30:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 09:30:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-17 09:30:51 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-17 09:31:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:31:00 --> No URI present. Default controller set.
DEBUG - 2022-02-17 09:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:31:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:31:00 --> Total execution time: 0.0035
DEBUG - 2022-02-17 09:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:31:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-17 09:31:01 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-17 09:41:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-17 09:41:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-17 09:41:00 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-17 09:48:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:48:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:48:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:48:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:48:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:48:35 --> Total execution time: 0.0054
DEBUG - 2022-02-17 09:48:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:48:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 09:48:41 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-17 09:48:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:48:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:48:43 --> Total execution time: 0.0047
DEBUG - 2022-02-17 09:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:54:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:54:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:54:57 --> Total execution time: 0.0057
DEBUG - 2022-02-17 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:55:25 --> No URI present. Default controller set.
DEBUG - 2022-02-17 09:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:55:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:55:25 --> Total execution time: 0.0056
DEBUG - 2022-02-17 09:55:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-17 09:55:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-17 09:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:55:26 --> No URI present. Default controller set.
DEBUG - 2022-02-17 09:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:55:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:55:26 --> Total execution time: 0.0031
DEBUG - 2022-02-17 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:56:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:56:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:56:05 --> Total execution time: 0.0054
DEBUG - 2022-02-17 09:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:59:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:59:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 09:59:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 09:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 09:59:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 09:59:25 --> Total execution time: 0.0058
DEBUG - 2022-02-17 10:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:02:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 10:02:11 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-17 10:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:02:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:02:16 --> Total execution time: 0.0041
DEBUG - 2022-02-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:08:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:08:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:08:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:08:13 --> Total execution time: 0.0053
DEBUG - 2022-02-17 10:10:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:10:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:10:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:10:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:10:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:10:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:10:05 --> Total execution time: 0.0049
DEBUG - 2022-02-17 10:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:19:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:19:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:19:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:19:02 --> Total execution time: 0.0055
DEBUG - 2022-02-17 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:24:17 --> Total execution time: 0.0066
DEBUG - 2022-02-17 10:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:25:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:25:37 --> Total execution time: 0.0312
DEBUG - 2022-02-17 10:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:32:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:32:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:32:49 --> Total execution time: 0.0058
DEBUG - 2022-02-17 10:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:34:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:34:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:34:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:34:29 --> Total execution time: 0.0061
DEBUG - 2022-02-17 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:43:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:43:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:43:37 --> Total execution time: 0.0057
DEBUG - 2022-02-17 10:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:47:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:47:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 10:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 10:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 10:47:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 10:47:36 --> Total execution time: 0.0067
DEBUG - 2022-02-17 11:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:02:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:02:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:02:59 --> Total execution time: 0.0069
DEBUG - 2022-02-17 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:03:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:03:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:03:23 --> Total execution time: 0.0044
DEBUG - 2022-02-17 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:12:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:12:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:12:59 --> Total execution time: 0.0059
DEBUG - 2022-02-17 11:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:13:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:13:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:13:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:13:58 --> Total execution time: 0.0042
DEBUG - 2022-02-17 11:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:24:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:24:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:24:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:24:17 --> Total execution time: 0.0060
DEBUG - 2022-02-17 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:28:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:28:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:28:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:28:19 --> Total execution time: 0.0059
DEBUG - 2022-02-17 11:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:32:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:32:42 --> Total execution time: 0.0063
DEBUG - 2022-02-17 11:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:35:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:35:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:35:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:35:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:35:34 --> Total execution time: 0.0050
DEBUG - 2022-02-17 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:37:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:37:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:37:13 --> Total execution time: 0.0058
DEBUG - 2022-02-17 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:40:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:40:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:40:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:40:27 --> Total execution time: 0.0059
DEBUG - 2022-02-17 11:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:43:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:43:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:43:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:43:08 --> Total execution time: 0.0050
DEBUG - 2022-02-17 11:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:48:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:48:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 11:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 11:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 11:48:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 11:48:54 --> Total execution time: 0.0054
DEBUG - 2022-02-17 12:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:19:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:19:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:19:57 --> Total execution time: 0.0064
DEBUG - 2022-02-17 12:23:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:23:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:23:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:23:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:23:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:23:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:23:58 --> Total execution time: 0.0047
DEBUG - 2022-02-17 12:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:25:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:25:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:25:58 --> Total execution time: 0.0062
DEBUG - 2022-02-17 12:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:29:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 12:29:57 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-17 12:30:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:30:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:30:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:30:15 --> Total execution time: 0.0054
DEBUG - 2022-02-17 12:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:31:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:31:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:31:03 --> Total execution time: 0.0046
DEBUG - 2022-02-17 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:34:58 --> Total execution time: 0.0067
DEBUG - 2022-02-17 12:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:41:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:41:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:41:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:41:36 --> Total execution time: 0.0063
DEBUG - 2022-02-17 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:41:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:41:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:41:51 --> Total execution time: 0.0038
DEBUG - 2022-02-17 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:44:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:44:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:44:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:44:59 --> Total execution time: 0.0068
DEBUG - 2022-02-17 12:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:46:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:46:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 12:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 12:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 12:46:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 12:46:33 --> Total execution time: 0.0057
DEBUG - 2022-02-17 13:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:39:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 13:39:49 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-17 13:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:40:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:40:10 --> Total execution time: 0.0060
DEBUG - 2022-02-17 13:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:40:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 13:40:16 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-17 13:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:40:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:40:20 --> Total execution time: 0.5628
DEBUG - 2022-02-17 13:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:43:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:43:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:43:52 --> Total execution time: 0.0063
DEBUG - 2022-02-17 13:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:44:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:44:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:44:42 --> Total execution time: 0.0041
DEBUG - 2022-02-17 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:47:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:47:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:47:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:47:21 --> Total execution time: 0.0051
DEBUG - 2022-02-17 13:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:51:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:51:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:51:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:51:28 --> Total execution time: 0.0060
DEBUG - 2022-02-17 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:56:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 13:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 13:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 13:56:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 13:56:48 --> Total execution time: 0.0053
DEBUG - 2022-02-17 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:00:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:00:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:00:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:00:14 --> Total execution time: 0.0067
DEBUG - 2022-02-17 14:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:07:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:07:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:07:44 --> Total execution time: 0.0066
DEBUG - 2022-02-17 14:14:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:14:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:14:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:14:42 --> Total execution time: 0.0062
DEBUG - 2022-02-17 14:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:14:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 14:14:44 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-17 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:14:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:14:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:14:49 --> Total execution time: 0.0041
DEBUG - 2022-02-17 14:15:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:15:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:15:05 --> Total execution time: 0.0051
DEBUG - 2022-02-17 14:15:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:15:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 14:15:08 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-17 14:15:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:15:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:15:10 --> Total execution time: 0.0037
DEBUG - 2022-02-17 14:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:19:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:19:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:19:51 --> Total execution time: 0.0059
DEBUG - 2022-02-17 14:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:37:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:37:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:37:02 --> Total execution time: 0.0068
DEBUG - 2022-02-17 14:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:48:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:48:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 14:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 14:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 14:48:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 14:48:14 --> Total execution time: 0.0062
DEBUG - 2022-02-17 15:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:02:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:02:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:02:13 --> Total execution time: 0.0057
DEBUG - 2022-02-17 15:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:15:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:15:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:15:30 --> Total execution time: 0.0057
DEBUG - 2022-02-17 15:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:23:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:23:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:23:25 --> Total execution time: 0.0073
DEBUG - 2022-02-17 15:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:29:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:29:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:29:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:29:08 --> Total execution time: 0.0066
DEBUG - 2022-02-17 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:32:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:32:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:32:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:32:01 --> Total execution time: 0.0056
DEBUG - 2022-02-17 15:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:35:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:35:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:35:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:35:14 --> Total execution time: 0.0058
DEBUG - 2022-02-17 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:35:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:35:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:35:55 --> Total execution time: 0.0038
DEBUG - 2022-02-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:37:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:37:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:37:29 --> Total execution time: 0.0051
DEBUG - 2022-02-17 15:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:41:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:41:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:41:07 --> Total execution time: 0.0049
DEBUG - 2022-02-17 15:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:43:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:43:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:43:51 --> Total execution time: 0.0051
DEBUG - 2022-02-17 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:44:16 --> Total execution time: 0.0042
DEBUG - 2022-02-17 15:47:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:47:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:47:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:47:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:47:44 --> Total execution time: 0.0048
DEBUG - 2022-02-17 15:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:58:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:58:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 15:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 15:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 15:58:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 15:58:51 --> Total execution time: 0.0063
DEBUG - 2022-02-17 16:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:00:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:00:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:00:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:00:13 --> Total execution time: 0.0057
DEBUG - 2022-02-17 16:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:00:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:00:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:00:16 --> Total execution time: 0.0041
DEBUG - 2022-02-17 16:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:02:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:02:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:02:53 --> Total execution time: 0.0058
DEBUG - 2022-02-17 16:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:05:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:05:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:05:10 --> Total execution time: 0.0052
DEBUG - 2022-02-17 16:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:39:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:39:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:39:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:39:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:39:13 --> Total execution time: 0.0066
DEBUG - 2022-02-17 16:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:41:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:41:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:41:18 --> Total execution time: 0.0068
DEBUG - 2022-02-17 16:44:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:44:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:44:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:44:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:44:36 --> Total execution time: 0.0055
DEBUG - 2022-02-17 16:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:47:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:47:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 16:47:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 16:47:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 16:47:13 --> Total execution time: 0.0032
DEBUG - 2022-02-17 16:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 16:47:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-17 16:47:14 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-17 17:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:00:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:00:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:00:48 --> Total execution time: 0.0059
DEBUG - 2022-02-17 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:03:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:03:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:03:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:03:34 --> Total execution time: 0.0046
DEBUG - 2022-02-17 17:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:08:50 --> No URI present. Default controller set.
DEBUG - 2022-02-17 17:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:08:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:08:50 --> Total execution time: 0.0305
DEBUG - 2022-02-17 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:08:51 --> No URI present. Default controller set.
DEBUG - 2022-02-17 17:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:08:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:08:51 --> Total execution time: 0.0034
DEBUG - 2022-02-17 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:08:51 --> No URI present. Default controller set.
DEBUG - 2022-02-17 17:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:08:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:08:51 --> Total execution time: 0.0038
DEBUG - 2022-02-17 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:08:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-17 17:08:51 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-02-17 17:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:11:46 --> No URI present. Default controller set.
DEBUG - 2022-02-17 17:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:11:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:11:46 --> Total execution time: 0.0302
DEBUG - 2022-02-17 17:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:16:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:16:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:16:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:16:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:16:26 --> Total execution time: 0.0063
DEBUG - 2022-02-17 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:19:27 --> Total execution time: 0.0051
DEBUG - 2022-02-17 17:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:25:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 17:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 17:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 17:25:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-17 17:25:23 --> Total execution time: 0.0062
DEBUG - 2022-02-17 18:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-17 18:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-17 18:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-17 18:14:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-17 18:14:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-17 18:14:12 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
