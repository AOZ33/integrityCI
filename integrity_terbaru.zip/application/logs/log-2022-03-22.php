<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-22 05:43:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:47 --> No URI present. Default controller set.
DEBUG - 2022-03-22 05:43:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 05:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 05:43:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 05:43:47 --> Total execution time: 0.0311
DEBUG - 2022-03-22 05:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 05:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:43:48 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-03-22 05:43:48 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 05:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:43:48 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 05:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:43:48 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 05:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:43:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:43:49 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 05:43:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:43:49 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 05:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:43:50 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 05:43:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:43:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:43:51 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 05:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:17 --> No URI present. Default controller set.
DEBUG - 2022-03-22 05:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 05:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 05:53:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 05:53:17 --> Total execution time: 0.0300
DEBUG - 2022-03-22 05:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:17 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:18 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:18 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:18 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:18 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 05:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:18 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:19 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 05:53:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:19 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 05:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 05:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 05:53:20 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:26:13 --> No URI present. Default controller set.
DEBUG - 2022-03-22 09:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 09:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 09:26:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 09:26:13 --> Total execution time: 0.0297
DEBUG - 2022-03-22 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 09:26:13 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 09:26:13 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 09:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 09:26:13 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 09:26:13 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 09:26:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 09:26:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 09:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 09:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 09:26:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 09:26:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 09:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 09:26:17 --> Total execution time: 0.0063
DEBUG - 2022-03-22 09:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 09:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 09:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 09:27:14 --> Total execution time: 0.0147
DEBUG - 2022-03-22 09:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 09:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 09:27:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 09:27:16 --> Total execution time: 0.0042
DEBUG - 2022-03-22 09:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 09:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 09:41:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 09:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 09:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 09:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 09:41:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 09:41:51 --> Total execution time: 0.0074
DEBUG - 2022-03-22 10:02:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:02:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:02:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:02:38 --> Total execution time: 0.0074
DEBUG - 2022-03-22 10:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:08:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:08:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:08:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:08:47 --> Total execution time: 0.0067
DEBUG - 2022-03-22 10:11:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:11:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:11:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:11:30 --> Total execution time: 0.0060
DEBUG - 2022-03-22 10:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:16:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:16:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:16:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:16:39 --> Total execution time: 0.0072
DEBUG - 2022-03-22 10:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:20:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:20:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:20:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:20:56 --> Total execution time: 0.0070
DEBUG - 2022-03-22 10:25:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:25:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:25:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:25:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:25:04 --> Total execution time: 0.0066
DEBUG - 2022-03-22 10:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:27:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:27:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:27:25 --> Total execution time: 0.0059
DEBUG - 2022-03-22 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:30:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:30:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:30:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:30:32 --> Total execution time: 0.0060
DEBUG - 2022-03-22 10:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:34:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:34:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:34:27 --> Total execution time: 0.0063
DEBUG - 2022-03-22 10:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:38:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:38:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:38:11 --> Total execution time: 0.0072
DEBUG - 2022-03-22 10:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:40:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:40:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:40:29 --> Total execution time: 0.0047
DEBUG - 2022-03-22 10:46:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:46:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:46:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:46:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:46:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:46:15 --> Total execution time: 0.0067
DEBUG - 2022-03-22 10:49:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:49:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:49:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:49:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:49:08 --> Total execution time: 0.0066
DEBUG - 2022-03-22 10:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:54:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:54:35 --> Total execution time: 0.0067
DEBUG - 2022-03-22 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:56:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:56:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:56:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:56:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:56:58 --> Total execution time: 0.0068
DEBUG - 2022-03-22 10:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:57:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:57:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 10:57:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 10:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 10:57:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 10:57:47 --> Total execution time: 0.0037
DEBUG - 2022-03-22 11:00:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:00:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:00:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:00:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:00:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:00:02 --> Total execution time: 0.0064
DEBUG - 2022-03-22 11:02:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:02:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:02:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:02:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:02:07 --> Total execution time: 0.0053
DEBUG - 2022-03-22 11:04:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:04:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:04:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:04:41 --> Total execution time: 0.0067
DEBUG - 2022-03-22 11:07:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:07:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:07:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:07:04 --> Total execution time: 0.0067
DEBUG - 2022-03-22 11:09:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:09:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:09:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:09:51 --> Total execution time: 0.0068
DEBUG - 2022-03-22 11:27:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:09 --> No URI present. Default controller set.
DEBUG - 2022-03-22 11:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:27:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:27:10 --> Total execution time: 0.0311
DEBUG - 2022-03-22 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 11:27:11 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 11:27:11 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 11:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 11:27:11 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 11:27:11 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 11:27:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 11:27:11 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 11:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:27:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:27:13 --> Total execution time: 0.0086
DEBUG - 2022-03-22 11:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:27:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:27:17 --> Total execution time: 0.0125
DEBUG - 2022-03-22 11:27:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:27:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:27:24 --> Total execution time: 0.0094
DEBUG - 2022-03-22 11:27:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:27:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:27:52 --> Total execution time: 0.0049
DEBUG - 2022-03-22 11:29:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:29:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:29:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:29:54 --> Total execution time: 0.0053
DEBUG - 2022-03-22 11:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:32:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:32:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:32:58 --> Total execution time: 0.0072
DEBUG - 2022-03-22 11:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:56:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:56:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 11:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 11:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 11:56:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 11:56:32 --> Total execution time: 0.0081
DEBUG - 2022-03-22 12:02:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:02:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:02:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:02:17 --> Total execution time: 0.0347
DEBUG - 2022-03-22 12:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:02:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:02:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:02:21 --> Total execution time: 0.0041
DEBUG - 2022-03-22 12:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:17:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:17:55 --> Total execution time: 0.0348
DEBUG - 2022-03-22 12:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:17:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:18:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:18:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:18:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:18:03 --> Total execution time: 0.0037
DEBUG - 2022-03-22 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:25:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:25:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:25:19 --> Total execution time: 0.0071
DEBUG - 2022-03-22 12:27:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:27:26 --> No URI present. Default controller set.
DEBUG - 2022-03-22 12:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:27:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:27:27 --> Total execution time: 0.0304
DEBUG - 2022-03-22 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 12:27:27 --> 404 Page Not Found: Js/main.js
ERROR - 2022-03-22 12:27:27 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 12:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:27:27 --> UTF-8 Support Enabled
ERROR - 2022-03-22 12:27:27 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 12:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 12:27:27 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 12:27:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:27:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 12:27:27 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 12:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:34:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:34:58 --> Total execution time: 0.0063
DEBUG - 2022-03-22 12:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:42:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:42:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:42:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:42:24 --> Total execution time: 0.0060
DEBUG - 2022-03-22 12:44:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:44:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:44:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:44:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:44:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:44:19 --> Total execution time: 0.0058
DEBUG - 2022-03-22 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:48:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:48:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:48:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:48:15 --> Total execution time: 0.0064
DEBUG - 2022-03-22 12:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:50:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:50:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:50:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:50:25 --> Total execution time: 0.0044
DEBUG - 2022-03-22 12:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:52:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 12:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 12:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 12:52:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 12:52:51 --> Total execution time: 0.0048
DEBUG - 2022-03-22 13:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:05:56 --> No URI present. Default controller set.
DEBUG - 2022-03-22 13:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:05:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:05:56 --> Total execution time: 0.0304
DEBUG - 2022-03-22 13:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:05:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 13:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:05:56 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 13:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:05:56 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 13:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:05:56 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 13:05:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:05:56 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 13:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:14:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:14:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:14:08 --> Total execution time: 0.0067
DEBUG - 2022-03-22 13:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:17:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:17:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:17:21 --> Total execution time: 0.0059
DEBUG - 2022-03-22 13:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:21:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:21:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:21:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:21:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:21:33 --> Total execution time: 0.0059
DEBUG - 2022-03-22 13:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:07 --> No URI present. Default controller set.
DEBUG - 2022-03-22 13:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:25:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:25:07 --> Total execution time: 0.0304
DEBUG - 2022-03-22 13:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:25:07 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 13:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:25:07 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 13:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:25:07 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 13:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:25:07 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 13:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 13:25:07 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 13:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:25:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:25:10 --> Total execution time: 0.0071
DEBUG - 2022-03-22 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:25:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:25:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:25:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:25:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:25:11 --> Total execution time: 0.0029
DEBUG - 2022-03-22 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:26:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:26:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:26:02 --> Total execution time: 0.0035
DEBUG - 2022-03-22 13:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:27:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:27:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:27:53 --> Total execution time: 0.0056
DEBUG - 2022-03-22 13:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:29:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:29:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:29:33 --> Total execution time: 0.0053
DEBUG - 2022-03-22 13:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:30:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:30:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:30:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:30:30 --> Total execution time: 0.0037
DEBUG - 2022-03-22 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:32:11 --> Total execution time: 0.0052
DEBUG - 2022-03-22 13:38:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:38:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:38:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:38:15 --> Total execution time: 0.0064
DEBUG - 2022-03-22 13:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:40:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:40:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:40:54 --> Total execution time: 0.0046
DEBUG - 2022-03-22 13:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:42:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:42:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:42:07 --> Total execution time: 0.0054
DEBUG - 2022-03-22 13:44:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:44:32 --> Total execution time: 0.0050
DEBUG - 2022-03-22 13:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:44:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:44:44 --> Total execution time: 0.0134
DEBUG - 2022-03-22 13:44:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:44:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:44:47 --> Total execution time: 0.0035
DEBUG - 2022-03-22 13:47:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:47:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:47:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:47:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:47:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:47:42 --> Total execution time: 0.0063
DEBUG - 2022-03-22 13:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:50:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:50:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:50:58 --> Total execution time: 0.0051
DEBUG - 2022-03-22 13:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:53:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:53:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:53:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:53:30 --> Total execution time: 0.0058
DEBUG - 2022-03-22 13:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:55:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:55:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 13:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 13:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 13:55:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 13:55:57 --> Total execution time: 0.0050
DEBUG - 2022-03-22 14:02:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:02:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:02:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:02:45 --> Total execution time: 0.0418
DEBUG - 2022-03-22 14:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:02:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:02:47 --> Total execution time: 0.0096
DEBUG - 2022-03-22 14:02:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:02:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:02:51 --> Total execution time: 0.0048
DEBUG - 2022-03-22 14:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:04:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:04:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:04:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:04:05 --> Total execution time: 0.0050
DEBUG - 2022-03-22 14:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:06:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:06:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:06:43 --> Total execution time: 0.0058
DEBUG - 2022-03-22 14:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:10:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:10:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:10:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:10:15 --> Total execution time: 0.0064
DEBUG - 2022-03-22 14:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:14:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:14:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:14:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:14:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:14:34 --> Total execution time: 0.0061
DEBUG - 2022-03-22 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:16:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:16:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:16:34 --> Total execution time: 0.0045
DEBUG - 2022-03-22 14:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:21:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:21:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:21:58 --> Total execution time: 0.0064
DEBUG - 2022-03-22 14:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:26:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:26:27 --> Total execution time: 0.0389
DEBUG - 2022-03-22 14:26:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:26:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:26:30 --> Total execution time: 0.0101
DEBUG - 2022-03-22 14:26:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:26:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:26:34 --> Total execution time: 0.0059
DEBUG - 2022-03-22 14:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:30:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:30:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:30:08 --> Total execution time: 0.0059
DEBUG - 2022-03-22 14:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:33:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:33:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:33:36 --> Total execution time: 0.0051
DEBUG - 2022-03-22 14:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:34:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:34:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:34:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:34:58 --> Total execution time: 0.0047
DEBUG - 2022-03-22 14:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:38:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:38:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:38:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:38:33 --> Total execution time: 0.0062
DEBUG - 2022-03-22 14:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:40:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:40:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:40:52 --> Total execution time: 0.0045
DEBUG - 2022-03-22 14:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:47:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:47:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:47:15 --> Total execution time: 0.0073
DEBUG - 2022-03-22 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:49:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:49:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:49:24 --> Total execution time: 0.0037
DEBUG - 2022-03-22 14:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:53:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:53:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:53:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:53:23 --> Total execution time: 0.0059
DEBUG - 2022-03-22 14:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:56:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:56:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:56:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:56:03 --> Total execution time: 0.0046
DEBUG - 2022-03-22 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:57:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:57:51 --> Total execution time: 0.0048
DEBUG - 2022-03-22 14:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:59:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:59:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:59:46 --> Total execution time: 0.0034
DEBUG - 2022-03-22 14:59:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 14:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 14:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 14:59:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 14:59:52 --> Total execution time: 0.0128
DEBUG - 2022-03-22 15:02:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:02:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:02:04 --> Total execution time: 0.0335
DEBUG - 2022-03-22 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:02:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:02:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:02:48 --> Total execution time: 0.0036
DEBUG - 2022-03-22 15:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:05:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:05:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:05:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:05:44 --> Total execution time: 0.0069
DEBUG - 2022-03-22 15:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:13:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:13:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:13:17 --> Total execution time: 0.0063
DEBUG - 2022-03-22 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:16:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:16:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:16:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:16:14 --> Total execution time: 0.0052
DEBUG - 2022-03-22 15:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:27:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:27:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:27:44 --> Total execution time: 0.0060
DEBUG - 2022-03-22 15:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:30:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:30:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:30:07 --> Total execution time: 0.0051
DEBUG - 2022-03-22 15:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:35:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:35:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:35:28 --> Total execution time: 0.0062
DEBUG - 2022-03-22 15:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:41:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:41:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:41:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:41:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:41:04 --> Total execution time: 0.0067
DEBUG - 2022-03-22 15:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:54:16 --> Total execution time: 0.0062
DEBUG - 2022-03-22 15:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:55:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:55:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:55:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:55:43 --> Total execution time: 0.0052
DEBUG - 2022-03-22 15:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 15:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 15:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 15:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 15:58:25 --> Total execution time: 0.0055
DEBUG - 2022-03-22 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:01:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:01:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:01:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:01:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:01:28 --> Total execution time: 0.0061
DEBUG - 2022-03-22 16:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:04:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:04:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:04:58 --> Total execution time: 0.0062
DEBUG - 2022-03-22 16:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:07:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:07:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:07:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:07:05 --> Total execution time: 0.0049
DEBUG - 2022-03-22 16:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:08:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:08:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:08:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:08:52 --> Total execution time: 0.0045
DEBUG - 2022-03-22 16:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:11:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:11:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:11:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:11:08 --> Total execution time: 0.0054
DEBUG - 2022-03-22 16:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:14:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:14:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:14:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:14:19 --> Total execution time: 0.0059
DEBUG - 2022-03-22 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:24:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:24:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:24:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:24:21 --> Total execution time: 0.0066
DEBUG - 2022-03-22 16:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:26:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:26:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:26:50 --> Total execution time: 0.0063
DEBUG - 2022-03-22 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:29:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:29:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:29:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:29:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:29:11 --> Total execution time: 0.0046
DEBUG - 2022-03-22 16:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:32:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:32:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:32:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:32:09 --> Total execution time: 0.0045
DEBUG - 2022-03-22 16:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:33:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:33:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:33:51 --> Total execution time: 0.0051
DEBUG - 2022-03-22 16:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:36:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:36:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:36:16 --> Total execution time: 0.0072
DEBUG - 2022-03-22 16:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:38:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:38:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:38:17 --> Total execution time: 0.0049
DEBUG - 2022-03-22 16:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:39:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:39:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:39:28 --> Total execution time: 0.0040
DEBUG - 2022-03-22 16:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:41:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:41:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:41:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:41:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:41:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:41:07 --> Total execution time: 0.0044
DEBUG - 2022-03-22 16:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:42:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:42:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:42:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:42:10 --> Total execution time: 0.0039
DEBUG - 2022-03-22 16:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:43:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:43:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:43:59 --> Total execution time: 0.0050
DEBUG - 2022-03-22 16:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:45:55 --> Total execution time: 0.0057
DEBUG - 2022-03-22 16:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:49:27 --> Total execution time: 0.0053
DEBUG - 2022-03-22 16:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:50:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:50:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:50:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:50:56 --> Total execution time: 0.0056
DEBUG - 2022-03-22 16:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:53:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:53:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:53:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:53:07 --> Total execution time: 0.0045
DEBUG - 2022-03-22 16:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:55:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:55:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:55:19 --> Total execution time: 0.0048
DEBUG - 2022-03-22 16:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 16:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 16:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 16:55:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 16:55:22 --> Total execution time: 0.0119
DEBUG - 2022-03-22 19:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:11 --> No URI present. Default controller set.
DEBUG - 2022-03-22 19:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:38:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 19:38:11 --> Total execution time: 0.0295
DEBUG - 2022-03-22 19:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 19:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:12 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 19:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:12 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 19:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:12 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 19:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:12 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 19:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:25 --> No URI present. Default controller set.
DEBUG - 2022-03-22 19:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 19:38:25 --> Total execution time: 0.0038
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> No URI present. Default controller set.
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:38:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 19:38:35 --> Total execution time: 0.0032
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 19:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:38:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:38:35 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 19:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:39:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 19:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:39:31 --> Total execution time: 0.0049
DEBUG - 2022-03-22 19:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:39:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:39:32 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-22 19:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:39:38 --> Total execution time: 0.0035
DEBUG - 2022-03-22 19:39:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:39:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:39:38 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-22 19:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:39:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 19:39:42 --> Total execution time: 0.0132
DEBUG - 2022-03-22 19:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:40:10 --> Total execution time: 0.0072
DEBUG - 2022-03-22 19:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:40:21 --> Total execution time: 0.0066
DEBUG - 2022-03-22 19:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 19:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 19:41:12 --> Total execution time: 0.0046
DEBUG - 2022-03-22 19:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 19:41:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 19:41:12 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-22 22:01:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 22:01:09 --> No URI present. Default controller set.
DEBUG - 2022-03-22 22:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 22:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-22 22:01:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-22 22:01:09 --> Total execution time: 0.0296
DEBUG - 2022-03-22 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 22:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 22:01:10 --> UTF-8 Support Enabled
ERROR - 2022-03-22 22:01:10 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-22 22:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 22:01:10 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-22 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 22:01:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-22 22:01:10 --> UTF-8 Support Enabled
ERROR - 2022-03-22 22:01:10 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-22 22:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 22:01:10 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-22 22:01:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-22 22:01:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-22 22:01:10 --> 404 Page Not Found: Assets/https:
