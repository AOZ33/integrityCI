<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-29 10:18:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:18:11 --> No URI present. Default controller set.
DEBUG - 2021-12-29 10:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:18:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:18:11 --> Total execution time: 0.0314
DEBUG - 2021-12-29 10:18:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-29 10:18:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-29 10:18:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:18:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-29 10:18:12 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-29 10:22:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:22:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:22:50 --> Total execution time: 0.0083
DEBUG - 2021-12-29 10:23:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:23:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:23:35 --> Total execution time: 0.0513
DEBUG - 2021-12-29 10:30:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:30:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:30:49 --> Total execution time: 0.0352
DEBUG - 2021-12-29 10:39:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:39:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:39:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:39:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:39:27 --> Total execution time: 0.0076
DEBUG - 2021-12-29 10:40:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:40:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:40:42 --> Total execution time: 0.0505
DEBUG - 2021-12-29 10:41:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:41:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:41:32 --> Total execution time: 0.0321
DEBUG - 2021-12-29 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:45:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:45:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:45:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:45:17 --> Total execution time: 0.0076
DEBUG - 2021-12-29 10:45:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:45:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:45:20 --> Total execution time: 0.0253
DEBUG - 2021-12-29 10:45:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:45:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:45:26 --> Total execution time: 0.0052
DEBUG - 2021-12-29 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:51:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:51:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:51:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:51:14 --> Total execution time: 0.0069
DEBUG - 2021-12-29 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:57:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:57:35 --> Total execution time: 0.0071
DEBUG - 2021-12-29 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:59:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:59:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:59:21 --> Total execution time: 0.0062
DEBUG - 2021-12-29 10:59:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 10:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 10:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 10:59:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 10:59:41 --> Total execution time: 0.0262
DEBUG - 2021-12-29 11:59:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 11:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 11:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 11:59:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 11:59:56 --> Total execution time: 0.0359
DEBUG - 2021-12-29 12:01:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:01:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:01:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:01:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:01:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:01:47 --> Total execution time: 0.0060
DEBUG - 2021-12-29 12:05:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:05:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:05:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:05:48 --> Total execution time: 0.0070
DEBUG - 2021-12-29 12:11:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:11:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:11:01 --> Total execution time: 0.0075
DEBUG - 2021-12-29 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:12:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:12:55 --> Total execution time: 0.0334
DEBUG - 2021-12-29 12:13:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:13:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:13:14 --> Total execution time: 0.0252
DEBUG - 2021-12-29 12:13:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:13:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:13:20 --> Total execution time: 0.0049
DEBUG - 2021-12-29 12:20:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:20:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:20:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:20:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:20:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:20:55 --> Total execution time: 0.0079
DEBUG - 2021-12-29 12:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:28:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 12:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 12:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 12:28:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 12:28:29 --> Total execution time: 0.0078
DEBUG - 2021-12-29 13:11:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:11:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:11:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:11:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:11:16 --> Total execution time: 0.0074
DEBUG - 2021-12-29 13:16:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:16:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:16:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:16:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:16:22 --> Total execution time: 0.0076
DEBUG - 2021-12-29 13:25:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:25:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:25:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:25:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:25:09 --> Total execution time: 0.0070
DEBUG - 2021-12-29 13:25:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:25:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:25:18 --> Total execution time: 0.0274
DEBUG - 2021-12-29 13:25:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:25:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:25:32 --> Total execution time: 0.0049
DEBUG - 2021-12-29 13:31:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:31:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:31:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:31:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:31:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:31:31 --> Total execution time: 0.0075
DEBUG - 2021-12-29 13:31:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:31:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:31:33 --> Total execution time: 0.0255
DEBUG - 2021-12-29 13:31:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:31:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:31:44 --> Total execution time: 0.0049
DEBUG - 2021-12-29 13:35:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:35:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:35:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:35:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:35:25 --> Total execution time: 0.0071
DEBUG - 2021-12-29 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:45:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:45:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:45:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:45:14 --> Total execution time: 0.0074
DEBUG - 2021-12-29 13:45:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:45:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:45:21 --> Total execution time: 0.0278
DEBUG - 2021-12-29 13:45:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 13:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 13:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 13:45:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 13:45:34 --> Total execution time: 0.0055
DEBUG - 2021-12-29 14:35:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 14:35:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:35:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 14:35:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:35:18 --> Total execution time: 0.0074
DEBUG - 2021-12-29 14:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 14:39:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 14:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 14:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 14:39:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 14:39:35 --> Total execution time: 0.0070
DEBUG - 2021-12-29 15:20:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 15:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 15:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 15:20:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:20:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 15:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 15:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 15:20:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:20:46 --> Total execution time: 0.0074
DEBUG - 2021-12-29 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 15:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 15:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 15:22:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 15:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 15:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 15:22:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:22:40 --> Total execution time: 0.0073
DEBUG - 2021-12-29 15:35:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 15:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 15:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 15:35:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:35:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 15:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 15:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 15:35:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:35:56 --> Total execution time: 0.0079
DEBUG - 2021-12-29 15:42:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 15:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 15:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 15:42:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:42:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 15:42:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 15:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 15:42:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 15:42:42 --> Total execution time: 0.0070
DEBUG - 2021-12-29 16:00:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 16:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 16:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 16:00:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:00:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 16:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 16:00:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 16:00:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:00:17 --> Total execution time: 0.0082
DEBUG - 2021-12-29 16:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 16:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 16:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 16:01:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:01:07 --> Total execution time: 0.0545
DEBUG - 2021-12-29 16:01:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 16:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 16:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 16:01:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:01:35 --> Total execution time: 0.0054
DEBUG - 2021-12-29 16:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 16:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 16:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 16:08:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:08:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 16:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 16:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 16:08:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:08:50 --> Total execution time: 0.0068
DEBUG - 2021-12-29 16:15:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 16:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 16:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 16:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:15:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-29 16:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-29 16:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-29 16:15:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-29 16:15:42 --> Total execution time: 0.0068
