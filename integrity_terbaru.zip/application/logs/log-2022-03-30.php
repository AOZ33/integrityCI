<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-30 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-30 12:05:53 --> No URI present. Default controller set.
DEBUG - 2022-03-30 12:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-30 12:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-30 12:05:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-30 12:05:53 --> Total execution time: 0.0308
DEBUG - 2022-03-30 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-30 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-30 12:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-30 12:05:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-30 12:05:53 --> 404 Page Not Found: Js/main.js
ERROR - 2022-03-30 12:05:53 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-30 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-30 12:05:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-30 12:05:53 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-30 12:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-30 12:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-30 12:05:53 --> UTF-8 Support Enabled
ERROR - 2022-03-30 12:05:53 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-30 12:05:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-30 12:05:53 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-30 12:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-30 12:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-30 12:06:09 --> 404 Page Not Found: Htaccess/index
DEBUG - 2022-03-30 12:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-30 12:06:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-30 12:06:12 --> 404 Page Not Found: Ada/index
DEBUG - 2022-03-30 12:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-30 12:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-30 12:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-30 12:06:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-30 12:06:15 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
