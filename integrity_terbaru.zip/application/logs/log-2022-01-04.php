<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-04 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:13:32 --> No URI present. Default controller set.
DEBUG - 2022-01-04 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:13:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:13:32 --> Total execution time: 0.0322
DEBUG - 2022-01-04 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:13:33 --> No URI present. Default controller set.
DEBUG - 2022-01-04 11:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:13:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:13:33 --> Total execution time: 0.0040
DEBUG - 2022-01-04 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 11:13:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-04 11:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:13:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-04 11:13:33 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-01-04 11:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:15:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:15:56 --> Total execution time: 0.0078
DEBUG - 2022-01-04 11:15:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:15:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:15:58 --> Total execution time: 0.0539
DEBUG - 2022-01-04 11:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:16:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:16:20 --> Total execution time: 0.0060
DEBUG - 2022-01-04 11:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:34:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:34:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:34:54 --> Total execution time: 0.0078
DEBUG - 2022-01-04 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:42:09 --> Total execution time: 0.0072
DEBUG - 2022-01-04 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:46:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:46:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:46:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:46:44 --> Total execution time: 0.0072
DEBUG - 2022-01-04 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:51:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:51:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:51:09 --> Total execution time: 0.0075
DEBUG - 2022-01-04 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:54:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-04 11:54:07 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-01-04 11:54:07 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Yessica  Ayuningtias Novitasari & Kevin Bagus Christianto', 'Yessica  Ayuningtias Novitasari & Kevin Bagus Christianto', '', NULL, '', '', '', '', '', '', '', '', '', '', '', 'JL. Cukang Kawung Alamanda IV No. 37', ' 085710538693', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '')
DEBUG - 2022-01-04 11:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:54:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:54:07 --> Total execution time: 0.0063
DEBUG - 2022-01-04 11:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:54:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:54:26 --> Total execution time: 0.0512
DEBUG - 2022-01-04 11:54:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 11:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 11:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 11:54:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 11:54:51 --> Total execution time: 0.0059
DEBUG - 2022-01-04 13:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:12:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:12:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:12:25 --> Total execution time: 0.0079
DEBUG - 2022-01-04 13:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:19:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:19:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:19:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:19:31 --> Total execution time: 0.0075
DEBUG - 2022-01-04 13:23:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:23:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:23:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:23:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:23:29 --> Total execution time: 0.0078
DEBUG - 2022-01-04 13:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:26:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:26:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:26:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:26:59 --> Total execution time: 0.0071
DEBUG - 2022-01-04 13:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:33:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:33:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:33:14 --> Total execution time: 0.0071
DEBUG - 2022-01-04 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:38:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:38:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:38:38 --> Total execution time: 0.0072
DEBUG - 2022-01-04 13:38:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:38:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:38:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:38:49 --> Total execution time: 0.0497
DEBUG - 2022-01-04 13:42:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:42:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:42:32 --> Total execution time: 0.0332
DEBUG - 2022-01-04 13:43:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:43:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:43:07 --> Total execution time: 0.0836
DEBUG - 2022-01-04 13:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:43:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:43:38 --> Total execution time: 0.0057
DEBUG - 2022-01-04 13:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:48:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:48:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:48:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:48:36 --> Total execution time: 0.0073
DEBUG - 2022-01-04 13:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:51:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:51:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:51:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:51:35 --> Total execution time: 0.0074
DEBUG - 2022-01-04 13:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 13:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 13:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 13:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 13:55:01 --> Total execution time: 0.0070
DEBUG - 2022-01-04 14:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:03:18 --> Total execution time: 0.0066
DEBUG - 2022-01-04 14:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:14:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:14:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:14:15 --> Total execution time: 0.0074
DEBUG - 2022-01-04 14:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:17:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:17:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:17:55 --> Total execution time: 0.0069
DEBUG - 2022-01-04 14:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:24:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:24:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:24:30 --> Total execution time: 0.0073
DEBUG - 2022-01-04 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:32:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:32:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:32:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:32:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:32:38 --> Total execution time: 0.0078
DEBUG - 2022-01-04 14:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:36:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:36:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:36:27 --> Total execution time: 0.0068
DEBUG - 2022-01-04 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:41:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:41:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:41:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:41:34 --> Total execution time: 0.0067
DEBUG - 2022-01-04 14:41:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:41:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:41:38 --> Total execution time: 0.0582
DEBUG - 2022-01-04 14:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:43:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:43:40 --> Total execution time: 0.0328
DEBUG - 2022-01-04 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:46:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:46:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:46:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:46:41 --> Total execution time: 0.0061
DEBUG - 2022-01-04 14:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:49:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:49:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:49:54 --> Total execution time: 0.0071
DEBUG - 2022-01-04 14:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:51:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:51:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:51:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:51:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:51:22 --> Total execution time: 0.0063
DEBUG - 2022-01-04 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:53:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:53:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:53:31 --> Total execution time: 0.0060
DEBUG - 2022-01-04 14:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:56:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:56:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 14:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 14:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 14:56:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 14:56:12 --> Total execution time: 0.0069
DEBUG - 2022-01-04 15:15:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:15:51 --> No URI present. Default controller set.
DEBUG - 2022-01-04 15:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:15:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:15:51 --> Total execution time: 0.0351
DEBUG - 2022-01-04 15:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:20:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:20:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:20:40 --> Total execution time: 0.0075
DEBUG - 2022-01-04 15:25:08 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:25:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:25:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:25:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:25:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:25:09 --> Total execution time: 0.0070
DEBUG - 2022-01-04 15:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:27:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:27:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:27:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:27:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:27:57 --> Total execution time: 0.0073
DEBUG - 2022-01-04 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:30:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:30:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:30:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:30:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:30:17 --> Total execution time: 0.0059
DEBUG - 2022-01-04 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:33:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:33:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:33:22 --> Total execution time: 0.0081
DEBUG - 2022-01-04 15:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:47:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:47:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:47:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:47:17 --> Total execution time: 0.0077
DEBUG - 2022-01-04 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:51:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:51:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:51:31 --> Total execution time: 0.0081
DEBUG - 2022-01-04 15:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:54:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:54:42 --> Total execution time: 0.0070
DEBUG - 2022-01-04 15:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:57:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:57:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:57:44 --> Total execution time: 0.0078
DEBUG - 2022-01-04 15:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:59:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:59:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:59:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:59:31 --> Total execution time: 0.0062
DEBUG - 2022-01-04 15:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:59:43 --> Total execution time: 0.0592
DEBUG - 2022-01-04 15:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 15:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 15:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 15:59:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 15:59:57 --> Total execution time: 0.0058
DEBUG - 2022-01-04 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:02:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:02:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:02:09 --> Total execution time: 0.0069
DEBUG - 2022-01-04 16:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:04:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:04:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:04:36 --> Total execution time: 0.0070
DEBUG - 2022-01-04 16:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:08:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:08:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:08:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:08:10 --> Total execution time: 0.0075
DEBUG - 2022-01-04 16:10:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:10:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:10:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:10:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:10:35 --> Total execution time: 0.0069
DEBUG - 2022-01-04 16:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:14:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:14:42 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:14:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:14:42 --> Total execution time: 0.0072
DEBUG - 2022-01-04 16:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:16:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:16:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:16:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:16:16 --> Total execution time: 0.0061
DEBUG - 2022-01-04 16:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:17:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:17:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:17:35 --> Total execution time: 0.0067
DEBUG - 2022-01-04 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:20:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:20:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:20:30 --> Total execution time: 0.0071
DEBUG - 2022-01-04 16:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:24:46 --> Total execution time: 0.0074
DEBUG - 2022-01-04 16:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:27:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:27:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:27:16 --> Total execution time: 0.0056
DEBUG - 2022-01-04 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:28:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:28:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:28:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:28:26 --> Total execution time: 0.0061
DEBUG - 2022-01-04 16:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:31:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:31:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:31:18 --> Total execution time: 0.0067
DEBUG - 2022-01-04 16:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:32:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:32:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:32:56 --> Total execution time: 0.0061
DEBUG - 2022-01-04 16:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:36:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:36:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:36:25 --> Total execution time: 0.0070
DEBUG - 2022-01-04 16:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:38:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:38:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:38:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:38:13 --> Total execution time: 0.0071
DEBUG - 2022-01-04 16:38:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-04 16:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-04 16:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-04 16:38:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-04 16:38:16 --> Total execution time: 0.0651
