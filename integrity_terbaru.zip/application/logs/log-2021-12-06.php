<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-06 03:57:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:31 --> No URI present. Default controller set.
DEBUG - 2021-12-06 03:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:31 --> Total execution time: 0.1055
DEBUG - 2021-12-06 03:57:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:35 --> Total execution time: 0.0529
DEBUG - 2021-12-06 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:39 --> Total execution time: 0.0664
DEBUG - 2021-12-06 03:57:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-06 03:57:41 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-06 03:57:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:42 --> Total execution time: 0.0358
DEBUG - 2021-12-06 03:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:43 --> Total execution time: 0.0289
DEBUG - 2021-12-06 03:57:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:45 --> Total execution time: 0.0524
DEBUG - 2021-12-06 03:57:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:51 --> Total execution time: 0.0279
DEBUG - 2021-12-06 03:57:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:57:52 --> Total execution time: 0.0424
DEBUG - 2021-12-06 03:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-06 03:57:53 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-06 03:58:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:58:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:58:06 --> Total execution time: 0.0481
DEBUG - 2021-12-06 03:58:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 03:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 03:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 03:58:07 --> Total execution time: 0.0380
DEBUG - 2021-12-06 04:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:08:38 --> Total execution time: 0.0377
DEBUG - 2021-12-06 04:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:08:56 --> Total execution time: 0.0458
DEBUG - 2021-12-06 04:09:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:09:11 --> Total execution time: 0.0416
DEBUG - 2021-12-06 04:09:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:09:29 --> Total execution time: 0.0425
DEBUG - 2021-12-06 04:09:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:09:54 --> Total execution time: 0.0439
DEBUG - 2021-12-06 04:15:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:15:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:15:53 --> Total execution time: 0.0412
DEBUG - 2021-12-06 04:15:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:15:54 --> Total execution time: 0.0418
DEBUG - 2021-12-06 04:16:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-06 04:16:10 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 29
DEBUG - 2021-12-06 04:16:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:16:13 --> Total execution time: 0.0479
DEBUG - 2021-12-06 04:16:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:16:18 --> Total execution time: 0.0491
DEBUG - 2021-12-06 04:18:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:18:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:18:50 --> Total execution time: 0.0452
DEBUG - 2021-12-06 04:18:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:18:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:18:56 --> Total execution time: 0.0442
DEBUG - 2021-12-06 04:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:19:11 --> Total execution time: 0.0410
DEBUG - 2021-12-06 04:21:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:21:00 --> Total execution time: 0.0492
DEBUG - 2021-12-06 04:21:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:21:27 --> Total execution time: 0.0501
DEBUG - 2021-12-06 04:21:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:21:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:21:43 --> Total execution time: 0.0494
DEBUG - 2021-12-06 04:22:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:22:12 --> Total execution time: 0.0521
DEBUG - 2021-12-06 04:23:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:23:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:23:20 --> Total execution time: 0.0422
DEBUG - 2021-12-06 04:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:23:51 --> Total execution time: 0.0431
DEBUG - 2021-12-06 04:24:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:24:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-06 04:24:11 --> Query error: Unknown column 'status' in 'where clause' - Invalid query: SELECT `date`, COUNT(id) as event_num
FROM `appointment`
WHERE `status` = 1
AND YEAR(date) = 2021
AND MONTH(date) = 12
GROUP BY `date`
DEBUG - 2021-12-06 04:24:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:24:13 --> Total execution time: 0.0409
DEBUG - 2021-12-06 04:24:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:24:38 --> Total execution time: 0.0502
DEBUG - 2021-12-06 04:24:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:24:49 --> Total execution time: 0.0494
DEBUG - 2021-12-06 04:25:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:25:07 --> Total execution time: 0.0277
DEBUG - 2021-12-06 04:25:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:25:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:25:27 --> Total execution time: 0.0289
DEBUG - 2021-12-06 04:25:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:25:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:25:35 --> Total execution time: 0.0432
DEBUG - 2021-12-06 04:26:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:26:04 --> Total execution time: 0.0429
DEBUG - 2021-12-06 04:26:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-06 04:26:04 --> Severity: error --> Exception: C:\xampp\htdocs\nesnu\application\models/User_model.php exists, but doesn't declare class User_model C:\xampp\htdocs\nesnu\system\core\Loader.php 340
DEBUG - 2021-12-06 04:26:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-06 04:26:13 --> Severity: Warning --> Undefined variable $eventCalendar C:\xampp\htdocs\nesnu\application\views\user\index.php 5
DEBUG - 2021-12-06 04:26:13 --> Total execution time: 0.0557
DEBUG - 2021-12-06 04:26:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:26:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-06 04:26:13 --> 404 Page Not Found: Assets/js
DEBUG - 2021-12-06 04:26:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:26:22 --> Total execution time: 0.0500
DEBUG - 2021-12-06 04:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:27:14 --> Total execution time: 0.0481
DEBUG - 2021-12-06 04:32:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:32:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:32:03 --> Total execution time: 0.0400
DEBUG - 2021-12-06 04:32:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:32:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:32:05 --> Total execution time: 0.0483
DEBUG - 2021-12-06 04:33:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:33:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:33:27 --> Total execution time: 0.0395
DEBUG - 2021-12-06 04:33:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:33:42 --> Total execution time: 0.0258
DEBUG - 2021-12-06 04:33:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:33:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:33:43 --> Total execution time: 0.0394
DEBUG - 2021-12-06 04:33:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:33:44 --> Total execution time: 0.0382
DEBUG - 2021-12-06 04:33:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:33:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:33:45 --> Total execution time: 0.0364
DEBUG - 2021-12-06 04:33:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:33:46 --> Total execution time: 0.0504
DEBUG - 2021-12-06 04:33:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:33:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:33:46 --> Total execution time: 0.0476
DEBUG - 2021-12-06 04:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:42:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:42:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:42:05 --> Total execution time: 0.0604
DEBUG - 2021-12-06 04:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:42:07 --> Total execution time: 0.0458
DEBUG - 2021-12-06 04:44:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:44:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:44:54 --> Total execution time: 0.0417
DEBUG - 2021-12-06 04:45:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:45:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:45:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:45:43 --> Total execution time: 0.0420
DEBUG - 2021-12-06 04:45:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:45:47 --> Total execution time: 0.0419
DEBUG - 2021-12-06 04:45:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:45:48 --> Total execution time: 0.0279
DEBUG - 2021-12-06 04:45:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:45:48 --> Total execution time: 0.0374
DEBUG - 2021-12-06 04:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:48:52 --> Total execution time: 0.0409
DEBUG - 2021-12-06 04:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:48:53 --> Total execution time: 0.0403
DEBUG - 2021-12-06 04:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:48:58 --> Total execution time: 0.0424
DEBUG - 2021-12-06 04:48:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:48:59 --> Total execution time: 0.0482
DEBUG - 2021-12-06 04:48:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:48:59 --> Total execution time: 0.0508
DEBUG - 2021-12-06 04:50:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:50:34 --> Total execution time: 0.0258
DEBUG - 2021-12-06 04:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:50:37 --> Total execution time: 0.0370
DEBUG - 2021-12-06 04:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:50:37 --> Total execution time: 0.0269
DEBUG - 2021-12-06 04:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:50:38 --> Total execution time: 0.0375
DEBUG - 2021-12-06 04:50:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:50:46 --> Total execution time: 0.0408
DEBUG - 2021-12-06 04:51:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 04:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 04:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 04:51:23 --> Total execution time: 0.0416
DEBUG - 2021-12-06 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:02:28 --> Total execution time: 0.0289
DEBUG - 2021-12-06 05:02:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:02:29 --> Total execution time: 0.0514
DEBUG - 2021-12-06 05:02:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:02:31 --> Total execution time: 0.0290
DEBUG - 2021-12-06 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:03:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:03:51 --> Total execution time: 0.0430
DEBUG - 2021-12-06 05:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:04:01 --> Total execution time: 0.0406
DEBUG - 2021-12-06 05:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:04:01 --> Total execution time: 0.0435
DEBUG - 2021-12-06 05:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-06 05:08:56 --> Severity: Warning --> Undefined array key "name" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 46
ERROR - 2021-12-06 05:08:56 --> Severity: Warning --> Undefined array key "image" C:\xampp\htdocs\nesnu\application\views\templates\topbar.php 47
DEBUG - 2021-12-06 05:08:56 --> Total execution time: 0.0478
DEBUG - 2021-12-06 05:09:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:09:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:09:25 --> Total execution time: 0.0400
DEBUG - 2021-12-06 05:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:09:43 --> Total execution time: 0.0670
DEBUG - 2021-12-06 05:09:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:09:45 --> Total execution time: 0.0375
DEBUG - 2021-12-06 05:10:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:10:16 --> Total execution time: 0.0360
DEBUG - 2021-12-06 05:11:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:11:41 --> Total execution time: 0.0387
DEBUG - 2021-12-06 05:11:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:11:56 --> Total execution time: 0.0531
DEBUG - 2021-12-06 05:12:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:04 --> Total execution time: 0.0464
DEBUG - 2021-12-06 05:12:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:04 --> Total execution time: 0.0395
DEBUG - 2021-12-06 05:12:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:21 --> Total execution time: 0.0499
DEBUG - 2021-12-06 05:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:22 --> Total execution time: 0.0254
DEBUG - 2021-12-06 05:12:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:23 --> Total execution time: 0.0359
DEBUG - 2021-12-06 05:12:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:25 --> Total execution time: 0.0439
DEBUG - 2021-12-06 05:12:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:28 --> Total execution time: 0.0430
DEBUG - 2021-12-06 05:12:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:12:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:12:30 --> Total execution time: 0.0441
DEBUG - 2021-12-06 05:14:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:14:15 --> Total execution time: 0.0532
DEBUG - 2021-12-06 05:14:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:14:16 --> Total execution time: 0.0448
DEBUG - 2021-12-06 05:14:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:14:16 --> Total execution time: 0.0270
DEBUG - 2021-12-06 05:14:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:14:17 --> Total execution time: 0.0451
DEBUG - 2021-12-06 05:14:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:14:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:14:33 --> Total execution time: 0.0640
DEBUG - 2021-12-06 05:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 05:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 05:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 05:43:56 --> Total execution time: 0.0395
DEBUG - 2021-12-06 06:12:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:12:00 --> Total execution time: 0.0506
DEBUG - 2021-12-06 06:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:12:22 --> Total execution time: 0.0395
DEBUG - 2021-12-06 06:12:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:12:23 --> Total execution time: 0.0458
DEBUG - 2021-12-06 06:12:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:12:24 --> Total execution time: 0.0461
DEBUG - 2021-12-06 06:12:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:12:25 --> Total execution time: 0.0494
DEBUG - 2021-12-06 06:34:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:34:00 --> Total execution time: 0.0556
DEBUG - 2021-12-06 06:34:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:34:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:34:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:34:09 --> Total execution time: 0.0420
DEBUG - 2021-12-06 06:34:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:34:10 --> Total execution time: 0.0533
DEBUG - 2021-12-06 06:34:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:34:10 --> Total execution time: 0.0288
DEBUG - 2021-12-06 06:34:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 06:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 06:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 06:34:11 --> Total execution time: 0.0521
DEBUG - 2021-12-06 07:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 07:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 07:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 07:32:34 --> Total execution time: 0.0466
DEBUG - 2021-12-06 07:32:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 07:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 07:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 07:32:52 --> Total execution time: 0.0471
DEBUG - 2021-12-06 07:33:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 07:33:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 07:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 07:33:09 --> Total execution time: 0.0540
DEBUG - 2021-12-06 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 07:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 07:46:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 07:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 07:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 07:46:13 --> Total execution time: 0.0414
DEBUG - 2021-12-06 08:01:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 08:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 08:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 08:01:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 08:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 08:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 08:01:37 --> Total execution time: 0.0408
DEBUG - 2021-12-06 08:22:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 08:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 08:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 08:22:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 08:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 08:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 08:22:35 --> Total execution time: 0.0410
DEBUG - 2021-12-06 08:45:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 08:45:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 08:45:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 08:45:47 --> Total execution time: 0.0535
DEBUG - 2021-12-06 08:45:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 08:45:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 08:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 08:45:52 --> Total execution time: 0.0254
DEBUG - 2021-12-06 08:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 08:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 08:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 08:45:53 --> Total execution time: 0.0391
DEBUG - 2021-12-06 08:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 08:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 08:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 08:46:05 --> Total execution time: 0.0387
DEBUG - 2021-12-06 09:17:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 09:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 09:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 09:17:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 09:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 09:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 09:17:56 --> Total execution time: 0.0278
DEBUG - 2021-12-06 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 09:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 09:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 09:24:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 09:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 09:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 09:24:09 --> Total execution time: 0.0426
DEBUG - 2021-12-06 09:25:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 09:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 09:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 09:25:21 --> Total execution time: 0.0469
DEBUG - 2021-12-06 09:25:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 09:25:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 09:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 09:25:28 --> Total execution time: 0.0455
DEBUG - 2021-12-06 09:25:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 09:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 09:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 09:25:30 --> Total execution time: 0.0549
DEBUG - 2021-12-06 09:25:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-06 09:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-06 09:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-06 09:25:31 --> Total execution time: 0.0409
