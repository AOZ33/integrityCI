<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-22 03:46:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 03:46:32 --> No URI present. Default controller set.
DEBUG - 2021-11-22 03:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 03:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 03:46:32 --> Total execution time: 0.0846
DEBUG - 2021-11-22 03:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 03:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 03:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 03:46:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 03:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 03:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 03:46:35 --> Total execution time: 0.0472
DEBUG - 2021-11-22 03:46:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 03:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 03:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 03:46:36 --> Total execution time: 0.0485
DEBUG - 2021-11-22 03:46:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 03:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 03:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 03:46:38 --> Total execution time: 0.0475
DEBUG - 2021-11-22 03:46:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 03:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 03:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 03:46:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 03:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 03:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 03:46:59 --> Total execution time: 0.0415
DEBUG - 2021-11-22 04:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:00:02 --> Total execution time: 0.0668
DEBUG - 2021-11-22 04:00:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:00:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:00:05 --> Total execution time: 0.0388
DEBUG - 2021-11-22 04:00:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:00:18 --> Total execution time: 0.0406
DEBUG - 2021-11-22 04:05:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:05:36 --> Total execution time: 0.0450
DEBUG - 2021-11-22 04:11:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:11:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:11:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:11:14 --> Total execution time: 0.0472
DEBUG - 2021-11-22 04:11:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:11:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:11:15 --> Total execution time: 0.0277
DEBUG - 2021-11-22 04:11:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:11:16 --> Total execution time: 0.0451
DEBUG - 2021-11-22 04:11:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:11:17 --> Total execution time: 0.0470
DEBUG - 2021-11-22 04:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:11:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:11:37 --> Total execution time: 0.0456
DEBUG - 2021-11-22 04:11:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:11:38 --> Total execution time: 0.0370
DEBUG - 2021-11-22 04:11:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:11:40 --> Total execution time: 0.0371
DEBUG - 2021-11-22 04:12:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:12:16 --> Total execution time: 0.0516
DEBUG - 2021-11-22 04:12:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:12:19 --> Total execution time: 0.0494
DEBUG - 2021-11-22 04:12:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:12:19 --> Total execution time: 0.0387
DEBUG - 2021-11-22 04:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:12:20 --> Total execution time: 0.0402
DEBUG - 2021-11-22 04:12:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:12:21 --> Total execution time: 0.0479
DEBUG - 2021-11-22 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:12:22 --> Total execution time: 0.0265
DEBUG - 2021-11-22 04:12:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:12:33 --> Total execution time: 0.0468
DEBUG - 2021-11-22 04:13:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:13:16 --> Total execution time: 0.0400
DEBUG - 2021-11-22 04:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:13:54 --> Total execution time: 0.0480
DEBUG - 2021-11-22 04:14:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:14:59 --> Total execution time: 0.0442
DEBUG - 2021-11-22 04:15:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:15:29 --> Total execution time: 0.0367
DEBUG - 2021-11-22 04:15:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:15:39 --> Total execution time: 0.0279
DEBUG - 2021-11-22 04:15:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:15:49 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:15:49 --> Total execution time: 0.0469
DEBUG - 2021-11-22 04:16:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:16:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 04:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 04:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 04:16:22 --> Total execution time: 0.0288
DEBUG - 2021-11-22 05:03:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:03:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:03:33 --> Total execution time: 0.0393
DEBUG - 2021-11-22 05:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:07:50 --> Total execution time: 0.0433
DEBUG - 2021-11-22 05:10:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:10:25 --> Total execution time: 0.0304
DEBUG - 2021-11-22 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:11:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:11:07 --> Total execution time: 0.0428
DEBUG - 2021-11-22 05:11:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:11:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:11:12 --> Total execution time: 0.0501
DEBUG - 2021-11-22 05:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:13:55 --> Total execution time: 0.0511
DEBUG - 2021-11-22 05:17:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:17:20 --> Total execution time: 0.0400
DEBUG - 2021-11-22 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:17:56 --> Total execution time: 0.0422
DEBUG - 2021-11-22 05:18:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:18:05 --> Total execution time: 0.0499
DEBUG - 2021-11-22 05:18:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:18:09 --> Total execution time: 0.0425
DEBUG - 2021-11-22 05:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:19:37 --> Total execution time: 0.0380
DEBUG - 2021-11-22 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:16 --> Total execution time: 0.0256
DEBUG - 2021-11-22 05:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:19 --> Total execution time: 0.0383
DEBUG - 2021-11-22 05:20:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:21 --> Total execution time: 0.0394
DEBUG - 2021-11-22 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:22 --> Total execution time: 0.0416
DEBUG - 2021-11-22 05:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:22 --> Total execution time: 0.0474
DEBUG - 2021-11-22 05:20:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:26 --> Total execution time: 0.0523
DEBUG - 2021-11-22 05:20:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:20:29 --> Total execution time: 0.0278
DEBUG - 2021-11-22 05:21:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:21:09 --> Total execution time: 0.0428
DEBUG - 2021-11-22 05:47:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:47:16 --> Total execution time: 0.0326
DEBUG - 2021-11-22 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:47:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 05:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 05:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 05:47:41 --> Total execution time: 0.0517
DEBUG - 2021-11-22 07:10:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:10:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:10:17 --> Total execution time: 0.0310
DEBUG - 2021-11-22 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:10:18 --> Total execution time: 0.0382
DEBUG - 2021-11-22 07:11:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:11:40 --> Total execution time: 0.0396
DEBUG - 2021-11-22 07:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:12:03 --> Total execution time: 0.0437
DEBUG - 2021-11-22 07:12:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:12:04 --> Total execution time: 0.0470
DEBUG - 2021-11-22 07:12:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:12:13 --> Total execution time: 0.0521
DEBUG - 2021-11-22 07:17:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:17:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:17:35 --> Total execution time: 0.0388
DEBUG - 2021-11-22 07:17:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:17:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:17:36 --> Total execution time: 0.0279
DEBUG - 2021-11-22 07:23:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:23:41 --> Total execution time: 0.0470
DEBUG - 2021-11-22 07:28:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:28:07 --> Total execution time: 0.0515
DEBUG - 2021-11-22 07:28:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:28:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:28:25 --> Total execution time: 0.0423
DEBUG - 2021-11-22 07:32:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:32:08 --> Total execution time: 0.0297
DEBUG - 2021-11-22 07:32:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:32:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:32:40 --> Total execution time: 0.0283
DEBUG - 2021-11-22 07:33:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:33:34 --> Total execution time: 0.0513
DEBUG - 2021-11-22 07:33:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:33:48 --> Total execution time: 0.0508
DEBUG - 2021-11-22 07:35:09 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:35:09 --> Total execution time: 0.0520
DEBUG - 2021-11-22 07:35:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:35:32 --> Total execution time: 0.0520
DEBUG - 2021-11-22 07:36:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:36:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:36:16 --> Total execution time: 0.0533
DEBUG - 2021-11-22 07:36:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:36:17 --> Total execution time: 0.0371
DEBUG - 2021-11-22 07:37:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:37:07 --> Total execution time: 0.0521
DEBUG - 2021-11-22 07:37:26 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:37:26 --> Total execution time: 0.0442
DEBUG - 2021-11-22 07:39:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:39:22 --> Total execution time: 0.0283
DEBUG - 2021-11-22 07:40:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:40:07 --> Total execution time: 0.0441
DEBUG - 2021-11-22 07:47:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:47:40 --> Total execution time: 0.0519
DEBUG - 2021-11-22 07:47:52 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:47:52 --> Total execution time: 0.0469
DEBUG - 2021-11-22 07:50:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:50:19 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:50:19 --> Total execution time: 0.0280
DEBUG - 2021-11-22 07:52:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:52:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:52:02 --> Total execution time: 0.0281
DEBUG - 2021-11-22 07:52:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:52:15 --> Total execution time: 0.0279
DEBUG - 2021-11-22 07:52:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:52:16 --> Total execution time: 0.0375
DEBUG - 2021-11-22 07:52:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:52:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:52:16 --> Total execution time: 0.0507
DEBUG - 2021-11-22 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:52:59 --> Total execution time: 0.0499
DEBUG - 2021-11-22 07:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:53:46 --> Total execution time: 0.0532
DEBUG - 2021-11-22 07:54:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:54:32 --> Total execution time: 0.0401
DEBUG - 2021-11-22 07:55:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:55:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:55:13 --> Total execution time: 0.0385
DEBUG - 2021-11-22 07:55:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:55:20 --> Total execution time: 0.0370
DEBUG - 2021-11-22 07:55:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:55:20 --> Total execution time: 0.0463
DEBUG - 2021-11-22 07:55:20 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:55:20 --> Total execution time: 0.0416
DEBUG - 2021-11-22 07:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:56:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:56:32 --> Total execution time: 0.0510
DEBUG - 2021-11-22 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:58:13 --> Total execution time: 0.0529
DEBUG - 2021-11-22 07:59:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 07:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 07:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 07:59:45 --> Total execution time: 0.0523
DEBUG - 2021-11-22 08:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:00:35 --> Total execution time: 0.0427
DEBUG - 2021-11-22 08:00:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:00:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:00:38 --> Total execution time: 0.0427
DEBUG - 2021-11-22 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:00:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:00:48 --> Total execution time: 0.0270
DEBUG - 2021-11-22 08:05:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:05:56 --> Total execution time: 0.0320
DEBUG - 2021-11-22 08:06:11 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:06:11 --> Total execution time: 0.0385
DEBUG - 2021-11-22 08:06:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:06:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:06:22 --> Total execution time: 0.0279
DEBUG - 2021-11-22 08:09:38 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:09:38 --> Total execution time: 0.0447
DEBUG - 2021-11-22 08:11:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:11:55 --> Total execution time: 0.0426
DEBUG - 2021-11-22 08:12:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:12:25 --> Total execution time: 0.0487
DEBUG - 2021-11-22 08:13:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-22 08:13:48 --> Severity: Notice --> Undefined variable: pe C:\xampp\htdocs\nesnu\application\views\package\index.php 28
ERROR - 2021-11-22 08:13:48 --> Severity: Notice --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\package\index.php 28
DEBUG - 2021-11-22 08:13:48 --> Total execution time: 0.0424
DEBUG - 2021-11-22 08:15:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:15:23 --> Total execution time: 0.0515
DEBUG - 2021-11-22 08:29:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:29:59 --> Total execution time: 0.0300
DEBUG - 2021-11-22 08:32:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:32:43 --> Total execution time: 0.0484
DEBUG - 2021-11-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:33:36 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:33:36 --> Total execution time: 0.0273
DEBUG - 2021-11-22 08:34:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:34:27 --> Total execution time: 0.0491
DEBUG - 2021-11-22 08:35:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:35:47 --> Total execution time: 0.0394
DEBUG - 2021-11-22 08:36:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:36:01 --> Total execution time: 0.0414
DEBUG - 2021-11-22 08:36:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:36:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:36:02 --> Total execution time: 0.0401
DEBUG - 2021-11-22 08:36:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:36:03 --> Total execution time: 0.0446
DEBUG - 2021-11-22 08:36:03 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:36:03 --> Total execution time: 0.0439
DEBUG - 2021-11-22 08:36:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:36:04 --> Total execution time: 0.0360
DEBUG - 2021-11-22 08:40:37 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:40:37 --> Total execution time: 0.0399
DEBUG - 2021-11-22 08:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:40:43 --> Total execution time: 0.0271
DEBUG - 2021-11-22 08:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:40:45 --> Total execution time: 0.0373
DEBUG - 2021-11-22 08:42:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:42:22 --> Total execution time: 0.0295
DEBUG - 2021-11-22 08:43:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:43:14 --> Total execution time: 0.0375
DEBUG - 2021-11-22 08:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:44:40 --> Total execution time: 0.0371
DEBUG - 2021-11-22 08:54:29 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:54:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:54:29 --> Total execution time: 0.0409
DEBUG - 2021-11-22 08:57:24 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:57:24 --> Total execution time: 0.0267
DEBUG - 2021-11-22 08:58:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 08:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 08:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 08:58:16 --> Total execution time: 0.0453
DEBUG - 2021-11-22 09:02:10 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 09:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 09:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 09:02:10 --> Total execution time: 0.0453
DEBUG - 2021-11-22 09:09:35 --> UTF-8 Support Enabled
DEBUG - 2021-11-22 09:09:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-22 09:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-22 09:09:35 --> Total execution time: 0.0723
