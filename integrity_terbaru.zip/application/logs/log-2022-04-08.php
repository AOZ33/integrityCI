<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-08 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:25 --> No URI present. Default controller set.
DEBUG - 2022-04-08 04:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:01:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:01:25 --> Total execution time: 0.0466
DEBUG - 2022-04-08 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:01:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:01:25 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-08 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:01:25 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-08 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:01:25 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-08 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:01:25 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-08 04:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:01:25 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-08 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:01:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:01:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:01:27 --> Total execution time: 0.0046
DEBUG - 2022-04-08 04:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:01:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:01:29 --> Total execution time: 0.0130
DEBUG - 2022-04-08 04:01:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:01:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:01:40 --> Total execution time: 0.0098
DEBUG - 2022-04-08 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:01:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:01:50 --> Total execution time: 0.0041
DEBUG - 2022-04-08 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:01:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:01:53 --> Total execution time: 0.0112
DEBUG - 2022-04-08 04:01:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:01:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:01:58 --> Total execution time: 0.0114
DEBUG - 2022-04-08 04:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:02:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:02:09 --> Total execution time: 0.0048
DEBUG - 2022-04-08 04:02:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:02:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:02:13 --> Total execution time: 0.0045
DEBUG - 2022-04-08 04:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:02:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:02:21 --> Total execution time: 0.0041
DEBUG - 2022-04-08 04:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:02:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:02:26 --> Total execution time: 0.0046
DEBUG - 2022-04-08 04:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:14:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:14:47 --> Total execution time: 0.0467
DEBUG - 2022-04-08 04:14:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:14:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:14:53 --> Total execution time: 0.0036
DEBUG - 2022-04-08 04:24:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:24:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 04:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:24:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:24:39 --> Total execution time: 0.0042
DEBUG - 2022-04-08 04:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:24:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:24:44 --> Total execution time: 0.0134
DEBUG - 2022-04-08 04:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:24:49 --> Total execution time: 0.0023
DEBUG - 2022-04-08 04:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:24:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:24:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:24:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:24:54 --> Total execution time: 0.0017
DEBUG - 2022-04-08 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:24:55 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:24:55 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-08 04:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:24:55 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-08 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:24:55 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-08 04:24:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:24:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:24:55 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-08 04:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:25:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:25:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 04:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:26:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:26:08 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 04:26:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:26:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 04:26:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 04:26:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:26:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:26:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 04:26:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 04:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 04:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 04:26:28 --> Total execution time: 0.0022
DEBUG - 2022-04-08 06:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:12:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:12:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:12:28 --> Total execution time: 0.0032
DEBUG - 2022-04-08 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:12:34 --> Total execution time: 0.0028
DEBUG - 2022-04-08 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:12:34 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:12:34 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-08 06:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:12:34 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-08 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:12:34 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-08 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:12:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:12:34 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-08 06:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:13:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:13:00 --> Total execution time: 0.0028
DEBUG - 2022-04-08 06:13:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:13:01 --> Total execution time: 0.0022
DEBUG - 2022-04-08 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:13:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:13:14 --> Total execution time: 0.0025
DEBUG - 2022-04-08 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:13:14 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:13:14 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-08 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:13:14 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-08 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:13:14 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-08 06:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:13:14 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-08 06:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:14:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:14:22 --> Total execution time: 0.0034
DEBUG - 2022-04-08 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:14:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:14:25 --> Total execution time: 0.0018
DEBUG - 2022-04-08 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:14:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:14:25 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-08 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:14:25 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-08 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:14:25 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-08 06:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:14:25 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-08 06:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:14:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:14:27 --> Total execution time: 0.0022
DEBUG - 2022-04-08 06:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:15:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:15:02 --> Total execution time: 0.0045
DEBUG - 2022-04-08 06:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:15:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:15:40 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:15:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:15:44 --> Total execution time: 0.0020
DEBUG - 2022-04-08 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:00 --> Total execution time: 0.0126
DEBUG - 2022-04-08 06:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:06 --> Total execution time: 0.0049
DEBUG - 2022-04-08 06:18:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:32 --> Total execution time: 0.0048
DEBUG - 2022-04-08 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:38 --> Total execution time: 0.0066
DEBUG - 2022-04-08 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:41 --> Total execution time: 0.0023
DEBUG - 2022-04-08 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:18:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:18:41 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-08 06:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:18:41 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-08 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:18:41 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-08 06:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:18:41 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-08 06:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:18:43 --> Total execution time: 0.0030
DEBUG - 2022-04-08 06:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:21:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:21:23 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:21:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:21:25 --> Total execution time: 0.0043
DEBUG - 2022-04-08 06:22:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:22:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:22:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:22:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:22:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:22:52 --> Total execution time: 0.0126
DEBUG - 2022-04-08 06:22:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:22:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:22:58 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-08 06:25:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:25:48 --> Total execution time: 0.0420
DEBUG - 2022-04-08 06:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:25:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:25:51 --> Total execution time: 0.0048
DEBUG - 2022-04-08 06:25:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:25:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:25:51 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-08 06:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:25:56 --> Total execution time: 0.0053
DEBUG - 2022-04-08 06:25:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:25:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:25:58 --> Total execution time: 0.0055
DEBUG - 2022-04-08 06:26:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:26:04 --> Total execution time: 0.0048
DEBUG - 2022-04-08 06:28:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:28:06 --> Total execution time: 0.0487
DEBUG - 2022-04-08 06:28:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:28:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:28:07 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-04-08 06:28:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:28:10 --> Total execution time: 0.0028
DEBUG - 2022-04-08 06:28:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:28:43 --> Total execution time: 0.0027
DEBUG - 2022-04-08 06:28:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:28:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:28:45 --> Total execution time: 0.0109
DEBUG - 2022-04-08 06:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:28:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:28:47 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-04-08 06:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:29:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:29:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:29:24 --> Total execution time: 0.0082
DEBUG - 2022-04-08 06:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:29:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:29:26 --> Total execution time: 0.0088
DEBUG - 2022-04-08 06:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:32:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:32:24 --> Total execution time: 0.0486
DEBUG - 2022-04-08 06:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:32:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:32:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:32:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:32:33 --> Total execution time: 0.0071
DEBUG - 2022-04-08 06:32:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:32:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:32:34 --> Total execution time: 0.0045
DEBUG - 2022-04-08 06:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:33:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:33:37 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-04-08 06:33:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:33:38 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-04-08 06:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:33:39 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-04-08 06:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:33:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:33:40 --> Total execution time: 0.0073
DEBUG - 2022-04-08 06:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:33:42 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-04-08 06:33:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:33:52 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-04-08 06:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:33:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:33:53 --> Total execution time: 0.0087
DEBUG - 2022-04-08 06:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:33:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-08 06:33:55 --> Total execution time: 0.0044
DEBUG - 2022-04-08 06:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:33:57 --> Total execution time: 0.0023
DEBUG - 2022-04-08 06:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:33:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-08 06:33:57 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-08 06:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:40:43 --> Total execution time: 0.0415
DEBUG - 2022-04-08 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:41:18 --> Total execution time: 0.0050
DEBUG - 2022-04-08 06:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:41:23 --> Total execution time: 0.0031
DEBUG - 2022-04-08 06:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:43:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:43:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:43:09 --> Total execution time: 0.0051
DEBUG - 2022-04-08 06:43:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:43:12 --> Total execution time: 0.0046
DEBUG - 2022-04-08 06:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:43:21 --> Total execution time: 0.0035
DEBUG - 2022-04-08 06:43:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:43:24 --> Total execution time: 0.0035
DEBUG - 2022-04-08 06:45:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:45:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:45:18 --> Total execution time: 0.0527
DEBUG - 2022-04-08 06:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:45:20 --> Total execution time: 0.0030
DEBUG - 2022-04-08 06:46:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-08 06:46:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-08 06:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-08 06:46:06 --> Total execution time: 0.0047
