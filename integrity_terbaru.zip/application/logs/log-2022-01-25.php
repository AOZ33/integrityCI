<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-25 09:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:30:20 --> No URI present. Default controller set.
DEBUG - 2022-01-25 09:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:30:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:30:20 --> Total execution time: 0.0306
DEBUG - 2022-01-25 09:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:30:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-25 09:30:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-25 09:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:30:21 --> No URI present. Default controller set.
DEBUG - 2022-01-25 09:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:30:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:30:21 --> Total execution time: 0.0036
DEBUG - 2022-01-25 09:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:31:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:31:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:31:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:31:28 --> Total execution time: 0.0062
DEBUG - 2022-01-25 09:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:31:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-25 09:31:30 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 117292256 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-25 09:33:39 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:33:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:33:39 --> Total execution time: 0.0324
DEBUG - 2022-01-25 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:39:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:39:57 --> Total execution time: 0.0341
DEBUG - 2022-01-25 09:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:50:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:50:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:50:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:50:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:50:44 --> Total execution time: 0.0067
DEBUG - 2022-01-25 09:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:58:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 09:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 09:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 09:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 09:58:25 --> Total execution time: 0.0063
DEBUG - 2022-01-25 10:01:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:01:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:01:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:01:31 --> Total execution time: 0.0062
DEBUG - 2022-01-25 10:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:03:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:03:19 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:03:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:03:19 --> Total execution time: 0.0049
DEBUG - 2022-01-25 10:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:06:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:06:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:06:51 --> Total execution time: 0.0055
DEBUG - 2022-01-25 10:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:13:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:13:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:13:32 --> Total execution time: 0.0069
DEBUG - 2022-01-25 10:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:18:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:18:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:18:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:18:21 --> Total execution time: 0.0061
DEBUG - 2022-01-25 10:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:20:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:20:27 --> Total execution time: 0.0049
DEBUG - 2022-01-25 10:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:30:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:30:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:30:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:30:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:30:09 --> Total execution time: 0.0060
DEBUG - 2022-01-25 10:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:31:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:31:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:31:44 --> Total execution time: 0.0047
DEBUG - 2022-01-25 10:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:40:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:40:44 --> Total execution time: 0.0343
DEBUG - 2022-01-25 10:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:51:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:51:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:51:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:51:49 --> Total execution time: 0.0061
DEBUG - 2022-01-25 10:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 10:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 10:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 10:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 10:54:35 --> Total execution time: 0.0047
DEBUG - 2022-01-25 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 11:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 11:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 11:20:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 11:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 11:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 11:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 11:20:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 11:20:40 --> Total execution time: 0.0070
DEBUG - 2022-01-25 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 11:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 11:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 11:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 11:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 11:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 11:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 11:50:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 11:50:59 --> Total execution time: 0.0066
DEBUG - 2022-01-25 11:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 11:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 11:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 11:58:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 11:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 11:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 11:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 11:58:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 11:58:36 --> Total execution time: 0.0063
DEBUG - 2022-01-25 12:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:03:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:03:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:03:36 --> Total execution time: 0.0064
DEBUG - 2022-01-25 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:07:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:07:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:07:21 --> Total execution time: 0.0052
DEBUG - 2022-01-25 12:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:09:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:09:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:09:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:09:21 --> Total execution time: 0.0057
DEBUG - 2022-01-25 12:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:11:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:11:01 --> Total execution time: 0.0050
DEBUG - 2022-01-25 12:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:16:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:16:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:16:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:16:02 --> Total execution time: 0.0063
DEBUG - 2022-01-25 12:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:20:10 --> Total execution time: 0.0059
DEBUG - 2022-01-25 12:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:28:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:28:15 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:28:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:28:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:28:15 --> Total execution time: 0.0058
DEBUG - 2022-01-25 12:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:31:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:31:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 12:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 12:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 12:31:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 12:31:09 --> Total execution time: 0.0066
DEBUG - 2022-01-25 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:06:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:06:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:06:03 --> Total execution time: 0.0066
DEBUG - 2022-01-25 13:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:08:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:08:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:08:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:08:58 --> Total execution time: 0.0061
DEBUG - 2022-01-25 13:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:11:26 --> Total execution time: 0.0050
DEBUG - 2022-01-25 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:14:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:14:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:14:22 --> Total execution time: 0.0055
DEBUG - 2022-01-25 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:18:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:18:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:18:28 --> Total execution time: 0.0066
DEBUG - 2022-01-25 13:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:27:14 --> Total execution time: 0.0059
DEBUG - 2022-01-25 13:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:35:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:35:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:35:20 --> Total execution time: 0.0060
DEBUG - 2022-01-25 13:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:41:13 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:41:13 --> Total execution time: 0.0065
DEBUG - 2022-01-25 13:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:47:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:47:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:47:55 --> Total execution time: 0.0068
DEBUG - 2022-01-25 13:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:51:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:51:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 13:51:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 13:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 13:51:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 13:51:58 --> Total execution time: 0.0058
DEBUG - 2022-01-25 14:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:03:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:03:51 --> Total execution time: 0.0341
DEBUG - 2022-01-25 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:03:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:03:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:03:54 --> Total execution time: 0.0036
DEBUG - 2022-01-25 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:17:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:17:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:17:46 --> Total execution time: 0.0067
DEBUG - 2022-01-25 14:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:19:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:19:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:19:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:19:17 --> Total execution time: 0.0052
DEBUG - 2022-01-25 14:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:24:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:24:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:24:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:24:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:24:45 --> Total execution time: 0.0065
DEBUG - 2022-01-25 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:30:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:30:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:30:43 --> Total execution time: 0.0055
DEBUG - 2022-01-25 14:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:36:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:36:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:36:41 --> Total execution time: 0.0063
DEBUG - 2022-01-25 14:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:41:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:41:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:41:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:41:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:41:12 --> Total execution time: 0.0059
DEBUG - 2022-01-25 14:48:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:48:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:48:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:48:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:48:38 --> Total execution time: 0.0059
DEBUG - 2022-01-25 14:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:57:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:57:09 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 14:57:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 14:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 14:57:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 14:57:09 --> Total execution time: 0.0063
DEBUG - 2022-01-25 15:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:05:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:05:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:05:28 --> Total execution time: 0.0070
DEBUG - 2022-01-25 15:08:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:08:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:08:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:08:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:08:21 --> Total execution time: 0.0059
DEBUG - 2022-01-25 15:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:16:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:16:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:16:40 --> Total execution time: 0.0064
DEBUG - 2022-01-25 15:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:20:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:20:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:20:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:20:29 --> Total execution time: 0.0063
DEBUG - 2022-01-25 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:28:24 --> Total execution time: 0.0071
DEBUG - 2022-01-25 15:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:30:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:30:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:30:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:30:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:30:43 --> Total execution time: 0.0052
DEBUG - 2022-01-25 15:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:36:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:36:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:36:03 --> Total execution time: 0.0067
DEBUG - 2022-01-25 15:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:44:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:44:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:44:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:44:20 --> Total execution time: 0.0065
DEBUG - 2022-01-25 15:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:52:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:52:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:52:07 --> Total execution time: 0.0061
DEBUG - 2022-01-25 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:57:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 15:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 15:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 15:57:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 15:57:28 --> Total execution time: 0.0067
DEBUG - 2022-01-25 16:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:14:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:14:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:14:02 --> Total execution time: 0.0062
DEBUG - 2022-01-25 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:21:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:21:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:21:40 --> Total execution time: 0.0067
DEBUG - 2022-01-25 16:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:31:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:31:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:31:40 --> Total execution time: 0.0066
DEBUG - 2022-01-25 16:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:37:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:37:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:37:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:37:31 --> Total execution time: 0.0067
DEBUG - 2022-01-25 16:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:39:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:39:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:39:54 --> Total execution time: 0.0049
DEBUG - 2022-01-25 16:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:52:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:52:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:52:24 --> Total execution time: 0.0066
DEBUG - 2022-01-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:58:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:58:44 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 16:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 16:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 16:58:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 16:58:44 --> Total execution time: 0.0059
DEBUG - 2022-01-25 17:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 17:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 17:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 17:05:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 17:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-25 17:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-25 17:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-25 17:05:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-25 17:05:31 --> Total execution time: 0.0066
