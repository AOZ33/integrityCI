<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-22 08:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 08:00:52 --> No URI present. Default controller set.
DEBUG - 2022-05-22 08:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 08:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 08:00:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 08:00:52 --> Total execution time: 0.2121
DEBUG - 2022-05-22 08:00:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 08:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 08:00:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-22 08:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 08:00:53 --> No URI present. Default controller set.
DEBUG - 2022-05-22 08:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 08:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 08:00:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 08:00:53 --> Total execution time: 0.0020
DEBUG - 2022-05-22 08:00:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 08:00:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 08:00:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> No URI present. Default controller set.
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 09:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 09:48:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 09:48:22 --> Total execution time: 0.0366
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-22 09:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:48:22 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-22 09:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 09:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 09:49:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 09:49:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 09:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 09:49:05 --> Total execution time: 0.0085
DEBUG - 2022-05-22 09:49:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:49:07 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-22 09:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 09:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 09:49:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 09:49:35 --> Total execution time: 0.0183
DEBUG - 2022-05-22 09:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 09:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 09:49:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 09:49:37 --> Total execution time: 0.0044
DEBUG - 2022-05-22 09:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:49:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 09:49:37 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-22 09:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 09:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 09:57:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 09:57:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 09:57:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 09:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 09:57:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 09:57:19 --> Total execution time: 0.0068
DEBUG - 2022-05-22 10:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:06:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:06:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:06:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:06:18 --> Total execution time: 0.0074
DEBUG - 2022-05-22 10:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:09:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:09:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:09:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:09:51 --> Total execution time: 0.0060
DEBUG - 2022-05-22 10:09:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:09:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:09:59 --> Total execution time: 0.0046
DEBUG - 2022-05-22 10:10:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:10:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:10:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:10:03 --> Total execution time: 0.0180
DEBUG - 2022-05-22 10:10:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:10:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:10:10 --> Total execution time: 0.0201
DEBUG - 2022-05-22 10:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:11:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:11:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:11:48 --> Total execution time: 0.0308
DEBUG - 2022-05-22 10:11:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:11:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:11:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:11:52 --> Total execution time: 0.0031
DEBUG - 2022-05-22 10:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:14:31 --> Total execution time: 0.0043
DEBUG - 2022-05-22 10:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:16:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:16:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:16:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:16:34 --> Total execution time: 0.0027
DEBUG - 2022-05-22 10:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:25:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:25:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:25:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:25:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:25:30 --> Total execution time: 0.0044
DEBUG - 2022-05-22 10:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:29:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:29:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:29:47 --> Total execution time: 0.0024
DEBUG - 2022-05-22 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:35:35 --> Total execution time: 0.0070
DEBUG - 2022-05-22 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:41:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:41:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:41:11 --> Total execution time: 0.0050
DEBUG - 2022-05-22 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:44:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:44:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:44:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:44:07 --> Total execution time: 0.0022
DEBUG - 2022-05-22 10:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:54:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:54:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:54:07 --> Total execution time: 0.0050
DEBUG - 2022-05-22 10:54:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:54:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:54:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:54:14 --> Total execution time: 0.0207
DEBUG - 2022-05-22 10:54:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:54:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:54:20 --> Total execution time: 0.0133
DEBUG - 2022-05-22 10:54:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:54:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:54:26 --> Total execution time: 0.0044
DEBUG - 2022-05-22 10:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:55:10 --> No URI present. Default controller set.
DEBUG - 2022-05-22 10:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:55:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:55:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:55:22 --> Total execution time: 0.0057
DEBUG - 2022-05-22 10:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:57:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:57:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:57:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:57:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:57:08 --> Total execution time: 0.0129
DEBUG - 2022-05-22 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:57:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:57:14 --> Total execution time: 0.0034
DEBUG - 2022-05-22 10:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:57:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:57:23 --> Total execution time: 0.0048
DEBUG - 2022-05-22 10:57:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:57:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:57:28 --> Total execution time: 0.0026
DEBUG - 2022-05-22 10:57:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:57:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:57:33 --> Total execution time: 0.0059
DEBUG - 2022-05-22 10:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:57:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:57:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:57:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:57:56 --> Total execution time: 0.0160
DEBUG - 2022-05-22 10:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:58:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:58:01 --> Total execution time: 0.0040
DEBUG - 2022-05-22 10:58:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:58:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:58:14 --> Total execution time: 0.0049
DEBUG - 2022-05-22 10:58:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:58:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:58:37 --> Total execution time: 0.0215
DEBUG - 2022-05-22 10:58:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:58:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:58:42 --> Total execution time: 0.0028
DEBUG - 2022-05-22 10:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:59:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:59:33 --> Total execution time: 0.0041
DEBUG - 2022-05-22 10:59:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:59:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:59:38 --> Total execution time: 0.0180
DEBUG - 2022-05-22 10:59:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 10:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 10:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 10:59:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 10:59:44 --> Total execution time: 0.0029
DEBUG - 2022-05-22 11:00:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:00:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:00:31 --> Total execution time: 0.0039
DEBUG - 2022-05-22 11:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:01:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:01:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:01:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:01:53 --> Total execution time: 0.0156
DEBUG - 2022-05-22 11:02:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:02:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:02:08 --> Total execution time: 0.0170
DEBUG - 2022-05-22 11:02:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:02:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:02:11 --> Total execution time: 0.0033
DEBUG - 2022-05-22 11:02:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:02:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:02:53 --> Total execution time: 0.0031
DEBUG - 2022-05-22 11:02:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:02:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:02:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:02:57 --> Total execution time: 0.0036
DEBUG - 2022-05-22 11:03:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:03:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:03:01 --> Total execution time: 0.0033
DEBUG - 2022-05-22 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:03:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:03:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:03:15 --> Total execution time: 0.0163
DEBUG - 2022-05-22 11:03:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:03:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:03:29 --> Total execution time: 0.0167
DEBUG - 2022-05-22 11:03:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:03:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:03:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:03:32 --> Total execution time: 0.0027
DEBUG - 2022-05-22 11:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:03:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:03:51 --> Total execution time: 0.0285
DEBUG - 2022-05-22 11:03:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:03:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:03:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:03:53 --> Total execution time: 0.0034
DEBUG - 2022-05-22 11:04:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:04:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:04:03 --> Total execution time: 0.0216
DEBUG - 2022-05-22 11:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:04:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:04:10 --> Total execution time: 0.0028
DEBUG - 2022-05-22 11:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:04:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:04:52 --> Total execution time: 0.0054
DEBUG - 2022-05-22 11:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:05:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:05:01 --> Total execution time: 0.0198
DEBUG - 2022-05-22 11:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:05:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:05:11 --> Total execution time: 0.0031
DEBUG - 2022-05-22 11:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:05:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:05:35 --> Total execution time: 0.0030
DEBUG - 2022-05-22 11:05:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:05:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:05:47 --> Total execution time: 0.0177
DEBUG - 2022-05-22 11:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:05:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:05:54 --> Total execution time: 0.0026
DEBUG - 2022-05-22 11:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:06:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:06:09 --> Total execution time: 0.0041
DEBUG - 2022-05-22 11:06:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:06:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:06:17 --> Total execution time: 0.0152
DEBUG - 2022-05-22 11:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:06:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:06:24 --> Total execution time: 0.0028
DEBUG - 2022-05-22 11:06:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:06:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:06:43 --> Total execution time: 0.0034
DEBUG - 2022-05-22 11:06:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:06:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:06:51 --> Total execution time: 0.0211
DEBUG - 2022-05-22 11:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:06:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:06:56 --> Total execution time: 0.0026
DEBUG - 2022-05-22 11:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:07:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:07:15 --> Total execution time: 0.0030
DEBUG - 2022-05-22 11:07:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:07:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:07:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:07:20 --> Total execution time: 0.0184
DEBUG - 2022-05-22 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:07:29 --> Total execution time: 0.0047
DEBUG - 2022-05-22 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:07:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:07:48 --> Total execution time: 0.0047
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:08:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-22 11:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-22 11:08:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-22 11:08:14 --> Total execution time: 0.0043
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 11:08:14 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 11:08:14 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 11:08:14 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 11:08:14 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 11:08:14 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 11:08:14 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-22 11:08:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-22 11:08:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-22 11:08:14 --> 404 Page Not Found: Js/main.js
