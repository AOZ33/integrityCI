<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-04 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:36:10 --> No URI present. Default controller set.
DEBUG - 2022-03-04 09:36:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:36:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:36:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 09:36:10 --> Total execution time: 0.0305
DEBUG - 2022-03-04 09:36:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:36:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 09:36:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 09:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:36:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 09:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:36:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:36:42 --> Total execution time: 0.0062
DEBUG - 2022-03-04 09:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:36:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:36:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:36:44 --> Total execution time: 0.0157
DEBUG - 2022-03-04 09:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:39:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:39:53 --> Total execution time: 0.0430
DEBUG - 2022-03-04 09:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:39:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:39:57 --> Total execution time: 0.0096
DEBUG - 2022-03-04 09:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:39:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:39:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:39:59 --> Total execution time: 0.0095
DEBUG - 2022-03-04 09:40:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:01 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:01 --> Total execution time: 0.0097
DEBUG - 2022-03-04 09:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:03 --> Total execution time: 0.0087
DEBUG - 2022-03-04 09:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:05 --> Total execution time: 0.0094
DEBUG - 2022-03-04 09:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:07 --> Total execution time: 0.0144
DEBUG - 2022-03-04 09:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:09 --> Total execution time: 0.0091
DEBUG - 2022-03-04 09:40:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:10 --> Total execution time: 0.0093
DEBUG - 2022-03-04 09:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:12 --> Total execution time: 0.0092
DEBUG - 2022-03-04 09:40:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:16 --> Total execution time: 0.0090
DEBUG - 2022-03-04 09:40:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 09:40:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 09:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 09:40:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 09:40:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 09:40:25 --> Total execution time: 0.0093
DEBUG - 2022-03-04 10:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:13:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 10:13:13 --> Total execution time: 0.0344
DEBUG - 2022-03-04 10:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:26:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 10:26:19 --> Total execution time: 0.0443
DEBUG - 2022-03-04 10:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:31:34 --> Total execution time: 0.0334
DEBUG - 2022-03-04 10:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:31:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:31:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 10:31:45 --> Total execution time: 0.0149
DEBUG - 2022-03-04 10:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:32:15 --> Total execution time: 0.0050
DEBUG - 2022-03-04 10:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:32:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:32:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 10:32:27 --> Total execution time: 0.0106
DEBUG - 2022-03-04 10:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:36:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 10:36:31 --> Total execution time: 0.0328
DEBUG - 2022-03-04 10:36:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:36:34 --> Total execution time: 0.0043
DEBUG - 2022-03-04 10:37:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:37:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:37:07 --> Total execution time: 0.0052
DEBUG - 2022-03-04 10:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:37:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:37:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 10:37:08 --> Total execution time: 0.0153
DEBUG - 2022-03-04 10:42:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:42:11 --> Total execution time: 0.0341
DEBUG - 2022-03-04 10:42:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:42:15 --> Total execution time: 0.0039
DEBUG - 2022-03-04 10:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:42:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 10:42:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 10:42:16 --> Total execution time: 0.0143
DEBUG - 2022-03-04 10:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:49:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 10:49:02 --> Total execution time: 0.0332
DEBUG - 2022-03-04 10:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:59:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 10:59:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 10:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 10:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 10:59:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 10:59:33 --> Total execution time: 0.0066
DEBUG - 2022-03-04 11:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:13:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 11:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:13:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 11:13:53 --> Total execution time: 0.0057
DEBUG - 2022-03-04 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:22:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 11:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:22:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 11:22:21 --> Total execution time: 0.0060
DEBUG - 2022-03-04 11:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:30:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 11:30:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:30:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 11:30:19 --> Total execution time: 0.0059
DEBUG - 2022-03-04 11:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:34:31 --> Total execution time: 0.0344
DEBUG - 2022-03-04 11:34:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:34:32 --> Total execution time: 0.0044
DEBUG - 2022-03-04 11:34:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:34:35 --> Total execution time: 0.0039
DEBUG - 2022-03-04 11:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:34:39 --> Total execution time: 0.0040
DEBUG - 2022-03-04 11:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 11:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 11:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 11:36:25 --> Total execution time: 0.0334
DEBUG - 2022-03-04 13:01:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:01:49 --> Total execution time: 0.0348
DEBUG - 2022-03-04 13:02:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:02:19 --> Total execution time: 0.0056
DEBUG - 2022-03-04 13:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:04:10 --> Total execution time: 0.0333
DEBUG - 2022-03-04 13:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:05:05 --> Total execution time: 0.0051
DEBUG - 2022-03-04 13:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:05:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:05:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:05:10 --> Total execution time: 0.0153
DEBUG - 2022-03-04 13:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:06:33 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:06:33 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:06:33 --> Total execution time: 0.0409
DEBUG - 2022-03-04 13:08:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:08:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:08:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:08:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:08:46 --> Total execution time: 0.0414
DEBUG - 2022-03-04 13:09:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:09:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:09:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:09:05 --> Total execution time: 0.0111
DEBUG - 2022-03-04 13:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:12:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:12:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:12:41 --> Total execution time: 0.0427
DEBUG - 2022-03-04 13:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:13:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:13:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:13:53 --> Total execution time: 0.0416
DEBUG - 2022-03-04 13:14:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:14:01 --> Total execution time: 0.0048
DEBUG - 2022-03-04 13:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:14:29 --> Total execution time: 0.0053
DEBUG - 2022-03-04 13:15:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:15:33 --> Total execution time: 0.0052
DEBUG - 2022-03-04 13:15:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:15:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:15:37 --> Total execution time: 0.0045
DEBUG - 2022-03-04 13:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:15:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:15:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:15:38 --> Total execution time: 0.0123
DEBUG - 2022-03-04 13:15:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:15:40 --> Total execution time: 0.0044
DEBUG - 2022-03-04 13:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:15:41 --> Total execution time: 0.0044
DEBUG - 2022-03-04 13:16:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:16:12 --> Total execution time: 0.0061
DEBUG - 2022-03-04 13:17:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:17:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:17:14 --> Total execution time: 0.0050
DEBUG - 2022-03-04 13:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:18:19 --> Total execution time: 0.0061
DEBUG - 2022-03-04 13:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:18:44 --> Total execution time: 0.0061
DEBUG - 2022-03-04 13:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:19:09 --> Total execution time: 0.0054
DEBUG - 2022-03-04 13:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:22:01 --> Total execution time: 0.0330
DEBUG - 2022-03-04 13:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:22:31 --> Total execution time: 0.0064
DEBUG - 2022-03-04 13:25:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:25:55 --> Total execution time: 0.0339
DEBUG - 2022-03-04 13:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:25:56 --> Total execution time: 0.0040
DEBUG - 2022-03-04 13:26:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:26:43 --> Total execution time: 0.0052
DEBUG - 2022-03-04 13:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:26:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:26:44 --> Total execution time: 0.0152
DEBUG - 2022-03-04 13:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:26:45 --> Total execution time: 0.0035
DEBUG - 2022-03-04 13:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:26:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:26:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:26:46 --> Total execution time: 0.0095
DEBUG - 2022-03-04 13:26:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:26:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 13:26:47 --> Total execution time: 0.0040
DEBUG - 2022-03-04 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:29:00 --> Total execution time: 0.0324
DEBUG - 2022-03-04 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:29:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:29:00 --> Total execution time: 0.0127
DEBUG - 2022-03-04 13:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:29:02 --> Total execution time: 0.0040
DEBUG - 2022-03-04 13:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:30:21 --> Total execution time: 0.0320
DEBUG - 2022-03-04 13:30:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:30:51 --> Total execution time: 0.0057
DEBUG - 2022-03-04 13:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:31:12 --> Total execution time: 0.0051
DEBUG - 2022-03-04 13:31:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:31:21 --> Total execution time: 0.0037
DEBUG - 2022-03-04 13:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:31:25 --> Total execution time: 0.0044
DEBUG - 2022-03-04 13:31:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:31:26 --> Total execution time: 0.0039
DEBUG - 2022-03-04 13:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:31:37 --> Total execution time: 0.0033
DEBUG - 2022-03-04 13:31:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:31:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:31:40 --> Total execution time: 0.0040
DEBUG - 2022-03-04 13:31:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:31:42 --> Total execution time: 0.0034
DEBUG - 2022-03-04 13:32:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:32:13 --> Total execution time: 0.0058
DEBUG - 2022-03-04 13:32:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:32:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:32:30 --> Total execution time: 0.0061
DEBUG - 2022-03-04 13:33:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:33:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:33:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:33:42 --> Total execution time: 0.0050
DEBUG - 2022-03-04 13:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:35:28 --> Total execution time: 0.0325
DEBUG - 2022-03-04 13:36:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:36:01 --> Total execution time: 0.0048
DEBUG - 2022-03-04 13:37:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:37:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:37:22 --> Total execution time: 0.0329
DEBUG - 2022-03-04 13:38:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:38:34 --> Total execution time: 0.0328
DEBUG - 2022-03-04 13:38:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:38:55 --> Total execution time: 0.0053
DEBUG - 2022-03-04 13:43:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:43:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:43:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:43:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:43:29 --> Total execution time: 0.0434
DEBUG - 2022-03-04 13:54:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:54:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:54:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:54:45 --> Total execution time: 0.0433
DEBUG - 2022-03-04 13:55:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:55:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:55:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:55:21 --> Total execution time: 0.0107
DEBUG - 2022-03-04 13:58:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:58:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 13:58:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 13:58:12 --> Total execution time: 0.0400
DEBUG - 2022-03-04 13:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:58:15 --> Total execution time: 0.0047
DEBUG - 2022-03-04 13:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:58:20 --> Total execution time: 0.0038
DEBUG - 2022-03-04 13:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:58:24 --> Total execution time: 0.0034
DEBUG - 2022-03-04 13:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 13:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 13:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 13:58:33 --> Total execution time: 0.0040
DEBUG - 2022-03-04 14:00:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:00:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:00:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:00:07 --> Total execution time: 0.0320
DEBUG - 2022-03-04 14:09:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:09:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:09:38 --> Total execution time: 0.0341
DEBUG - 2022-03-04 14:10:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:10:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:10:59 --> Total execution time: 0.0330
DEBUG - 2022-03-04 14:11:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:11:00 --> Total execution time: 0.0040
DEBUG - 2022-03-04 14:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:12:37 --> Total execution time: 0.0314
DEBUG - 2022-03-04 14:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:14:02 --> Total execution time: 0.0313
DEBUG - 2022-03-04 14:15:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:15:26 --> Total execution time: 0.0330
DEBUG - 2022-03-04 14:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:23:06 --> Total execution time: 0.0347
DEBUG - 2022-03-04 14:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:29:14 --> Total execution time: 0.0341
DEBUG - 2022-03-04 14:30:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:30:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:30:29 --> Total execution time: 0.0325
DEBUG - 2022-03-04 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:34:11 --> Total execution time: 0.0325
DEBUG - 2022-03-04 14:37:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:37:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:37:25 --> Total execution time: 0.0325
DEBUG - 2022-03-04 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:37:43 --> Total execution time: 0.0048
DEBUG - 2022-03-04 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:38:19 --> Total execution time: 0.0055
DEBUG - 2022-03-04 14:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:41:49 --> Total execution time: 0.0330
DEBUG - 2022-03-04 14:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:41:56 --> Total execution time: 0.0036
DEBUG - 2022-03-04 14:52:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:52:45 --> Total execution time: 0.0335
DEBUG - 2022-03-04 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:52:52 --> Total execution time: 0.0048
DEBUG - 2022-03-04 14:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:52:52 --> Total execution time: 0.0035
DEBUG - 2022-03-04 14:52:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:52:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:52:54 --> Total execution time: 0.0053
DEBUG - 2022-03-04 14:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:52:55 --> Total execution time: 0.0036
DEBUG - 2022-03-04 14:53:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:53:41 --> Total execution time: 0.0052
DEBUG - 2022-03-04 14:53:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:53:46 --> Total execution time: 0.0041
DEBUG - 2022-03-04 14:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:57:35 --> Total execution time: 0.0328
DEBUG - 2022-03-04 14:58:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:58:20 --> Total execution time: 0.0054
DEBUG - 2022-03-04 14:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:58:24 --> Total execution time: 0.0041
DEBUG - 2022-03-04 14:58:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:58:26 --> Total execution time: 0.0034
DEBUG - 2022-03-04 14:58:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:58:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:58:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 14:58:28 --> Total execution time: 0.0155
DEBUG - 2022-03-04 14:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:58:58 --> Total execution time: 0.0056
DEBUG - 2022-03-04 14:59:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:59:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:05 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 14:59:05 --> Total execution time: 0.0102
DEBUG - 2022-03-04 14:59:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:59:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 14:59:18 --> Total execution time: 0.0060
DEBUG - 2022-03-04 14:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:59:54 --> Total execution time: 0.0045
DEBUG - 2022-03-04 14:59:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 14:59:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 14:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 14:59:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 14:59:56 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 14:59:56 --> Total execution time: 0.0101
DEBUG - 2022-03-04 15:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:04:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:04:51 --> Total execution time: 0.0348
DEBUG - 2022-03-04 15:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:08:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:08:04 --> Total execution time: 0.0333
DEBUG - 2022-03-04 15:08:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:08:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:08:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:08:06 --> Total execution time: 0.0149
DEBUG - 2022-03-04 15:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:09:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:09:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:09:58 --> Total execution time: 0.0432
DEBUG - 2022-03-04 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:10:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:10:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:10:02 --> Total execution time: 0.0131
DEBUG - 2022-03-04 15:11:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:11:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:11:30 --> Total execution time: 0.0420
DEBUG - 2022-03-04 15:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:11:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:11:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:11:53 --> Total execution time: 0.0126
DEBUG - 2022-03-04 15:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:13:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:13:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:13:41 --> Total execution time: 0.0397
DEBUG - 2022-03-04 15:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:15:36 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:15:36 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:15:36 --> Total execution time: 0.0403
DEBUG - 2022-03-04 15:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:15:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:15:56 --> Total execution time: 0.0051
DEBUG - 2022-03-04 15:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:16:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:16:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:16:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:16:53 --> Total execution time: 0.0039
DEBUG - 2022-03-04 15:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:16:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:16:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:16:57 --> Total execution time: 0.0126
DEBUG - 2022-03-04 15:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:17:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:17:00 --> Total execution time: 0.0134
DEBUG - 2022-03-04 15:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:17:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:17:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:17:02 --> Total execution time: 0.0101
DEBUG - 2022-03-04 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:17:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:17:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 286
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 287
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 288
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 289
ERROR - 2022-03-04 15:17:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 290
DEBUG - 2022-03-04 15:17:44 --> Total execution time: 0.0135
DEBUG - 2022-03-04 15:24:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:24:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:24:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
DEBUG - 2022-03-04 15:24:34 --> Total execution time: 0.0455
DEBUG - 2022-03-04 15:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:24:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:38 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
DEBUG - 2022-03-04 15:24:38 --> Total execution time: 0.0101
DEBUG - 2022-03-04 15:24:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:24:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:24:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
DEBUG - 2022-03-04 15:24:44 --> Total execution time: 0.0097
DEBUG - 2022-03-04 15:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:24:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
DEBUG - 2022-03-04 15:24:46 --> Total execution time: 0.0102
DEBUG - 2022-03-04 15:24:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:24:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
DEBUG - 2022-03-04 15:24:47 --> Total execution time: 0.0101
DEBUG - 2022-03-04 15:24:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:24:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
DEBUG - 2022-03-04 15:24:49 --> Total execution time: 0.0091
DEBUG - 2022-03-04 15:24:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:24:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
DEBUG - 2022-03-04 15:24:51 --> Total execution time: 0.0097
DEBUG - 2022-03-04 15:24:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:24:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 298
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 299
ERROR - 2022-03-04 15:24:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 300
DEBUG - 2022-03-04 15:24:52 --> Total execution time: 0.0092
DEBUG - 2022-03-04 15:25:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:25:37 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 293
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 294
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 295
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 293
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 294
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 295
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 293
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 294
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 295
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 293
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 294
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 295
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 293
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 294
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 295
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 296
ERROR - 2022-03-04 15:25:37 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 297
DEBUG - 2022-03-04 15:25:37 --> Total execution time: 0.0134
DEBUG - 2022-03-04 15:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:27:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:27:47 --> Total execution time: 0.0406
DEBUG - 2022-03-04 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:27:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:27:50 --> Total execution time: 0.0103
DEBUG - 2022-03-04 15:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:27:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:27:53 --> Total execution time: 0.0116
DEBUG - 2022-03-04 15:27:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:27:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:27:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:27:58 --> Total execution time: 0.0122
DEBUG - 2022-03-04 15:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:28:40 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:40 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:28:40 --> Total execution time: 0.0124
DEBUG - 2022-03-04 15:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:28:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:28:44 --> Total execution time: 0.0136
DEBUG - 2022-03-04 15:28:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:28:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:28:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:28:55 --> Total execution time: 0.0100
DEBUG - 2022-03-04 15:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:28:58 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:28:58 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:28:58 --> Total execution time: 0.0109
DEBUG - 2022-03-04 15:29:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:29:00 --> Total execution time: 0.0098
DEBUG - 2022-03-04 15:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:29:02 --> Total execution time: 0.0101
DEBUG - 2022-03-04 15:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:07 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:29:07 --> Total execution time: 0.0118
DEBUG - 2022-03-04 15:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:29:10 --> Total execution time: 0.0097
DEBUG - 2022-03-04 15:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:13 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:29:13 --> Total execution time: 0.0111
DEBUG - 2022-03-04 15:29:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:14 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:14 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:29:14 --> Total execution time: 0.0111
DEBUG - 2022-03-04 15:29:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:16 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:16 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:29:16 --> Total execution time: 0.0117
DEBUG - 2022-03-04 15:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:21 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:29:21 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:29:21 --> Total execution time: 0.0092
DEBUG - 2022-03-04 15:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:29:50 --> Total execution time: 0.0071
DEBUG - 2022-03-04 15:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:08 --> Total execution time: 0.0055
DEBUG - 2022-03-04 15:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:13 --> Total execution time: 0.0051
DEBUG - 2022-03-04 15:30:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:24 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:30:24 --> Total execution time: 0.0096
DEBUG - 2022-03-04 15:30:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:34 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:34 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:30:34 --> Total execution time: 0.0149
DEBUG - 2022-03-04 15:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:30:42 --> Total execution time: 0.0124
DEBUG - 2022-03-04 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:45 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:45 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:30:45 --> Total execution time: 0.0128
DEBUG - 2022-03-04 15:30:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:30:47 --> Total execution time: 0.0132
DEBUG - 2022-03-04 15:30:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:30:49 --> Total execution time: 0.0099
DEBUG - 2022-03-04 15:30:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:30:54 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 15:30:54 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 15:30:54 --> Total execution time: 0.0092
DEBUG - 2022-03-04 15:31:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:31:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 15:31:29 --> Total execution time: 0.0059
DEBUG - 2022-03-04 15:39:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 15:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 15:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 15:39:21 --> Total execution time: 0.0338
DEBUG - 2022-03-04 16:02:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:02:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:02:03 --> Total execution time: 0.0494
DEBUG - 2022-03-04 16:02:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:02:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 16:02:18 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-03-04 16:02:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:02:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:02:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:02:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:02:20 --> Total execution time: 0.0103
DEBUG - 2022-03-04 16:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:02:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:02:25 --> Total execution time: 0.0044
DEBUG - 2022-03-04 16:04:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:26 --> Total execution time: 0.0313
DEBUG - 2022-03-04 16:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:28 --> Total execution time: 0.0125
DEBUG - 2022-03-04 16:04:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:39 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:39 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:39 --> Total execution time: 0.0151
DEBUG - 2022-03-04 16:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:41 --> Total execution time: 0.0094
DEBUG - 2022-03-04 16:04:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:42 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:42 --> Total execution time: 0.0128
DEBUG - 2022-03-04 16:04:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:44 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:44 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:44 --> Total execution time: 0.0122
DEBUG - 2022-03-04 16:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:46 --> Total execution time: 0.0130
DEBUG - 2022-03-04 16:04:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:47 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:47 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:47 --> Total execution time: 0.0164
DEBUG - 2022-03-04 16:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:49 --> Total execution time: 0.0137
DEBUG - 2022-03-04 16:04:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:50 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:50 --> Total execution time: 0.0133
DEBUG - 2022-03-04 16:04:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:52 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:52 --> Total execution time: 0.0135
DEBUG - 2022-03-04 16:04:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:53 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:53 --> Total execution time: 0.0134
DEBUG - 2022-03-04 16:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:55 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:55 --> Total execution time: 0.0140
DEBUG - 2022-03-04 16:04:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:57 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:57 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:57 --> Total execution time: 0.0138
DEBUG - 2022-03-04 16:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:04:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:04:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:04:59 --> Total execution time: 0.0137
DEBUG - 2022-03-04 16:05:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:05:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:05:00 --> Total execution time: 0.0131
DEBUG - 2022-03-04 16:05:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:05:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:05:09 --> Total execution time: 0.0131
DEBUG - 2022-03-04 16:05:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:05:19 --> Total execution time: 0.0048
DEBUG - 2022-03-04 16:05:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:05:30 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:05:30 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:05:30 --> Total execution time: 0.0094
DEBUG - 2022-03-04 16:05:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:05:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:05:32 --> Total execution time: 0.0047
DEBUG - 2022-03-04 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:15:25 --> Total execution time: 0.0343
DEBUG - 2022-03-04 16:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:15:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:15:32 --> Total execution time: 0.0040
DEBUG - 2022-03-04 16:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:15:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 16:15:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 16:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:17:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:17:04 --> Total execution time: 0.0031
DEBUG - 2022-03-04 16:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 16:17:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 16:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:22 --> Total execution time: 0.0043
DEBUG - 2022-03-04 16:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:24 --> Total execution time: 0.0035
DEBUG - 2022-03-04 16:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:26 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:17:26 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:17:26 --> Total execution time: 0.0193
DEBUG - 2022-03-04 16:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:17:40 --> Total execution time: 0.0028
DEBUG - 2022-03-04 16:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 16:17:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 16:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:17:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:17:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:17:51 --> Total execution time: 0.0053
DEBUG - 2022-03-04 16:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:18:42 --> No URI present. Default controller set.
DEBUG - 2022-03-04 16:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:18:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:18:42 --> Total execution time: 0.0038
DEBUG - 2022-03-04 16:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:18:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 16:18:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 16:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:20:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:20:15 --> Total execution time: 0.0042
DEBUG - 2022-03-04 16:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:20:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:27 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:20:27 --> Total execution time: 0.0163
DEBUG - 2022-03-04 16:20:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:20:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:20:40 --> Total execution time: 0.0060
DEBUG - 2022-03-04 16:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:20:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:20:59 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:20:59 --> Total execution time: 0.0105
DEBUG - 2022-03-04 16:21:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:21:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:21:28 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:21:28 --> Total execution time: 0.0163
DEBUG - 2022-03-04 16:22:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:22:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:22:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:22:36 --> Total execution time: 0.0059
DEBUG - 2022-03-04 16:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:24:05 --> Total execution time: 0.0327
DEBUG - 2022-03-04 16:24:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:24:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:24:28 --> Total execution time: 0.0069
DEBUG - 2022-03-04 16:25:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:25:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:25:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:25:10 --> Total execution time: 0.0216
DEBUG - 2022-03-04 16:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:26:16 --> Total execution time: 0.0063
DEBUG - 2022-03-04 16:26:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:26:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:26:19 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:26:19 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:26:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:26:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:26:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:26:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:26:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:26:20 --> Total execution time: 0.0104
DEBUG - 2022-03-04 16:31:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:31:05 --> Total execution time: 0.0336
DEBUG - 2022-03-04 16:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:31:34 --> Total execution time: 0.0050
DEBUG - 2022-03-04 16:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:32:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:32:02 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:32:02 --> Total execution time: 0.0204
DEBUG - 2022-03-04 16:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:35:16 --> Total execution time: 0.0324
DEBUG - 2022-03-04 16:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:35:22 --> Total execution time: 0.0042
DEBUG - 2022-03-04 16:37:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:37:23 --> Total execution time: 0.0349
DEBUG - 2022-03-04 16:39:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:39:49 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:39:49 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:39:49 --> Total execution time: 0.0466
DEBUG - 2022-03-04 16:40:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:40:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 16:40:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 16:40:12 --> Total execution time: 0.0130
DEBUG - 2022-03-04 16:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:51:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 16:51:08 --> 404 Page Not Found: Magento_version/index
ERROR - 2022-03-04 16:51:08 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-04 16:51:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 16:51:11 --> No URI present. Default controller set.
DEBUG - 2022-03-04 16:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 16:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 16:51:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 16:51:11 --> Total execution time: 0.0222
DEBUG - 2022-03-04 17:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:15:56 --> No URI present. Default controller set.
DEBUG - 2022-03-04 17:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 17:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 17:15:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 17:15:56 --> Total execution time: 0.0306
DEBUG - 2022-03-04 17:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:15:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 17:15:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 17:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:15:57 --> No URI present. Default controller set.
DEBUG - 2022-03-04 17:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 17:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 17:15:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 17:15:57 --> Total execution time: 0.0038
DEBUG - 2022-03-04 17:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 17:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 17:16:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 17:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 17:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 17:16:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 17:16:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 17:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 17:16:03 --> Total execution time: 0.0061
DEBUG - 2022-03-04 17:16:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 17:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 17:16:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:10 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 17:16:10 --> Total execution time: 0.0152
DEBUG - 2022-03-04 17:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 17:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 17:16:20 --> Total execution time: 0.0040
DEBUG - 2022-03-04 17:16:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 17:16:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 17:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 17:16:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 17:16:46 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 17:16:46 --> Total execution time: 0.0119
DEBUG - 2022-03-04 20:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:13:26 --> No URI present. Default controller set.
DEBUG - 2022-03-04 20:13:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 20:13:26 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-04 20:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:13:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 20:13:26 --> Total execution time: 0.0320
DEBUG - 2022-03-04 20:13:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:13:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 20:13:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 20:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:13:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 20:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:13:37 --> Total execution time: 0.0063
DEBUG - 2022-03-04 20:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:18:48 --> Total execution time: 0.0338
DEBUG - 2022-03-04 20:18:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:18:51 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:18:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:18:51 --> Total execution time: 0.0153
DEBUG - 2022-03-04 20:19:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:00 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:00 --> Total execution time: 0.0122
DEBUG - 2022-03-04 20:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:03 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:03 --> Total execution time: 0.0097
DEBUG - 2022-03-04 20:19:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:09 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:09 --> Total execution time: 0.0094
DEBUG - 2022-03-04 20:19:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:11 --> Total execution time: 0.0121
DEBUG - 2022-03-04 20:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:15 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:15 --> Total execution time: 0.0107
DEBUG - 2022-03-04 20:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:20 --> Total execution time: 0.0163
DEBUG - 2022-03-04 20:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:23 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:23 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:23 --> Total execution time: 0.0147
DEBUG - 2022-03-04 20:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:25 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:25 --> Total execution time: 0.0104
DEBUG - 2022-03-04 20:19:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:19:29 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:19:29 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:19:29 --> Total execution time: 0.0098
DEBUG - 2022-03-04 20:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:31:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 20:31:11 --> 404 Page Not Found: Appointment/print
DEBUG - 2022-03-04 20:31:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 20:31:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 20:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 20:31:12 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 20:31:12 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 20:31:12 --> Total execution time: 0.0393
DEBUG - 2022-03-04 22:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-04 22:50:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-04 22:50:00 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-04 22:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:03 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:50:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-04 22:50:03 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-04 22:50:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:07 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:50:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-04 22:50:07 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-04 22:50:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:50:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-04 22:50:08 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-04 22:50:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:09 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:50:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-04 22:50:09 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-04 22:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:13 --> No URI present. Default controller set.
DEBUG - 2022-03-04 22:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 22:50:13 --> Total execution time: 0.0043
DEBUG - 2022-03-04 22:50:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 22:50:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 22:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 22:50:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 22:50:18 --> Total execution time: 0.0029
DEBUG - 2022-03-04 22:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 22:50:19 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 22:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 22:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 22:50:28 --> Total execution time: 0.0039
DEBUG - 2022-03-04 22:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 22:50:29 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 22:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 22:50:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:34 --> Total execution time: 0.0067
DEBUG - 2022-03-04 22:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:38 --> Total execution time: 0.0048
DEBUG - 2022-03-04 22:50:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:50 --> Total execution time: 0.0056
DEBUG - 2022-03-04 22:50:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:53 --> Total execution time: 0.0052
DEBUG - 2022-03-04 22:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:55 --> Total execution time: 0.0053
DEBUG - 2022-03-04 22:50:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:57 --> Total execution time: 0.0054
DEBUG - 2022-03-04 22:50:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:50:59 --> Total execution time: 0.0045
DEBUG - 2022-03-04 22:51:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:51:01 --> Total execution time: 0.0042
DEBUG - 2022-03-04 22:51:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:51:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:51:09 --> Total execution time: 0.0054
DEBUG - 2022-03-04 22:51:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:51:41 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:51:41 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 22:51:41 --> Total execution time: 0.0133
DEBUG - 2022-03-04 22:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:53:20 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:53:20 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 22:53:20 --> Total execution time: 0.0446
DEBUG - 2022-03-04 22:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:54:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:06 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 22:54:06 --> Total execution time: 0.0153
DEBUG - 2022-03-04 22:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:54:08 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:08 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 22:54:08 --> Total execution time: 0.0137
DEBUG - 2022-03-04 22:54:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 22:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 22:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 22:54:11 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 327
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 328
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 329
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 330
ERROR - 2022-03-04 22:54:11 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /home/dunr4521/public_html/integrity/application/views/data/index.php 331
DEBUG - 2022-03-04 22:54:11 --> Total execution time: 0.0093
DEBUG - 2022-03-04 23:15:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-04 23:15:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-04 23:15:24 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-04 23:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:15:30 --> No URI present. Default controller set.
DEBUG - 2022-03-04 23:15:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:15:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 23:15:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 23:15:30 --> Total execution time: 0.0037
DEBUG - 2022-03-04 23:15:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:15:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:15:30 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 23:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:15:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:15:34 --> 404 Page Not Found: Integriti/index
DEBUG - 2022-03-04 23:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:15:36 --> No URI present. Default controller set.
DEBUG - 2022-03-04 23:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 23:15:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 23:15:36 --> Total execution time: 0.0042
DEBUG - 2022-03-04 23:15:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:15:43 --> No URI present. Default controller set.
DEBUG - 2022-03-04 23:15:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 23:15:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 23:15:43 --> Total execution time: 0.0033
DEBUG - 2022-03-04 23:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:16:56 --> No URI present. Default controller set.
DEBUG - 2022-03-04 23:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 23:16:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 23:16:56 --> Total execution time: 0.0300
DEBUG - 2022-03-04 23:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:16:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:16:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 23:17:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:17:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:17:18 --> 404 Page Not Found: Integrity/index
DEBUG - 2022-03-04 23:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-04 23:17:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-04 23:17:21 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-04 23:17:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:17:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:17:27 --> 404 Page Not Found: Spk/index
DEBUG - 2022-03-04 23:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:17:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:17:30 --> 404 Page Not Found: Spkadmin/index
DEBUG - 2022-03-04 23:17:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:17:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:17:35 --> 404 Page Not Found: Spkprewed/index
DEBUG - 2022-03-04 23:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:17:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:17:39 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-03-04 23:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:17:42 --> No URI present. Default controller set.
DEBUG - 2022-03-04 23:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 23:17:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 23:17:42 --> Total execution time: 0.0033
DEBUG - 2022-03-04 23:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:17:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:17:42 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 23:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 23:18:01 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-03-04 23:18:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-04 23:18:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-03-04 23:18:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:18:12 --> No URI present. Default controller set.
DEBUG - 2022-03-04 23:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 23:18:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 23:18:12 --> Total execution time: 0.0039
DEBUG - 2022-03-04 23:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:18:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:18:13 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-04 23:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:19:59 --> No URI present. Default controller set.
DEBUG - 2022-03-04 23:19:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-04 23:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-04 23:19:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-04 23:19:59 --> Total execution time: 0.0049
DEBUG - 2022-03-04 23:19:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-04 23:19:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-04 23:19:59 --> 404 Page Not Found: Assets/https:
