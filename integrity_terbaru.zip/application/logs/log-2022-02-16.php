<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-16 01:03:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 01:03:31 --> No URI present. Default controller set.
DEBUG - 2022-02-16 01:03:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 01:03:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 01:03:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 01:03:31 --> Total execution time: 0.0311
DEBUG - 2022-02-16 09:36:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:36:51 --> No URI present. Default controller set.
DEBUG - 2022-02-16 09:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:36:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:36:51 --> Total execution time: 0.0303
DEBUG - 2022-02-16 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:36:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 09:36:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 09:36:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:36:52 --> No URI present. Default controller set.
DEBUG - 2022-02-16 09:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:36:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:36:52 --> Total execution time: 0.0032
DEBUG - 2022-02-16 09:46:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:46:40 --> No URI present. Default controller set.
DEBUG - 2022-02-16 09:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:46:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:46:40 --> Total execution time: 0.0300
DEBUG - 2022-02-16 09:46:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:46:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 09:46:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 09:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:46:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:46:54 --> Total execution time: 0.0048
DEBUG - 2022-02-16 09:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:47:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 09:47:00 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1612
DEBUG - 2022-02-16 09:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:47:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:47:03 --> Total execution time: 0.0039
DEBUG - 2022-02-16 09:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:51:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:51:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:51:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:51:24 --> Total execution time: 0.0058
DEBUG - 2022-02-16 09:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:58:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:58:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 09:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 09:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 09:58:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 09:58:01 --> Total execution time: 0.0058
DEBUG - 2022-02-16 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:05:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:05:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:05:49 --> Total execution time: 0.0068
DEBUG - 2022-02-16 10:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:05:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 10:05:51 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1612
DEBUG - 2022-02-16 10:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:05:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:05:52 --> Total execution time: 0.0042
DEBUG - 2022-02-16 10:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:21:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:21:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:21:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:21:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:21:45 --> Total execution time: 0.0063
DEBUG - 2022-02-16 10:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:25:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:25:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:25:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:25:19 --> Total execution time: 0.0053
DEBUG - 2022-02-16 10:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:29:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:29:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:29:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:29:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:29:22 --> Total execution time: 0.0057
DEBUG - 2022-02-16 10:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:51:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:51:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:51:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:51:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:51:17 --> Total execution time: 0.0065
DEBUG - 2022-02-16 10:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:54:46 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 10:54:46 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-16 10:55:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:55:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:55:11 --> Total execution time: 0.0054
DEBUG - 2022-02-16 10:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:55:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 10:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 10:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 10:55:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 10:55:16 --> Total execution time: 0.0038
DEBUG - 2022-02-16 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:00:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:00:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:00:19 --> Total execution time: 0.0062
DEBUG - 2022-02-16 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:03:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 11:03:15 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-16 11:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:04:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:04:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:04:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:04:06 --> Total execution time: 0.0049
DEBUG - 2022-02-16 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:04:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:04:13 --> Total execution time: 0.0034
DEBUG - 2022-02-16 11:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:11:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:11:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:11:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:11:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:11:03 --> Total execution time: 0.0067
DEBUG - 2022-02-16 11:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:33:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:33:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:33:22 --> Total execution time: 0.0058
DEBUG - 2022-02-16 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:38:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:38:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:38:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:38:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:38:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:38:26 --> Total execution time: 0.0056
DEBUG - 2022-02-16 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:48:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:48:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:48:04 --> Total execution time: 0.0059
DEBUG - 2022-02-16 11:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:54:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 11:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 11:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 11:54:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 11:54:06 --> Total execution time: 0.0058
DEBUG - 2022-02-16 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 12:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 12:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 12:07:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 12:07:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 12:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 12:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 12:07:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 12:07:21 --> Total execution time: 0.0058
DEBUG - 2022-02-16 12:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 12:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 12:12:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 12:12:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 12:12:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 12:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 12:12:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 12:12:45 --> Total execution time: 0.0057
DEBUG - 2022-02-16 13:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:08:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:08:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:08:33 --> Total execution time: 0.0069
DEBUG - 2022-02-16 13:16:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:16:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:16:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 13:16:25 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-16 13:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:16:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:16:58 --> Total execution time: 0.0053
DEBUG - 2022-02-16 13:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:17:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:17:06 --> Total execution time: 0.0036
DEBUG - 2022-02-16 13:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:17:38 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 13:17:39 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1457
DEBUG - 2022-02-16 13:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:20:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:20:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:20:47 --> Total execution time: 0.0062
DEBUG - 2022-02-16 13:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:33:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:33:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:33:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:33:12 --> Total execution time: 0.0065
DEBUG - 2022-02-16 13:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:39:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:39:03 --> Total execution time: 0.0333
DEBUG - 2022-02-16 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:39:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:39:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:39:05 --> Total execution time: 0.0037
DEBUG - 2022-02-16 13:50:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:50:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:50:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 13:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 13:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 13:50:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 13:50:38 --> Total execution time: 0.0068
DEBUG - 2022-02-16 14:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:32:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:32:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:32:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:32:15 --> Total execution time: 0.0064
DEBUG - 2022-02-16 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:38:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:38:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:38:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:38:20 --> Total execution time: 0.0065
DEBUG - 2022-02-16 14:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:44:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:44:57 --> Total execution time: 0.0065
DEBUG - 2022-02-16 14:49:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:24 --> No URI present. Default controller set.
DEBUG - 2022-02-16 14:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:49:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:49:24 --> Total execution time: 0.0308
DEBUG - 2022-02-16 14:49:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 14:49:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 14:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:49:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:49:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:49:32 --> Total execution time: 0.0032
DEBUG - 2022-02-16 14:49:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 14:49:34 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 14:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:49:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:49:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:49:44 --> Total execution time: 0.0046
DEBUG - 2022-02-16 14:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:49:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 14:49:53 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1457
DEBUG - 2022-02-16 14:49:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:49:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:49:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:49:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:49:58 --> Total execution time: 0.0060
DEBUG - 2022-02-16 14:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:55:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:55:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:55:12 --> Total execution time: 0.0054
DEBUG - 2022-02-16 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:57:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 14:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 14:57:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 14:57:52 --> Total execution time: 0.0059
DEBUG - 2022-02-16 15:00:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:00:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:00:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:00:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:00:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:00:43 --> Total execution time: 0.0055
DEBUG - 2022-02-16 15:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:03:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:03:11 --> Total execution time: 0.0049
DEBUG - 2022-02-16 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:03:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:03:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:03:49 --> Total execution time: 0.0046
DEBUG - 2022-02-16 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:07:22 --> Total execution time: 0.0050
DEBUG - 2022-02-16 15:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:09:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:09:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:09:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:09:44 --> Total execution time: 0.0064
DEBUG - 2022-02-16 15:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:13:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:13:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:13:37 --> Total execution time: 0.0058
DEBUG - 2022-02-16 15:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:17:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:17:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:17:11 --> Total execution time: 0.0059
DEBUG - 2022-02-16 15:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:17:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:17:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:17:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:17:48 --> Total execution time: 0.0045
DEBUG - 2022-02-16 15:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:22:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:22:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:22:56 --> Total execution time: 0.0060
DEBUG - 2022-02-16 15:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:23:02 --> Total execution time: 0.0039
DEBUG - 2022-02-16 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:27:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:27:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:27:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:27:05 --> Total execution time: 0.0062
DEBUG - 2022-02-16 15:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:28:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:28:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:28:40 --> Total execution time: 0.0056
DEBUG - 2022-02-16 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:32:39 --> No URI present. Default controller set.
DEBUG - 2022-02-16 15:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:32:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 15:32:39 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-02-16 15:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:32:39 --> Total execution time: 0.0305
DEBUG - 2022-02-16 15:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:32:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:32:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:32:41 --> Total execution time: 0.0054
DEBUG - 2022-02-16 15:32:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:32:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 15:32:42 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 15:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:32:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:32:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:32:50 --> Total execution time: 0.0051
DEBUG - 2022-02-16 15:32:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:32:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 15:32:53 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 199245824 bytes) /home/dunr4521/public_html/integrity/application/views/data/index.php 1489
DEBUG - 2022-02-16 15:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:34:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:34:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:34:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:34:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:34:31 --> Total execution time: 0.0062
DEBUG - 2022-02-16 15:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:37:18 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 15:37:18 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-16 15:37:18 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Ira & Yoyo', '', 'Paket Wedding Only', NULL, '', 'custom 2 in 1 leather', '', '1(16RP)', '', 'Acara & Group', '', '', 'full editing', '', '', 'Jl.Pasir Jaya 8 No.10 Bandung', '081224005240', 'iraaugusfianty@yahoo.com', '', 'Rp. 7.500.000', 'Rp. 1.600.000', '', 'Rp. 5.900.000', '', '', '', '', '', '2018-03-24', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '2017-08-29', '', '2018-02-23', '', '', '', '', '', '')
DEBUG - 2022-02-16 15:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:37:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:37:18 --> Total execution time: 0.0053
DEBUG - 2022-02-16 15:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:43:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:43:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:43:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:43:55 --> Total execution time: 0.0057
DEBUG - 2022-02-16 15:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:46:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:46:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 15:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 15:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 15:46:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 15:46:58 --> Total execution time: 0.0050
DEBUG - 2022-02-16 16:33:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 16:33:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 16:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 16:33:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 16:33:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 16:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 16:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 16:33:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 16:33:35 --> Total execution time: 0.0083
DEBUG - 2022-02-16 16:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 16:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 16:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 16:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 16:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 16:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 16:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 16:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 16:37:51 --> Total execution time: 0.0058
DEBUG - 2022-02-16 16:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 16:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 16:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 16:47:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 16:47:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 16:47:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 16:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 16:47:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 16:47:09 --> Total execution time: 0.0058
DEBUG - 2022-02-16 16:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 16:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 16:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 16:57:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 16:57:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 16:57:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 16:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 16:57:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 16:57:37 --> Total execution time: 0.0060
DEBUG - 2022-02-16 17:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 17:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 17:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 17:01:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 17:01:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 17:01:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 17:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 17:01:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 17:01:32 --> Total execution time: 0.0064
DEBUG - 2022-02-16 17:08:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 17:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 17:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 17:08:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 17:08:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 17:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 17:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 17:08:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 17:08:34 --> Total execution time: 0.0069
DEBUG - 2022-02-16 17:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 17:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 17:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 17:08:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 17:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 17:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 17:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 17:08:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 17:08:41 --> Total execution time: 0.0030
DEBUG - 2022-02-16 17:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 17:08:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 17:08:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:20:01 --> No URI present. Default controller set.
DEBUG - 2022-02-16 19:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:20:01 --> Total execution time: 0.0326
DEBUG - 2022-02-16 19:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:20:02 --> No URI present. Default controller set.
DEBUG - 2022-02-16 19:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:20:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:20:02 --> Total execution time: 0.0033
DEBUG - 2022-02-16 19:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:20:02 --> No URI present. Default controller set.
DEBUG - 2022-02-16 19:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:20:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:20:02 --> Total execution time: 0.0038
DEBUG - 2022-02-16 19:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:20:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:20:03 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-02-16 19:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:27:14 --> No URI present. Default controller set.
DEBUG - 2022-02-16 19:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:27:14 --> Total execution time: 0.0308
DEBUG - 2022-02-16 19:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:40:53 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 19:40:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 19:40:53 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 19:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:41:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 19:41:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 19:41:05 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 19:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:41:54 --> No URI present. Default controller set.
DEBUG - 2022-02-16 19:41:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:41:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:41:54 --> Total execution time: 0.0058
DEBUG - 2022-02-16 19:41:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:41:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:41:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:42:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:42:20 --> Total execution time: 0.0059
DEBUG - 2022-02-16 19:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:42:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:42:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:42:26 --> Total execution time: 0.0041
DEBUG - 2022-02-16 19:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:42:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:42:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:42:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:42:37 --> Total execution time: 0.0031
DEBUG - 2022-02-16 19:42:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:42:38 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:42:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:42:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:42:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:42:47 --> Total execution time: 0.0032
DEBUG - 2022-02-16 19:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:42:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:42:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:42:51 --> Total execution time: 0.0035
DEBUG - 2022-02-16 19:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:43:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:44:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:44:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:44:00 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:44:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:44:02 --> Total execution time: 0.0040
DEBUG - 2022-02-16 19:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:44:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:44:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:45:26 --> No URI present. Default controller set.
DEBUG - 2022-02-16 19:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:45:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:45:26 --> Total execution time: 0.0303
DEBUG - 2022-02-16 19:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:45:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:45:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:45:38 --> No URI present. Default controller set.
DEBUG - 2022-02-16 19:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:45:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:45:38 --> Total execution time: 0.0045
DEBUG - 2022-02-16 19:45:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:45:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:45:38 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 19:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:47:52 --> No URI present. Default controller set.
DEBUG - 2022-02-16 19:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 19:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 19:47:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 19:47:52 --> Total execution time: 0.0052
DEBUG - 2022-02-16 19:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 19:47:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 19:47:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 20:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:05:02 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 20:05:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:05:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:05:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:05:12 --> 404 Page Not Found: Dashboard/index
DEBUG - 2022-02-16 20:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-16 20:05:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:05:16 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:05:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:05:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 20:05:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:05:24 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:05:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:05:29 --> 404 Page Not Found: Client/index
DEBUG - 2022-02-16 20:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-16 20:05:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:05:33 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:05:39 --> 404 Page Not Found: Stat/index
DEBUG - 2022-02-16 20:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-16 20:05:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:05:41 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:05:43 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 20:05:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:05:43 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:05:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-16 20:05:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:05:43 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:50 --> No URI present. Default controller set.
DEBUG - 2022-02-16 20:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:05:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 20:05:50 --> Total execution time: 0.0051
DEBUG - 2022-02-16 20:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:05:50 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 20:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:05:52 --> No URI present. Default controller set.
DEBUG - 2022-02-16 20:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:05:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 20:05:52 --> Total execution time: 0.0033
DEBUG - 2022-02-16 20:06:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:06:24 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 20:06:24 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:06:24 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:06:27 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-16 20:06:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:06:27 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:06:54 --> No URI present. Default controller set.
DEBUG - 2022-02-16 20:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:06:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 20:06:54 --> Total execution time: 0.0038
DEBUG - 2022-02-16 20:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:06:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:06:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-16 20:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-16 20:07:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-16 20:07:11 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-16 20:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:08:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:08:22 --> 404 Page Not Found: Client/index
DEBUG - 2022-02-16 20:08:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:08:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:08:26 --> 404 Page Not Found: Addclient/index
DEBUG - 2022-02-16 20:08:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:08:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:08:30 --> 404 Page Not Found: Tambahclient/index
DEBUG - 2022-02-16 20:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:08:32 --> No URI present. Default controller set.
DEBUG - 2022-02-16 20:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-16 20:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-16 20:08:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-16 20:08:32 --> Total execution time: 0.0038
DEBUG - 2022-02-16 20:08:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-16 20:08:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-16 20:08:32 --> 404 Page Not Found: Assets/https:
