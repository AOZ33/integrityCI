<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-08 10:30:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-08 10:30:46 --> No URI present. Default controller set.
DEBUG - 2022-01-08 10:30:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-08 10:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-08 10:30:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 10:30:46 --> Total execution time: 0.0311
DEBUG - 2022-01-08 10:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-01-08 10:39:14 --> No URI present. Default controller set.
DEBUG - 2022-01-08 10:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-08 10:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-08 10:39:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 10:39:14 --> Total execution time: 0.0312
DEBUG - 2022-01-08 11:34:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-08 11:34:26 --> No URI present. Default controller set.
DEBUG - 2022-01-08 11:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-08 11:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-08 11:34:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 11:34:26 --> Total execution time: 0.0306
DEBUG - 2022-01-08 15:45:27 --> UTF-8 Support Enabled
DEBUG - 2022-01-08 15:45:27 --> No URI present. Default controller set.
DEBUG - 2022-01-08 15:45:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-08 15:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-08 15:45:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-08 15:45:27 --> Total execution time: 0.0316
