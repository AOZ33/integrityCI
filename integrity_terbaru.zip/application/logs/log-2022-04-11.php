<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-11 05:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:52 --> No URI present. Default controller set.
DEBUG - 2022-04-11 05:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:05:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 05:05:52 --> Total execution time: 0.0545
DEBUG - 2022-04-11 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:05:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-11 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:05:54 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-11 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:05:54 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-11 05:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:05:54 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-11 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:05:54 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-11 05:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:05:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-11 05:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:05:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 05:05:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:05:56 --> Total execution time: 0.0094
DEBUG - 2022-04-11 05:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:05:59 --> Total execution time: 0.0041
DEBUG - 2022-04-11 05:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:15:31 --> Total execution time: 0.0416
DEBUG - 2022-04-11 05:15:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:15:42 --> Total execution time: 0.0033
DEBUG - 2022-04-11 05:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:15:44 --> 404 Page Not Found: Profile/myindex
DEBUG - 2022-04-11 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:15:47 --> Total execution time: 0.0033
DEBUG - 2022-04-11 05:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:15:48 --> 404 Page Not Found: Profile/myindex
DEBUG - 2022-04-11 05:15:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:15:53 --> Total execution time: 0.0034
DEBUG - 2022-04-11 05:15:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:15:55 --> Total execution time: 0.0033
DEBUG - 2022-04-11 05:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:15:57 --> Total execution time: 0.0055
DEBUG - 2022-04-11 05:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:15:59 --> Total execution time: 0.0061
DEBUG - 2022-04-11 05:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:19:01 --> Total execution time: 0.0516
DEBUG - 2022-04-11 05:19:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:19:03 --> Total execution time: 0.0024
DEBUG - 2022-04-11 05:19:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:19:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:19:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:19:05 --> Total execution time: 0.0021
DEBUG - 2022-04-11 05:19:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:19:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:19:07 --> Total execution time: 0.0025
DEBUG - 2022-04-11 05:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:22:15 --> Total execution time: 0.0441
DEBUG - 2022-04-11 05:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:22:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:22:15 --> 404 Page Not Found: Profile/...
DEBUG - 2022-04-11 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:23:25 --> Total execution time: 0.0026
DEBUG - 2022-04-11 05:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:23:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:23:25 --> 404 Page Not Found: Profile/...
DEBUG - 2022-04-11 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:23:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:23:26 --> Total execution time: 0.0021
DEBUG - 2022-04-11 05:23:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:23:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 05:23:26 --> 404 Page Not Found: Profile/...
DEBUG - 2022-04-11 05:25:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:25:56 --> Total execution time: 0.0397
DEBUG - 2022-04-11 05:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:26:06 --> Total execution time: 0.0046
DEBUG - 2022-04-11 05:26:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:26:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:26:09 --> Total execution time: 0.0040
DEBUG - 2022-04-11 05:26:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:26:14 --> Total execution time: 0.0047
DEBUG - 2022-04-11 05:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:26:23 --> Total execution time: 0.0084
DEBUG - 2022-04-11 05:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:30:13 --> Total execution time: 0.0486
DEBUG - 2022-04-11 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:30:25 --> Total execution time: 0.0098
DEBUG - 2022-04-11 05:30:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:30:58 --> Total execution time: 0.0039
DEBUG - 2022-04-11 05:30:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:30:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:30:59 --> Total execution time: 0.0023
DEBUG - 2022-04-11 05:31:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:31:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:31:03 --> Total execution time: 0.0056
DEBUG - 2022-04-11 05:31:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:31:04 --> Total execution time: 0.0020
DEBUG - 2022-04-11 05:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:32:26 --> Total execution time: 0.0406
DEBUG - 2022-04-11 05:34:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:34:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:34:39 --> Total execution time: 0.0049
DEBUG - 2022-04-11 05:34:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:34:41 --> Total execution time: 0.0021
DEBUG - 2022-04-11 05:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:51:31 --> Total execution time: 0.0395
DEBUG - 2022-04-11 05:51:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:51:38 --> Total execution time: 0.0034
DEBUG - 2022-04-11 05:51:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:51:53 --> Total execution time: 0.0035
DEBUG - 2022-04-11 05:51:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:51:54 --> Total execution time: 0.0020
DEBUG - 2022-04-11 05:52:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:52:30 --> Total execution time: 0.0034
DEBUG - 2022-04-11 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 05:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 05:53:00 --> Total execution time: 0.0020
DEBUG - 2022-04-11 06:02:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:02:15 --> Total execution time: 0.0422
DEBUG - 2022-04-11 06:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:03:05 --> Total execution time: 0.0028
DEBUG - 2022-04-11 06:05:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:05:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:05:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:05:51 --> Total execution time: 0.0023
DEBUG - 2022-04-11 06:07:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:07:04 --> Total execution time: 0.0033
DEBUG - 2022-04-11 06:07:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:07:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:07:45 --> Total execution time: 0.0027
DEBUG - 2022-04-11 06:09:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:09:46 --> Total execution time: 0.0025
DEBUG - 2022-04-11 06:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:16:59 --> Total execution time: 0.0421
DEBUG - 2022-04-11 06:17:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:17:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:17:31 --> Total execution time: 0.0024
DEBUG - 2022-04-11 06:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:18:44 --> Total execution time: 0.0022
DEBUG - 2022-04-11 06:19:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:19:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:19:35 --> Total execution time: 0.0027
DEBUG - 2022-04-11 06:20:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:20:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:20:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:20:21 --> Total execution time: 0.0027
DEBUG - 2022-04-11 06:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:22:01 --> Total execution time: 0.0079
DEBUG - 2022-04-11 06:23:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:23:36 --> Total execution time: 0.0036
DEBUG - 2022-04-11 06:25:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:25:44 --> Total execution time: 0.0028
DEBUG - 2022-04-11 06:27:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:27:49 --> Total execution time: 0.0025
DEBUG - 2022-04-11 06:28:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:28:48 --> Total execution time: 0.0037
DEBUG - 2022-04-11 06:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:30:25 --> Total execution time: 0.0033
DEBUG - 2022-04-11 06:39:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:39:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:39:31 --> Total execution time: 0.0447
DEBUG - 2022-04-11 06:39:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:39:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:39:32 --> Total execution time: 0.0020
DEBUG - 2022-04-11 06:39:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:39:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:39:40 --> Total execution time: 0.0022
DEBUG - 2022-04-11 06:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:39:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:39:42 --> Total execution time: 0.0017
DEBUG - 2022-04-11 06:39:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:39:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:39:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:39:43 --> Total execution time: 0.0030
DEBUG - 2022-04-11 06:40:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:40:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:40:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:40:23 --> Total execution time: 0.0036
DEBUG - 2022-04-11 06:40:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:40:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:40:24 --> Total execution time: 0.0015
DEBUG - 2022-04-11 06:40:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:40:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:40:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:40:28 --> Total execution time: 0.0032
DEBUG - 2022-04-11 06:57:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:32 --> Total execution time: 0.0405
DEBUG - 2022-04-11 06:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:35 --> Total execution time: 0.0032
DEBUG - 2022-04-11 06:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:40 --> Total execution time: 0.0034
DEBUG - 2022-04-11 06:57:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:42 --> Total execution time: 0.0032
DEBUG - 2022-04-11 06:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:45 --> Total execution time: 0.0025
DEBUG - 2022-04-11 06:57:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:49 --> Total execution time: 0.0037
DEBUG - 2022-04-11 06:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:57:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:57:53 --> Total execution time: 0.0033
DEBUG - 2022-04-11 06:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:58:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:58:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 06:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 06:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 06:58:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 06:58:09 --> Total execution time: 0.0024
DEBUG - 2022-04-11 07:00:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:00:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:00:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:00:47 --> Total execution time: 0.0386
DEBUG - 2022-04-11 07:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:00:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:00:49 --> Total execution time: 0.0021
DEBUG - 2022-04-11 07:00:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:00:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:01:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:01:06 --> Total execution time: 0.0026
DEBUG - 2022-04-11 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:01:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:01:06 --> Total execution time: 0.0021
DEBUG - 2022-04-11 07:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:01:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:01:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:01:20 --> Total execution time: 0.0020
DEBUG - 2022-04-11 07:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:06:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:06:39 --> Total execution time: 0.0575
DEBUG - 2022-04-11 07:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:06:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:06:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:06:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:06:47 --> Total execution time: 0.0022
DEBUG - 2022-04-11 07:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:06:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:06:55 --> Total execution time: 0.0021
DEBUG - 2022-04-11 07:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:11:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:11:31 --> Severity: error --> Exception: syntax error, unexpected 'file_name' (T_STRING), expecting ')' /home/nsnmt.com/integrity/application/controllers/Profile.php 46
DEBUG - 2022-04-11 07:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:13:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:13:31 --> Total execution time: 0.0390
DEBUG - 2022-04-11 07:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:13:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:13:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:13:46 --> Total execution time: 0.0025
DEBUG - 2022-04-11 07:13:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:13:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:13:55 --> Total execution time: 0.0033
DEBUG - 2022-04-11 07:15:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:15:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:15:44 --> Total execution time: 0.0579
DEBUG - 2022-04-11 07:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:16:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:16:33 --> Total execution time: 0.0041
DEBUG - 2022-04-11 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:16:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:16:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:16:40 --> Total execution time: 0.0027
DEBUG - 2022-04-11 07:20:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:20:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:20:04 --> Total execution time: 0.0413
DEBUG - 2022-04-11 07:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:20:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:20:05 --> Total execution time: 0.0024
DEBUG - 2022-04-11 07:20:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:20:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:20:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:20:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:20:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:20:10 --> Total execution time: 0.0034
DEBUG - 2022-04-11 07:20:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:20:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:20:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:20:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:20:44 --> Total execution time: 0.0036
DEBUG - 2022-04-11 07:20:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:20:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:20:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:20:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:20:47 --> Total execution time: 0.0023
DEBUG - 2022-04-11 07:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:22:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:22:07 --> Total execution time: 0.0031
DEBUG - 2022-04-11 07:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:22:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:22:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:22:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:22:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:22:10 --> Total execution time: 0.0020
DEBUG - 2022-04-11 07:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:22:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:22:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:22:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:22:29 --> Total execution time: 0.0021
DEBUG - 2022-04-11 07:23:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:23:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:23:04 --> Total execution time: 0.0036
DEBUG - 2022-04-11 07:23:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:23:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:23:08 --> Total execution time: 0.0038
DEBUG - 2022-04-11 07:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:24:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:24:14 --> Total execution time: 0.0387
DEBUG - 2022-04-11 07:24:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:24:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:24:29 --> Total execution time: 0.0033
DEBUG - 2022-04-11 07:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:25:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:25:00 --> Total execution time: 0.0037
DEBUG - 2022-04-11 07:25:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:25:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:25:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:25:15 --> Total execution time: 0.0035
DEBUG - 2022-04-11 07:26:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:26:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:26:38 --> Total execution time: 0.0386
DEBUG - 2022-04-11 07:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:26:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:26:42 --> Total execution time: 0.0147
DEBUG - 2022-04-11 07:26:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:26:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:26:44 --> Total execution time: 0.0037
DEBUG - 2022-04-11 07:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:26:54 --> Total execution time: 0.0040
DEBUG - 2022-04-11 07:26:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:26:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:26:54 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:29:13 --> Total execution time: 0.0026
DEBUG - 2022-04-11 07:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:29:13 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:29:38 --> Total execution time: 0.0036
DEBUG - 2022-04-11 07:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:29:38 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:29:39 --> Total execution time: 0.0023
DEBUG - 2022-04-11 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:29:39 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:29:39 --> Total execution time: 0.0020
DEBUG - 2022-04-11 07:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:29:39 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:29:46 --> Total execution time: 0.0040
DEBUG - 2022-04-11 07:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:29:46 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:29:47 --> Total execution time: 0.0027
DEBUG - 2022-04-11 07:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:29:47 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:29:57 --> Total execution time: 0.0022
DEBUG - 2022-04-11 07:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:29:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:29:57 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:30:00 --> Total execution time: 0.0023
DEBUG - 2022-04-11 07:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:30:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:30:00 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:30:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:30:13 --> Total execution time: 0.0030
DEBUG - 2022-04-11 07:30:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:30:13 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:30:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:30:40 --> Total execution time: 0.0051
DEBUG - 2022-04-11 07:30:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:30:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:30:40 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:30:41 --> Total execution time: 0.0023
DEBUG - 2022-04-11 07:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:30:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:30:41 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-11 07:43:59 --> Severity: error --> Exception: Call to a member function hitungJumlahklien() on null /home/nsnmt.com/integrity/application/controllers/User.php 13
DEBUG - 2022-04-11 07:44:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:44:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-11 07:44:45 --> Severity: error --> Exception: Call to a member function hitungJumlahKlien() on null /home/nsnmt.com/integrity/application/controllers/User.php 13
DEBUG - 2022-04-11 07:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-11 07:45:24 --> Severity: error --> Exception: Call to a member function hitungJumlahKlien() on null /home/nsnmt.com/integrity/application/controllers/User.php 13
DEBUG - 2022-04-11 07:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-11 07:45:25 --> Severity: error --> Exception: Call to a member function hitungJumlahKlien() on null /home/nsnmt.com/integrity/application/controllers/User.php 13
DEBUG - 2022-04-11 07:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-11 07:45:25 --> Severity: error --> Exception: Call to a member function hitungJumlahKlien() on null /home/nsnmt.com/integrity/application/controllers/User.php 13
DEBUG - 2022-04-11 07:45:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:45:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-11 07:45:25 --> Severity: error --> Exception: Call to a member function hitungJumlahKlien() on null /home/nsnmt.com/integrity/application/controllers/User.php 13
DEBUG - 2022-04-11 07:45:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:45:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:45:26 --> Total execution time: 0.0038
DEBUG - 2022-04-11 07:45:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-11 07:45:30 --> Severity: error --> Exception: Call to a member function hitungJumlahKlien() on null /home/nsnmt.com/integrity/application/controllers/User.php 13
DEBUG - 2022-04-11 07:46:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:46:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:46:52 --> Total execution time: 0.0231
DEBUG - 2022-04-11 07:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:46:53 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:47:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:47:33 --> Total execution time: 0.0246
DEBUG - 2022-04-11 07:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:47:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:47:33 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:48:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:48:22 --> Total execution time: 0.0249
DEBUG - 2022-04-11 07:48:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:48:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 07:48:22 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 07:48:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:48:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:48:56 --> Total execution time: 0.0049
DEBUG - 2022-04-11 07:48:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:48:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:48:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:48:59 --> Total execution time: 0.0030
DEBUG - 2022-04-11 07:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:49:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:49:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:49:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:49:12 --> Total execution time: 0.0027
DEBUG - 2022-04-11 07:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:49:23 --> Total execution time: 0.0044
DEBUG - 2022-04-11 07:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:49:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:49:26 --> Total execution time: 0.0111
DEBUG - 2022-04-11 07:51:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:51:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:51:43 --> Total execution time: 0.0039
DEBUG - 2022-04-11 07:56:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:56:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:56:11 --> Total execution time: 0.0429
DEBUG - 2022-04-11 07:57:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 07:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 07:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 07:57:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 07:57:53 --> Total execution time: 0.0439
DEBUG - 2022-04-11 08:02:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:02:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 08:02:25 --> Total execution time: 0.0532
DEBUG - 2022-04-11 08:02:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:02:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 08:02:32 --> Total execution time: 0.0185
DEBUG - 2022-04-11 08:02:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:02:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 08:02:36 --> Total execution time: 0.0030
DEBUG - 2022-04-11 08:06:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:06:42 --> Total execution time: 0.0406
DEBUG - 2022-04-11 08:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:07:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 08:07:06 --> Total execution time: 0.0232
DEBUG - 2022-04-11 08:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:07:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 08:07:06 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-11 08:07:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:07:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:07:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 08:07:07 --> Total execution time: 0.0061
DEBUG - 2022-04-11 08:07:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:07:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-11 08:07:10 --> Total execution time: 0.0070
DEBUG - 2022-04-11 08:08:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:36 --> Total execution time: 0.0054
DEBUG - 2022-04-11 08:08:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:39 --> Total execution time: 0.0053
DEBUG - 2022-04-11 08:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:41 --> Total execution time: 0.0039
DEBUG - 2022-04-11 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:45 --> Total execution time: 0.0042
DEBUG - 2022-04-11 08:08:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:50 --> Total execution time: 0.0040
DEBUG - 2022-04-11 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:53 --> Total execution time: 0.0037
DEBUG - 2022-04-11 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:55 --> Total execution time: 0.0038
DEBUG - 2022-04-11 08:08:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:08:57 --> Total execution time: 0.0076
DEBUG - 2022-04-11 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:00 --> Total execution time: 0.0040
DEBUG - 2022-04-11 08:09:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:03 --> Total execution time: 0.0058
DEBUG - 2022-04-11 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:06 --> Total execution time: 0.0041
DEBUG - 2022-04-11 08:09:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:08 --> Total execution time: 0.0028
DEBUG - 2022-04-11 08:09:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:10 --> Total execution time: 0.0053
DEBUG - 2022-04-11 08:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:13 --> Total execution time: 0.0029
DEBUG - 2022-04-11 08:09:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:16 --> Total execution time: 0.0024
DEBUG - 2022-04-11 08:09:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:17 --> Total execution time: 0.0048
DEBUG - 2022-04-11 08:09:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:20 --> Total execution time: 0.0063
DEBUG - 2022-04-11 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:27 --> Total execution time: 0.0028
DEBUG - 2022-04-11 08:09:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:29 --> Total execution time: 0.0034
DEBUG - 2022-04-11 08:09:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 08:09:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-11 08:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-11 08:09:34 --> Total execution time: 0.0038
DEBUG - 2022-04-11 20:28:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-11 20:28:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-11 20:28:01 --> 404 Page Not Found: Wp-loginphp/index
