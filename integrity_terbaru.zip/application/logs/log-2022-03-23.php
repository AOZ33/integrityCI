<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-23 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:37:49 --> No URI present. Default controller set.
DEBUG - 2022-03-23 09:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 09:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 09:37:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 09:37:49 --> Total execution time: 0.0307
DEBUG - 2022-03-23 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:37:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-03-23 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:37:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-23 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:37:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-23 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:37:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-23 09:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:37:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-23 09:37:49 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-23 09:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 09:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 09:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 09:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 09:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 09:37:51 --> Total execution time: 0.0067
DEBUG - 2022-03-23 09:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 09:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 09:42:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 09:42:45 --> Total execution time: 0.0401
DEBUG - 2022-03-23 09:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 09:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 09:42:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 09:42:46 --> Total execution time: 0.0036
DEBUG - 2022-03-23 09:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 09:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 09:49:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 09:49:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 09:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 09:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 09:49:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 09:49:03 --> Total execution time: 0.0064
DEBUG - 2022-03-23 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 10:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 10:00:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 10:00:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 10:00:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 10:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 10:00:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 10:00:45 --> Total execution time: 0.0068
DEBUG - 2022-03-23 10:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 10:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 10:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 10:06:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 10:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 10:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 10:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 10:06:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 10:06:37 --> Total execution time: 0.0065
DEBUG - 2022-03-23 11:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:06:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:06:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:06:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:06:07 --> Total execution time: 0.0064
DEBUG - 2022-03-23 11:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:16:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:16:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:16:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:16:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:16:44 --> Total execution time: 0.0059
DEBUG - 2022-03-23 11:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:20:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:20:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:20:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:20:05 --> Total execution time: 0.0057
DEBUG - 2022-03-23 11:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:33:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:33:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:33:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:33:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:33:33 --> Total execution time: 0.0063
DEBUG - 2022-03-23 11:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:37:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:37:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:37:21 --> Total execution time: 0.0060
DEBUG - 2022-03-23 11:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:41:29 --> Total execution time: 0.0061
DEBUG - 2022-03-23 11:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:44:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:44:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:44:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:44:04 --> Total execution time: 0.0057
DEBUG - 2022-03-23 11:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:47:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:47:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:47:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:47:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:47:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:47:15 --> Total execution time: 0.0060
DEBUG - 2022-03-23 11:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:49:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:49:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:49:27 --> Total execution time: 0.0062
DEBUG - 2022-03-23 11:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:51:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:51:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:51:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:51:46 --> Total execution time: 0.0050
DEBUG - 2022-03-23 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:56:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 11:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 11:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 11:56:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 11:56:55 --> Total execution time: 0.0062
DEBUG - 2022-03-23 12:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:30:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:30:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:30:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:30:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:30:39 --> Total execution time: 0.0070
DEBUG - 2022-03-23 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:32:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:32:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:32:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:32:24 --> Total execution time: 0.0050
DEBUG - 2022-03-23 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:35:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:35:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:35:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:35:07 --> Total execution time: 0.0062
DEBUG - 2022-03-23 12:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:39:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:39:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:39:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:39:48 --> Total execution time: 0.0059
DEBUG - 2022-03-23 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:42:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:42:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:42:49 --> Total execution time: 0.0064
DEBUG - 2022-03-23 12:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:43:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:43:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:43:59 --> Total execution time: 0.0035
DEBUG - 2022-03-23 12:47:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:47:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:47:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:47:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:47:34 --> Total execution time: 0.0056
DEBUG - 2022-03-23 12:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:49:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:49:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:49:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:49:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:49:38 --> Total execution time: 0.0057
DEBUG - 2022-03-23 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:51:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:51:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:51:45 --> Total execution time: 0.0054
DEBUG - 2022-03-23 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:53:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:53:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:53:29 --> Total execution time: 0.0051
DEBUG - 2022-03-23 12:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:56:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:56:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:56:21 --> Total execution time: 0.0053
DEBUG - 2022-03-23 12:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:58:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:58:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 12:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 12:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 12:58:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 12:58:57 --> Total execution time: 0.0062
DEBUG - 2022-03-23 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:03:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:03:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:03:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:03:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:03:16 --> Total execution time: 0.0066
DEBUG - 2022-03-23 13:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:05:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:05:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:05:54 --> Total execution time: 0.0049
DEBUG - 2022-03-23 13:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:10:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:10:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:10:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:10:31 --> Total execution time: 0.0063
DEBUG - 2022-03-23 13:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:19:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:19:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:19:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:19:58 --> Total execution time: 0.0063
DEBUG - 2022-03-23 13:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:24:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:24:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:24:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:24:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:24:01 --> Total execution time: 0.0067
DEBUG - 2022-03-23 13:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:32:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:32:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:32:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:32:27 --> Total execution time: 0.0063
DEBUG - 2022-03-23 13:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:35:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:35:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:35:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:35:56 --> Total execution time: 0.0043
DEBUG - 2022-03-23 13:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:37:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:37:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:37:51 --> Total execution time: 0.0054
DEBUG - 2022-03-23 13:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:38:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:38:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:38:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:38:37 --> Total execution time: 0.0037
DEBUG - 2022-03-23 13:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:39:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:39:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:39:59 --> Total execution time: 0.0052
DEBUG - 2022-03-23 13:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:41:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:41:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:41:24 --> Total execution time: 0.0048
DEBUG - 2022-03-23 13:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:42:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:42:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:42:54 --> Total execution time: 0.0044
DEBUG - 2022-03-23 13:45:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:45:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:45:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:45:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:45:51 --> Total execution time: 0.0045
DEBUG - 2022-03-23 13:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:48:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:48:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:48:53 --> Total execution time: 0.0044
DEBUG - 2022-03-23 13:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:51:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:51:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:51:32 --> Total execution time: 0.0052
DEBUG - 2022-03-23 13:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:55:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 13:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 13:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 13:55:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 13:55:38 --> Total execution time: 0.0065
DEBUG - 2022-03-23 14:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:06:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:06:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:06:35 --> Total execution time: 0.0062
DEBUG - 2022-03-23 14:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:09:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:09:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:09:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:09:11 --> Total execution time: 0.0056
DEBUG - 2022-03-23 14:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:10:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:10:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:10:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:10:36 --> Total execution time: 0.0045
DEBUG - 2022-03-23 14:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:14:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:14:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:14:35 --> Total execution time: 0.0063
DEBUG - 2022-03-23 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:18:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:18:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:18:31 --> Total execution time: 0.0060
DEBUG - 2022-03-23 14:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:19:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:19:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:19:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:19:57 --> Total execution time: 0.0047
DEBUG - 2022-03-23 14:20:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:20:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:20:00 --> Total execution time: 0.0129
DEBUG - 2022-03-23 14:20:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:20:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:20:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:20:03 --> Total execution time: 0.0034
DEBUG - 2022-03-23 14:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:22:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:22:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:22:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:22:09 --> Total execution time: 0.0043
DEBUG - 2022-03-23 14:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:24:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:24:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:24:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:24:30 --> Total execution time: 0.0070
DEBUG - 2022-03-23 14:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:26:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:26:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:26:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:26:23 --> Total execution time: 0.0045
DEBUG - 2022-03-23 14:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:39:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:39:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:39:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:39:16 --> Total execution time: 0.0059
DEBUG - 2022-03-23 14:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:46:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:46:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:46:59 --> Total execution time: 0.0068
DEBUG - 2022-03-23 14:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:49:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:49:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:49:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:49:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:49:16 --> Total execution time: 0.0049
DEBUG - 2022-03-23 14:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:51:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:51:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:51:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:51:06 --> Total execution time: 0.0052
DEBUG - 2022-03-23 14:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:53:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:53:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:53:15 --> Total execution time: 0.0045
DEBUG - 2022-03-23 14:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:55:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:55:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:55:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:55:29 --> Total execution time: 0.0050
DEBUG - 2022-03-23 14:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:59:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 14:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 14:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 14:59:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 14:59:46 --> Total execution time: 0.0062
DEBUG - 2022-03-23 15:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:01:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:01:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:01:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:01:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:01:57 --> Total execution time: 0.0046
DEBUG - 2022-03-23 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:10:58 --> Total execution time: 0.0062
DEBUG - 2022-03-23 15:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:22:03 --> Total execution time: 0.0062
DEBUG - 2022-03-23 15:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:24:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:24:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:24:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:24:53 --> Total execution time: 0.0052
DEBUG - 2022-03-23 15:27:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:27:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:27:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:27:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:27:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:27:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:27:17 --> Total execution time: 0.0049
DEBUG - 2022-03-23 15:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:30:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:30:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:30:05 --> Total execution time: 0.0060
DEBUG - 2022-03-23 15:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:31:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:31:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:31:53 --> Total execution time: 0.0049
DEBUG - 2022-03-23 15:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:33:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:33:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:33:41 --> Total execution time: 0.0052
DEBUG - 2022-03-23 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:34:30 --> Total execution time: 0.0048
DEBUG - 2022-03-23 15:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:37:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:37:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:37:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:37:46 --> Total execution time: 0.0058
DEBUG - 2022-03-23 15:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:41:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:41:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:41:02 --> Total execution time: 0.0060
DEBUG - 2022-03-23 15:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:43:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:43:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:43:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:43:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:43:15 --> Total execution time: 0.0044
DEBUG - 2022-03-23 15:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:50:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:50:02 --> Total execution time: 0.0055
DEBUG - 2022-03-23 15:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:52:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:52:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:52:55 --> Total execution time: 0.0045
DEBUG - 2022-03-23 15:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:55:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:55:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:55:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:55:08 --> Total execution time: 0.0051
DEBUG - 2022-03-23 15:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:57:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:57:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 15:57:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 15:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 15:57:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 15:57:23 --> Total execution time: 0.0056
DEBUG - 2022-03-23 16:02:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:02:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:02:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:02:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:02:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:02:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:02:59 --> Total execution time: 0.0061
DEBUG - 2022-03-23 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:05:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:05:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:05:05 --> Total execution time: 0.0050
DEBUG - 2022-03-23 16:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:07:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:07:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:07:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:07:22 --> Total execution time: 0.0059
DEBUG - 2022-03-23 16:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:11:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:11:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:11:13 --> Total execution time: 0.0071
DEBUG - 2022-03-23 16:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:12:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:12:18 --> Total execution time: 0.0154
DEBUG - 2022-03-23 16:12:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:12:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:12:24 --> Total execution time: 0.0034
DEBUG - 2022-03-23 16:12:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:12:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:12:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:12:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:12:35 --> Total execution time: 0.0064
DEBUG - 2022-03-23 16:14:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:14:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:14:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:14:44 --> Total execution time: 0.0326
DEBUG - 2022-03-23 16:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:14:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:14:54 --> Total execution time: 0.0088
DEBUG - 2022-03-23 16:14:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:14:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:14:57 --> Total execution time: 0.0035
DEBUG - 2022-03-23 16:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:17:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:17:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:17:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:17:55 --> Total execution time: 0.0051
DEBUG - 2022-03-23 16:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:23:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:23:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:23:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:23:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:23:50 --> Total execution time: 0.0063
DEBUG - 2022-03-23 16:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:29:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:29:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:29:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:29:45 --> Total execution time: 0.0062
DEBUG - 2022-03-23 16:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:32:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:32:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:32:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:32:37 --> Total execution time: 0.0049
DEBUG - 2022-03-23 16:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:32:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:32:56 --> Total execution time: 0.0132
DEBUG - 2022-03-23 16:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:33:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:33:07 --> Total execution time: 0.0036
DEBUG - 2022-03-23 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:45:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:45:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:45:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:45:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:45:32 --> Total execution time: 0.0065
DEBUG - 2022-03-23 16:45:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:45:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:45:36 --> Total execution time: 0.0133
DEBUG - 2022-03-23 16:45:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:45:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:45:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:45:39 --> Total execution time: 0.0037
DEBUG - 2022-03-23 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:47:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:47:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-23 16:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-23 16:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-23 16:47:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-23 16:47:31 --> Total execution time: 0.0048
