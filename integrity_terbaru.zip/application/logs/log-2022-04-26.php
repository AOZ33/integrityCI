<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-26 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:15 --> No URI present. Default controller set.
DEBUG - 2022-04-26 03:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 03:07:15 --> Total execution time: 0.0399
DEBUG - 2022-04-26 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 03:07:15 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-26 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 03:07:15 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-26 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 03:07:15 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-26 03:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 03:07:15 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-26 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 03:07:15 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-26 03:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 03:07:15 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-26 03:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 03:07:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:16 --> Total execution time: 0.0088
DEBUG - 2022-04-26 03:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:18 --> Total execution time: 0.0045
DEBUG - 2022-04-26 03:07:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:18 --> Total execution time: 0.0507
DEBUG - 2022-04-26 03:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:25 --> Total execution time: 0.0477
DEBUG - 2022-04-26 03:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:25 --> Total execution time: 0.0454
DEBUG - 2022-04-26 03:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:26 --> Total execution time: 0.0452
DEBUG - 2022-04-26 03:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:27 --> Total execution time: 0.0493
DEBUG - 2022-04-26 03:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:28 --> Total execution time: 0.0405
DEBUG - 2022-04-26 03:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:38 --> Total execution time: 0.0039
DEBUG - 2022-04-26 03:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 03:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 03:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 03:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 03:07:46 --> Total execution time: 0.0180
DEBUG - 2022-04-26 04:05:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:05:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:05:05 --> Total execution time: 0.0516
DEBUG - 2022-04-26 04:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:05:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 04:05:07 --> 404 Page Not Found: Calendar/index1
DEBUG - 2022-04-26 04:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:05:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:05:16 --> Total execution time: 0.0083
DEBUG - 2022-04-26 04:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:05:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:05:48 --> Total execution time: 0.0090
DEBUG - 2022-04-26 04:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:05:53 --> Total execution time: 0.0036
DEBUG - 2022-04-26 04:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:05:53 --> Total execution time: 0.0489
DEBUG - 2022-04-26 04:06:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:00 --> Total execution time: 0.0523
DEBUG - 2022-04-26 04:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:01 --> Total execution time: 0.0474
DEBUG - 2022-04-26 04:06:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:01 --> Total execution time: 0.0481
DEBUG - 2022-04-26 04:06:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:02 --> Total execution time: 0.0450
DEBUG - 2022-04-26 04:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:03 --> Total execution time: 0.0461
DEBUG - 2022-04-26 04:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:04 --> Total execution time: 0.0445
DEBUG - 2022-04-26 04:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:04 --> Total execution time: 0.0401
DEBUG - 2022-04-26 04:06:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:04 --> Total execution time: 0.0421
DEBUG - 2022-04-26 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:05 --> Total execution time: 0.0429
DEBUG - 2022-04-26 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:05 --> Total execution time: 0.0522
DEBUG - 2022-04-26 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:05 --> Total execution time: 0.0519
DEBUG - 2022-04-26 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:05 --> Total execution time: 0.0508
DEBUG - 2022-04-26 04:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:06 --> Total execution time: 0.0436
DEBUG - 2022-04-26 04:06:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:07 --> Total execution time: 0.0402
DEBUG - 2022-04-26 04:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:09 --> Total execution time: 0.0444
DEBUG - 2022-04-26 04:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:10 --> Total execution time: 0.0392
DEBUG - 2022-04-26 04:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:10 --> Total execution time: 0.0512
DEBUG - 2022-04-26 04:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:10 --> Total execution time: 0.0534
DEBUG - 2022-04-26 04:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:10 --> Total execution time: 0.0455
DEBUG - 2022-04-26 04:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:11 --> Total execution time: 0.0415
DEBUG - 2022-04-26 04:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:11 --> Total execution time: 0.0427
DEBUG - 2022-04-26 04:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:11 --> Total execution time: 0.0440
DEBUG - 2022-04-26 04:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:11 --> Total execution time: 0.0453
DEBUG - 2022-04-26 04:06:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:12 --> Total execution time: 0.0465
DEBUG - 2022-04-26 04:06:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:12 --> Total execution time: 0.0430
DEBUG - 2022-04-26 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:13 --> Total execution time: 0.0428
DEBUG - 2022-04-26 04:06:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:13 --> Total execution time: 0.0358
DEBUG - 2022-04-26 04:06:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:14 --> Total execution time: 0.0411
DEBUG - 2022-04-26 04:06:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:06:21 --> Total execution time: 0.0089
DEBUG - 2022-04-26 04:06:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:06:27 --> Total execution time: 0.0173
DEBUG - 2022-04-26 04:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:32 --> Total execution time: 0.0031
DEBUG - 2022-04-26 04:06:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:32 --> Total execution time: 0.0553
DEBUG - 2022-04-26 04:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:35 --> Total execution time: 0.0527
DEBUG - 2022-04-26 04:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:35 --> Total execution time: 0.0462
DEBUG - 2022-04-26 04:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:35 --> Total execution time: 0.0456
DEBUG - 2022-04-26 04:06:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:36 --> Total execution time: 0.0616
DEBUG - 2022-04-26 04:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:36 --> Total execution time: 0.0508
DEBUG - 2022-04-26 04:06:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:36 --> Total execution time: 0.0586
DEBUG - 2022-04-26 04:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:38 --> Total execution time: 0.0512
DEBUG - 2022-04-26 04:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:38 --> Total execution time: 0.0487
DEBUG - 2022-04-26 04:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:38 --> Total execution time: 0.0447
DEBUG - 2022-04-26 04:06:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:38 --> Total execution time: 0.0493
DEBUG - 2022-04-26 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:39 --> Total execution time: 0.0502
DEBUG - 2022-04-26 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:39 --> Total execution time: 0.0448
DEBUG - 2022-04-26 04:06:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:39 --> Total execution time: 0.0437
DEBUG - 2022-04-26 04:06:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:06:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:06:40 --> Total execution time: 0.0034
DEBUG - 2022-04-26 04:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:07:14 --> Total execution time: 0.0029
DEBUG - 2022-04-26 04:07:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:07:14 --> Total execution time: 0.0498
DEBUG - 2022-04-26 04:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:10:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:10:30 --> Total execution time: 0.0739
DEBUG - 2022-04-26 04:11:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:11:39 --> Total execution time: 0.0053
DEBUG - 2022-04-26 04:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:41 --> Total execution time: 0.0023
DEBUG - 2022-04-26 04:11:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:41 --> Total execution time: 0.0420
DEBUG - 2022-04-26 04:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:44 --> Total execution time: 0.0482
DEBUG - 2022-04-26 04:11:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:44 --> Total execution time: 0.0438
DEBUG - 2022-04-26 04:11:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:45 --> Total execution time: 0.0452
DEBUG - 2022-04-26 04:11:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:46 --> Total execution time: 0.0423
DEBUG - 2022-04-26 04:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:47 --> Total execution time: 0.0428
DEBUG - 2022-04-26 04:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:48 --> Total execution time: 0.0453
DEBUG - 2022-04-26 04:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:48 --> Total execution time: 0.0518
DEBUG - 2022-04-26 04:11:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:50 --> Total execution time: 0.0422
DEBUG - 2022-04-26 04:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:53 --> Total execution time: 0.0374
DEBUG - 2022-04-26 04:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:54 --> Total execution time: 0.0435
DEBUG - 2022-04-26 04:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:55 --> Total execution time: 0.0400
DEBUG - 2022-04-26 04:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:56 --> Total execution time: 0.0400
DEBUG - 2022-04-26 04:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:57 --> Total execution time: 0.0380
DEBUG - 2022-04-26 04:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:57 --> Total execution time: 0.0482
DEBUG - 2022-04-26 04:11:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:57 --> Total execution time: 0.0423
DEBUG - 2022-04-26 04:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:58 --> Total execution time: 0.0409
DEBUG - 2022-04-26 04:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:58 --> Total execution time: 0.0480
DEBUG - 2022-04-26 04:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:59 --> Total execution time: 0.0415
DEBUG - 2022-04-26 04:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:59 --> Total execution time: 0.0518
DEBUG - 2022-04-26 04:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:11:59 --> Total execution time: 0.0412
DEBUG - 2022-04-26 04:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:12:00 --> Total execution time: 0.0412
DEBUG - 2022-04-26 04:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:12:00 --> Total execution time: 0.0419
DEBUG - 2022-04-26 04:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:12:01 --> Total execution time: 0.0402
DEBUG - 2022-04-26 04:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:12:01 --> Total execution time: 0.0446
DEBUG - 2022-04-26 04:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:12:01 --> Total execution time: 0.0702
DEBUG - 2022-04-26 04:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:13 --> Total execution time: 0.0917
DEBUG - 2022-04-26 04:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:14 --> Total execution time: 0.0451
DEBUG - 2022-04-26 04:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:15 --> Total execution time: 0.0566
DEBUG - 2022-04-26 04:13:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:15 --> Total execution time: 0.0446
DEBUG - 2022-04-26 04:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:16 --> Total execution time: 0.0626
DEBUG - 2022-04-26 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:17 --> Total execution time: 0.0438
DEBUG - 2022-04-26 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:17 --> Total execution time: 0.0474
DEBUG - 2022-04-26 04:13:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:18 --> Total execution time: 0.0416
DEBUG - 2022-04-26 04:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:19 --> Total execution time: 0.0390
DEBUG - 2022-04-26 04:13:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:19 --> Total execution time: 0.0435
DEBUG - 2022-04-26 04:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:20 --> Total execution time: 0.0477
DEBUG - 2022-04-26 04:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:20 --> Total execution time: 0.0454
DEBUG - 2022-04-26 04:13:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:20 --> Total execution time: 0.0423
DEBUG - 2022-04-26 04:13:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:22 --> Total execution time: 0.0403
DEBUG - 2022-04-26 04:13:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:23 --> Total execution time: 0.0443
DEBUG - 2022-04-26 04:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:24 --> Total execution time: 0.0412
DEBUG - 2022-04-26 04:13:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:27 --> Total execution time: 0.0408
DEBUG - 2022-04-26 04:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:28 --> Total execution time: 0.0441
DEBUG - 2022-04-26 04:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:28 --> Total execution time: 0.0455
DEBUG - 2022-04-26 04:13:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:30 --> Total execution time: 0.0464
DEBUG - 2022-04-26 04:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:31 --> Total execution time: 0.0507
DEBUG - 2022-04-26 04:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:31 --> Total execution time: 0.0463
DEBUG - 2022-04-26 04:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:32 --> Total execution time: 0.0430
DEBUG - 2022-04-26 04:13:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:33 --> Total execution time: 0.0366
DEBUG - 2022-04-26 04:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:34 --> Total execution time: 0.0408
DEBUG - 2022-04-26 04:13:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:34 --> Total execution time: 0.0501
DEBUG - 2022-04-26 04:13:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:35 --> Total execution time: 0.0467
DEBUG - 2022-04-26 04:13:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:36 --> Total execution time: 0.0468
DEBUG - 2022-04-26 04:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:37 --> Total execution time: 0.0417
DEBUG - 2022-04-26 04:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:37 --> Total execution time: 0.0387
DEBUG - 2022-04-26 04:13:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:39 --> Total execution time: 0.0512
DEBUG - 2022-04-26 04:13:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:41 --> Total execution time: 0.0441
DEBUG - 2022-04-26 04:13:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:42 --> Total execution time: 0.0420
DEBUG - 2022-04-26 04:13:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:13:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:13:56 --> Total execution time: 0.0089
DEBUG - 2022-04-26 04:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:14:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:14:08 --> Total execution time: 0.0174
DEBUG - 2022-04-26 04:14:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:14:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:14:15 --> Total execution time: 0.0182
DEBUG - 2022-04-26 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:17:26 --> Total execution time: 0.0426
DEBUG - 2022-04-26 04:17:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:17:26 --> Total execution time: 0.0645
DEBUG - 2022-04-26 04:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:03 --> Total execution time: 0.0441
DEBUG - 2022-04-26 04:35:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:03 --> Total execution time: 0.0523
DEBUG - 2022-04-26 04:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:35:09 --> Total execution time: 0.0107
DEBUG - 2022-04-26 04:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:11 --> Total execution time: 0.0028
DEBUG - 2022-04-26 04:35:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:11 --> Total execution time: 0.0488
DEBUG - 2022-04-26 04:35:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:15 --> Total execution time: 0.0547
DEBUG - 2022-04-26 04:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:16 --> Total execution time: 0.0461
DEBUG - 2022-04-26 04:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:16 --> Total execution time: 0.0437
DEBUG - 2022-04-26 04:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:17 --> Total execution time: 0.0451
DEBUG - 2022-04-26 04:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:17 --> Total execution time: 0.0451
DEBUG - 2022-04-26 04:35:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:17 --> Total execution time: 0.0445
DEBUG - 2022-04-26 04:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:18 --> Total execution time: 0.0449
DEBUG - 2022-04-26 04:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:18 --> Total execution time: 0.0505
DEBUG - 2022-04-26 04:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:18 --> Total execution time: 0.0459
DEBUG - 2022-04-26 04:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 04:35:19 --> Total execution time: 0.0046
DEBUG - 2022-04-26 04:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:22 --> Total execution time: 0.0026
DEBUG - 2022-04-26 04:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 04:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 04:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 04:35:22 --> Total execution time: 0.0422
DEBUG - 2022-04-26 05:33:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 05:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 05:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 05:33:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 05:33:01 --> Total execution time: 0.0593
DEBUG - 2022-04-26 06:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:13:52 --> Total execution time: 0.0393
DEBUG - 2022-04-26 06:13:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:13:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:13:52 --> Total execution time: 0.0510
DEBUG - 2022-04-26 06:13:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:13:53 --> Total execution time: 0.0437
DEBUG - 2022-04-26 06:13:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:13:54 --> Total execution time: 0.0444
DEBUG - 2022-04-26 06:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:35:33 --> Total execution time: 0.0414
DEBUG - 2022-04-26 06:35:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:35:33 --> Total execution time: 0.0554
DEBUG - 2022-04-26 06:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:35:55 --> Total execution time: 0.0026
DEBUG - 2022-04-26 06:35:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:35:55 --> Total execution time: 0.0549
DEBUG - 2022-04-26 06:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:36:26 --> Total execution time: 0.0031
DEBUG - 2022-04-26 06:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:36:26 --> Total execution time: 0.0741
DEBUG - 2022-04-26 06:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:36:49 --> Total execution time: 0.0027
DEBUG - 2022-04-26 06:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:36:49 --> Total execution time: 0.0498
DEBUG - 2022-04-26 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:37:54 --> Total execution time: 0.0390
DEBUG - 2022-04-26 06:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:37:54 --> Total execution time: 0.0487
DEBUG - 2022-04-26 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:38:12 --> Total execution time: 0.0014
DEBUG - 2022-04-26 06:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:38:12 --> Total execution time: 0.0495
DEBUG - 2022-04-26 06:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:40:44 --> Total execution time: 0.0369
DEBUG - 2022-04-26 06:40:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:40:44 --> Total execution time: 0.0608
DEBUG - 2022-04-26 06:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:41:27 --> Total execution time: 0.0015
DEBUG - 2022-04-26 06:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:41:27 --> Total execution time: 0.0410
DEBUG - 2022-04-26 06:42:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:42:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 06:42:34 --> Total execution time: 0.0113
DEBUG - 2022-04-26 06:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:48:05 --> Total execution time: 0.0382
DEBUG - 2022-04-26 06:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:48:05 --> Total execution time: 0.0562
DEBUG - 2022-04-26 06:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:48:32 --> Total execution time: 0.0026
DEBUG - 2022-04-26 06:48:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:48:32 --> Total execution time: 0.0491
DEBUG - 2022-04-26 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:48:57 --> Total execution time: 0.0027
DEBUG - 2022-04-26 06:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:48:57 --> Total execution time: 0.0543
DEBUG - 2022-04-26 06:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:49:11 --> Total execution time: 0.0017
DEBUG - 2022-04-26 06:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 06:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 06:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 06:49:11 --> Total execution time: 0.0550
DEBUG - 2022-04-26 07:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:12:34 --> Total execution time: 0.0459
DEBUG - 2022-04-26 07:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:12:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:12:36 --> Total execution time: 0.0073
DEBUG - 2022-04-26 07:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:14:05 --> Total execution time: 0.0030
DEBUG - 2022-04-26 07:14:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:14:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:14:06 --> Total execution time: 0.0516
DEBUG - 2022-04-26 07:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:14:54 --> Total execution time: 0.0026
DEBUG - 2022-04-26 07:14:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:14:54 --> Total execution time: 0.0498
DEBUG - 2022-04-26 07:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:15:27 --> Total execution time: 0.0028
DEBUG - 2022-04-26 07:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:15:27 --> Total execution time: 0.0629
DEBUG - 2022-04-26 07:15:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:15:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:15:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:15:32 --> Total execution time: 0.0049
DEBUG - 2022-04-26 07:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:15:34 --> Total execution time: 0.0020
DEBUG - 2022-04-26 07:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:15:34 --> Total execution time: 0.0494
DEBUG - 2022-04-26 07:17:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:17:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:17:19 --> Total execution time: 0.0045
DEBUG - 2022-04-26 07:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:17:22 --> Total execution time: 0.0016
DEBUG - 2022-04-26 07:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:17:23 --> Total execution time: 0.0699
DEBUG - 2022-04-26 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:18:39 --> Total execution time: 0.0026
DEBUG - 2022-04-26 07:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:18:39 --> Total execution time: 0.0474
DEBUG - 2022-04-26 07:18:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:18:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:18:41 --> Total execution time: 0.0041
DEBUG - 2022-04-26 07:18:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:18:42 --> Total execution time: 0.0016
DEBUG - 2022-04-26 07:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:18:43 --> Total execution time: 0.0482
DEBUG - 2022-04-26 07:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:42:56 --> Total execution time: 0.0372
DEBUG - 2022-04-26 07:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:42:56 --> Total execution time: 0.0534
DEBUG - 2022-04-26 07:42:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:42:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:42:56 --> Total execution time: 0.0127
DEBUG - 2022-04-26 07:42:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:42:58 --> Total execution time: 0.0017
DEBUG - 2022-04-26 07:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:42:59 --> Total execution time: 0.0496
DEBUG - 2022-04-26 07:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:43:18 --> Total execution time: 0.0027
DEBUG - 2022-04-26 07:43:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:43:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:43:18 --> Total execution time: 0.0515
DEBUG - 2022-04-26 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:43:46 --> Total execution time: 0.0018
DEBUG - 2022-04-26 07:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:43:46 --> Total execution time: 0.0470
DEBUG - 2022-04-26 07:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:44:17 --> Total execution time: 0.0020
DEBUG - 2022-04-26 07:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:44:17 --> Total execution time: 0.0490
DEBUG - 2022-04-26 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:44:18 --> Total execution time: 0.0014
DEBUG - 2022-04-26 07:44:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:44:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:44:18 --> Total execution time: 0.0559
DEBUG - 2022-04-26 07:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:44:48 --> Total execution time: 0.0017
DEBUG - 2022-04-26 07:44:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:44:48 --> Total execution time: 0.0466
DEBUG - 2022-04-26 07:45:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:45:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:45:09 --> Total execution time: 0.0049
DEBUG - 2022-04-26 07:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:45:11 --> Total execution time: 0.0016
DEBUG - 2022-04-26 07:45:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:45:12 --> Total execution time: 0.0440
DEBUG - 2022-04-26 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:45:55 --> Total execution time: 0.0019
DEBUG - 2022-04-26 07:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:45:55 --> Total execution time: 0.0462
DEBUG - 2022-04-26 07:45:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:45:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 07:45:57 --> Total execution time: 0.0043
DEBUG - 2022-04-26 07:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:45:59 --> Total execution time: 0.0016
DEBUG - 2022-04-26 07:45:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 07:45:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 07:45:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 07:45:59 --> Total execution time: 0.0579
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> No URI present. Default controller set.
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:11:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 09:11:58 --> Total execution time: 0.0393
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:11:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:11:58 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:11:58 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:11:58 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:11:58 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:11:58 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> No URI present. Default controller set.
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:11:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 09:11:58 --> Total execution time: 0.0022
DEBUG - 2022-04-26 09:11:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:11:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-26 09:11:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:11:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-26 09:11:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-26 09:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-26 09:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:03 --> Total execution time: 0.0043
DEBUG - 2022-04-26 09:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:07 --> Total execution time: 0.0028
DEBUG - 2022-04-26 09:12:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:07 --> Total execution time: 0.0424
DEBUG - 2022-04-26 09:12:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:09 --> Total execution time: 0.0028
DEBUG - 2022-04-26 09:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:11 --> Total execution time: 0.0014
DEBUG - 2022-04-26 09:12:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:11 --> Total execution time: 0.0603
DEBUG - 2022-04-26 09:12:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:14 --> Total execution time: 0.0461
DEBUG - 2022-04-26 09:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:15 --> Total execution time: 0.0564
DEBUG - 2022-04-26 09:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:15 --> Total execution time: 0.0430
DEBUG - 2022-04-26 09:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:15 --> Total execution time: 0.0471
DEBUG - 2022-04-26 09:12:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:15 --> Total execution time: 0.0455
DEBUG - 2022-04-26 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:16 --> Total execution time: 0.0483
DEBUG - 2022-04-26 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:16 --> Total execution time: 0.0429
DEBUG - 2022-04-26 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:16 --> Total execution time: 0.0383
DEBUG - 2022-04-26 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:16 --> Total execution time: 0.0488
DEBUG - 2022-04-26 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:16 --> Total execution time: 0.0451
DEBUG - 2022-04-26 09:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:16 --> Total execution time: 0.0479
DEBUG - 2022-04-26 09:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:17 --> Total execution time: 0.0385
DEBUG - 2022-04-26 09:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:17 --> Total execution time: 0.0449
DEBUG - 2022-04-26 09:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:17 --> Total execution time: 0.0447
DEBUG - 2022-04-26 09:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:17 --> Total execution time: 0.0449
DEBUG - 2022-04-26 09:12:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:17 --> Total execution time: 0.0441
DEBUG - 2022-04-26 09:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:18 --> Total execution time: 0.0447
DEBUG - 2022-04-26 09:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:18 --> Total execution time: 0.0456
DEBUG - 2022-04-26 09:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:18 --> Total execution time: 0.0478
DEBUG - 2022-04-26 09:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:19 --> Total execution time: 0.0413
DEBUG - 2022-04-26 09:12:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:19 --> Total execution time: 0.0377
DEBUG - 2022-04-26 09:12:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:20 --> Total execution time: 0.0028
DEBUG - 2022-04-26 09:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:22 --> Total execution time: 0.0018
DEBUG - 2022-04-26 09:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:22 --> Total execution time: 0.0496
DEBUG - 2022-04-26 09:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:25 --> Total execution time: 0.0414
DEBUG - 2022-04-26 09:12:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:25 --> Total execution time: 0.0471
DEBUG - 2022-04-26 09:12:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:26 --> Total execution time: 0.0417
DEBUG - 2022-04-26 09:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:27 --> Total execution time: 0.0543
DEBUG - 2022-04-26 09:12:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:12:27 --> Total execution time: 0.0454
DEBUG - 2022-04-26 09:14:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-26 09:14:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-26 09:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-26 09:14:30 --> Total execution time: 0.0038
