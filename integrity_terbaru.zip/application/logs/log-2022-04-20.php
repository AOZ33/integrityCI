<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-20 00:04:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 00:04:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 00:04:46 --> 404 Page Not Found: Wp-loginphp/index
DEBUG - 2022-04-20 02:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:19 --> No URI present. Default controller set.
DEBUG - 2022-04-20 02:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:51:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:51:19 --> Total execution time: 0.0447
DEBUG - 2022-04-20 02:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:19 --> UTF-8 Support Enabled
ERROR - 2022-04-20 02:51:19 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-20 02:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:51:19 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-20 02:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:51:19 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-20 02:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:51:19 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-20 02:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:51:19 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-20 02:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:51:19 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-20 02:51:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:19 --> No URI present. Default controller set.
DEBUG - 2022-04-20 02:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:51:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:51:19 --> Total execution time: 0.0022
DEBUG - 2022-04-20 02:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:51:20 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-20 02:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:51:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:51:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:51:27 --> Total execution time: 0.0077
DEBUG - 2022-04-20 02:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:51:32 --> Total execution time: 0.0087
DEBUG - 2022-04-20 02:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:51:37 --> 404 Page Not Found: Techmeet/detail_techmeet
DEBUG - 2022-04-20 02:51:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:51:39 --> Total execution time: 0.0034
DEBUG - 2022-04-20 02:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:51:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:51:45 --> Total execution time: 0.0154
DEBUG - 2022-04-20 02:51:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:51:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:51:52 --> Total execution time: 0.0033
DEBUG - 2022-04-20 02:52:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:52:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:52:33 --> Total execution time: 0.0057
DEBUG - 2022-04-20 02:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:52:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:52:36 --> Total execution time: 0.0033
DEBUG - 2022-04-20 02:53:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:53:17 --> Total execution time: 0.0030
DEBUG - 2022-04-20 02:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:53:20 --> 404 Page Not Found: Techmeet/detail_techmeet
DEBUG - 2022-04-20 02:53:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:53:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:53:22 --> Total execution time: 0.0028
DEBUG - 2022-04-20 02:53:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:53:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:53:34 --> 404 Page Not Found: Techmeet/detail_techmeet
DEBUG - 2022-04-20 02:53:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:53:35 --> Total execution time: 0.0026
DEBUG - 2022-04-20 02:54:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:54:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:54:08 --> 404 Page Not Found: Techmeet/detail_techmeet
DEBUG - 2022-04-20 02:54:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:54:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:54:09 --> Total execution time: 0.0039
DEBUG - 2022-04-20 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:49 --> No URI present. Default controller set.
DEBUG - 2022-04-20 02:56:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:56:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:56:49 --> Total execution time: 0.0375
DEBUG - 2022-04-20 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:56:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-20 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:56:49 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-20 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:56:49 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-20 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:56:49 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-20 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:56:49 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-20 02:56:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 02:56:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-20 02:56:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:56:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:56:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:56:51 --> Total execution time: 0.0039
DEBUG - 2022-04-20 02:56:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 02:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 02:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 02:56:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 02:56:56 --> Total execution time: 0.0152
DEBUG - 2022-04-20 03:02:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:02:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 03:02:09 --> Total execution time: 0.0416
DEBUG - 2022-04-20 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:02:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 03:02:21 --> Total execution time: 0.0277
DEBUG - 2022-04-20 03:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 03:02:21 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 03:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:02:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 03:02:30 --> Total execution time: 0.0234
DEBUG - 2022-04-20 03:02:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 03:02:30 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 03:02:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:02:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 03:02:31 --> Total execution time: 0.0111
DEBUG - 2022-04-20 03:02:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:02:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 03:02:38 --> Total execution time: 0.0255
DEBUG - 2022-04-20 03:02:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 03:02:39 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:02:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 03:02:42 --> Total execution time: 0.0223
DEBUG - 2022-04-20 03:02:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 03:02:42 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 03:02:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:02:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:02:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:02:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 03:02:44 --> Total execution time: 0.0065
DEBUG - 2022-04-20 03:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:29:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 03:29:01 --> Total execution time: 0.0445
DEBUG - 2022-04-20 03:38:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 03:38:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 03:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 03:38:18 --> Total execution time: 0.0442
DEBUG - 2022-04-20 04:16:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:16:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:16:08 --> Total execution time: 0.0487
DEBUG - 2022-04-20 04:16:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:16:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:16:56 --> Total execution time: 0.0040
DEBUG - 2022-04-20 04:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:16:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 04:16:58 --> 404 Page Not Found: Techmeet/edit_techmeet
DEBUG - 2022-04-20 04:18:39 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-20 04:18:39 --> Severity: error --> Exception: Call to a member function techmeet() on null /home/nsnmt.com/integrity/application/controllers/Techmeet.php 83
DEBUG - 2022-04-20 04:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-20 04:19:18 --> Severity: error --> Exception: Call to undefined method Techmeet_model::techmeet() /home/nsnmt.com/integrity/application/controllers/Techmeet.php 83
DEBUG - 2022-04-20 04:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-20 04:19:19 --> Severity: error --> Exception: Call to undefined method Techmeet_model::techmeet() /home/nsnmt.com/integrity/application/controllers/Techmeet.php 83
DEBUG - 2022-04-20 04:19:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:19:23 --> Total execution time: 0.0051
DEBUG - 2022-04-20 04:19:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:19:25 --> Total execution time: 0.0024
DEBUG - 2022-04-20 04:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-20 04:19:27 --> Severity: error --> Exception: Call to undefined method Techmeet_model::techmeet() /home/nsnmt.com/integrity/application/controllers/Techmeet.php 83
DEBUG - 2022-04-20 04:20:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:20:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:20:11 --> Total execution time: 0.0052
DEBUG - 2022-04-20 04:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:21:13 --> Total execution time: 0.0042
DEBUG - 2022-04-20 04:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:21:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 04:21:26 --> 404 Page Not Found: Data/edit
DEBUG - 2022-04-20 04:21:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:21:52 --> Total execution time: 0.0040
DEBUG - 2022-04-20 04:21:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:21:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:21:54 --> Total execution time: 0.0022
DEBUG - 2022-04-20 04:22:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-20 04:22:04 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `techmeet`
WHERE `id` = Array
ERROR - 2022-04-20 04:22:04 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/nsnmt.com/integrity/application/models/Techmeet_model.php 25
DEBUG - 2022-04-20 04:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:23:25 --> Total execution time: 0.0037
DEBUG - 2022-04-20 04:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-20 04:23:27 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `techmeet`
WHERE `id` = Array
ERROR - 2022-04-20 04:23:27 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/nsnmt.com/integrity/application/models/Techmeet_model.php 25
DEBUG - 2022-04-20 04:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:23:31 --> Total execution time: 0.0033
DEBUG - 2022-04-20 04:25:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-04-20 04:25:07 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT *
FROM `techmeet`
WHERE `id` = Array
ERROR - 2022-04-20 04:25:07 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/nsnmt.com/integrity/application/models/Techmeet_model.php 25
DEBUG - 2022-04-20 04:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:25:47 --> Total execution time: 0.0068
DEBUG - 2022-04-20 04:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:25:47 --> Total execution time: 0.0025
DEBUG - 2022-04-20 04:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:25:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:25:57 --> Total execution time: 0.0046
DEBUG - 2022-04-20 04:26:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:26:02 --> Total execution time: 0.0026
DEBUG - 2022-04-20 04:26:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:26:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:26:06 --> Total execution time: 0.0024
DEBUG - 2022-04-20 04:27:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:27:56 --> Total execution time: 0.0422
DEBUG - 2022-04-20 04:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:28:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:28:06 --> Total execution time: 0.0040
DEBUG - 2022-04-20 04:28:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:28:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:28:13 --> Total execution time: 0.0023
DEBUG - 2022-04-20 04:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:15 --> Total execution time: 0.0028
DEBUG - 2022-04-20 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:18 --> Total execution time: 0.0031
DEBUG - 2022-04-20 04:29:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:29:23 --> Total execution time: 0.0116
DEBUG - 2022-04-20 04:29:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:29:26 --> Total execution time: 0.0023
DEBUG - 2022-04-20 04:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:29:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:29:42 --> Total execution time: 0.0080
DEBUG - 2022-04-20 04:29:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:47 --> Total execution time: 0.0029
DEBUG - 2022-04-20 04:29:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:29:54 --> Total execution time: 0.0026
DEBUG - 2022-04-20 04:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:30:03 --> Total execution time: 0.0024
DEBUG - 2022-04-20 04:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:30:08 --> Total execution time: 0.0022
DEBUG - 2022-04-20 04:32:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:32:56 --> No URI present. Default controller set.
DEBUG - 2022-04-20 04:32:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:32:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:32:56 --> Total execution time: 0.0368
DEBUG - 2022-04-20 04:33:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:33:21 --> Total execution time: 0.0179
DEBUG - 2022-04-20 04:33:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:33:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:33:22 --> Total execution time: 0.0025
DEBUG - 2022-04-20 04:33:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:33:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:33:23 --> Total execution time: 0.0059
DEBUG - 2022-04-20 04:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:33:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:33:28 --> Total execution time: 0.0071
DEBUG - 2022-04-20 04:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:33:30 --> Total execution time: 0.0043
DEBUG - 2022-04-20 04:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:33:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:33:36 --> Total execution time: 0.0067
DEBUG - 2022-04-20 04:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:38:01 --> Total execution time: 0.0494
DEBUG - 2022-04-20 04:38:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:38:31 --> Total execution time: 0.0049
DEBUG - 2022-04-20 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:38:43 --> Total execution time: 0.0029
DEBUG - 2022-04-20 04:38:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:38:47 --> Total execution time: 0.0025
DEBUG - 2022-04-20 04:38:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:38:50 --> Total execution time: 0.0034
DEBUG - 2022-04-20 04:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:40:57 --> Total execution time: 0.0026
DEBUG - 2022-04-20 04:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:40:59 --> Total execution time: 0.0023
DEBUG - 2022-04-20 04:41:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:41:02 --> Total execution time: 0.0027
DEBUG - 2022-04-20 04:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:42:25 --> Total execution time: 0.0032
DEBUG - 2022-04-20 04:42:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:42:26 --> Total execution time: 0.0027
DEBUG - 2022-04-20 04:42:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:42:28 --> Total execution time: 0.0025
DEBUG - 2022-04-20 04:43:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:02 --> Total execution time: 0.0031
DEBUG - 2022-04-20 04:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:10 --> Total execution time: 0.0030
DEBUG - 2022-04-20 04:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:16 --> Total execution time: 0.0032
DEBUG - 2022-04-20 04:43:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:50 --> Total execution time: 0.0026
DEBUG - 2022-04-20 04:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:43:52 --> Total execution time: 0.0114
DEBUG - 2022-04-20 04:43:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:54 --> Total execution time: 0.0056
DEBUG - 2022-04-20 04:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:43:58 --> Total execution time: 0.0046
DEBUG - 2022-04-20 04:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:44:01 --> Total execution time: 0.0055
DEBUG - 2022-04-20 04:44:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:44:05 --> Total execution time: 0.0041
DEBUG - 2022-04-20 04:44:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:44:08 --> Total execution time: 0.0035
DEBUG - 2022-04-20 04:44:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:44:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:44:12 --> Total execution time: 0.0038
DEBUG - 2022-04-20 04:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:44:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:44:14 --> Total execution time: 0.0024
DEBUG - 2022-04-20 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:44:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:44:26 --> Total execution time: 0.0257
DEBUG - 2022-04-20 04:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 04:44:26 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 04:44:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:44:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:44:42 --> Total execution time: 0.0236
DEBUG - 2022-04-20 04:44:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 04:44:43 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 04:44:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 04:44:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 04:44:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 04:44:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 04:44:44 --> Total execution time: 0.0075
DEBUG - 2022-04-20 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:25:53 --> No URI present. Default controller set.
DEBUG - 2022-04-20 05:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 05:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 05:25:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 05:25:53 --> Total execution time: 0.0425
DEBUG - 2022-04-20 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 05:25:53 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-20 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 05:25:53 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-20 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 05:25:53 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-20 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 05:25:53 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-20 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 05:25:53 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-20 05:25:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:25:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 05:25:53 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-20 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 05:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 05:26:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 05:26:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 05:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 05:26:37 --> Total execution time: 0.0034
DEBUG - 2022-04-20 05:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 05:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 05:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 05:26:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 05:26:46 --> Total execution time: 0.0108
DEBUG - 2022-04-20 06:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:12:51 --> Total execution time: 0.0518
DEBUG - 2022-04-20 06:13:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:13:37 --> Total execution time: 0.0024
DEBUG - 2022-04-20 06:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:14:11 --> Total execution time: 0.0046
DEBUG - 2022-04-20 06:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:15:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:15:01 --> Total execution time: 0.0270
DEBUG - 2022-04-20 06:15:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:15:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 06:15:02 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 06:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:15:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:15:04 --> Total execution time: 0.0099
DEBUG - 2022-04-20 06:37:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:37:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:37:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:37:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:37:50 --> Total execution time: 0.0427
DEBUG - 2022-04-20 06:39:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:39:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:39:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:39:22 --> Total execution time: 0.0040
DEBUG - 2022-04-20 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:39:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:39:24 --> Total execution time: 0.0142
DEBUG - 2022-04-20 06:39:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:39:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:39:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:39:33 --> Total execution time: 0.0024
DEBUG - 2022-04-20 06:40:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:40:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:40:55 --> Total execution time: 0.0422
DEBUG - 2022-04-20 06:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:40:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:40:59 --> Total execution time: 0.0098
DEBUG - 2022-04-20 06:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:41:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:41:01 --> Total execution time: 0.0029
DEBUG - 2022-04-20 06:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:41:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:41:24 --> Total execution time: 0.0025
DEBUG - 2022-04-20 06:41:30 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:41:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:41:30 --> Total execution time: 0.0038
DEBUG - 2022-04-20 06:41:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:41:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:41:32 --> Total execution time: 0.0075
DEBUG - 2022-04-20 06:41:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:41:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:41:35 --> Total execution time: 0.0038
DEBUG - 2022-04-20 06:41:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:41:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:41:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:41:42 --> Total execution time: 0.0072
DEBUG - 2022-04-20 06:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:41:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:41:43 --> Total execution time: 0.0022
DEBUG - 2022-04-20 06:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:41:53 --> Total execution time: 0.0063
DEBUG - 2022-04-20 06:43:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:43:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:43:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:43:03 --> Total execution time: 0.0113
DEBUG - 2022-04-20 06:43:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:43:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:43:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:43:11 --> Total execution time: 0.0047
DEBUG - 2022-04-20 06:43:14 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:43:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:43:14 --> Total execution time: 0.0087
DEBUG - 2022-04-20 06:44:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 06:44:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 06:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 06:44:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 06:44:17 --> Total execution time: 0.0596
DEBUG - 2022-04-20 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:25 --> No URI present. Default controller set.
DEBUG - 2022-04-20 07:05:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:05:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:05:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:05:25 --> Total execution time: 0.0496
DEBUG - 2022-04-20 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:05:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-20 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:05:25 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-20 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:05:25 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-20 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:05:25 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-20 07:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:05:25 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-20 07:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:05:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:05:31 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:05:31 --> Total execution time: 0.0037
DEBUG - 2022-04-20 07:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:05:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:05:38 --> Total execution time: 0.0267
DEBUG - 2022-04-20 07:05:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:05:38 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 07:05:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:05:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:05:40 --> Total execution time: 0.0048
DEBUG - 2022-04-20 07:07:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:07:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:07:00 --> Total execution time: 0.0684
DEBUG - 2022-04-20 07:07:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:07:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:07:06 --> Total execution time: 0.0045
DEBUG - 2022-04-20 07:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:07:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:07:11 --> Total execution time: 0.0065
DEBUG - 2022-04-20 07:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:07:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:07:13 --> Total execution time: 0.0027
DEBUG - 2022-04-20 07:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:08:03 --> Total execution time: 0.0092
DEBUG - 2022-04-20 07:08:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:08:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:08:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:08:17 --> Total execution time: 0.0038
DEBUG - 2022-04-20 07:14:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:14:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:14:23 --> Total execution time: 0.0499
DEBUG - 2022-04-20 07:32:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:32:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:32:20 --> Total execution time: 0.0640
DEBUG - 2022-04-20 07:32:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:32:21 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-04-20 07:32:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:32:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:32:32 --> Total execution time: 0.0125
DEBUG - 2022-04-20 07:32:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:58 --> No URI present. Default controller set.
DEBUG - 2022-04-20 07:32:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:32:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:32:58 --> Total execution time: 0.0029
DEBUG - 2022-04-20 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:32:59 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-20 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:32:59 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-20 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:32:59 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-20 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:32:59 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-20 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:32:59 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-20 07:32:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:32:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 07:32:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-20 07:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:33:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:33:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:33:10 --> Total execution time: 0.0074
DEBUG - 2022-04-20 07:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:37:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:37:02 --> Total execution time: 0.0435
DEBUG - 2022-04-20 07:37:04 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:37:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:37:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:37:04 --> Total execution time: 0.0118
DEBUG - 2022-04-20 07:37:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:37:15 --> Total execution time: 0.0042
DEBUG - 2022-04-20 07:37:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:37:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:37:19 --> Total execution time: 0.0037
DEBUG - 2022-04-20 07:37:27 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:37:27 --> Total execution time: 0.0032
DEBUG - 2022-04-20 07:37:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:37:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:37:49 --> Total execution time: 0.0046
DEBUG - 2022-04-20 07:37:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:37:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:37:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:37:55 --> Total execution time: 0.0032
DEBUG - 2022-04-20 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:38:10 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-20 07:38:10 --> The upload path does not appear to be valid.
DEBUG - 2022-04-20 07:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 07:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 07:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 07:38:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 07:38:10 --> Total execution time: 0.0029
DEBUG - 2022-04-20 08:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:39:58 --> No URI present. Default controller set.
DEBUG - 2022-04-20 08:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:39:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 08:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:39:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 08:39:58 --> Total execution time: 0.0165
DEBUG - 2022-04-20 08:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:39:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 08:39:58 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-04-20 08:39:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:39:58 --> No URI present. Default controller set.
DEBUG - 2022-04-20 08:39:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:39:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 08:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:39:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 08:39:59 --> Total execution time: 0.0076
DEBUG - 2022-04-20 08:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:40:05 --> Total execution time: 0.0046
DEBUG - 2022-04-20 08:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:40:09 --> Total execution time: 0.0038
DEBUG - 2022-04-20 08:40:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:40:50 --> Total execution time: 0.0041
DEBUG - 2022-04-20 08:40:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:40:51 --> Total execution time: 0.0026
DEBUG - 2022-04-20 08:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:40:53 --> Total execution time: 0.0036
DEBUG - 2022-04-20 08:41:19 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:41:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:41:19 --> Total execution time: 0.0038
DEBUG - 2022-04-20 08:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:41:56 --> Total execution time: 0.0036
DEBUG - 2022-04-20 08:42:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 08:42:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 08:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 08:42:08 --> Total execution time: 0.0039
DEBUG - 2022-04-20 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:28:24 --> No URI present. Default controller set.
DEBUG - 2022-04-20 15:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-20 15:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-20 15:28:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-20 15:28:24 --> Total execution time: 0.0397
DEBUG - 2022-04-20 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 15:28:24 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-20 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 15:28:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-20 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 15:28:24 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-20 15:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 15:28:24 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-20 15:28:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 15:28:24 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-20 15:28:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-20 15:28:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-20 15:28:25 --> 404 Page Not Found: Faviconico/index
