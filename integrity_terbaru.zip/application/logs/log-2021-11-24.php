<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-11-24 03:13:47 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:13:47 --> No URI present. Default controller set.
DEBUG - 2021-11-24 03:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 03:13:47 --> Total execution time: 0.1084
DEBUG - 2021-11-24 03:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 03:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 03:13:54 --> Total execution time: 0.0754
DEBUG - 2021-11-24 03:14:07 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:14:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 03:14:07 --> Total execution time: 0.0560
DEBUG - 2021-11-24 03:14:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:14:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:14:23 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 243
ERROR - 2021-11-24 03:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 243
ERROR - 2021-11-24 03:14:23 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 330
ERROR - 2021-11-24 03:14:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 330
DEBUG - 2021-11-24 03:14:23 --> Total execution time: 0.0409
DEBUG - 2021-11-24 03:39:23 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:39:23 --> Severity: Notice --> Undefined variable: join_table C:\xampp\htdocs\nesnu\application\views\package\index.php 243
ERROR - 2021-11-24 03:39:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 243
ERROR - 2021-11-24 03:39:23 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 330
ERROR - 2021-11-24 03:39:23 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 330
DEBUG - 2021-11-24 03:39:23 --> Total execution time: 0.0571
DEBUG - 2021-11-24 03:40:30 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:40:30 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 240
ERROR - 2021-11-24 03:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 240
ERROR - 2021-11-24 03:40:30 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 327
ERROR - 2021-11-24 03:40:30 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 327
DEBUG - 2021-11-24 03:40:30 --> Total execution time: 0.0513
DEBUG - 2021-11-24 03:48:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:48:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:48:56 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 292
ERROR - 2021-11-24 03:48:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 292
DEBUG - 2021-11-24 03:48:56 --> Total execution time: 0.0306
DEBUG - 2021-11-24 03:50:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:50:04 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 292
ERROR - 2021-11-24 03:50:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 292
DEBUG - 2021-11-24 03:50:04 --> Total execution time: 0.0507
DEBUG - 2021-11-24 03:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:50:14 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 292
ERROR - 2021-11-24 03:50:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 292
DEBUG - 2021-11-24 03:50:14 --> Total execution time: 0.0380
DEBUG - 2021-11-24 03:50:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:50:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 03:50:15 --> 404 Page Not Found: Package/detail
DEBUG - 2021-11-24 03:54:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:54:39 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 03:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 03:54:39 --> Total execution time: 0.0427
DEBUG - 2021-11-24 03:54:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:54:39 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 03:54:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 03:54:39 --> Total execution time: 0.0502
DEBUG - 2021-11-24 03:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:54:46 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 03:54:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 03:54:46 --> Total execution time: 0.0385
DEBUG - 2021-11-24 03:55:00 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:55:00 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 03:55:00 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 03:55:00 --> Total execution time: 0.0394
DEBUG - 2021-11-24 03:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:55:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 03:55:01 --> 404 Page Not Found: Package/detail1
DEBUG - 2021-11-24 03:55:05 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:55:05 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 03:55:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 03:55:05 --> Total execution time: 0.0499
DEBUG - 2021-11-24 03:55:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:55:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 03:55:06 --> 404 Page Not Found: Package/detail2
DEBUG - 2021-11-24 03:55:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 03:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 03:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 03:55:08 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 03:55:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 03:55:08 --> Total execution time: 0.0412
DEBUG - 2021-11-24 04:00:39 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:00:39 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 04:00:39 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 04:00:39 --> Total execution time: 0.0295
DEBUG - 2021-11-24 04:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 04:00:41 --> 404 Page Not Found: Package/detail1
DEBUG - 2021-11-24 04:02:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:02:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 04:02:02 --> 404 Page Not Found: Package/detail1
DEBUG - 2021-11-24 04:02:02 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:02:02 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 04:02:02 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 04:02:02 --> Total execution time: 0.0500
DEBUG - 2021-11-24 04:02:04 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 04:02:04 --> 404 Page Not Found: Package/detail1
DEBUG - 2021-11-24 04:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:02:42 --> Severity: error --> Exception: Too few arguments to function Package::detail(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\package.php 69
DEBUG - 2021-11-24 04:20:40 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:20:40 --> Severity: error --> Exception: Too few arguments to function Package::detail(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\package.php 69
DEBUG - 2021-11-24 04:22:12 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:22:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:22:12 --> Severity: error --> Exception: Too few arguments to function Package::detail(), 0 passed in C:\xampp\htdocs\nesnu\system\core\CodeIgniter.php on line 532 and exactly 1 expected C:\xampp\htdocs\nesnu\application\controllers\package.php 69
DEBUG - 2021-11-24 04:22:13 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:22:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 04:22:13 --> 404 Page Not Found: Package/detail1
DEBUG - 2021-11-24 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 04:22:14 --> 404 Page Not Found: Package/detail1
DEBUG - 2021-11-24 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:22:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-11-24 04:22:14 --> 404 Page Not Found: Package/detail1
DEBUG - 2021-11-24 04:22:14 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:22:14 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 04:22:14 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 04:22:14 --> Total execution time: 0.0492
DEBUG - 2021-11-24 04:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:22:15 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 04:22:15 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 04:22:15 --> Total execution time: 0.0286
DEBUG - 2021-11-24 04:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:22:16 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 04:22:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 04:22:16 --> Total execution time: 0.0458
DEBUG - 2021-11-24 04:22:16 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:22:16 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 293
ERROR - 2021-11-24 04:22:16 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 293
DEBUG - 2021-11-24 04:22:16 --> Total execution time: 0.0480
DEBUG - 2021-11-24 04:23:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:23:17 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 336
ERROR - 2021-11-24 04:23:17 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 336
DEBUG - 2021-11-24 04:23:17 --> Total execution time: 0.0511
DEBUG - 2021-11-24 04:26:17 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:26:18 --> Severity: Notice --> Undefined variable: ps C:\xampp\htdocs\nesnu\application\views\package\index.php 308
ERROR - 2021-11-24 04:26:18 --> Severity: Notice --> Trying to get property 'name_p' of non-object C:\xampp\htdocs\nesnu\application\views\package\index.php 308
ERROR - 2021-11-24 04:26:18 --> Severity: Notice --> Undefined variable: ps C:\xampp\htdocs\nesnu\application\views\package\index.php 308
ERROR - 2021-11-24 04:26:18 --> Severity: Notice --> Trying to get property 'name_p' of non-object C:\xampp\htdocs\nesnu\application\views\package\index.php 308
ERROR - 2021-11-24 04:26:18 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 332
ERROR - 2021-11-24 04:26:18 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 332
DEBUG - 2021-11-24 04:26:18 --> Total execution time: 0.0446
DEBUG - 2021-11-24 04:26:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:26:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:26:59 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 311
ERROR - 2021-11-24 04:26:59 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 311
ERROR - 2021-11-24 04:26:59 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 335
ERROR - 2021-11-24 04:26:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 335
DEBUG - 2021-11-24 04:26:59 --> Total execution time: 0.0313
DEBUG - 2021-11-24 04:30:44 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:30:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:30:44 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:30:44 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:30:44 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 04:30:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 04:30:44 --> Total execution time: 0.0474
DEBUG - 2021-11-24 04:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:32:27 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:32:27 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:32:27 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 04:32:27 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 04:32:27 --> Total execution time: 0.0458
DEBUG - 2021-11-24 04:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 04:32:34 --> Total execution time: 0.0400
DEBUG - 2021-11-24 04:32:41 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:32:41 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:32:41 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:32:41 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 04:32:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 04:32:41 --> Total execution time: 0.0524
DEBUG - 2021-11-24 04:32:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:32:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 04:32:42 --> Total execution time: 0.0444
DEBUG - 2021-11-24 04:35:56 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:35:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:35:56 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:35:56 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:35:56 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 04:35:56 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 04:35:56 --> Total execution time: 0.0424
DEBUG - 2021-11-24 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:36:59 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:36:59 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:36:59 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 04:36:59 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 04:36:59 --> Total execution time: 0.0384
DEBUG - 2021-11-24 04:36:59 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 04:36:59 --> Total execution time: 0.0391
DEBUG - 2021-11-24 04:37:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:37:01 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:37:01 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:37:01 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 04:37:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 04:37:01 --> Total execution time: 0.0279
DEBUG - 2021-11-24 04:37:01 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 04:37:01 --> Total execution time: 0.0477
DEBUG - 2021-11-24 04:37:31 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:37:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 04:37:31 --> Total execution time: 0.0510
DEBUG - 2021-11-24 04:37:33 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:37:33 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:37:33 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:37:33 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 04:37:33 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 04:37:33 --> Total execution time: 0.0415
DEBUG - 2021-11-24 04:38:06 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 04:38:06 --> Total execution time: 0.0404
DEBUG - 2021-11-24 04:45:08 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 04:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 04:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 04:45:08 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:45:08 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 04:45:08 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 04:45:08 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 04:45:08 --> Total execution time: 0.0565
DEBUG - 2021-11-24 05:13:48 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 05:13:48 --> Total execution time: 0.0316
DEBUG - 2021-11-24 05:13:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:13:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 05:13:53 --> Total execution time: 0.0513
DEBUG - 2021-11-24 05:13:54 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:13:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 05:13:54 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 05:13:54 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 05:13:54 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 05:13:54 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 05:13:54 --> Total execution time: 0.0494
DEBUG - 2021-11-24 05:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 05:13:55 --> Total execution time: 0.0467
DEBUG - 2021-11-24 05:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 05:13:55 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 05:13:55 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 05:13:55 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 05:13:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 05:13:55 --> Total execution time: 0.0448
DEBUG - 2021-11-24 05:15:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 05:15:18 --> Total execution time: 0.0409
DEBUG - 2021-11-24 05:15:25 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 05:15:25 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 05:15:25 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 05:15:25 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 05:15:25 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 05:15:25 --> Total execution time: 0.0523
DEBUG - 2021-11-24 05:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 05:18:18 --> Total execution time: 0.0482
DEBUG - 2021-11-24 05:18:21 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:18:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 05:18:21 --> Total execution time: 0.0292
DEBUG - 2021-11-24 05:18:22 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 05:18:22 --> Total execution time: 0.0401
DEBUG - 2021-11-24 05:18:42 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:18:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-11-24 05:18:42 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 05:18:42 --> Severity: Notice --> Undefined variable: name_p C:\xampp\htdocs\nesnu\application\views\package\index.php 310
ERROR - 2021-11-24 05:18:42 --> Severity: Notice --> Undefined variable: packages C:\xampp\htdocs\nesnu\application\views\package\index.php 333
ERROR - 2021-11-24 05:18:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nesnu\application\views\package\index.php 333
DEBUG - 2021-11-24 05:18:42 --> Total execution time: 0.0417
DEBUG - 2021-11-24 05:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-11-24 05:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-11-24 05:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-11-24 05:18:53 --> Total execution time: 0.0281
