<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-22 02:46:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 02:46:16 --> No URI present. Default controller set.
DEBUG - 2021-12-22 02:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 02:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 02:46:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 02:46:16 --> Total execution time: 0.0907
DEBUG - 2021-12-22 02:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 02:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 02:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 02:46:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 02:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 02:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 02:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 02:46:18 --> Total execution time: 0.0510
DEBUG - 2021-12-22 02:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 02:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 02:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 02:49:45 --> Total execution time: 0.0445
DEBUG - 2021-12-22 03:02:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:02:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:02:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:02:11 --> Total execution time: 0.0414
DEBUG - 2021-12-22 03:02:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:02:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:02:36 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:02:36 --> Total execution time: 0.0406
DEBUG - 2021-12-22 03:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:03:40 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:03:40 --> Total execution time: 0.0474
DEBUG - 2021-12-22 03:03:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:03:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:03:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:03:44 --> Total execution time: 0.0390
DEBUG - 2021-12-22 03:04:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:04:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:04:13 --> Total execution time: 0.0431
DEBUG - 2021-12-22 03:04:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:04:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:04:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:04:17 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:04:17 --> Total execution time: 0.0385
DEBUG - 2021-12-22 03:04:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:04:42 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:04:42 --> Total execution time: 0.0293
DEBUG - 2021-12-22 03:05:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:05:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:05:07 --> Total execution time: 0.0291
DEBUG - 2021-12-22 03:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:06:03 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:06:03 --> Total execution time: 0.0496
DEBUG - 2021-12-22 03:06:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:06:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:06:07 --> Total execution time: 0.0526
DEBUG - 2021-12-22 03:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:06:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:06:08 --> Total execution time: 0.0372
DEBUG - 2021-12-22 03:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:06:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:06:08 --> Total execution time: 0.0453
DEBUG - 2021-12-22 03:07:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:07:31 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 139
DEBUG - 2021-12-22 03:07:31 --> Total execution time: 0.0520
DEBUG - 2021-12-22 03:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:09:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:09:52 --> Total execution time: 0.0498
DEBUG - 2021-12-22 03:09:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:09:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:09:59 --> Total execution time: 0.0627
DEBUG - 2021-12-22 03:10:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:10:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:10:41 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:10:41 --> Total execution time: 0.0459
DEBUG - 2021-12-22 03:10:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:10:54 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:10:54 --> Total execution time: 0.0496
DEBUG - 2021-12-22 03:11:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:11:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:11:27 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 136
DEBUG - 2021-12-22 03:11:27 --> Total execution time: 0.0429
DEBUG - 2021-12-22 03:11:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:11:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:11:59 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 135
DEBUG - 2021-12-22 03:11:59 --> Total execution time: 0.0516
DEBUG - 2021-12-22 03:12:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:12:07 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 135
DEBUG - 2021-12-22 03:12:07 --> Total execution time: 0.0286
DEBUG - 2021-12-22 03:12:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:12:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:12:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 135
DEBUG - 2021-12-22 03:12:38 --> Total execution time: 0.0490
DEBUG - 2021-12-22 03:13:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:13:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:13:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 135
DEBUG - 2021-12-22 03:13:22 --> Total execution time: 0.0467
DEBUG - 2021-12-22 03:14:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:14:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 134
DEBUG - 2021-12-22 03:14:38 --> Total execution time: 0.0485
DEBUG - 2021-12-22 03:15:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:15:12 --> Total execution time: 0.0399
DEBUG - 2021-12-22 03:15:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:15:28 --> Total execution time: 0.0298
DEBUG - 2021-12-22 03:18:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:18:04 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:18:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:18:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:18:04 --> Total execution time: 0.0351
DEBUG - 2021-12-22 03:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:18:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:18:06 --> Total execution time: 0.0585
DEBUG - 2021-12-22 03:18:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:18:08 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:18:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:18:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:18:08 --> Total execution time: 0.0246
DEBUG - 2021-12-22 03:19:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:19:10 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:19:10 --> Total execution time: 0.0560
DEBUG - 2021-12-22 03:19:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:19:14 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:19:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:19:14 --> Total execution time: 0.0259
DEBUG - 2021-12-22 03:19:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:19:48 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:19:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:19:48 --> Total execution time: 0.0424
DEBUG - 2021-12-22 03:19:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:19:49 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:19:49 --> Total execution time: 0.0245
DEBUG - 2021-12-22 03:19:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:19:53 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:19:53 --> Total execution time: 0.0258
DEBUG - 2021-12-22 03:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:19:58 --> Total execution time: 0.0388
DEBUG - 2021-12-22 03:20:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:02 --> Total execution time: 0.0405
DEBUG - 2021-12-22 03:20:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:04 --> Total execution time: 0.0421
DEBUG - 2021-12-22 03:20:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:09 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:09 --> Total execution time: 0.0258
DEBUG - 2021-12-22 03:20:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:13 --> Total execution time: 0.0412
DEBUG - 2021-12-22 03:20:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:20:18 --> Severity: Warning --> Undefined property: Menu::$form_validation C:\xampp\htdocs\nesnu\application\controllers\menu.php 19
ERROR - 2021-12-22 03:20:18 --> Severity: error --> Exception: Call to a member function set_rules() on null C:\xampp\htdocs\nesnu\application\controllers\menu.php 19
DEBUG - 2021-12-22 03:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:20:38 --> Severity: Warning --> Undefined property: Menu::$form_validation C:\xampp\htdocs\nesnu\application\controllers\menu.php 19
ERROR - 2021-12-22 03:20:38 --> Severity: error --> Exception: Call to a member function run() on null C:\xampp\htdocs\nesnu\application\controllers\menu.php 19
DEBUG - 2021-12-22 03:20:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:20:39 --> Severity: Warning --> Undefined property: Menu::$form_validation C:\xampp\htdocs\nesnu\application\controllers\menu.php 19
ERROR - 2021-12-22 03:20:39 --> Severity: error --> Exception: Call to a member function run() on null C:\xampp\htdocs\nesnu\application\controllers\menu.php 19
DEBUG - 2021-12-22 03:20:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 03:20:40 --> Severity: Warning --> Undefined property: Menu::$form_validation C:\xampp\htdocs\nesnu\application\controllers\menu.php 19
ERROR - 2021-12-22 03:20:40 --> Severity: error --> Exception: Call to a member function run() on null C:\xampp\htdocs\nesnu\application\controllers\menu.php 19
DEBUG - 2021-12-22 03:20:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:47 --> Total execution time: 0.0490
DEBUG - 2021-12-22 03:20:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:20:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:20:52 --> Total execution time: 0.0281
DEBUG - 2021-12-22 03:28:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:28:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:28:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:28:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:28:02 --> Total execution time: 0.0388
DEBUG - 2021-12-22 03:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:28:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:28:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:28:29 --> Total execution time: 0.0376
DEBUG - 2021-12-22 03:28:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:28:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:28:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:28:40 --> Total execution time: 0.0559
DEBUG - 2021-12-22 03:28:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:28:45 --> Total execution time: 0.0373
DEBUG - 2021-12-22 03:29:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:29:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:29:29 --> Total execution time: 0.0334
DEBUG - 2021-12-22 03:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:30:41 --> Total execution time: 0.0378
DEBUG - 2021-12-22 03:30:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:30:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:47 --> Total execution time: 0.0401
DEBUG - 2021-12-22 03:30:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:49 --> Total execution time: 0.0392
DEBUG - 2021-12-22 03:30:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:30:50 --> Total execution time: 0.0393
DEBUG - 2021-12-22 03:30:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:30:51 --> Total execution time: 0.0575
DEBUG - 2021-12-22 03:30:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:51 --> Total execution time: 0.0458
DEBUG - 2021-12-22 03:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:52 --> Total execution time: 0.0535
DEBUG - 2021-12-22 03:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:52 --> Total execution time: 0.0497
DEBUG - 2021-12-22 03:30:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:53 --> Total execution time: 0.0334
DEBUG - 2021-12-22 03:30:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:54 --> Total execution time: 0.0525
DEBUG - 2021-12-22 03:30:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:54 --> Total execution time: 0.0452
DEBUG - 2021-12-22 03:30:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:30:55 --> Total execution time: 0.0342
DEBUG - 2021-12-22 03:31:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:31:07 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:31:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:31:08 --> Total execution time: 0.0391
DEBUG - 2021-12-22 03:31:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:31:43 --> Total execution time: 0.0541
DEBUG - 2021-12-22 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:31:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:31:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:31:46 --> Total execution time: 0.0426
DEBUG - 2021-12-22 03:31:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:31:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:31:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:31:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:31:47 --> Total execution time: 0.0434
DEBUG - 2021-12-22 03:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:31:48 --> Total execution time: 0.0388
DEBUG - 2021-12-22 03:42:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:42:28 --> No URI present. Default controller set.
DEBUG - 2021-12-22 03:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:42:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:42:28 --> Total execution time: 0.4526
DEBUG - 2021-12-22 03:42:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:42:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:42:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:42:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:42:31 --> Total execution time: 0.0775
DEBUG - 2021-12-22 03:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:42:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:42:34 --> Total execution time: 0.0874
DEBUG - 2021-12-22 03:42:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:42:35 --> Total execution time: 0.0347
DEBUG - 2021-12-22 03:42:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:42:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:42:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:42:36 --> Total execution time: 0.0969
DEBUG - 2021-12-22 03:42:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:42:38 --> Total execution time: 0.0529
DEBUG - 2021-12-22 03:44:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:44:30 --> Total execution time: 0.0420
DEBUG - 2021-12-22 03:45:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:45:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:45:05 --> Total execution time: 0.0515
DEBUG - 2021-12-22 03:45:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:45:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:45:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:45:09 --> Total execution time: 0.0528
DEBUG - 2021-12-22 03:48:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:03 --> Total execution time: 0.4588
DEBUG - 2021-12-22 03:48:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:06 --> Total execution time: 0.0523
DEBUG - 2021-12-22 03:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:10 --> Total execution time: 0.0407
DEBUG - 2021-12-22 03:48:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:13 --> Total execution time: 0.0521
DEBUG - 2021-12-22 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:15 --> Total execution time: 0.0434
DEBUG - 2021-12-22 03:48:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:17 --> Total execution time: 0.0283
DEBUG - 2021-12-22 03:48:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:22 --> Total execution time: 0.0302
DEBUG - 2021-12-22 03:48:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:48:25 --> Total execution time: 0.0512
DEBUG - 2021-12-22 03:51:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:51:30 --> Total execution time: 0.0465
DEBUG - 2021-12-22 03:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:52:58 --> Total execution time: 0.0464
DEBUG - 2021-12-22 03:53:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:09 --> Total execution time: 0.0466
DEBUG - 2021-12-22 03:53:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:53:12 --> Total execution time: 0.0673
DEBUG - 2021-12-22 03:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:53:25 --> Total execution time: 0.0279
DEBUG - 2021-12-22 03:53:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 03:53:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:27 --> Total execution time: 0.0530
DEBUG - 2021-12-22 03:53:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:29 --> Total execution time: 0.0465
DEBUG - 2021-12-22 03:53:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:32 --> Total execution time: 0.0460
DEBUG - 2021-12-22 03:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:33 --> Total execution time: 0.0464
DEBUG - 2021-12-22 03:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:33 --> Total execution time: 0.0392
DEBUG - 2021-12-22 03:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:34 --> Total execution time: 0.0282
DEBUG - 2021-12-22 03:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:35 --> Total execution time: 0.0462
DEBUG - 2021-12-22 03:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:35 --> Total execution time: 0.0440
DEBUG - 2021-12-22 03:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:36 --> Total execution time: 0.0452
DEBUG - 2021-12-22 03:53:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:53:38 --> Total execution time: 0.0460
DEBUG - 2021-12-22 03:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:54:21 --> Total execution time: 0.0479
DEBUG - 2021-12-22 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:54:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:54:22 --> Total execution time: 0.0484
DEBUG - 2021-12-22 03:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 03:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 03:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 03:55:22 --> Total execution time: 0.0434
DEBUG - 2021-12-22 04:10:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:10:26 --> Total execution time: 0.0306
DEBUG - 2021-12-22 04:13:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:13:13 --> Total execution time: 0.0500
DEBUG - 2021-12-22 04:13:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:13:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:13:43 --> Total execution time: 0.0492
DEBUG - 2021-12-22 04:13:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:13:44 --> Total execution time: 0.0508
DEBUG - 2021-12-22 04:13:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:13:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:13:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:13:57 --> Total execution time: 0.0396
DEBUG - 2021-12-22 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:18:22 --> Total execution time: 0.0447
DEBUG - 2021-12-22 04:18:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined array key "active" C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 66
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 67
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $m C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 68
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> Undefined variable $menu C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 114
ERROR - 2021-12-22 04:18:23 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 114
DEBUG - 2021-12-22 04:18:23 --> Total execution time: 0.1085
DEBUG - 2021-12-22 04:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 04:18:53 --> Severity: Warning --> Undefined variable $menu C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 114
ERROR - 2021-12-22 04:18:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 114
DEBUG - 2021-12-22 04:18:53 --> Total execution time: 0.0459
DEBUG - 2021-12-22 04:27:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 04:27:50 --> Query error: Unknown column ' user_sub_menu.menu_id' in 'on clause' - Invalid query: SELECT `user_sub_menu`.*, `user_menu`.`menu`
                    FROM `user_sub_menu` JOIN `user_menu`
                    ON ` user_sub_menu`.`menu_id` =`user_menu`.`id`       
                     
DEBUG - 2021-12-22 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 04:29:08 --> Query error: Unknown column ' user_sub_menu.menu_id' in 'on clause' - Invalid query: SELECT `user_sub_menu`.*, `user_menu`.`menu`
                    FROM `user_sub_menu` JOIN `user_menu`
                    ON ` user_sub_menu`.`menu_id` =`user_menu`.`id`       
                     
DEBUG - 2021-12-22 04:29:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:29:08 --> Total execution time: 0.0311
DEBUG - 2021-12-22 04:29:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 04:29:10 --> Query error: Unknown column ' user_sub_menu.menu_id' in 'on clause' - Invalid query: SELECT `user_sub_menu`.*, `user_menu`.`menu`
                    FROM `user_sub_menu` JOIN `user_menu`
                    ON ` user_sub_menu`.`menu_id` =`user_menu`.`id`       
                     
DEBUG - 2021-12-22 04:31:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 04:31:30 --> Severity: Warning --> Undefined variable $menu C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 114
ERROR - 2021-12-22 04:31:30 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 114
DEBUG - 2021-12-22 04:31:30 --> Total execution time: 0.0479
DEBUG - 2021-12-22 04:36:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:36:21 --> Total execution time: 0.0489
DEBUG - 2021-12-22 04:38:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:38:37 --> Total execution time: 0.0411
DEBUG - 2021-12-22 04:39:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:39:53 --> Total execution time: 0.0505
DEBUG - 2021-12-22 04:55:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:55:32 --> Total execution time: 0.0561
DEBUG - 2021-12-22 04:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 04:57:27 --> Severity: error --> Exception: Unclosed '{' on line 5 C:\xampp\htdocs\nesnu\application\controllers\menu.php 69
DEBUG - 2021-12-22 04:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 04:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 04:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 04:58:22 --> Total execution time: 0.0468
DEBUG - 2021-12-22 05:01:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:01:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:01:16 --> Total execution time: 0.0520
DEBUG - 2021-12-22 05:01:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:01:18 --> Total execution time: 0.0460
DEBUG - 2021-12-22 05:48:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:48:29 --> Total execution time: 0.0498
DEBUG - 2021-12-22 05:48:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:48:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:48:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:48:41 --> Total execution time: 0.0566
DEBUG - 2021-12-22 05:51:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:51:00 --> Total execution time: 0.0310
DEBUG - 2021-12-22 05:51:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:51:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:51:05 --> Total execution time: 0.0414
DEBUG - 2021-12-22 05:58:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:58:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:58:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:58:12 --> Total execution time: 0.0433
DEBUG - 2021-12-22 05:58:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 05:58:13 --> Severity: error --> Exception: C:\xampp\htdocs\nesnu\application\models/Admin_model.php exists, but doesn't declare class Admin_model C:\xampp\htdocs\nesnu\system\core\Loader.php 340
DEBUG - 2021-12-22 05:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 05:58:29 --> Query error: Table 'admin_nesnu.userrole' doesn't exist - Invalid query: SELECT *
FROM `userRole`
DEBUG - 2021-12-22 05:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 05:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 05:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 05:59:50 --> Total execution time: 0.0542
DEBUG - 2021-12-22 06:00:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:00:32 --> Total execution time: 0.0542
DEBUG - 2021-12-22 06:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:06:15 --> Total execution time: 0.0388
DEBUG - 2021-12-22 06:15:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:15:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:15:34 --> Total execution time: 0.0626
DEBUG - 2021-12-22 06:16:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:16:11 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:16:11 --> Total execution time: 0.0603
DEBUG - 2021-12-22 06:19:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:19:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:19:25 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:19:25 --> Total execution time: 0.0566
DEBUG - 2021-12-22 06:24:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:24:55 --> No URI present. Default controller set.
DEBUG - 2021-12-22 06:24:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:24:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:24:55 --> Total execution time: 0.0391
DEBUG - 2021-12-22 06:24:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:24:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:24:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:24:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:24:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:24:57 --> Total execution time: 0.0355
DEBUG - 2021-12-22 06:30:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:30:24 --> No URI present. Default controller set.
DEBUG - 2021-12-22 06:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:30:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:30:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:30:24 --> Total execution time: 0.4383
DEBUG - 2021-12-22 06:30:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:30:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:30:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:30:26 --> Total execution time: 0.1366
DEBUG - 2021-12-22 06:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:45 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:31:45 --> Total execution time: 0.1093
DEBUG - 2021-12-22 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:31:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:31:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:31:51 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:31:51 --> Total execution time: 0.0502
DEBUG - 2021-12-22 06:32:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:32:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:32:01 --> Total execution time: 0.1056
DEBUG - 2021-12-22 06:32:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:32:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:32:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:32:01 --> Total execution time: 0.0764
DEBUG - 2021-12-22 06:32:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:32:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:32:03 --> Total execution time: 0.0393
DEBUG - 2021-12-22 06:32:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:32:20 --> Total execution time: 0.0515
DEBUG - 2021-12-22 06:32:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:32:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:32:20 --> Total execution time: 0.0474
DEBUG - 2021-12-22 06:32:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:32:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:32:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 06:32:21 --> Total execution time: 0.0395
DEBUG - 2021-12-22 06:32:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:32:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:32:24 --> Total execution time: 0.0494
DEBUG - 2021-12-22 06:33:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:33:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:33:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:33:28 --> Total execution time: 0.0559
DEBUG - 2021-12-22 06:34:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:34:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:04 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:34:04 --> Total execution time: 0.0573
DEBUG - 2021-12-22 06:34:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:30 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:34:30 --> Total execution time: 0.0570
DEBUG - 2021-12-22 06:34:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:34:38 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:34:38 --> Total execution time: 0.0360
DEBUG - 2021-12-22 06:35:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:35:28 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:35:28 --> Total execution time: 0.0402
DEBUG - 2021-12-22 06:36:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:15 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:36:15 --> Total execution time: 0.0535
DEBUG - 2021-12-22 06:36:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:24 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:36:24 --> Total execution time: 0.0552
DEBUG - 2021-12-22 06:36:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:36:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:36:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:36:47 --> Total execution time: 0.0353
DEBUG - 2021-12-22 06:36:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:36:58 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:36:58 --> Total execution time: 0.0546
DEBUG - 2021-12-22 06:37:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:37:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:37:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:37:17 --> Total execution time: 0.0451
DEBUG - 2021-12-22 06:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:37:46 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:37:46 --> Total execution time: 0.0525
DEBUG - 2021-12-22 06:39:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:39:18 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:39:18 --> Total execution time: 0.4640
DEBUG - 2021-12-22 06:39:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:39:53 --> Total execution time: 0.0811
DEBUG - 2021-12-22 06:40:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:40:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:40:22 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:40:22 --> Total execution time: 0.0365
DEBUG - 2021-12-22 06:46:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:46:29 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
DEBUG - 2021-12-22 06:46:29 --> Total execution time: 0.0579
DEBUG - 2021-12-22 06:47:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:47:40 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
DEBUG - 2021-12-22 06:47:40 --> Total execution time: 0.0468
DEBUG - 2021-12-22 06:48:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:48:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:48:11 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
DEBUG - 2021-12-22 06:48:11 --> Total execution time: 0.0484
DEBUG - 2021-12-22 06:48:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:48:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
DEBUG - 2021-12-22 06:48:28 --> Total execution time: 0.0434
DEBUG - 2021-12-22 06:49:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:49:02 --> Total execution time: 0.0597
DEBUG - 2021-12-22 06:49:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:49:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:49:17 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
DEBUG - 2021-12-22 06:49:17 --> Total execution time: 0.0362
DEBUG - 2021-12-22 06:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
ERROR - 2021-12-22 06:49:28 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 138
DEBUG - 2021-12-22 06:49:28 --> Total execution time: 0.0601
DEBUG - 2021-12-22 06:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:49:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:49:33 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:49:33 --> Total execution time: 0.0360
DEBUG - 2021-12-22 06:50:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:50:06 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:50:06 --> Total execution time: 0.0360
DEBUG - 2021-12-22 06:52:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:08 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:52:08 --> Total execution time: 0.0502
DEBUG - 2021-12-22 06:52:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
ERROR - 2021-12-22 06:52:43 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 158
DEBUG - 2021-12-22 06:52:43 --> Total execution time: 0.0376
DEBUG - 2021-12-22 06:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:53:18 --> Severity: error --> Exception: syntax error, unexpected token "endforeach", expecting end of file C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 189
DEBUG - 2021-12-22 06:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:53:24 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:53:24 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 144
ERROR - 2021-12-22 06:53:24 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 159
ERROR - 2021-12-22 06:53:24 --> Severity: Warning --> Undefined variable $icon C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 162
DEBUG - 2021-12-22 06:53:24 --> Total execution time: 0.0485
DEBUG - 2021-12-22 06:53:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:53:38 --> Total execution time: 0.0507
DEBUG - 2021-12-22 06:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 06:54:20 --> Total execution time: 0.0418
DEBUG - 2021-12-22 06:55:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:55:01 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 135
ERROR - 2021-12-22 06:55:01 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 144
ERROR - 2021-12-22 06:55:01 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 154
ERROR - 2021-12-22 06:55:01 --> Severity: Warning --> Undefined variable $icon C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 157
DEBUG - 2021-12-22 06:55:01 --> Total execution time: 0.0459
DEBUG - 2021-12-22 06:55:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:55:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 137
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 146
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:55:44 --> Severity: Warning --> Undefined variable $url C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 161
DEBUG - 2021-12-22 06:55:44 --> Total execution time: 0.0562
DEBUG - 2021-12-22 06:56:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:56:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> Undefined variable $id C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 137
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:56:52 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
DEBUG - 2021-12-22 06:56:52 --> Total execution time: 0.0596
DEBUG - 2021-12-22 06:57:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 06:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 06:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
ERROR - 2021-12-22 06:57:34 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\submenu.php 152
DEBUG - 2021-12-22 06:57:34 --> Total execution time: 0.0521
DEBUG - 2021-12-22 07:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:00:42 --> Total execution time: 0.0402
DEBUG - 2021-12-22 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:00:56 --> Total execution time: 0.0430
DEBUG - 2021-12-22 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:01:06 --> Total execution time: 0.0432
DEBUG - 2021-12-22 07:01:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:01:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:01:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:01:13 --> Total execution time: 0.0432
DEBUG - 2021-12-22 07:01:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:01:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:01:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:01:17 --> Total execution time: 0.0440
DEBUG - 2021-12-22 07:01:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:01:34 --> Total execution time: 0.0281
DEBUG - 2021-12-22 07:02:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:04 --> Total execution time: 0.0387
DEBUG - 2021-12-22 07:02:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:07 --> Total execution time: 0.0443
DEBUG - 2021-12-22 07:02:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 07:02:07 --> Total execution time: 0.0620
DEBUG - 2021-12-22 07:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 07:02:28 --> Total execution time: 0.0726
DEBUG - 2021-12-22 07:02:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:38 --> Total execution time: 0.0576
DEBUG - 2021-12-22 07:02:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:38 --> Total execution time: 0.0277
DEBUG - 2021-12-22 07:02:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:42 --> Total execution time: 0.0494
DEBUG - 2021-12-22 07:02:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:46 --> Total execution time: 0.0937
DEBUG - 2021-12-22 07:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:47 --> Total execution time: 0.0680
DEBUG - 2021-12-22 07:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:48 --> Total execution time: 0.0765
DEBUG - 2021-12-22 07:02:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:49 --> Total execution time: 0.0516
DEBUG - 2021-12-22 07:02:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:50 --> Total execution time: 0.0429
DEBUG - 2021-12-22 07:02:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:50 --> Total execution time: 0.0425
DEBUG - 2021-12-22 07:02:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:51 --> Total execution time: 0.0444
DEBUG - 2021-12-22 07:02:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:52 --> Total execution time: 0.0390
DEBUG - 2021-12-22 07:02:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:52 --> Total execution time: 0.0849
DEBUG - 2021-12-22 07:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:53 --> Total execution time: 0.0942
DEBUG - 2021-12-22 07:02:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:54 --> Total execution time: 0.0872
DEBUG - 2021-12-22 07:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:02:55 --> Total execution time: 0.0851
DEBUG - 2021-12-22 07:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:03:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 07:03:00 --> Total execution time: 0.0458
DEBUG - 2021-12-22 07:03:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:03:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 07:03:58 --> Total execution time: 0.0290
DEBUG - 2021-12-22 07:05:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:05:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:05:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 07:05:30 --> Total execution time: 0.0455
DEBUG - 2021-12-22 07:05:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:05:59 --> Total execution time: 0.0455
DEBUG - 2021-12-22 07:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:06:01 --> Total execution time: 0.0410
DEBUG - 2021-12-22 07:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:06:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 07:06:03 --> Total execution time: 0.0500
DEBUG - 2021-12-22 07:06:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:06:05 --> Total execution time: 0.0423
DEBUG - 2021-12-22 07:06:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:06:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:06:07 --> Total execution time: 0.0427
DEBUG - 2021-12-22 07:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:12:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:12:27 --> Total execution time: 0.0389
DEBUG - 2021-12-22 07:15:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:15:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:15:12 --> Total execution time: 0.0523
DEBUG - 2021-12-22 07:20:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:20:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-22 07:20:45 --> Severity: Warning --> Undefined variable $r C:\xampp\htdocs\nesnu\application\views\admin\index.php 149
ERROR - 2021-12-22 07:20:45 --> Severity: Warning --> Trying to access array offset on value of type null C:\xampp\htdocs\nesnu\application\views\admin\index.php 149
DEBUG - 2021-12-22 07:20:45 --> Total execution time: 0.0537
DEBUG - 2021-12-22 07:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:21:36 --> Total execution time: 0.0290
DEBUG - 2021-12-22 07:22:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:22:29 --> Total execution time: 0.0436
DEBUG - 2021-12-22 07:22:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:22:32 --> Total execution time: 0.0488
DEBUG - 2021-12-22 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:23:02 --> Total execution time: 0.0368
DEBUG - 2021-12-22 07:23:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:23:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:23:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 07:23:13 --> Total execution time: 0.0455
DEBUG - 2021-12-22 07:23:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:23:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:23:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 07:23:14 --> Total execution time: 0.0389
DEBUG - 2021-12-22 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:23:15 --> Total execution time: 0.0425
DEBUG - 2021-12-22 07:23:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:23:15 --> Total execution time: 0.0419
DEBUG - 2021-12-22 07:23:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:23:16 --> Total execution time: 0.0514
DEBUG - 2021-12-22 07:23:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 07:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 07:23:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 07:23:17 --> Total execution time: 0.0384
DEBUG - 2021-12-22 16:46:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:46:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 16:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:46:32 --> 404 Page Not Found: /index
ERROR - 2021-12-22 16:46:32 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2021-12-22 16:46:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:46:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:46:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 16:46:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:46:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:46:35 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:46:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:46:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:46:41 --> 404 Page Not Found: Public/index
DEBUG - 2021-12-22 16:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:46:45 --> 404 Page Not Found: View/index
DEBUG - 2021-12-22 16:47:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:47:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:47:04 --> 404 Page Not Found: Views/index
DEBUG - 2021-12-22 16:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:49:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:49:54 --> 404 Page Not Found: Views/index
DEBUG - 2021-12-22 16:49:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:49:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:49:56 --> 404 Page Not Found: V/index
DEBUG - 2021-12-22 16:50:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:50:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:50:21 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:50:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:50:40 --> 404 Page Not Found: Auth/index
DEBUG - 2021-12-22 16:51:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:51:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:51:56 --> 404 Page Not Found: Auth/index
DEBUG - 2021-12-22 16:51:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:51:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:51:58 --> 404 Page Not Found: Auth/index
DEBUG - 2021-12-22 16:52:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:52:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:52:01 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:52:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:52:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:52:02 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:56:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:56:02 --> 404 Page Not Found: Views/auth
DEBUG - 2021-12-22 16:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:56:08 --> 404 Page Not Found: Views/auth
DEBUG - 2021-12-22 16:56:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:56:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:56:57 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:57:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:57:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:57:06 --> 404 Page Not Found: Auth/index
DEBUG - 2021-12-22 16:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:31 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:33 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:33 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:33 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:34 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:51 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:51 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:52 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:52 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:52 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:58:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:58:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:58:52 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 16:59:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 16:59:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 16:59:44 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:02:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:02:24 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 17:02:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:02:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:02:53 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:04:20 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 17:04:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:04:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:04:35 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 17:04:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:04:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:04:37 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 17:07:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:07:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:07:47 --> 404 Page Not Found: /index
DEBUG - 2021-12-22 17:12:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:12:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:12:26 --> Total execution time: 0.0303
DEBUG - 2021-12-22 17:12:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:12:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:12:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:12:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:12:26 --> 404 Page Not Found: Nesnu/assets
ERROR - 2021-12-22 17:12:26 --> 404 Page Not Found: Nesnu/assets
ERROR - 2021-12-22 17:12:26 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:12:27 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:12:27 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:12:27 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:12:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:12:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:12:27 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:13:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:13:49 --> Total execution time: 0.0305
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:13:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:13:49 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:14:36 --> Total execution time: 0.0294
DEBUG - 2021-12-22 17:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:14:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:14:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:14:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:14:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:14:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:14:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:14:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:14:51 --> Total execution time: 0.0041
DEBUG - 2021-12-22 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:14:52 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:14:52 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:14:52 --> UTF-8 Support Enabled
ERROR - 2021-12-22 17:14:52 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:14:52 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:14:52 --> 404 Page Not Found: Nesnu/assets
ERROR - 2021-12-22 17:14:52 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:14:52 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:14:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:14:52 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:15:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:15:25 --> 404 Page Not Found: Nesnu/auth
DEBUG - 2021-12-22 17:15:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:15:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:15:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:15:33 --> Total execution time: 0.0232
DEBUG - 2021-12-22 17:15:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:15:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:15:34 --> 404 Page Not Found: Nesnu/assets
DEBUG - 2021-12-22 17:15:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:15:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:15:36 --> Total execution time: 0.0040
DEBUG - 2021-12-22 17:15:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:15:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:15:38 --> Total execution time: 0.0036
DEBUG - 2021-12-22 17:17:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:17:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:17:02 --> Total execution time: 0.0301
DEBUG - 2021-12-22 17:17:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:17:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:17:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:17:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:17:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:17:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:17:47 --> Total execution time: 0.0043
DEBUG - 2021-12-22 17:17:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:17:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:17:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:18:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:18:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:18:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:18:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:18:10 --> Total execution time: 0.0040
DEBUG - 2021-12-22 17:18:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:18:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:18:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:18:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:18:23 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:18:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:18:23 --> Total execution time: 0.0043
DEBUG - 2021-12-22 17:18:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:18:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:18:23 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:18:45 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:18:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:18:45 --> Total execution time: 0.0039
DEBUG - 2021-12-22 17:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:18:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:18:45 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:18:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:18:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:18:46 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 17:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:19:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:19:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:19:08 --> Total execution time: 0.0071
DEBUG - 2021-12-22 17:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:19:39 --> Total execution time: 0.0329
DEBUG - 2021-12-22 17:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:19:57 --> Total execution time: 0.0056
DEBUG - 2021-12-22 17:20:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:20:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:20:04 --> Total execution time: 0.0060
DEBUG - 2021-12-22 17:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:20:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:20:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:20:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:20:35 --> Total execution time: 0.0055
DEBUG - 2021-12-22 17:20:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:20:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:20:50 --> Total execution time: 0.0080
DEBUG - 2021-12-22 17:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:21:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 17:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:21:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:21:59 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 17:22:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:22:01 --> 404 Page Not Found: Nesnu/index
DEBUG - 2021-12-22 17:22:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:22:03 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:22:03 --> Total execution time: 0.0238
DEBUG - 2021-12-22 17:22:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:22:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:22:03 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:22:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:22:10 --> Total execution time: 0.0057
DEBUG - 2021-12-22 17:26:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:26:04 --> Total execution time: 0.0336
DEBUG - 2021-12-22 17:26:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:04 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:26:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:26:04 --> Total execution time: 0.0048
DEBUG - 2021-12-22 17:26:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:26:05 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:26:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:26:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 17:26:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:26:08 --> Total execution time: 0.0062
DEBUG - 2021-12-22 17:26:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:26:11 --> Total execution time: 0.0063
DEBUG - 2021-12-22 17:26:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:26:13 --> Total execution time: 0.0048
DEBUG - 2021-12-22 17:26:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:26:14 --> Total execution time: 0.0055
DEBUG - 2021-12-22 17:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:26:15 --> Total execution time: 0.0044
DEBUG - 2021-12-22 17:26:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:26:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:26:16 --> Total execution time: 0.0069
DEBUG - 2021-12-22 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:27:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:27:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:27:04 --> Total execution time: 0.0037
DEBUG - 2021-12-22 17:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:27:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:27:04 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:27:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:27:09 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:27:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:27:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:27:09 --> Total execution time: 0.0043
DEBUG - 2021-12-22 17:27:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:27:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:27:09 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:27:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:27:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:27:38 --> 404 Page Not Found: Forgot-passwordhtml/index
DEBUG - 2021-12-22 17:27:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:27:39 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:27:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:27:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:27:39 --> Total execution time: 0.0044
DEBUG - 2021-12-22 17:34:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:34:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:34:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:34:54 --> Total execution time: 0.0066
DEBUG - 2021-12-22 17:34:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:34:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:34:57 --> Total execution time: 0.0070
DEBUG - 2021-12-22 17:38:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:38:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:38:31 --> Total execution time: 0.0334
DEBUG - 2021-12-22 17:38:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:38:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:38:33 --> Total execution time: 0.0053
DEBUG - 2021-12-22 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:38:34 --> Total execution time: 0.0063
DEBUG - 2021-12-22 17:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:38:34 --> Total execution time: 0.0056
DEBUG - 2021-12-22 17:38:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:38:35 --> Total execution time: 0.0067
DEBUG - 2021-12-22 17:38:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:38:37 --> Total execution time: 0.0058
DEBUG - 2021-12-22 17:38:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:38:38 --> Total execution time: 0.0050
DEBUG - 2021-12-22 17:38:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:38:39 --> Total execution time: 0.0045
DEBUG - 2021-12-22 17:40:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:40:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:40:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:40:35 --> Total execution time: 0.0350
DEBUG - 2021-12-22 17:40:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:40:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:40:37 --> Total execution time: 0.0057
DEBUG - 2021-12-22 17:40:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:40:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:40:42 --> Total execution time: 0.0056
DEBUG - 2021-12-22 17:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:40:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:40:43 --> Total execution time: 0.0050
DEBUG - 2021-12-22 17:40:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:40:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:40:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:40:44 --> Total execution time: 0.0055
DEBUG - 2021-12-22 17:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:40:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:40:45 --> Total execution time: 0.0046
DEBUG - 2021-12-22 17:40:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:40:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:40:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:40:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:40:46 --> Total execution time: 0.0051
DEBUG - 2021-12-22 17:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:52:28 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:52:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:52:28 --> Total execution time: 0.0308
DEBUG - 2021-12-22 17:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:52:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:52:28 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:53:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:23 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:53:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:53:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:53:23 --> Total execution time: 0.0312
DEBUG - 2021-12-22 17:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:53:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:53:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 17:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:25 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:53:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:53:25 --> Total execution time: 0.0038
DEBUG - 2021-12-22 17:53:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:53:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:32 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:53:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:53:32 --> Total execution time: 0.0039
DEBUG - 2021-12-22 17:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:53:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:53:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:53:32 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 17:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:52 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:53:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:53:52 --> Total execution time: 0.0043
DEBUG - 2021-12-22 17:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:53:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:53:52 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:54:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:01 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:54:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:54:01 --> Total execution time: 0.0046
DEBUG - 2021-12-22 17:54:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:54:01 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:06 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:54:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:54:06 --> Total execution time: 0.0042
DEBUG - 2021-12-22 17:54:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:54:06 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:54:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:54:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:54:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:54:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:54:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:54:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:54:26 --> Total execution time: 0.0041
DEBUG - 2021-12-22 17:54:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:54:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 17:54:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:49 --> No URI present. Default controller set.
DEBUG - 2021-12-22 17:54:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 17:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 17:54:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 17:54:49 --> Total execution time: 0.0041
DEBUG - 2021-12-22 17:54:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 17:54:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 17:54:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 18:01:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:01:19 --> No URI present. Default controller set.
DEBUG - 2021-12-22 18:01:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:01:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:01:19 --> Total execution time: 0.0308
DEBUG - 2021-12-22 18:01:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:01:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 18:01:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 18:05:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:05:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:05:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:05:01 --> Total execution time: 0.0075
DEBUG - 2021-12-22 18:08:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:06 --> Total execution time: 0.0340
DEBUG - 2021-12-22 18:08:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:08:07 --> Total execution time: 0.0078
DEBUG - 2021-12-22 18:08:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:08:09 --> Total execution time: 0.0057
DEBUG - 2021-12-22 18:08:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:08:14 --> Total execution time: 0.0051
DEBUG - 2021-12-22 18:08:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:08:15 --> Total execution time: 0.0053
DEBUG - 2021-12-22 18:08:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:08:40 --> Total execution time: 0.0048
DEBUG - 2021-12-22 18:08:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:08:41 --> Total execution time: 0.0049
DEBUG - 2021-12-22 18:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:08:42 --> Total execution time: 0.0046
DEBUG - 2021-12-22 18:08:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:08:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:08:43 --> Total execution time: 0.0051
DEBUG - 2021-12-22 18:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:09:16 --> No URI present. Default controller set.
DEBUG - 2021-12-22 18:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:09:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:09:16 --> Total execution time: 0.0315
DEBUG - 2021-12-22 18:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 18:09:16 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 18:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:09:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 18:09:16 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 18:10:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:10:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 18:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 18:10:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 18:10:24 --> Total execution time: 0.0039
DEBUG - 2021-12-22 18:10:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 18:10:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 18:10:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 21:08:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:08:20 --> No URI present. Default controller set.
DEBUG - 2021-12-22 21:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 21:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 21:08:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 21:08:20 --> Total execution time: 0.0306
DEBUG - 2021-12-22 21:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 21:08:21 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 21:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 21:08:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-22 21:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 21:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 21:08:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 21:08:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 21:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 21:08:29 --> Total execution time: 0.0071
DEBUG - 2021-12-22 21:08:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 21:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 21:08:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 21:08:41 --> Total execution time: 0.0044
DEBUG - 2021-12-22 21:08:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:08:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-22 21:08:41 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-22 21:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 21:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 21:08:51 --> Total execution time: 0.0048
DEBUG - 2021-12-22 21:39:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 21:39:57 --> No URI present. Default controller set.
DEBUG - 2021-12-22 21:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 21:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 21:39:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 21:39:57 --> Total execution time: 0.0306
DEBUG - 2021-12-22 23:53:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 23:53:10 --> No URI present. Default controller set.
DEBUG - 2021-12-22 23:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 23:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 23:53:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 23:53:10 --> Total execution time: 0.0314
DEBUG - 2021-12-22 23:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 23:53:11 --> No URI present. Default controller set.
DEBUG - 2021-12-22 23:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 23:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 23:53:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 23:53:11 --> Total execution time: 0.0040
DEBUG - 2021-12-22 23:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 23:53:11 --> No URI present. Default controller set.
DEBUG - 2021-12-22 23:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 23:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 23:53:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 23:53:11 --> Total execution time: 0.0038
DEBUG - 2021-12-22 23:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-22 23:53:11 --> No URI present. Default controller set.
DEBUG - 2021-12-22 23:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-22 23:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-22 23:53:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-22 23:53:11 --> Total execution time: 0.0038
