<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-20 00:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-20 00:34:33 --> No URI present. Default controller set.
DEBUG - 2022-02-20 00:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-20 00:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-20 00:34:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-20 00:34:33 --> Total execution time: 0.0301
DEBUG - 2022-02-20 22:40:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-20 22:40:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-20 22:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-02-20 22:40:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-20 22:40:19 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-02-20 23:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-20 23:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-20 23:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-20 23:53:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-20 23:53:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-02-20 23:53:56 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
