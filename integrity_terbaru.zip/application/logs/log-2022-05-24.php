<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-24 03:05:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:05:41 --> No URI present. Default controller set.
DEBUG - 2022-05-24 03:05:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:05:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:05:41 --> Total execution time: 0.0518
DEBUG - 2022-05-24 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:05:42 --> 404 Page Not Found: Assets/https:
ERROR - 2022-05-24 03:05:42 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-24 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:05:42 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-24 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:05:42 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-24 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:05:42 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-24 03:05:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:05:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:05:42 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-24 03:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:08:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:08:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:08:43 --> Total execution time: 0.0066
DEBUG - 2022-05-24 03:34:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:34:53 --> No URI present. Default controller set.
DEBUG - 2022-05-24 03:34:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:34:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:34:54 --> Total execution time: 0.0502
DEBUG - 2022-05-24 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:34:54 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-24 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:34:54 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-24 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:34:54 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-24 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:34:54 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-24 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:34:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-05-24 03:34:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:34:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:34:54 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-24 03:34:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:34:55 --> No URI present. Default controller set.
DEBUG - 2022-05-24 03:34:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:34:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:34:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:34:55 --> Total execution time: 0.0027
DEBUG - 2022-05-24 03:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:35:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:35:20 --> Total execution time: 0.0040
DEBUG - 2022-05-24 03:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 03:35:21 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-24 03:35:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:35:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:35:25 --> Total execution time: 0.0176
DEBUG - 2022-05-24 03:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:37:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:37:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:37:14 --> Total execution time: 0.0616
DEBUG - 2022-05-24 03:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 03:38:52 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 03:38:52 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' Nurizka & Fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Highlight     1 menit')
DEBUG - 2022-05-24 03:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:38:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:38:52 --> Total execution time: 0.0140
DEBUG - 2022-05-24 03:39:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:39:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:39:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:39:20 --> Total execution time: 0.0055
DEBUG - 2022-05-24 03:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:39:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:39:42 --> Total execution time: 0.0050
DEBUG - 2022-05-24 03:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 03:40:49 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 03:40:49 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' nurizka & fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Akad & Resepsi        (10-20menit)')
DEBUG - 2022-05-24 03:40:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:40:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:40:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:40:49 --> Total execution time: 0.0110
DEBUG - 2022-05-24 03:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 03:41:56 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 03:41:56 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' Nurizka & Fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'PHOTO', 'Akad        (20X60)\r\nResepsi    (20X60)\r\n\r\nPembesaran uk. 16Rp (1)')
DEBUG - 2022-05-24 03:41:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:41:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:41:56 --> Total execution time: 0.0092
DEBUG - 2022-05-24 03:42:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:42:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:42:00 --> Total execution time: 0.0067
DEBUG - 2022-05-24 03:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:42:02 --> Total execution time: 0.0051
DEBUG - 2022-05-24 03:42:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:42:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:42:04 --> Total execution time: 0.0050
DEBUG - 2022-05-24 03:42:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:42:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:42:13 --> Total execution time: 0.0084
DEBUG - 2022-05-24 03:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:42:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:42:19 --> Total execution time: 0.0049
DEBUG - 2022-05-24 03:43:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:16 --> Total execution time: 0.0073
DEBUG - 2022-05-24 03:43:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:17 --> Total execution time: 0.0030
DEBUG - 2022-05-24 03:43:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:21 --> Total execution time: 0.0054
DEBUG - 2022-05-24 03:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:25 --> Total execution time: 0.0081
DEBUG - 2022-05-24 03:43:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:26 --> Total execution time: 0.0024
DEBUG - 2022-05-24 03:43:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:33 --> Total execution time: 0.0041
DEBUG - 2022-05-24 03:43:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:35 --> Total execution time: 0.0046
DEBUG - 2022-05-24 03:43:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:38 --> Total execution time: 0.0044
DEBUG - 2022-05-24 03:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:40 --> Total execution time: 0.0059
DEBUG - 2022-05-24 03:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:42 --> Total execution time: 0.0108
DEBUG - 2022-05-24 03:43:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:44 --> Total execution time: 0.0041
DEBUG - 2022-05-24 03:43:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:52 --> Total execution time: 0.0039
DEBUG - 2022-05-24 03:43:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:43:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:43:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:43:58 --> Total execution time: 0.0048
DEBUG - 2022-05-24 03:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:44:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:44:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:44:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:44:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:44:54 --> Total execution time: 0.0038
DEBUG - 2022-05-24 03:44:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:44:57 --> Total execution time: 0.0038
DEBUG - 2022-05-24 03:45:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:45:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:45:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:45:03 --> Total execution time: 0.0043
DEBUG - 2022-05-24 03:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 03:46:00 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 03:46:00 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' Nurizka & Fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Akad & Resepsi       (10-20menit)')
DEBUG - 2022-05-24 03:46:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:46:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:46:00 --> Total execution time: 0.0041
DEBUG - 2022-05-24 03:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 03:47:37 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 03:47:37 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' Nurizka & Fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'PHOTO', 'Akad         (20X60)\r\nResepsi     (20X60)\r\n\r\nPembesaran uk. 16Rp (1)')
DEBUG - 2022-05-24 03:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:47:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:47:37 --> Total execution time: 0.0100
DEBUG - 2022-05-24 03:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:48:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:48:13 --> Total execution time: 0.0031
DEBUG - 2022-05-24 03:48:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:48:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:48:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:48:21 --> Total execution time: 0.0029
DEBUG - 2022-05-24 03:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:49:11 --> No URI present. Default controller set.
DEBUG - 2022-05-24 03:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:49:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:49:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:49:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:49:11 --> Total execution time: 0.0044
DEBUG - 2022-05-24 03:49:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:49:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:49:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:49:29 --> Total execution time: 0.0088
DEBUG - 2022-05-24 03:49:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:49:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:49:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:49:31 --> Total execution time: 0.0067
DEBUG - 2022-05-24 03:49:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:49:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:49:37 --> Total execution time: 0.0049
DEBUG - 2022-05-24 03:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:50:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:50:22 --> Total execution time: 0.0048
DEBUG - 2022-05-24 03:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:50:28 --> No URI present. Default controller set.
DEBUG - 2022-05-24 03:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:50:28 --> Total execution time: 0.0030
DEBUG - 2022-05-24 03:51:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:51:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:51:20 --> Total execution time: 0.0033
DEBUG - 2022-05-24 03:51:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:51:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:51:36 --> Total execution time: 0.0053
DEBUG - 2022-05-24 03:51:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:51:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:51:50 --> Total execution time: 0.0037
DEBUG - 2022-05-24 03:52:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:52:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:52:13 --> Total execution time: 0.0060
DEBUG - 2022-05-24 03:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:52:15 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-05-24 03:52:15 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-05-24 03:52:15 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-05-24 03:52:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:52:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:52:21 --> Total execution time: 0.0171
DEBUG - 2022-05-24 03:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:52:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:52:58 --> Total execution time: 0.0032
DEBUG - 2022-05-24 03:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:53:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:53:15 --> Total execution time: 0.0055
DEBUG - 2022-05-24 03:53:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:53:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:53:18 --> Total execution time: 0.0164
DEBUG - 2022-05-24 03:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:55:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:55:01 --> Total execution time: 0.0043
DEBUG - 2022-05-24 03:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:56:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:56:21 --> Total execution time: 0.0470
DEBUG - 2022-05-24 03:59:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:59:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:59:27 --> Total execution time: 0.0630
DEBUG - 2022-05-24 03:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 03:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 03:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 03:59:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 03:59:54 --> Total execution time: 0.0058
DEBUG - 2022-05-24 04:00:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:00:03 --> Total execution time: 0.0054
DEBUG - 2022-05-24 04:00:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:08 --> Total execution time: 0.0077
DEBUG - 2022-05-24 04:00:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:10 --> Total execution time: 0.0073
DEBUG - 2022-05-24 04:00:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:12 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:00:16 --> Total execution time: 0.0049
DEBUG - 2022-05-24 04:00:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:00:23 --> Total execution time: 0.0074
DEBUG - 2022-05-24 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:00:30 --> Total execution time: 0.0073
DEBUG - 2022-05-24 04:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:00:33 --> Total execution time: 0.0062
DEBUG - 2022-05-24 04:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:00:37 --> Total execution time: 0.0061
DEBUG - 2022-05-24 04:00:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:40 --> Total execution time: 0.0055
DEBUG - 2022-05-24 04:00:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:00:51 --> Total execution time: 0.0045
DEBUG - 2022-05-24 04:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:01:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:01:36 --> Total execution time: 0.0163
DEBUG - 2022-05-24 04:01:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:01:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:01:41 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:03:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:03:26 --> Total execution time: 0.0092
DEBUG - 2022-05-24 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:03:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:03:28 --> Total execution time: 0.0068
DEBUG - 2022-05-24 04:03:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:03:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:03:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:03:36 --> Total execution time: 0.0049
DEBUG - 2022-05-24 04:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:04:15 --> No URI present. Default controller set.
DEBUG - 2022-05-24 04:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:04:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:04:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:04:15 --> Total execution time: 0.0048
DEBUG - 2022-05-24 04:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:04:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:04:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:04:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:04:55 --> Total execution time: 0.0039
DEBUG - 2022-05-24 04:05:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:05:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:05:01 --> Total execution time: 0.0058
DEBUG - 2022-05-24 04:05:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:05:06 --> Total execution time: 0.0046
DEBUG - 2022-05-24 04:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:05:10 --> Total execution time: 0.0028
DEBUG - 2022-05-24 04:05:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:05:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:05:14 --> Total execution time: 0.0031
DEBUG - 2022-05-24 04:05:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:05:21 --> Total execution time: 0.0060
DEBUG - 2022-05-24 04:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:05:50 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:05:50 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Archita Ayu Febriana & Hafiz Mahesa Anom', '2022-05-21', '2022-05-21', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Wedding Clip     2-3menit')
DEBUG - 2022-05-24 04:05:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:05:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:05:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:05:50 --> Total execution time: 0.0039
DEBUG - 2022-05-24 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:06:33 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:06:33 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Archita Ayu Febriana & Hafiz Mahesa Anom', '2022-05-21', '2022-05-21', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Akad & Resepsi          (10-20menit)')
DEBUG - 2022-05-24 04:06:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:06:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:06:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:06:33 --> Total execution time: 0.0027
DEBUG - 2022-05-24 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:07:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:07:30 --> Total execution time: 0.0035
DEBUG - 2022-05-24 04:07:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:07:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:07:33 --> Total execution time: 0.0029
DEBUG - 2022-05-24 04:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:07:46 --> Total execution time: 0.0045
DEBUG - 2022-05-24 04:07:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:07:53 --> Total execution time: 0.0031
DEBUG - 2022-05-24 04:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:07:56 --> Total execution time: 0.0034
DEBUG - 2022-05-24 04:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:07:59 --> Total execution time: 0.0030
DEBUG - 2022-05-24 04:08:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:08:02 --> Total execution time: 0.0027
DEBUG - 2022-05-24 04:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:08:08 --> Total execution time: 0.0030
DEBUG - 2022-05-24 04:08:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:08:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:08:23 --> Total execution time: 0.0040
DEBUG - 2022-05-24 04:08:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:08:31 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:08:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:08:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:08:53 --> Total execution time: 0.0032
DEBUG - 2022-05-24 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:09:39 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:09:39 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' nurizka & fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Akad & Resepsi     (10-20menit)')
DEBUG - 2022-05-24 04:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:09:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:09:39 --> Total execution time: 0.0046
DEBUG - 2022-05-24 04:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:10:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:10:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:10:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:10:42 --> Total execution time: 0.0033
DEBUG - 2022-05-24 04:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:10:46 --> Total execution time: 0.0033
DEBUG - 2022-05-24 04:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:10:50 --> Total execution time: 0.0043
DEBUG - 2022-05-24 04:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:10:53 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:10:58 --> Total execution time: 0.0033
DEBUG - 2022-05-24 04:11:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:11:08 --> Total execution time: 0.0036
DEBUG - 2022-05-24 04:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:11:16 --> Total execution time: 0.0028
DEBUG - 2022-05-24 04:11:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:11:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:11:26 --> Total execution time: 0.0067
DEBUG - 2022-05-24 04:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:11:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:11:34 --> Total execution time: 0.0029
DEBUG - 2022-05-24 04:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:12:18 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:12:18 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' Nurizka & Fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Akad & Resepsi      (10-20menit)')
DEBUG - 2022-05-24 04:12:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:12:18 --> Total execution time: 0.0036
DEBUG - 2022-05-24 04:12:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:22 --> Total execution time: 0.0026
DEBUG - 2022-05-24 04:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:31 --> Total execution time: 0.0030
DEBUG - 2022-05-24 04:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:36 --> Total execution time: 0.0036
DEBUG - 2022-05-24 04:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:42 --> No URI present. Default controller set.
DEBUG - 2022-05-24 04:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:12:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:12:42 --> Total execution time: 0.0055
DEBUG - 2022-05-24 04:12:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:48 --> Total execution time: 0.0035
DEBUG - 2022-05-24 04:12:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:51 --> Total execution time: 0.0028
DEBUG - 2022-05-24 04:12:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:54 --> Total execution time: 0.0029
DEBUG - 2022-05-24 04:12:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:12:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:12:59 --> Total execution time: 0.0029
DEBUG - 2022-05-24 04:13:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:13:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:13:00 --> Total execution time: 0.0028
DEBUG - 2022-05-24 04:13:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:13:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:13:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:13:03 --> Total execution time: 0.0029
DEBUG - 2022-05-24 04:13:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:13:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:13:16 --> Total execution time: 0.0030
DEBUG - 2022-05-24 04:13:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:13:24 --> Total execution time: 0.0037
DEBUG - 2022-05-24 04:14:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:14:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:14:09 --> Total execution time: 0.0026
DEBUG - 2022-05-24 04:14:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:14:14 --> Total execution time: 0.0029
DEBUG - 2022-05-24 04:14:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:14:21 --> Total execution time: 0.0035
DEBUG - 2022-05-24 04:14:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:14:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:14:25 --> Total execution time: 0.0033
DEBUG - 2022-05-24 04:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:14:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:14:27 --> Total execution time: 0.0052
DEBUG - 2022-05-24 04:14:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:14:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:14:31 --> Total execution time: 0.0166
DEBUG - 2022-05-24 04:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:15:00 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:15:00 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' nurizka & fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Akad & Resepsi (10-20menit)')
DEBUG - 2022-05-24 04:15:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:15:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:15:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:15:00 --> Total execution time: 0.0032
DEBUG - 2022-05-24 04:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:15:03 --> Total execution time: 0.0032
DEBUG - 2022-05-24 04:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:16:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:16:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:16:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:16:38 --> Total execution time: 0.0114
DEBUG - 2022-05-24 04:16:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:16:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:16:42 --> Total execution time: 0.0067
DEBUG - 2022-05-24 04:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:16:48 --> Total execution time: 0.0043
DEBUG - 2022-05-24 04:17:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:17:06 --> Total execution time: 0.0057
DEBUG - 2022-05-24 04:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:17:11 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:17:11 --> Total execution time: 0.0024
DEBUG - 2022-05-24 04:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:17:20 --> Total execution time: 0.0045
DEBUG - 2022-05-24 04:17:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:17:33 --> Total execution time: 0.0055
DEBUG - 2022-05-24 04:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:18:25 --> Total execution time: 0.0057
DEBUG - 2022-05-24 04:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:18:27 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:18:28 --> Total execution time: 0.0029
DEBUG - 2022-05-24 04:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:18:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:18:58 --> Total execution time: 0.0040
DEBUG - 2022-05-24 04:19:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:19:06 --> Total execution time: 0.0051
DEBUG - 2022-05-24 04:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:19:18 --> Total execution time: 0.0048
DEBUG - 2022-05-24 04:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:20 --> Total execution time: 0.0057
DEBUG - 2022-05-24 04:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:32 --> No URI present. Default controller set.
DEBUG - 2022-05-24 04:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:19:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:19:32 --> Total execution time: 0.0065
DEBUG - 2022-05-24 04:19:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:38 --> Total execution time: 0.0048
DEBUG - 2022-05-24 04:19:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:40 --> Total execution time: 0.0033
DEBUG - 2022-05-24 04:19:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:42 --> Total execution time: 0.0031
DEBUG - 2022-05-24 04:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:47 --> Total execution time: 0.0028
DEBUG - 2022-05-24 04:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:19:49 --> Total execution time: 0.0026
DEBUG - 2022-05-24 04:20:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:20:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:20:06 --> Total execution time: 0.0065
DEBUG - 2022-05-24 04:20:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:20:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:20:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:20:12 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:20:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:20:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:20:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:20:59 --> Total execution time: 0.0030
DEBUG - 2022-05-24 04:21:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:21:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:21:03 --> Total execution time: 0.0043
DEBUG - 2022-05-24 04:21:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:21:34 --> Total execution time: 0.0037
DEBUG - 2022-05-24 04:21:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:21:40 --> Total execution time: 0.0031
DEBUG - 2022-05-24 04:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:21:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:21:57 --> Total execution time: 0.0030
DEBUG - 2022-05-24 04:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:25:34 --> Total execution time: 0.0433
DEBUG - 2022-05-24 04:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:25:39 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:27:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:27:20 --> Total execution time: 0.0519
DEBUG - 2022-05-24 04:27:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:27:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:27:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:27:31 --> Total execution time: 0.0075
DEBUG - 2022-05-24 04:27:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:27:53 --> Total execution time: 0.0034
DEBUG - 2022-05-24 04:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:28:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:28:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:28:28 --> Total execution time: 0.0027
DEBUG - 2022-05-24 04:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:28:32 --> Total execution time: 0.0036
DEBUG - 2022-05-24 04:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:28:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:28:44 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:29:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:01 --> Total execution time: 0.0036
DEBUG - 2022-05-24 04:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:29:07 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 84
DEBUG - 2022-05-24 04:29:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:07 --> Total execution time: 0.0032
DEBUG - 2022-05-24 04:29:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:29:09 --> Total execution time: 0.0053
DEBUG - 2022-05-24 04:29:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:10 --> Total execution time: 0.0052
DEBUG - 2022-05-24 04:29:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:13 --> Total execution time: 0.0043
DEBUG - 2022-05-24 04:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:29:29 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 84
DEBUG - 2022-05-24 04:29:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:29 --> Total execution time: 0.0057
DEBUG - 2022-05-24 04:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:36 --> Total execution time: 0.0044
DEBUG - 2022-05-24 04:29:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:38 --> Total execution time: 0.0044
DEBUG - 2022-05-24 04:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:40 --> Total execution time: 0.0040
DEBUG - 2022-05-24 04:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:46 --> Total execution time: 0.0033
DEBUG - 2022-05-24 04:29:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:48 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:29:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:51 --> Total execution time: 0.0034
DEBUG - 2022-05-24 04:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:29:57 --> Total execution time: 0.0039
DEBUG - 2022-05-24 04:30:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:30:00 --> Total execution time: 0.0041
DEBUG - 2022-05-24 04:30:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:30:03 --> Total execution time: 0.0046
DEBUG - 2022-05-24 04:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:30:08 --> Total execution time: 0.0047
DEBUG - 2022-05-24 04:30:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:30:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:30:11 --> Total execution time: 0.0054
DEBUG - 2022-05-24 04:30:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:30:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:30:16 --> Total execution time: 0.0043
DEBUG - 2022-05-24 04:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:31:01 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:31:01 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' Nurizka & Fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Highlight     1 menit')
DEBUG - 2022-05-24 04:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:31:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:31:01 --> Total execution time: 0.0041
DEBUG - 2022-05-24 04:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:31:44 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:31:44 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' Nurizka & Fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Akad & Resepsi       (10-20menit)')
DEBUG - 2022-05-24 04:31:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:31:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:31:44 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:32:39 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:32:39 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' Nurizka & Fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'PHOTO', 'Akad       (20X60)\r\nResepsi   (20x60)\r\n\r\nPembesaran uk. 16Rp (1)')
DEBUG - 2022-05-24 04:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:32:39 --> Total execution time: 0.0039
DEBUG - 2022-05-24 04:32:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:32:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:32:43 --> Total execution time: 0.0048
DEBUG - 2022-05-24 04:32:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:32:47 --> Total execution time: 0.0037
DEBUG - 2022-05-24 04:32:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:32:49 --> Total execution time: 0.0035
DEBUG - 2022-05-24 04:32:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:32:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:32:51 --> Total execution time: 0.0040
DEBUG - 2022-05-24 04:32:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:32:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:32:54 --> Total execution time: 0.0032
DEBUG - 2022-05-24 04:32:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:32:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:32:57 --> Total execution time: 0.0033
DEBUG - 2022-05-24 04:33:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:33:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:33:03 --> Total execution time: 0.0057
DEBUG - 2022-05-24 04:33:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:33:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:33:07 --> Total execution time: 0.0039
DEBUG - 2022-05-24 04:34:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:34:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:34:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:34:33 --> Total execution time: 0.0699
DEBUG - 2022-05-24 04:34:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:34:34 --> Total execution time: 0.0030
DEBUG - 2022-05-24 04:34:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:34:36 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:34:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:34:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:34:38 --> Total execution time: 0.0026
DEBUG - 2022-05-24 04:34:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:34:40 --> Total execution time: 0.0028
DEBUG - 2022-05-24 04:34:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:34:42 --> Total execution time: 0.0033
DEBUG - 2022-05-24 04:34:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:34:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:34:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:34:46 --> Total execution time: 0.0111
DEBUG - 2022-05-24 04:34:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:34:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:34:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:34:52 --> Total execution time: 0.0031
DEBUG - 2022-05-24 04:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:35:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:35:27 --> Total execution time: 0.0039
DEBUG - 2022-05-24 04:35:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:35:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:35:30 --> Total execution time: 0.0036
DEBUG - 2022-05-24 04:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:35:35 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:36:33 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:36:33 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES (' nurizka & fachri', '2022-05-16', '2022-05-16', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Akad & Resepsi     (10-20menit)')
DEBUG - 2022-05-24 04:36:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:36:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:36:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:36:33 --> Total execution time: 0.0043
DEBUG - 2022-05-24 04:36:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:36:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:36:38 --> Total execution time: 0.0027
DEBUG - 2022-05-24 04:36:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:36:44 --> Total execution time: 0.0028
DEBUG - 2022-05-24 04:36:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:36:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:36:49 --> Total execution time: 0.0043
DEBUG - 2022-05-24 04:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:37:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:37:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:37:26 --> Total execution time: 0.0035
DEBUG - 2022-05-24 04:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:37:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:37:33 --> Total execution time: 0.0037
DEBUG - 2022-05-24 04:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:37:49 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:38:10 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 84
DEBUG - 2022-05-24 04:38:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:38:10 --> Total execution time: 0.0044
DEBUG - 2022-05-24 04:38:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:38:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:38:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:38:17 --> Total execution time: 0.0041
DEBUG - 2022-05-24 04:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:39:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:39:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:39:14 --> Total execution time: 0.0037
DEBUG - 2022-05-24 04:39:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:39:18 --> Total execution time: 0.0041
DEBUG - 2022-05-24 04:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:39:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:39:27 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:39:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:39:29 --> Total execution time: 0.0178
DEBUG - 2022-05-24 04:39:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:39:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:39:47 --> Total execution time: 0.0158
DEBUG - 2022-05-24 04:39:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:39:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:39:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:39:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:39:54 --> Total execution time: 0.0039
DEBUG - 2022-05-24 04:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:40:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:40:05 --> Total execution time: 0.0072
DEBUG - 2022-05-24 04:40:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:40:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:40:07 --> Total execution time: 0.0048
DEBUG - 2022-05-24 04:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:40:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:40:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:40:53 --> Total execution time: 0.0066
DEBUG - 2022-05-24 04:40:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:40:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:40:59 --> Total execution time: 0.0046
DEBUG - 2022-05-24 04:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:41:43 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Spk.php 269
ERROR - 2022-05-24 04:41:43 --> Query error: Column 'editor' cannot be null - Invalid query: INSERT INTO `editor` (`name`, `date_w`, `date_r`, `date_m`, `date_s`, `editor`, `category`, `note`) VALUES ('Ayu & Agung ', '2022-05-21', '2022-05-21', '2022-05-25', '2022-06-03', NULL, 'VIDEO', 'Intimatte      (10-15menit)')
DEBUG - 2022-05-24 04:41:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:41:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:41:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:41:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:41:43 --> Total execution time: 0.0149
DEBUG - 2022-05-24 04:41:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:41:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:41:47 --> Total execution time: 0.0075
DEBUG - 2022-05-24 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:42:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:42:37 --> Total execution time: 0.0088
DEBUG - 2022-05-24 04:42:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:42:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:42:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:42:41 --> Total execution time: 0.0116
DEBUG - 2022-05-24 04:42:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:42:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:42:48 --> Total execution time: 0.0030
DEBUG - 2022-05-24 04:42:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:42:55 --> Total execution time: 0.0043
DEBUG - 2022-05-24 04:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-05-24 04:43:19 --> Severity: Warning --> implode(): Invalid arguments passed /home/nsnmt.com/integrity/application/controllers/Editor.php 84
DEBUG - 2022-05-24 04:43:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:19 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:31 --> Total execution time: 0.0038
DEBUG - 2022-05-24 04:43:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:34 --> Total execution time: 0.0042
DEBUG - 2022-05-24 04:43:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:37 --> Total execution time: 0.0036
DEBUG - 2022-05-24 04:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:43:42 --> Total execution time: 0.0056
DEBUG - 2022-05-24 04:43:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:43:46 --> Total execution time: 0.0111
DEBUG - 2022-05-24 04:43:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:43:53 --> Total execution time: 0.0055
DEBUG - 2022-05-24 04:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:43:57 --> Total execution time: 0.0053
DEBUG - 2022-05-24 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:44:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:44:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:44:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:44:38 --> Total execution time: 0.0085
DEBUG - 2022-05-24 04:44:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:44:40 --> Total execution time: 0.0047
DEBUG - 2022-05-24 04:44:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:44:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:44:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:44:50 --> Total execution time: 0.0087
DEBUG - 2022-05-24 04:46:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:46:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:46:11 --> Total execution time: 0.0853
DEBUG - 2022-05-24 04:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:47:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:47:06 --> Total execution time: 0.0031
DEBUG - 2022-05-24 04:47:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:47:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:47:24 --> Total execution time: 0.0041
DEBUG - 2022-05-24 04:47:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:47:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:47:30 --> Total execution time: 0.0032
DEBUG - 2022-05-24 04:48:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:48:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:48:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:48:00 --> Total execution time: 0.0076
DEBUG - 2022-05-24 04:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:48:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:48:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:48:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:48:07 --> Total execution time: 0.0203
DEBUG - 2022-05-24 04:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:48:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:48:13 --> Total execution time: 0.0056
DEBUG - 2022-05-24 04:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:48:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:48:29 --> Total execution time: 0.0058
DEBUG - 2022-05-24 04:48:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:48:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:48:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:48:45 --> Total execution time: 0.0216
DEBUG - 2022-05-24 04:48:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 04:48:51 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-05-24 04:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:50:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:50:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:50:12 --> Total execution time: 0.0045
DEBUG - 2022-05-24 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:51:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:51:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:51:40 --> Total execution time: 0.0060
DEBUG - 2022-05-24 04:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:53:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:53:06 --> Total execution time: 0.0148
DEBUG - 2022-05-24 04:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:53:10 --> Total execution time: 0.0053
DEBUG - 2022-05-24 04:53:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:53:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:53:31 --> Total execution time: 0.0040
DEBUG - 2022-05-24 04:53:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:53:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:53:37 --> Total execution time: 0.0228
DEBUG - 2022-05-24 04:53:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 04:53:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 04:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 04:53:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 04:53:40 --> Total execution time: 0.0038
DEBUG - 2022-05-24 05:01:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:01:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:01:07 --> Total execution time: 0.0780
DEBUG - 2022-05-24 05:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:01:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:01:15 --> Total execution time: 0.0035
DEBUG - 2022-05-24 05:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:01:54 --> No URI present. Default controller set.
DEBUG - 2022-05-24 05:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:01:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:01:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:01:54 --> Total execution time: 0.0064
DEBUG - 2022-05-24 05:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:02:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:02:54 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:03:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:03:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:03:58 --> Total execution time: 0.0039
DEBUG - 2022-05-24 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:06:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:06:50 --> Total execution time: 0.0109
DEBUG - 2022-05-24 05:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:06:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:06:59 --> Total execution time: 0.0041
DEBUG - 2022-05-24 05:07:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:07:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:07:08 --> Total execution time: 0.0064
DEBUG - 2022-05-24 05:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:07:12 --> Total execution time: 0.0057
DEBUG - 2022-05-24 05:07:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:07:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:07:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:07:30 --> Total execution time: 0.0180
DEBUG - 2022-05-24 05:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:07:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:07:37 --> Total execution time: 0.0042
DEBUG - 2022-05-24 05:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:08:03 --> Total execution time: 0.0066
DEBUG - 2022-05-24 05:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:08:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:08:37 --> Total execution time: 0.0048
DEBUG - 2022-05-24 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:09:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:09:28 --> Total execution time: 0.0051
DEBUG - 2022-05-24 05:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:10:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:10:30 --> Total execution time: 0.0045
DEBUG - 2022-05-24 05:10:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:10:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:10:33 --> Total execution time: 0.0052
DEBUG - 2022-05-24 05:10:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:10:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:10:39 --> Total execution time: 0.0054
DEBUG - 2022-05-24 05:10:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:10:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:10:45 --> Total execution time: 0.0228
DEBUG - 2022-05-24 05:11:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:11:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:11:01 --> Total execution time: 0.0057
DEBUG - 2022-05-24 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:11:09 --> No URI present. Default controller set.
DEBUG - 2022-05-24 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:11:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:11:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:11:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:11:09 --> Total execution time: 0.0065
DEBUG - 2022-05-24 05:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:11:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:11:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:11:55 --> Total execution time: 0.0055
DEBUG - 2022-05-24 05:14:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:14:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:14:12 --> Total execution time: 0.0135
DEBUG - 2022-05-24 05:14:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:14:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:14:16 --> Total execution time: 0.0146
DEBUG - 2022-05-24 05:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:15:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:15:41 --> Total execution time: 0.0070
DEBUG - 2022-05-24 05:15:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:15:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:15:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:15:47 --> Total execution time: 0.0038
DEBUG - 2022-05-24 05:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:16:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:16:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:16:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:16:29 --> Total execution time: 0.0080
DEBUG - 2022-05-24 05:16:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:16:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:16:34 --> Total execution time: 0.0079
DEBUG - 2022-05-24 05:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:17:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:17:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:17:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:17:42 --> Total execution time: 0.0062
DEBUG - 2022-05-24 05:17:46 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:17:46 --> Total execution time: 0.0036
DEBUG - 2022-05-24 05:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:18:19 --> Total execution time: 0.0033
DEBUG - 2022-05-24 05:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:18:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:18:44 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:19:12 --> Total execution time: 0.0041
DEBUG - 2022-05-24 05:19:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:19:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:19:16 --> Total execution time: 0.0185
DEBUG - 2022-05-24 05:19:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:19:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:19:19 --> Total execution time: 0.0051
DEBUG - 2022-05-24 05:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:19:27 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:19:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:19:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:19:51 --> Total execution time: 0.0048
DEBUG - 2022-05-24 05:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:20:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:20:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:20:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:20:26 --> Total execution time: 0.0064
DEBUG - 2022-05-24 05:20:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:20:30 --> Total execution time: 0.0042
DEBUG - 2022-05-24 05:20:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:20:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:20:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:20:36 --> Total execution time: 0.0048
DEBUG - 2022-05-24 05:20:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:20:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:20:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:20:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:20:53 --> Total execution time: 0.0185
DEBUG - 2022-05-24 05:21:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:21:00 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:21:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:21:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:21:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:21:25 --> Total execution time: 0.0031
DEBUG - 2022-05-24 05:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:22:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:22:23 --> Total execution time: 0.0045
DEBUG - 2022-05-24 05:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:26:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:26:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:26:01 --> Total execution time: 0.0110
DEBUG - 2022-05-24 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:29:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:29:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:29:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:29:50 --> Total execution time: 0.0099
DEBUG - 2022-05-24 05:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:29:58 --> Total execution time: 0.0050
DEBUG - 2022-05-24 05:30:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:30:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:30:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:30:20 --> Total execution time: 0.0038
DEBUG - 2022-05-24 05:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:30:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:30:25 --> Total execution time: 0.0173
DEBUG - 2022-05-24 05:30:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:30:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:30:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:30:33 --> Total execution time: 0.0032
DEBUG - 2022-05-24 05:35:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:35:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:35:02 --> Total execution time: 0.0584
DEBUG - 2022-05-24 05:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:35:35 --> Total execution time: 0.0171
DEBUG - 2022-05-24 05:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:35:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:35:48 --> Total execution time: 0.0043
DEBUG - 2022-05-24 05:35:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:35:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:35:57 --> Total execution time: 0.0067
DEBUG - 2022-05-24 05:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:36:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:36:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:36:39 --> Total execution time: 0.0054
DEBUG - 2022-05-24 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:37:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:37:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:37:37 --> Total execution time: 0.0048
DEBUG - 2022-05-24 05:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:38:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:38:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:38:54 --> Total execution time: 0.0146
DEBUG - 2022-05-24 05:38:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:38:59 --> Total execution time: 0.0040
DEBUG - 2022-05-24 05:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:39:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:39:03 --> Total execution time: 0.0065
DEBUG - 2022-05-24 05:39:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:39:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:39:09 --> Total execution time: 0.0181
DEBUG - 2022-05-24 05:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:39:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:39:24 --> Total execution time: 0.0033
DEBUG - 2022-05-24 05:39:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:39:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:39:42 --> Total execution time: 0.0050
DEBUG - 2022-05-24 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:40:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:40:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:40:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:40:14 --> Total execution time: 0.0045
DEBUG - 2022-05-24 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:40:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:40:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:40:57 --> Total execution time: 0.0037
DEBUG - 2022-05-24 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:41:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:41:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 05:41:53 --> Total execution time: 0.0040
DEBUG - 2022-05-24 05:41:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:41:58 --> Total execution time: 0.0049
DEBUG - 2022-05-24 05:42:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:01 --> Total execution time: 0.0053
DEBUG - 2022-05-24 05:42:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:03 --> Total execution time: 0.0060
DEBUG - 2022-05-24 05:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:14 --> Total execution time: 0.0051
DEBUG - 2022-05-24 05:42:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:20 --> Total execution time: 0.0033
DEBUG - 2022-05-24 05:42:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:30 --> Total execution time: 0.0034
DEBUG - 2022-05-24 05:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:37 --> Total execution time: 0.0037
DEBUG - 2022-05-24 05:42:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:45 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:42:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:49 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:42:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:51 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:42:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:42:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:42:59 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:48:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:48:58 --> Total execution time: 0.0401
DEBUG - 2022-05-24 05:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:49:30 --> Total execution time: 0.0051
DEBUG - 2022-05-24 05:49:35 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:49:35 --> Total execution time: 0.0032
DEBUG - 2022-05-24 05:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:49:47 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:49:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:49:50 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:49:54 --> Total execution time: 0.0025
DEBUG - 2022-05-24 05:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:50:16 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:50:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:50:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:50:19 --> Total execution time: 0.0024
DEBUG - 2022-05-24 05:50:29 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:50:29 --> Total execution time: 0.0035
DEBUG - 2022-05-24 05:50:33 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:50:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:50:33 --> Total execution time: 0.0025
DEBUG - 2022-05-24 05:50:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:50:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:50:39 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:50:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:50:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:50:43 --> Total execution time: 0.0024
DEBUG - 2022-05-24 05:50:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:50:51 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:50:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:50:55 --> Total execution time: 0.0023
DEBUG - 2022-05-24 05:51:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:04 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:51:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:08 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:51:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:15 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:51:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:21 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:31 --> Total execution time: 0.0024
DEBUG - 2022-05-24 05:51:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:37 --> Total execution time: 0.0028
DEBUG - 2022-05-24 05:51:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:45 --> Total execution time: 0.0030
DEBUG - 2022-05-24 05:51:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:51 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:51:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:51:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:51:59 --> Total execution time: 0.0043
DEBUG - 2022-05-24 05:52:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:04 --> Total execution time: 0.0043
DEBUG - 2022-05-24 05:52:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:11 --> Total execution time: 0.0063
DEBUG - 2022-05-24 05:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:17 --> Total execution time: 0.0040
DEBUG - 2022-05-24 05:52:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:24 --> Total execution time: 0.0051
DEBUG - 2022-05-24 05:52:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:28 --> Total execution time: 0.0040
DEBUG - 2022-05-24 05:52:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:36 --> Total execution time: 0.0042
DEBUG - 2022-05-24 05:52:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:39 --> Total execution time: 0.0042
DEBUG - 2022-05-24 05:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:42 --> Total execution time: 0.0042
DEBUG - 2022-05-24 05:52:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:49 --> Total execution time: 0.0057
DEBUG - 2022-05-24 05:52:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:52:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:52:52 --> Total execution time: 0.0036
DEBUG - 2022-05-24 05:53:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:00 --> Total execution time: 0.0051
DEBUG - 2022-05-24 05:53:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:06 --> Total execution time: 0.0028
DEBUG - 2022-05-24 05:53:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:12 --> Total execution time: 0.0025
DEBUG - 2022-05-24 05:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:15 --> Total execution time: 0.0032
DEBUG - 2022-05-24 05:53:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:28 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:53:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:32 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:53:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:38 --> Total execution time: 0.0036
DEBUG - 2022-05-24 05:53:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:43 --> Total execution time: 0.0023
DEBUG - 2022-05-24 05:53:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:49 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:53:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:53:54 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:54:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:01 --> Total execution time: 0.0033
DEBUG - 2022-05-24 05:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:06 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:17 --> Total execution time: 0.0036
DEBUG - 2022-05-24 05:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:22 --> Total execution time: 0.0034
DEBUG - 2022-05-24 05:54:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:31 --> Total execution time: 0.0028
DEBUG - 2022-05-24 05:54:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:36 --> Total execution time: 0.0024
DEBUG - 2022-05-24 05:54:42 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:42 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:54:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:47 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:54:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:53 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:54:57 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:54:57 --> Total execution time: 0.0026
DEBUG - 2022-05-24 05:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:07 --> Total execution time: 0.0049
DEBUG - 2022-05-24 05:55:09 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:09 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:55:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:12 --> Total execution time: 0.0029
DEBUG - 2022-05-24 05:55:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:19 --> Total execution time: 0.0027
DEBUG - 2022-05-24 05:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:22 --> Total execution time: 0.0025
DEBUG - 2022-05-24 05:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:34 --> Total execution time: 0.0044
DEBUG - 2022-05-24 05:55:38 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:38 --> Total execution time: 0.0034
DEBUG - 2022-05-24 05:55:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:45 --> Total execution time: 0.0042
DEBUG - 2022-05-24 05:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:51 --> Total execution time: 0.0038
DEBUG - 2022-05-24 05:55:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:55:56 --> Total execution time: 0.0042
DEBUG - 2022-05-24 05:56:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:56:00 --> Total execution time: 0.0037
DEBUG - 2022-05-24 05:56:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:56:08 --> Total execution time: 0.0047
DEBUG - 2022-05-24 05:56:13 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:56:13 --> Total execution time: 0.0038
DEBUG - 2022-05-24 05:56:19 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:56:19 --> Total execution time: 0.0041
DEBUG - 2022-05-24 05:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:56:23 --> Total execution time: 0.0039
DEBUG - 2022-05-24 05:56:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:56:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:56:27 --> Total execution time: 0.0043
DEBUG - 2022-05-24 05:56:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:56:30 --> Total execution time: 0.0040
DEBUG - 2022-05-24 05:57:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:57:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:57:31 --> Total execution time: 0.0044
DEBUG - 2022-05-24 05:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:57:34 --> Total execution time: 0.0049
DEBUG - 2022-05-24 05:57:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:57:39 --> Total execution time: 0.0048
DEBUG - 2022-05-24 05:57:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 05:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 05:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 05:57:43 --> Total execution time: 0.0073
DEBUG - 2022-05-24 06:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:10:08 --> Total execution time: 0.0520
DEBUG - 2022-05-24 06:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:12:28 --> Total execution time: 0.0445
DEBUG - 2022-05-24 06:12:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:12:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:12:31 --> Total execution time: 0.0236
DEBUG - 2022-05-24 06:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:12:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:12:34 --> Total execution time: 0.0103
DEBUG - 2022-05-24 06:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:13:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:13:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:13:25 --> Total execution time: 0.0063
DEBUG - 2022-05-24 06:13:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:13:28 --> Total execution time: 0.0029
DEBUG - 2022-05-24 06:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:17:32 --> Total execution time: 0.0423
DEBUG - 2022-05-24 06:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:17:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-24 06:17:53 --> 404 Page Not Found: Personal/p_wedding_f
DEBUG - 2022-05-24 06:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:17 --> Total execution time: 0.0399
DEBUG - 2022-05-24 06:22:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:21 --> Total execution time: 0.0054
DEBUG - 2022-05-24 06:22:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:23 --> Total execution time: 0.0040
DEBUG - 2022-05-24 06:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:26 --> Total execution time: 0.0043
DEBUG - 2022-05-24 06:22:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:28 --> Total execution time: 0.0042
DEBUG - 2022-05-24 06:22:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:31 --> Total execution time: 0.0039
DEBUG - 2022-05-24 06:22:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:44 --> Total execution time: 0.0037
DEBUG - 2022-05-24 06:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:47 --> Total execution time: 0.0072
DEBUG - 2022-05-24 06:22:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:47 --> Total execution time: 0.0028
DEBUG - 2022-05-24 06:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:51 --> Total execution time: 0.0035
DEBUG - 2022-05-24 06:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:53 --> Total execution time: 0.0044
DEBUG - 2022-05-24 06:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:22:59 --> Total execution time: 0.0041
DEBUG - 2022-05-24 06:23:21 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:23:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:23:21 --> Total execution time: 0.0072
DEBUG - 2022-05-24 06:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:23:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:23:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:23:25 --> Total execution time: 0.0034
DEBUG - 2022-05-24 06:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:23:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:23:39 --> Total execution time: 0.0039
DEBUG - 2022-05-24 06:23:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:23:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:23:41 --> Total execution time: 0.0057
DEBUG - 2022-05-24 06:23:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:23:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:23:45 --> Total execution time: 0.0042
DEBUG - 2022-05-24 06:28:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:28:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:28:22 --> Total execution time: 0.0437
DEBUG - 2022-05-24 06:28:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:28:24 --> Total execution time: 0.0150
DEBUG - 2022-05-24 06:28:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:28:31 --> Total execution time: 0.0035
DEBUG - 2022-05-24 06:28:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:28:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:28:32 --> Total execution time: 0.0028
DEBUG - 2022-05-24 06:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:28:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:28:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:28:36 --> Total execution time: 0.0038
DEBUG - 2022-05-24 06:28:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:28:51 --> Total execution time: 0.0064
DEBUG - 2022-05-24 06:28:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:28:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:28:53 --> Total execution time: 0.0036
DEBUG - 2022-05-24 06:29:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:02 --> Total execution time: 0.0040
DEBUG - 2022-05-24 06:29:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:28 --> Total execution time: 0.0036
DEBUG - 2022-05-24 06:29:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:30 --> Total execution time: 0.0040
DEBUG - 2022-05-24 06:29:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:37 --> Total execution time: 0.0053
DEBUG - 2022-05-24 06:29:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:39 --> Total execution time: 0.0038
DEBUG - 2022-05-24 06:29:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:41 --> Total execution time: 0.0039
DEBUG - 2022-05-24 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:52 --> Total execution time: 0.0035
DEBUG - 2022-05-24 06:29:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:55 --> Total execution time: 0.0042
DEBUG - 2022-05-24 06:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:58 --> Total execution time: 0.0042
DEBUG - 2022-05-24 06:29:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:29:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:29:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:29:59 --> Total execution time: 0.0032
DEBUG - 2022-05-24 06:30:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:30:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:30:05 --> Total execution time: 0.0039
DEBUG - 2022-05-24 06:30:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:30:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:30:07 --> Total execution time: 0.0050
DEBUG - 2022-05-24 06:30:08 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:30:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:30:08 --> Total execution time: 0.0038
DEBUG - 2022-05-24 06:33:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:33:58 --> Total execution time: 0.0596
DEBUG - 2022-05-24 06:34:05 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:34:05 --> Total execution time: 0.0073
DEBUG - 2022-05-24 06:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:36:04 --> Total execution time: 0.0635
DEBUG - 2022-05-24 06:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:36:28 --> Total execution time: 0.0048
DEBUG - 2022-05-24 06:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:36:31 --> Total execution time: 0.0059
DEBUG - 2022-05-24 06:36:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:36:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:36:43 --> Total execution time: 0.0048
DEBUG - 2022-05-24 06:37:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:37:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:37:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:37:16 --> Total execution time: 0.0042
DEBUG - 2022-05-24 06:37:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:37:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:37:18 --> Total execution time: 0.0041
DEBUG - 2022-05-24 06:38:07 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:38:07 --> Total execution time: 0.0047
DEBUG - 2022-05-24 06:38:40 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:38:40 --> Total execution time: 0.0047
DEBUG - 2022-05-24 06:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:39:24 --> Total execution time: 0.0046
DEBUG - 2022-05-24 06:39:27 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:39:27 --> Total execution time: 0.0040
DEBUG - 2022-05-24 06:41:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:41:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:41:14 --> Total execution time: 0.0499
DEBUG - 2022-05-24 06:41:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:41:18 --> Total execution time: 0.0040
DEBUG - 2022-05-24 06:41:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:41:23 --> Total execution time: 0.0033
DEBUG - 2022-05-24 06:43:20 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:43:20 --> Total execution time: 0.0038
DEBUG - 2022-05-24 06:43:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:43:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:43:22 --> Total execution time: 0.0044
DEBUG - 2022-05-24 06:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:45:52 --> Total execution time: 0.0501
DEBUG - 2022-05-24 06:45:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:45:53 --> Total execution time: 0.0033
DEBUG - 2022-05-24 06:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:45:58 --> Total execution time: 0.0042
DEBUG - 2022-05-24 06:45:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:45:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:45:58 --> Total execution time: 0.0041
DEBUG - 2022-05-24 06:46:16 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:46:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:46:16 --> Total execution time: 0.0280
DEBUG - 2022-05-24 06:46:53 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:46:53 --> Total execution time: 0.0053
DEBUG - 2022-05-24 06:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:46:55 --> Total execution time: 0.0028
DEBUG - 2022-05-24 06:46:55 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:46:55 --> Total execution time: 0.0033
DEBUG - 2022-05-24 06:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:46:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:46:59 --> Total execution time: 0.0093
DEBUG - 2022-05-24 06:47:00 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:47:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:47:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:47:00 --> Total execution time: 0.0045
DEBUG - 2022-05-24 06:47:02 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:47:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:47:02 --> Total execution time: 0.0063
DEBUG - 2022-05-24 06:47:06 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:47:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:47:06 --> Total execution time: 0.0065
DEBUG - 2022-05-24 06:47:11 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:47:11 --> Total execution time: 0.0024
DEBUG - 2022-05-24 06:47:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:47:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:47:12 --> Total execution time: 0.0048
DEBUG - 2022-05-24 06:47:14 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:47:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:47:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:47:14 --> Total execution time: 0.0037
DEBUG - 2022-05-24 06:47:18 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:47:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:47:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:47:18 --> Total execution time: 0.0062
DEBUG - 2022-05-24 06:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:49:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 06:49:51 --> Total execution time: 0.0658
DEBUG - 2022-05-24 06:49:54 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:49:54 --> Total execution time: 0.0042
DEBUG - 2022-05-24 06:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:49:56 --> Total execution time: 0.0032
DEBUG - 2022-05-24 06:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:50:03 --> Total execution time: 0.0033
DEBUG - 2022-05-24 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:50:47 --> Total execution time: 0.0050
DEBUG - 2022-05-24 06:50:52 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:50:52 --> Total execution time: 0.0044
DEBUG - 2022-05-24 06:51:23 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:51:23 --> Total execution time: 0.0047
DEBUG - 2022-05-24 06:51:25 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:51:25 --> Total execution time: 0.0045
DEBUG - 2022-05-24 06:51:32 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:51:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:51:32 --> Total execution time: 0.0045
DEBUG - 2022-05-24 06:55:22 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:55:22 --> Total execution time: 0.0482
DEBUG - 2022-05-24 06:55:24 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:55:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:55:24 --> Total execution time: 0.0034
DEBUG - 2022-05-24 06:55:30 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:55:30 --> Total execution time: 0.0032
DEBUG - 2022-05-24 06:56:41 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:56:41 --> Total execution time: 0.0428
DEBUG - 2022-05-24 06:56:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:56:43 --> Total execution time: 0.0095
DEBUG - 2022-05-24 06:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:56:44 --> Total execution time: 0.0032
DEBUG - 2022-05-24 06:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:56:45 --> Total execution time: 0.0037
DEBUG - 2022-05-24 06:56:47 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:56:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:56:47 --> Total execution time: 0.0034
DEBUG - 2022-05-24 06:56:59 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:56:59 --> Total execution time: 0.0036
DEBUG - 2022-05-24 06:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 06:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 06:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 06:57:01 --> Total execution time: 0.0039
DEBUG - 2022-05-24 07:05:36 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 07:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 07:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 07:05:36 --> Total execution time: 0.0414
DEBUG - 2022-05-24 07:05:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 07:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 07:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 07:05:37 --> Total execution time: 0.0026
DEBUG - 2022-05-24 07:05:39 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 07:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 07:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 07:05:39 --> Total execution time: 0.0051
DEBUG - 2022-05-24 07:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 07:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 07:05:45 --> Total execution time: 0.0059
DEBUG - 2022-05-24 07:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 07:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 07:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 07:05:45 --> Total execution time: 0.0026
DEBUG - 2022-05-24 07:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 07:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 07:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 07:06:37 --> Total execution time: 0.0059
DEBUG - 2022-05-24 08:08:37 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 08:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 08:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 08:08:37 --> Total execution time: 0.0415
DEBUG - 2022-05-24 23:13:12 --> UTF-8 Support Enabled
DEBUG - 2022-05-24 23:13:12 --> No URI present. Default controller set.
DEBUG - 2022-05-24 23:13:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-24 23:13:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-24 23:13:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-24 23:13:12 --> Total execution time: 0.0418
