<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-14 09:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 09:15:31 --> No URI present. Default controller set.
DEBUG - 2022-02-14 09:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 09:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 09:15:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 09:15:31 --> Total execution time: 0.0309
DEBUG - 2022-02-14 09:15:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 09:15:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-14 09:15:31 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-14 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 10:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 10:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 10:21:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 10:21:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 10:21:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 10:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 10:21:57 --> Total execution time: 0.0058
DEBUG - 2022-02-14 10:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 10:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 10:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 10:21:59 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-14 10:21:59 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 188977088 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-14 10:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 10:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 10:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 10:22:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 10:22:04 --> Total execution time: 1.8133
DEBUG - 2022-02-14 11:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 11:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 11:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 11:34:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 11:34:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 11:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 11:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 11:34:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 11:34:06 --> Total execution time: 0.0070
DEBUG - 2022-02-14 11:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 11:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 11:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 11:50:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 11:50:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 11:50:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 11:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 11:50:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 11:50:22 --> Total execution time: 0.0054
DEBUG - 2022-02-14 12:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:03:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:03:43 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:03:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:03:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:03:43 --> Total execution time: 0.0051
DEBUG - 2022-02-14 12:17:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:17:01 --> No URI present. Default controller set.
DEBUG - 2022-02-14 12:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:17:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:17:02 --> Total execution time: 0.0317
DEBUG - 2022-02-14 12:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:17:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-14 12:17:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-14 12:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:17:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:17:22 --> Total execution time: 0.0046
DEBUG - 2022-02-14 12:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:17:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:17:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:17:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:17:25 --> Total execution time: 0.0037
DEBUG - 2022-02-14 12:17:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:17:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:17:28 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-14 12:17:28 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 189463728 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-14 12:22:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:22:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:22:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:22:02 --> Total execution time: 0.0061
DEBUG - 2022-02-14 12:22:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:22:22 --> Total execution time: 0.0055
DEBUG - 2022-02-14 12:22:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:22:25 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-14 12:22:25 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 189584992 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-14 12:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:23:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:23:00 --> Total execution time: 0.0050
DEBUG - 2022-02-14 12:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:23:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:23:03 --> Total execution time: 0.0034
DEBUG - 2022-02-14 12:23:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:23:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:23:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:23:05 --> Total execution time: 0.0032
DEBUG - 2022-02-14 12:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:29:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:29:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:29:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:29:21 --> Total execution time: 0.0057
DEBUG - 2022-02-14 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:30:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:30:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:30:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:30:27 --> Total execution time: 0.0042
DEBUG - 2022-02-14 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:49:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:49:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:49:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:49:26 --> Total execution time: 0.0061
DEBUG - 2022-02-14 12:52:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:52:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:52:58 --> Total execution time: 0.0343
DEBUG - 2022-02-14 12:53:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:53:13 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-14 12:53:13 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 189949408 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-14 12:53:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:53:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:53:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:53:29 --> Total execution time: 0.0059
DEBUG - 2022-02-14 12:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:59:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:59:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 12:59:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 12:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 12:59:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 12:59:41 --> Total execution time: 0.0056
DEBUG - 2022-02-14 13:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:01:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:01:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:01:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:01:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:01:34 --> Total execution time: 0.0053
DEBUG - 2022-02-14 13:02:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:02:47 --> No URI present. Default controller set.
DEBUG - 2022-02-14 13:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:02:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:02:47 --> Total execution time: 0.0314
DEBUG - 2022-02-14 13:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:03:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-14 13:03:26 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-14 13:03:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:03:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:03:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:03:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:03:54 --> Total execution time: 0.0054
DEBUG - 2022-02-14 13:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:04:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:04:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:04:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:04:51 --> Total execution time: 0.0051
DEBUG - 2022-02-14 13:05:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:05:11 --> Total execution time: 0.0048
DEBUG - 2022-02-14 13:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:05:17 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-14 13:05:17 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 190313848 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-14 13:05:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:06:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:06:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:06:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:06:19 --> Total execution time: 0.0055
DEBUG - 2022-02-14 13:07:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:07:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:07:25 --> Total execution time: 0.0051
DEBUG - 2022-02-14 13:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:12:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:12:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:12:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:12:40 --> Total execution time: 0.0062
DEBUG - 2022-02-14 13:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:14:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:14:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:14:58 --> Total execution time: 0.0052
DEBUG - 2022-02-14 13:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:16:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:16:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:16:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:16:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:16:49 --> Total execution time: 0.0055
DEBUG - 2022-02-14 13:22:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:22:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:22:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:22:18 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:22:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:22:18 --> Total execution time: 0.0055
DEBUG - 2022-02-14 13:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:22:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:22:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:22:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:22:27 --> Total execution time: 0.0040
DEBUG - 2022-02-14 13:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:26:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:26:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:26:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:26:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:26:36 --> Total execution time: 0.0061
DEBUG - 2022-02-14 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:30:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:30:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:30:41 --> Total execution time: 0.0062
DEBUG - 2022-02-14 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:34:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:34:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:34:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:34:10 --> Total execution time: 0.0055
DEBUG - 2022-02-14 13:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:37:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:37:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:37:10 --> Total execution time: 0.0057
DEBUG - 2022-02-14 13:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:40:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:40:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:40:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:40:09 --> Total execution time: 0.0053
DEBUG - 2022-02-14 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:42:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:42:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:42:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:42:33 --> Total execution time: 0.0062
DEBUG - 2022-02-14 13:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:43:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:43:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:43:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:43:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:43:23 --> Total execution time: 0.0051
DEBUG - 2022-02-14 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:48:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:48:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:48:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:48:04 --> Total execution time: 0.0055
DEBUG - 2022-02-14 13:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:49:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:49:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:49:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:49:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:49:51 --> Total execution time: 0.0056
DEBUG - 2022-02-14 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:53:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:53:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:53:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:53:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:53:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:53:56 --> Total execution time: 0.0055
DEBUG - 2022-02-14 13:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:55:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:55:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:55:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:55:51 --> Total execution time: 0.0060
DEBUG - 2022-02-14 13:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:58:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:58:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:58:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:58:58 --> Total execution time: 0.0058
DEBUG - 2022-02-14 13:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:59:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 13:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 13:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 13:59:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 13:59:54 --> Total execution time: 0.0046
DEBUG - 2022-02-14 14:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:02:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:02:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:02:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:02:54 --> Total execution time: 0.0055
DEBUG - 2022-02-14 14:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:04:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:04:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:04:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:04:36 --> Total execution time: 0.0062
DEBUG - 2022-02-14 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:07:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:07:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:07:26 --> Total execution time: 0.0048
DEBUG - 2022-02-14 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:12:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:12:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:12:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:12:02 --> Total execution time: 0.0056
DEBUG - 2022-02-14 14:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:15:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:15:21 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:15:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:15:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:15:21 --> Total execution time: 0.0055
DEBUG - 2022-02-14 14:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:17:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:17:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:17:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:17:54 --> Total execution time: 0.0048
DEBUG - 2022-02-14 14:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:19:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:19:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:19:30 --> Total execution time: 0.0053
DEBUG - 2022-02-14 14:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:22:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:22:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:22:03 --> Total execution time: 0.0060
DEBUG - 2022-02-14 14:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:24:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:24:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:24:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:24:16 --> Total execution time: 0.0054
DEBUG - 2022-02-14 14:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:27:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:27:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:27:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:27:13 --> Total execution time: 0.0065
DEBUG - 2022-02-14 14:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:28:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:28:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:28:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:28:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:28:40 --> Total execution time: 0.0058
DEBUG - 2022-02-14 14:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:30:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:30:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:30:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:30:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:30:42 --> Total execution time: 0.0066
DEBUG - 2022-02-14 14:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:33:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:33:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:33:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:33:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:33:14 --> Total execution time: 0.0061
DEBUG - 2022-02-14 14:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:33:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:33:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:33:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:33:41 --> Total execution time: 0.0036
DEBUG - 2022-02-14 14:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:36:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:36:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:36:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:36:58 --> Total execution time: 0.0055
DEBUG - 2022-02-14 14:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:38:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:38:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:38:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:38:29 --> Total execution time: 0.0057
DEBUG - 2022-02-14 14:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:39:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:39:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:39:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:39:57 --> Total execution time: 0.0056
DEBUG - 2022-02-14 14:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:44:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:44:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:44:56 --> Total execution time: 0.0059
DEBUG - 2022-02-14 14:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:45:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:45:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:45:55 --> Total execution time: 0.0055
DEBUG - 2022-02-14 14:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:49:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:49:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 14:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 14:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 14:49:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 14:49:57 --> Total execution time: 0.0051
DEBUG - 2022-02-14 15:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:14:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:14:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:14:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:14:48 --> Total execution time: 0.0064
DEBUG - 2022-02-14 15:18:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:18:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:18:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:18:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:18:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:18:27 --> Total execution time: 0.0044
DEBUG - 2022-02-14 15:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:20:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:20:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:20:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:20:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:20:02 --> Total execution time: 0.0060
DEBUG - 2022-02-14 15:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:20:28 --> Total execution time: 0.0034
DEBUG - 2022-02-14 15:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:24:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:24:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:24:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:24:41 --> Total execution time: 0.0056
DEBUG - 2022-02-14 15:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:28:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:28:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:28:54 --> Total execution time: 0.0057
DEBUG - 2022-02-14 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:33:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:33:11 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:33:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:33:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:33:11 --> Total execution time: 0.0067
DEBUG - 2022-02-14 15:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:33:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:33:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:33:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:33:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:33:25 --> Total execution time: 0.0041
DEBUG - 2022-02-14 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:35:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:35:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:35:41 --> Total execution time: 0.0053
DEBUG - 2022-02-14 15:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:35:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:35:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:35:52 --> Total execution time: 0.0031
DEBUG - 2022-02-14 15:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:38:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:38:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:38:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:38:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:38:01 --> Total execution time: 0.0050
DEBUG - 2022-02-14 15:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:39:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:39:08 --> Total execution time: 0.0042
DEBUG - 2022-02-14 15:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:43:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:43:05 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:43:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:43:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:43:05 --> Total execution time: 0.0057
DEBUG - 2022-02-14 15:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:44:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:44:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:44:22 --> Total execution time: 0.0059
DEBUG - 2022-02-14 15:47:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:47:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:47:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:48:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:48:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:48:02 --> Total execution time: 0.0070
DEBUG - 2022-02-14 15:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:49:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:49:10 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:49:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:49:10 --> Total execution time: 0.0042
DEBUG - 2022-02-14 15:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:54:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:54:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 15:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 15:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 15:54:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 15:54:07 --> Total execution time: 0.0066
DEBUG - 2022-02-14 16:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:02:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:02:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:02:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:02:26 --> Total execution time: 0.0059
DEBUG - 2022-02-14 16:03:27 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:03:27 --> No URI present. Default controller set.
DEBUG - 2022-02-14 16:03:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:03:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:03:27 --> Total execution time: 0.0045
DEBUG - 2022-02-14 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:04:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:04:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:04:32 --> Total execution time: 0.0039
DEBUG - 2022-02-14 16:10:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:10:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:10:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:10:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:10:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:10:30 --> Total execution time: 0.0059
DEBUG - 2022-02-14 16:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:20:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:20:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:20:16 --> Total execution time: 0.0057
DEBUG - 2022-02-14 16:24:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:24:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:24:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:24:38 --> Total execution time: 0.0055
DEBUG - 2022-02-14 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:29:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:29:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:29:15 --> Total execution time: 0.0055
DEBUG - 2022-02-14 16:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:29:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:29:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:29:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:29:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:29:46 --> Total execution time: 0.0046
DEBUG - 2022-02-14 16:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:33:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:33:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:33:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:33:55 --> Total execution time: 0.0061
DEBUG - 2022-02-14 16:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:34:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:34:24 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:34:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:34:24 --> Total execution time: 0.0044
DEBUG - 2022-02-14 16:38:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:38:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:38:36 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:38:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:38:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:38:36 --> Total execution time: 0.0057
DEBUG - 2022-02-14 16:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:41:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:41:44 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:41:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:41:44 --> Total execution time: 0.0053
DEBUG - 2022-02-14 16:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:43:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:43:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:43:25 --> Total execution time: 0.0055
DEBUG - 2022-02-14 16:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:46:37 --> Total execution time: 0.0056
DEBUG - 2022-02-14 16:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:46:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:46:38 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:46:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:46:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:46:38 --> Total execution time: 0.0037
DEBUG - 2022-02-14 16:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:49:23 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:49:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:49:23 --> Total execution time: 0.0051
DEBUG - 2022-02-14 16:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:52:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:52:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:52:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:52:26 --> Total execution time: 0.0056
DEBUG - 2022-02-14 16:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:53:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:53:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:53:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:53:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:53:08 --> Total execution time: 0.0037
DEBUG - 2022-02-14 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:58:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 16:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 16:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 16:58:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 16:58:54 --> Total execution time: 0.0051
DEBUG - 2022-02-14 17:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:00:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:00:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:00:49 --> Total execution time: 0.0060
DEBUG - 2022-02-14 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:02:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:02:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:02:33 --> Total execution time: 0.0054
DEBUG - 2022-02-14 17:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:03:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:03:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:03:08 --> Total execution time: 0.0045
DEBUG - 2022-02-14 17:05:15 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:05:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:05:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:05:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:05:16 --> Total execution time: 0.0054
DEBUG - 2022-02-14 17:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:05:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:05:28 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:05:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:05:28 --> Total execution time: 0.0043
DEBUG - 2022-02-14 17:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:09:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:09:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:09:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:09:39 --> Total execution time: 0.0058
DEBUG - 2022-02-14 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:09:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:09:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:09:47 --> Total execution time: 0.0035
DEBUG - 2022-02-14 17:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:09:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-14 17:09:47 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-14 17:10:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:10:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:10:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:10:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:10:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:10:50 --> Total execution time: 0.0042
DEBUG - 2022-02-14 17:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:15:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:15:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:15:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:15:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:15:48 --> Total execution time: 0.0059
DEBUG - 2022-02-14 17:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:17:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:17:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:17:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:17:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:17:02 --> Total execution time: 0.0045
DEBUG - 2022-02-14 17:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:23:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:23:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:23:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:23:31 --> Total execution time: 0.0063
DEBUG - 2022-02-14 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:28:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:28:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:28:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:28:47 --> Total execution time: 0.0066
DEBUG - 2022-02-14 17:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:32:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:32:06 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:32:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:32:06 --> Total execution time: 0.0050
DEBUG - 2022-02-14 17:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:34:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:34:12 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:34:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:34:12 --> Total execution time: 0.0047
DEBUG - 2022-02-14 17:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:35:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:35:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-14 17:35:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-14 17:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-14 17:35:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-14 17:35:50 --> Total execution time: 0.0048
