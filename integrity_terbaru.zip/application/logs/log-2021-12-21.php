<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-21 01:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:55:56 --> No URI present. Default controller set.
DEBUG - 2021-12-21 01:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:55:56 --> Total execution time: 0.0868
DEBUG - 2021-12-21 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:55:57 --> Total execution time: 0.0601
DEBUG - 2021-12-21 01:56:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:56:02 --> Total execution time: 0.0441
DEBUG - 2021-12-21 01:56:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "album" C:\xampp\htdocs\nesnu\application\views\data\index.php 85
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "pembesaran" C:\xampp\htdocs\nesnu\application\views\data\index.php 86
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "ukuran_f" C:\xampp\htdocs\nesnu\application\views\data\index.php 89
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "same_d" C:\xampp\htdocs\nesnu\application\views\data\index.php 92
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 94
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "more" C:\xampp\htdocs\nesnu\application\views\data\index.php 95
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 101
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "album" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "pembesaran" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "ukuran_f" C:\xampp\htdocs\nesnu\application\views\data\index.php 365
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "same_d" C:\xampp\htdocs\nesnu\application\views\data\index.php 368
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 370
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "more" C:\xampp\htdocs\nesnu\application\views\data\index.php 371
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 377
ERROR - 2021-12-21 01:56:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 581
DEBUG - 2021-12-21 01:56:09 --> Total execution time: 0.0657
DEBUG - 2021-12-21 01:56:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:56:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:56:11 --> Total execution time: 0.0330
DEBUG - 2021-12-21 01:56:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:56:12 --> Total execution time: 0.0247
DEBUG - 2021-12-21 01:56:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:56:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:56:12 --> Total execution time: 0.0384
DEBUG - 2021-12-21 01:56:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:56:21 --> No URI present. Default controller set.
DEBUG - 2021-12-21 01:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:56:21 --> Total execution time: 0.0444
DEBUG - 2021-12-21 01:58:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:58:56 --> Total execution time: 0.0412
DEBUG - 2021-12-21 01:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 01:59:07 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-21 01:59:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:59:09 --> Total execution time: 0.0306
DEBUG - 2021-12-21 01:59:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:59:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:59:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 01:59:16 --> Total execution time: 0.0409
DEBUG - 2021-12-21 01:59:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 01:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 01:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "album" C:\xampp\htdocs\nesnu\application\views\data\index.php 85
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "pembesaran" C:\xampp\htdocs\nesnu\application\views\data\index.php 86
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "ukuran_f" C:\xampp\htdocs\nesnu\application\views\data\index.php 89
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "same_d" C:\xampp\htdocs\nesnu\application\views\data\index.php 92
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 94
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "more" C:\xampp\htdocs\nesnu\application\views\data\index.php 95
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 101
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "album" C:\xampp\htdocs\nesnu\application\views\data\index.php 361
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "pembesaran" C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "ukuran_f" C:\xampp\htdocs\nesnu\application\views\data\index.php 365
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "same_d" C:\xampp\htdocs\nesnu\application\views\data\index.php 368
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 370
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "more" C:\xampp\htdocs\nesnu\application\views\data\index.php 371
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 377
ERROR - 2021-12-21 01:59:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 581
DEBUG - 2021-12-21 01:59:44 --> Total execution time: 0.0477
DEBUG - 2021-12-21 02:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 97
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 181
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 239
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "album" C:\xampp\htdocs\nesnu\application\views\data\index.php 268
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "pembesaran" C:\xampp\htdocs\nesnu\application\views\data\index.php 269
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "ukuran_f" C:\xampp\htdocs\nesnu\application\views\data\index.php 272
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "same_d" C:\xampp\htdocs\nesnu\application\views\data\index.php 275
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 277
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "more" C:\xampp\htdocs\nesnu\application\views\data\index.php 278
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 284
ERROR - 2021-12-21 02:30:52 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 488
DEBUG - 2021-12-21 02:30:52 --> Total execution time: 0.0545
DEBUG - 2021-12-21 02:31:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 97
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 181
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 239
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 280
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 374
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 424
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 429
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 444
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 466
ERROR - 2021-12-21 02:31:20 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 502
DEBUG - 2021-12-21 02:31:20 --> Total execution time: 0.0605
DEBUG - 2021-12-21 02:31:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:31:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 180
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 238
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 422
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 427
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 442
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 457
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 464
ERROR - 2021-12-21 02:31:55 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 500
DEBUG - 2021-12-21 02:31:55 --> Total execution time: 0.0559
DEBUG - 2021-12-21 02:33:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 02:33:39 --> Total execution time: 0.0415
DEBUG - 2021-12-21 02:34:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:34:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 02:34:06 --> Total execution time: 0.0508
DEBUG - 2021-12-21 02:34:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:34:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 189
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 247
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 381
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 431
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 436
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 451
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 466
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 02:34:08 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 509
DEBUG - 2021-12-21 02:34:08 --> Total execution time: 0.0437
DEBUG - 2021-12-21 02:35:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 189
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 249
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 384
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 434
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 439
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 454
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 469
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 476
ERROR - 2021-12-21 02:35:02 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 512
DEBUG - 2021-12-21 02:35:02 --> Total execution time: 0.0583
DEBUG - 2021-12-21 02:36:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 189
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 249
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 403
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 453
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 495
ERROR - 2021-12-21 02:36:25 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 531
DEBUG - 2021-12-21 02:36:25 --> Total execution time: 0.0484
DEBUG - 2021-12-21 02:36:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 189
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 249
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 403
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 453
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 495
ERROR - 2021-12-21 02:36:49 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 531
DEBUG - 2021-12-21 02:36:49 --> Total execution time: 0.0525
DEBUG - 2021-12-21 02:36:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 02:36:50 --> Total execution time: 0.0385
DEBUG - 2021-12-21 02:37:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 02:37:24 --> Total execution time: 0.0505
DEBUG - 2021-12-21 02:37:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 02:37:27 --> Total execution time: 0.0411
DEBUG - 2021-12-21 02:37:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 189
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 249
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 403
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 453
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 495
ERROR - 2021-12-21 02:37:28 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 531
DEBUG - 2021-12-21 02:37:28 --> Total execution time: 0.0468
DEBUG - 2021-12-21 02:37:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 189
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 249
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 403
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 453
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 495
ERROR - 2021-12-21 02:37:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 531
DEBUG - 2021-12-21 02:37:44 --> Total execution time: 0.0504
DEBUG - 2021-12-21 02:47:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:47:38 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 405
ERROR - 2021-12-21 02:47:38 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 455
ERROR - 2021-12-21 02:47:38 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 460
ERROR - 2021-12-21 02:47:38 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 475
ERROR - 2021-12-21 02:47:38 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 490
ERROR - 2021-12-21 02:47:38 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 02:47:38 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 533
DEBUG - 2021-12-21 02:47:38 --> Total execution time: 0.0530
DEBUG - 2021-12-21 02:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:49:11 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 404
ERROR - 2021-12-21 02:49:11 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 454
ERROR - 2021-12-21 02:49:11 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 459
ERROR - 2021-12-21 02:49:11 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 474
ERROR - 2021-12-21 02:49:11 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 489
ERROR - 2021-12-21 02:49:11 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 496
ERROR - 2021-12-21 02:49:11 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 532
DEBUG - 2021-12-21 02:49:11 --> Total execution time: 0.0550
DEBUG - 2021-12-21 02:49:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:49:44 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 403
ERROR - 2021-12-21 02:49:44 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 453
ERROR - 2021-12-21 02:49:44 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 02:49:44 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 02:49:44 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 02:49:44 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 495
ERROR - 2021-12-21 02:49:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 531
DEBUG - 2021-12-21 02:49:44 --> Total execution time: 0.0363
DEBUG - 2021-12-21 02:50:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 02:50:24 --> Total execution time: 0.0537
DEBUG - 2021-12-21 02:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 02:51:44 --> Total execution time: 0.0389
DEBUG - 2021-12-21 02:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:51:45 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 403
ERROR - 2021-12-21 02:51:45 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 453
ERROR - 2021-12-21 02:51:45 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 02:51:45 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 02:51:45 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 02:51:45 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 495
ERROR - 2021-12-21 02:51:45 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 531
DEBUG - 2021-12-21 02:51:45 --> Total execution time: 0.0464
DEBUG - 2021-12-21 02:52:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:52:18 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 257
ERROR - 2021-12-21 02:52:18 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 411
ERROR - 2021-12-21 02:52:18 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 461
ERROR - 2021-12-21 02:52:18 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 466
ERROR - 2021-12-21 02:52:18 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 481
ERROR - 2021-12-21 02:52:18 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 496
ERROR - 2021-12-21 02:52:18 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 503
ERROR - 2021-12-21 02:52:18 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 539
DEBUG - 2021-12-21 02:52:18 --> Total execution time: 0.0518
DEBUG - 2021-12-21 02:52:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 180
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 238
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 372
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 422
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 427
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 442
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 457
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 464
ERROR - 2021-12-21 02:52:29 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 500
DEBUG - 2021-12-21 02:52:29 --> Total execution time: 0.0553
DEBUG - 2021-12-21 02:53:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:53:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 97
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 181
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 283
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 346
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "album" C:\xampp\htdocs\nesnu\application\views\data\index.php 375
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "pembesaran" C:\xampp\htdocs\nesnu\application\views\data\index.php 376
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "ukuran_f" C:\xampp\htdocs\nesnu\application\views\data\index.php 379
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "same_d" C:\xampp\htdocs\nesnu\application\views\data\index.php 382
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 384
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "more" C:\xampp\htdocs\nesnu\application\views\data\index.php 385
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 391
ERROR - 2021-12-21 02:53:01 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 595
DEBUG - 2021-12-21 02:53:01 --> Total execution time: 0.0382
DEBUG - 2021-12-21 02:53:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 97
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 181
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 283
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 346
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined array key "charge" C:\xampp\htdocs\nesnu\application\views\data\index.php 387
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 481
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 531
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 536
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 551
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 573
ERROR - 2021-12-21 02:53:41 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 609
DEBUG - 2021-12-21 02:53:41 --> Total execution time: 0.0528
DEBUG - 2021-12-21 02:53:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 180
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 282
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 345
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 479
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 529
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 534
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 549
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 564
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 571
ERROR - 2021-12-21 02:53:55 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 607
DEBUG - 2021-12-21 02:53:55 --> Total execution time: 0.0541
DEBUG - 2021-12-21 02:54:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:54:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 282
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 345
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 479
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 529
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 534
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 549
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 564
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 571
ERROR - 2021-12-21 02:54:51 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 607
DEBUG - 2021-12-21 02:54:51 --> Total execution time: 0.0561
DEBUG - 2021-12-21 02:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 282
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 345
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 479
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 529
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 534
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 549
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 564
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 571
ERROR - 2021-12-21 02:55:18 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 607
DEBUG - 2021-12-21 02:55:18 --> Total execution time: 0.0453
DEBUG - 2021-12-21 02:55:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:55:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 297
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 360
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 494
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 544
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 549
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 564
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 579
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 586
ERROR - 2021-12-21 02:55:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 622
DEBUG - 2021-12-21 02:55:57 --> Total execution time: 0.0593
DEBUG - 2021-12-21 02:56:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 282
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 345
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 479
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 529
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 534
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 549
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 564
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 571
ERROR - 2021-12-21 02:56:19 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 607
DEBUG - 2021-12-21 02:56:19 --> Total execution time: 0.0478
DEBUG - 2021-12-21 02:57:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:57:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 296
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 359
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 493
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 543
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 548
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 563
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 578
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 585
ERROR - 2021-12-21 02:57:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 621
DEBUG - 2021-12-21 02:57:15 --> Total execution time: 0.0356
DEBUG - 2021-12-21 02:57:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:57:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 301
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 364
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 498
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 548
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 553
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 568
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 583
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 590
ERROR - 2021-12-21 02:57:59 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 626
DEBUG - 2021-12-21 02:57:59 --> Total execution time: 0.0552
DEBUG - 2021-12-21 02:58:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 299
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 362
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 496
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 546
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 551
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 566
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 581
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 588
ERROR - 2021-12-21 02:58:11 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 624
DEBUG - 2021-12-21 02:58:11 --> Total execution time: 0.0450
DEBUG - 2021-12-21 02:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 300
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 363
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 547
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 552
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 567
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 582
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 589
ERROR - 2021-12-21 02:58:25 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 625
DEBUG - 2021-12-21 02:58:25 --> Total execution time: 0.0346
DEBUG - 2021-12-21 02:58:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:58:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:58:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 300
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 363
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 547
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 552
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 567
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 582
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 589
ERROR - 2021-12-21 02:58:38 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 625
DEBUG - 2021-12-21 02:58:38 --> Total execution time: 0.0505
DEBUG - 2021-12-21 02:58:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:58:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 300
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 363
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 547
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 552
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 567
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 582
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 589
ERROR - 2021-12-21 02:58:51 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 625
DEBUG - 2021-12-21 02:58:51 --> Total execution time: 0.0487
DEBUG - 2021-12-21 02:59:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:59:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 300
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 363
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 547
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 552
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 567
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 582
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 589
ERROR - 2021-12-21 02:59:03 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 625
DEBUG - 2021-12-21 02:59:03 --> Total execution time: 0.0469
DEBUG - 2021-12-21 02:59:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 02:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 02:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 305
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 368
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 502
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 552
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 557
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 572
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 587
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 594
ERROR - 2021-12-21 02:59:52 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 630
DEBUG - 2021-12-21 02:59:52 --> Total execution time: 0.0504
DEBUG - 2021-12-21 03:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 341
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 404
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 538
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 588
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 593
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 608
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 623
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 630
ERROR - 2021-12-21 03:00:13 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 666
DEBUG - 2021-12-21 03:00:14 --> Total execution time: 0.0702
DEBUG - 2021-12-21 03:01:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:01:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 311
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 374
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 508
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 558
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 563
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 578
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 593
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 600
ERROR - 2021-12-21 03:01:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 636
DEBUG - 2021-12-21 03:01:09 --> Total execution time: 0.0438
DEBUG - 2021-12-21 03:03:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 330
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 393
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 527
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 577
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 582
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 597
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 612
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 619
ERROR - 2021-12-21 03:03:02 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 655
DEBUG - 2021-12-21 03:03:02 --> Total execution time: 0.0338
DEBUG - 2021-12-21 03:06:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 338
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 401
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 535
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 585
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 590
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 605
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 620
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 627
ERROR - 2021-12-21 03:06:10 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 663
DEBUG - 2021-12-21 03:06:10 --> Total execution time: 0.0515
DEBUG - 2021-12-21 03:06:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:06:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:06:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 338
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 401
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 535
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 585
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 590
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 605
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 620
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 627
ERROR - 2021-12-21 03:06:47 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 663
DEBUG - 2021-12-21 03:06:47 --> Total execution time: 0.0558
DEBUG - 2021-12-21 03:07:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 326
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 389
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 523
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 573
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 578
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 593
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 608
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 615
ERROR - 2021-12-21 03:07:38 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 651
DEBUG - 2021-12-21 03:07:38 --> Total execution time: 0.0554
DEBUG - 2021-12-21 03:08:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 326
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 389
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 523
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 573
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 578
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 593
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 608
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 615
ERROR - 2021-12-21 03:08:36 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 651
DEBUG - 2021-12-21 03:08:36 --> Total execution time: 0.0430
DEBUG - 2021-12-21 03:10:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 326
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 389
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 523
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 573
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 578
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 593
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 608
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 615
ERROR - 2021-12-21 03:10:30 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 651
DEBUG - 2021-12-21 03:10:30 --> Total execution time: 0.0480
DEBUG - 2021-12-21 03:11:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:11:18 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 265
ERROR - 2021-12-21 03:11:18 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 399
ERROR - 2021-12-21 03:11:18 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 449
ERROR - 2021-12-21 03:11:18 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 454
ERROR - 2021-12-21 03:11:18 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 469
ERROR - 2021-12-21 03:11:18 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 484
ERROR - 2021-12-21 03:11:18 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 491
ERROR - 2021-12-21 03:11:18 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 527
DEBUG - 2021-12-21 03:11:18 --> Total execution time: 0.0512
DEBUG - 2021-12-21 03:11:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:11:53 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 412
ERROR - 2021-12-21 03:11:53 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 462
ERROR - 2021-12-21 03:11:53 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 467
ERROR - 2021-12-21 03:11:53 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 482
ERROR - 2021-12-21 03:11:53 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 03:11:53 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 504
ERROR - 2021-12-21 03:11:53 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 540
DEBUG - 2021-12-21 03:11:53 --> Total execution time: 0.0579
DEBUG - 2021-12-21 03:12:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:12:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:12:22 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 407
ERROR - 2021-12-21 03:12:22 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 457
ERROR - 2021-12-21 03:12:22 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 462
ERROR - 2021-12-21 03:12:22 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 477
ERROR - 2021-12-21 03:12:22 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 492
ERROR - 2021-12-21 03:12:22 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 499
ERROR - 2021-12-21 03:12:22 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 535
DEBUG - 2021-12-21 03:12:22 --> Total execution time: 0.0769
DEBUG - 2021-12-21 03:12:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:12:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:12:43 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 408
ERROR - 2021-12-21 03:12:43 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 03:12:43 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 463
ERROR - 2021-12-21 03:12:43 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 478
ERROR - 2021-12-21 03:12:43 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 493
ERROR - 2021-12-21 03:12:43 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 500
ERROR - 2021-12-21 03:12:43 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 536
DEBUG - 2021-12-21 03:12:43 --> Total execution time: 0.0531
DEBUG - 2021-12-21 03:19:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:19:24 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 408
ERROR - 2021-12-21 03:19:24 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 03:19:24 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 463
ERROR - 2021-12-21 03:19:24 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 478
ERROR - 2021-12-21 03:19:24 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 493
ERROR - 2021-12-21 03:19:24 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 500
ERROR - 2021-12-21 03:19:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 536
DEBUG - 2021-12-21 03:19:24 --> Total execution time: 0.0566
DEBUG - 2021-12-21 03:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:19:42 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 408
ERROR - 2021-12-21 03:19:42 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 458
ERROR - 2021-12-21 03:19:42 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 463
ERROR - 2021-12-21 03:19:42 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 478
ERROR - 2021-12-21 03:19:42 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 493
ERROR - 2021-12-21 03:19:42 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 500
ERROR - 2021-12-21 03:19:42 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 536
DEBUG - 2021-12-21 03:19:42 --> Total execution time: 0.0476
DEBUG - 2021-12-21 03:22:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:22:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:22:32 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 395
ERROR - 2021-12-21 03:22:32 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 445
ERROR - 2021-12-21 03:22:32 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 450
ERROR - 2021-12-21 03:22:32 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 465
ERROR - 2021-12-21 03:22:32 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 480
ERROR - 2021-12-21 03:22:32 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 487
ERROR - 2021-12-21 03:22:32 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 523
DEBUG - 2021-12-21 03:22:32 --> Total execution time: 0.0579
DEBUG - 2021-12-21 03:28:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:28:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:28:28 --> Severity: Warning --> Undefined variable $place_s C:\xampp\htdocs\nesnu\application\views\data\index.php 250
ERROR - 2021-12-21 03:28:28 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 404
ERROR - 2021-12-21 03:28:28 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 454
ERROR - 2021-12-21 03:28:28 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 459
ERROR - 2021-12-21 03:28:28 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 474
ERROR - 2021-12-21 03:28:28 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 489
ERROR - 2021-12-21 03:28:28 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 496
ERROR - 2021-12-21 03:28:28 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 532
DEBUG - 2021-12-21 03:28:28 --> Total execution time: 0.0522
DEBUG - 2021-12-21 03:28:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:28:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:28:42 --> Severity: Warning --> Undefined variable $place_s C:\xampp\htdocs\nesnu\application\views\data\index.php 250
ERROR - 2021-12-21 03:28:42 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 404
ERROR - 2021-12-21 03:28:42 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 454
ERROR - 2021-12-21 03:28:42 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 459
ERROR - 2021-12-21 03:28:42 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 474
ERROR - 2021-12-21 03:28:42 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 489
ERROR - 2021-12-21 03:28:42 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 496
ERROR - 2021-12-21 03:28:42 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 532
DEBUG - 2021-12-21 03:28:42 --> Total execution time: 0.0577
DEBUG - 2021-12-21 03:29:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:29:53 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 405
ERROR - 2021-12-21 03:29:53 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 455
ERROR - 2021-12-21 03:29:53 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 460
ERROR - 2021-12-21 03:29:53 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 475
ERROR - 2021-12-21 03:29:53 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 490
ERROR - 2021-12-21 03:29:53 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 03:29:53 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 533
DEBUG - 2021-12-21 03:29:53 --> Total execution time: 0.0341
DEBUG - 2021-12-21 03:30:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:30:25 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 405
ERROR - 2021-12-21 03:30:25 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 455
ERROR - 2021-12-21 03:30:25 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 460
ERROR - 2021-12-21 03:30:25 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 475
ERROR - 2021-12-21 03:30:25 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 490
ERROR - 2021-12-21 03:30:25 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 03:30:25 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 533
DEBUG - 2021-12-21 03:30:25 --> Total execution time: 0.0505
DEBUG - 2021-12-21 03:31:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:31:07 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 405
ERROR - 2021-12-21 03:31:07 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 455
ERROR - 2021-12-21 03:31:07 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 460
ERROR - 2021-12-21 03:31:07 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 475
ERROR - 2021-12-21 03:31:07 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 490
ERROR - 2021-12-21 03:31:07 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 03:31:07 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 533
DEBUG - 2021-12-21 03:31:07 --> Total execution time: 0.0422
DEBUG - 2021-12-21 03:32:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:32:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:32:24 --> Total execution time: 0.0523
DEBUG - 2021-12-21 03:35:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:35:57 --> Total execution time: 0.0299
DEBUG - 2021-12-21 03:36:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:36:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:36:19 --> Total execution time: 0.0512
DEBUG - 2021-12-21 03:36:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:36:41 --> Total execution time: 0.0430
DEBUG - 2021-12-21 03:36:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:36:52 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 405
ERROR - 2021-12-21 03:36:52 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 455
ERROR - 2021-12-21 03:36:52 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 460
ERROR - 2021-12-21 03:36:52 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 475
ERROR - 2021-12-21 03:36:52 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 490
ERROR - 2021-12-21 03:36:52 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 03:36:52 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 533
DEBUG - 2021-12-21 03:36:52 --> Total execution time: 0.0441
DEBUG - 2021-12-21 03:37:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:37:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:37:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:37:12 --> Total execution time: 0.0436
DEBUG - 2021-12-21 03:37:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:37:13 --> Total execution time: 0.0391
DEBUG - 2021-12-21 03:37:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:37:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:37:47 --> Total execution time: 0.0628
DEBUG - 2021-12-21 03:38:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:38:39 --> Total execution time: 0.0514
DEBUG - 2021-12-21 03:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:38:40 --> Total execution time: 0.0374
DEBUG - 2021-12-21 03:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:38:40 --> Total execution time: 0.0447
DEBUG - 2021-12-21 03:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:38:41 --> Total execution time: 0.0409
DEBUG - 2021-12-21 03:38:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:38:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:38:42 --> Total execution time: 0.0442
DEBUG - 2021-12-21 03:42:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:42:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:42:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:42:30 --> Total execution time: 0.0277
DEBUG - 2021-12-21 03:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $date_m C:\xampp\htdocs\nesnu\application\views\data\index.php 249
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $w_siraman C:\xampp\htdocs\nesnu\application\views\data\index.php 250
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $place_m C:\xampp\htdocs\nesnu\application\views\data\index.php 251
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 411
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 461
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 466
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 481
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 496
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 503
ERROR - 2021-12-21 03:42:34 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 539
DEBUG - 2021-12-21 03:42:34 --> Total execution time: 0.0560
DEBUG - 2021-12-21 03:43:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:43:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:43:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:43:38 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 414
ERROR - 2021-12-21 03:43:38 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 464
ERROR - 2021-12-21 03:43:38 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 469
ERROR - 2021-12-21 03:43:38 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 484
ERROR - 2021-12-21 03:43:38 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 499
ERROR - 2021-12-21 03:43:38 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 506
ERROR - 2021-12-21 03:43:38 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 542
DEBUG - 2021-12-21 03:43:38 --> Total execution time: 0.0493
DEBUG - 2021-12-21 03:43:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:43:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:43:53 --> Total execution time: 0.0466
DEBUG - 2021-12-21 03:43:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:43:55 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 414
ERROR - 2021-12-21 03:43:55 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 464
ERROR - 2021-12-21 03:43:55 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 469
ERROR - 2021-12-21 03:43:55 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 484
ERROR - 2021-12-21 03:43:55 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 499
ERROR - 2021-12-21 03:43:55 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 506
ERROR - 2021-12-21 03:43:55 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 542
DEBUG - 2021-12-21 03:43:55 --> Total execution time: 0.0323
DEBUG - 2021-12-21 03:43:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 03:43:55 --> Total execution time: 0.0390
DEBUG - 2021-12-21 03:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:43:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:43:56 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 414
ERROR - 2021-12-21 03:43:56 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 464
ERROR - 2021-12-21 03:43:56 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 469
ERROR - 2021-12-21 03:43:56 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 484
ERROR - 2021-12-21 03:43:56 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 499
ERROR - 2021-12-21 03:43:56 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 506
ERROR - 2021-12-21 03:43:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 542
DEBUG - 2021-12-21 03:43:56 --> Total execution time: 0.0536
DEBUG - 2021-12-21 03:46:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:46:03 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 418
ERROR - 2021-12-21 03:46:03 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 468
ERROR - 2021-12-21 03:46:03 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 03:46:03 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 03:46:03 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 502
ERROR - 2021-12-21 03:46:03 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 509
ERROR - 2021-12-21 03:46:03 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 545
DEBUG - 2021-12-21 03:46:03 --> Total execution time: 0.0450
DEBUG - 2021-12-21 03:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:46:34 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 418
ERROR - 2021-12-21 03:46:34 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 468
ERROR - 2021-12-21 03:46:34 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 03:46:34 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 03:46:34 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 503
ERROR - 2021-12-21 03:46:34 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 510
ERROR - 2021-12-21 03:46:34 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 546
DEBUG - 2021-12-21 03:46:34 --> Total execution time: 0.0760
DEBUG - 2021-12-21 03:47:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:47:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:47:11 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 419
ERROR - 2021-12-21 03:47:11 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 468
ERROR - 2021-12-21 03:47:11 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 03:47:11 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 03:47:11 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 503
ERROR - 2021-12-21 03:47:11 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 510
ERROR - 2021-12-21 03:47:11 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 546
DEBUG - 2021-12-21 03:47:11 --> Total execution time: 0.0476
DEBUG - 2021-12-21 03:47:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:47:29 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 468
ERROR - 2021-12-21 03:47:29 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 03:47:29 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 03:47:29 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 503
ERROR - 2021-12-21 03:47:29 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 510
ERROR - 2021-12-21 03:47:29 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 546
DEBUG - 2021-12-21 03:47:29 --> Total execution time: 0.0426
DEBUG - 2021-12-21 03:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:48:40 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 475
ERROR - 2021-12-21 03:48:40 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 490
ERROR - 2021-12-21 03:48:40 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 505
ERROR - 2021-12-21 03:48:40 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 512
ERROR - 2021-12-21 03:48:40 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 548
DEBUG - 2021-12-21 03:48:40 --> Total execution time: 0.0578
DEBUG - 2021-12-21 03:49:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:49:30 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 482
ERROR - 2021-12-21 03:49:30 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 497
ERROR - 2021-12-21 03:49:30 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 512
ERROR - 2021-12-21 03:49:30 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 519
ERROR - 2021-12-21 03:49:30 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 555
DEBUG - 2021-12-21 03:49:30 --> Total execution time: 0.0486
DEBUG - 2021-12-21 03:51:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:51:11 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 499
ERROR - 2021-12-21 03:51:11 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 514
ERROR - 2021-12-21 03:51:11 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 521
ERROR - 2021-12-21 03:51:11 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 557
DEBUG - 2021-12-21 03:51:11 --> Total execution time: 0.0493
DEBUG - 2021-12-21 03:52:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:52:20 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 504
ERROR - 2021-12-21 03:52:20 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 536
DEBUG - 2021-12-21 03:52:20 --> Total execution time: 0.0453
DEBUG - 2021-12-21 03:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:52:34 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 527
DEBUG - 2021-12-21 03:52:34 --> Total execution time: 0.0294
DEBUG - 2021-12-21 03:53:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:53:09 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 504
ERROR - 2021-12-21 03:53:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 540
DEBUG - 2021-12-21 03:53:09 --> Total execution time: 0.0438
DEBUG - 2021-12-21 03:54:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:54:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:54:27 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 418
ERROR - 2021-12-21 03:54:27 --> Severity: Warning --> Undefined variable $album C:\xampp\htdocs\nesnu\application\views\data\index.php 468
ERROR - 2021-12-21 03:54:27 --> Severity: Warning --> Undefined variable $pembesaran C:\xampp\htdocs\nesnu\application\views\data\index.php 473
ERROR - 2021-12-21 03:54:27 --> Severity: Warning --> Undefined variable $ukuran_f C:\xampp\htdocs\nesnu\application\views\data\index.php 488
ERROR - 2021-12-21 03:54:27 --> Severity: Warning --> Undefined variable $charge C:\xampp\htdocs\nesnu\application\views\data\index.php 503
ERROR - 2021-12-21 03:54:27 --> Severity: Warning --> Undefined variable $more C:\xampp\htdocs\nesnu\application\views\data\index.php 510
ERROR - 2021-12-21 03:54:27 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 546
DEBUG - 2021-12-21 03:54:27 --> Total execution time: 0.0594
DEBUG - 2021-12-21 03:54:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:54:56 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 418
ERROR - 2021-12-21 03:54:56 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 522
DEBUG - 2021-12-21 03:54:56 --> Total execution time: 0.0487
DEBUG - 2021-12-21 03:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:55:12 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 522
DEBUG - 2021-12-21 03:55:12 --> Total execution time: 0.0304
DEBUG - 2021-12-21 03:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 03:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 03:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 03:55:58 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 03:55:58 --> Total execution time: 0.0435
DEBUG - 2021-12-21 04:09:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:09:22 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:09:22 --> Total execution time: 0.0499
DEBUG - 2021-12-21 04:10:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:10:05 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:10:05 --> Total execution time: 0.0467
DEBUG - 2021-12-21 04:11:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:11:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:11:00 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:11:00 --> Total execution time: 0.0511
DEBUG - 2021-12-21 04:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:12:03 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:12:03 --> Total execution time: 0.0458
DEBUG - 2021-12-21 04:12:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:12:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:12:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:12:14 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:12:14 --> Total execution time: 0.0305
DEBUG - 2021-12-21 04:12:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:12:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:12:24 --> Total execution time: 0.0418
DEBUG - 2021-12-21 04:12:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:12:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:12:39 --> Total execution time: 0.0338
DEBUG - 2021-12-21 04:13:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:13:01 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:13:01 --> Total execution time: 0.0306
DEBUG - 2021-12-21 04:13:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:13:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:13:17 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:13:17 --> Total execution time: 0.0531
DEBUG - 2021-12-21 04:13:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:13:31 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:13:31 --> Total execution time: 0.0298
DEBUG - 2021-12-21 04:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:13:49 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 520
DEBUG - 2021-12-21 04:13:49 --> Total execution time: 0.0467
DEBUG - 2021-12-21 04:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:14:36 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 528
DEBUG - 2021-12-21 04:14:36 --> Total execution time: 0.0569
DEBUG - 2021-12-21 04:15:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:15:18 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 527
DEBUG - 2021-12-21 04:15:18 --> Total execution time: 0.0411
DEBUG - 2021-12-21 04:17:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:17:20 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 549
DEBUG - 2021-12-21 04:17:20 --> Total execution time: 0.0310
DEBUG - 2021-12-21 04:17:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:17:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:17:55 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 549
DEBUG - 2021-12-21 04:17:55 --> Total execution time: 0.0433
DEBUG - 2021-12-21 04:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:18:06 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 549
DEBUG - 2021-12-21 04:18:06 --> Total execution time: 0.0498
DEBUG - 2021-12-21 04:18:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:18:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:18:45 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 557
DEBUG - 2021-12-21 04:18:45 --> Total execution time: 0.0491
DEBUG - 2021-12-21 04:23:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:23:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 583
DEBUG - 2021-12-21 04:23:39 --> Total execution time: 0.0448
DEBUG - 2021-12-21 04:25:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:25:42 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 585
DEBUG - 2021-12-21 04:25:42 --> Total execution time: 0.0504
DEBUG - 2021-12-21 04:25:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:25:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:25:57 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 585
DEBUG - 2021-12-21 04:25:57 --> Total execution time: 0.0499
DEBUG - 2021-12-21 04:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:34:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 594
DEBUG - 2021-12-21 04:34:24 --> Total execution time: 0.0326
DEBUG - 2021-12-21 04:37:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:37:01 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 593
DEBUG - 2021-12-21 04:37:01 --> Total execution time: 0.0495
DEBUG - 2021-12-21 04:38:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:38:05 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 596
DEBUG - 2021-12-21 04:38:05 --> Total execution time: 0.0426
DEBUG - 2021-12-21 04:38:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:38:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:38:40 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 597
DEBUG - 2021-12-21 04:38:40 --> Total execution time: 0.0303
DEBUG - 2021-12-21 04:38:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:38:52 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 598
DEBUG - 2021-12-21 04:38:52 --> Total execution time: 0.0301
DEBUG - 2021-12-21 04:39:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:39:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:39:39 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 602
DEBUG - 2021-12-21 04:39:39 --> Total execution time: 0.0323
DEBUG - 2021-12-21 04:40:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:40:37 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 604
DEBUG - 2021-12-21 04:40:37 --> Total execution time: 0.0549
DEBUG - 2021-12-21 04:41:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:41:02 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 601
DEBUG - 2021-12-21 04:41:02 --> Total execution time: 0.0303
DEBUG - 2021-12-21 04:42:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:42:07 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 616
DEBUG - 2021-12-21 04:42:07 --> Total execution time: 0.0412
DEBUG - 2021-12-21 04:42:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:42:51 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 618
DEBUG - 2021-12-21 04:42:51 --> Total execution time: 0.0426
DEBUG - 2021-12-21 04:44:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:44:06 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 632
DEBUG - 2021-12-21 04:44:06 --> Total execution time: 0.0554
DEBUG - 2021-12-21 04:45:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:45:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:45:08 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 629
DEBUG - 2021-12-21 04:45:08 --> Total execution time: 0.0312
DEBUG - 2021-12-21 04:45:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:45:16 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 629
DEBUG - 2021-12-21 04:45:16 --> Total execution time: 0.0297
DEBUG - 2021-12-21 04:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:45:53 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 629
DEBUG - 2021-12-21 04:45:53 --> Total execution time: 0.0424
DEBUG - 2021-12-21 04:46:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:46:28 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 631
DEBUG - 2021-12-21 04:46:28 --> Total execution time: 0.0444
DEBUG - 2021-12-21 04:47:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:47:01 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 629
DEBUG - 2021-12-21 04:47:01 --> Total execution time: 0.0497
DEBUG - 2021-12-21 04:47:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:47:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:47:48 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 630
DEBUG - 2021-12-21 04:47:48 --> Total execution time: 0.0467
DEBUG - 2021-12-21 04:48:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:48:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:48:04 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 632
DEBUG - 2021-12-21 04:48:04 --> Total execution time: 0.0517
DEBUG - 2021-12-21 04:48:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:48:30 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 632
DEBUG - 2021-12-21 04:48:30 --> Total execution time: 0.0303
DEBUG - 2021-12-21 04:48:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:48:43 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\data\index.php 629
DEBUG - 2021-12-21 04:48:43 --> Total execution time: 0.0461
DEBUG - 2021-12-21 04:50:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:50:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:50:08 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 660
DEBUG - 2021-12-21 04:50:08 --> Total execution time: 0.0544
DEBUG - 2021-12-21 04:50:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:50:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:50:30 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 660
DEBUG - 2021-12-21 04:50:30 --> Total execution time: 0.0490
DEBUG - 2021-12-21 04:50:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:50:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:50:40 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\data\index.php 660
DEBUG - 2021-12-21 04:50:40 --> Total execution time: 0.0462
DEBUG - 2021-12-21 04:50:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:50:59 --> Total execution time: 0.0511
DEBUG - 2021-12-21 04:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:52:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:52:35 --> Total execution time: 0.0518
DEBUG - 2021-12-21 04:53:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:53:09 --> Total execution time: 0.0388
DEBUG - 2021-12-21 04:53:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:53:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:53:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:53:41 --> Total execution time: 0.0489
DEBUG - 2021-12-21 04:54:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:54:00 --> Total execution time: 0.0391
DEBUG - 2021-12-21 04:54:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:54:35 --> Total execution time: 0.0481
DEBUG - 2021-12-21 04:57:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:57:00 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 31
DEBUG - 2021-12-21 04:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:57:05 --> Total execution time: 0.0388
DEBUG - 2021-12-21 04:57:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:57:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 04:57:28 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\data.php 31
DEBUG - 2021-12-21 04:58:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:58:10 --> Total execution time: 0.0285
DEBUG - 2021-12-21 04:58:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:58:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:58:16 --> Total execution time: 0.0288
DEBUG - 2021-12-21 04:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 04:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 04:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 04:58:30 --> Total execution time: 0.0446
DEBUG - 2021-12-21 06:09:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:09:58 --> Total execution time: 0.0275
DEBUG - 2021-12-21 06:09:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:09:59 --> Total execution time: 0.0436
DEBUG - 2021-12-21 06:09:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:09:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:09:59 --> Total execution time: 0.0410
DEBUG - 2021-12-21 06:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:10:28 --> Total execution time: 0.0481
DEBUG - 2021-12-21 06:10:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:10:30 --> Total execution time: 0.0617
DEBUG - 2021-12-21 06:10:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:10:31 --> Total execution time: 0.0393
DEBUG - 2021-12-21 06:24:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:24:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:24:53 --> Total execution time: 0.0571
DEBUG - 2021-12-21 06:26:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:26:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:26:37 --> Total execution time: 0.0484
DEBUG - 2021-12-21 06:26:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:26:38 --> Total execution time: 0.0273
DEBUG - 2021-12-21 06:26:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:26:39 --> Total execution time: 0.0405
DEBUG - 2021-12-21 06:26:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:26:39 --> Total execution time: 0.0378
DEBUG - 2021-12-21 06:26:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:26:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 06:26:40 --> 404 Page Not Found: Lamaran/index
DEBUG - 2021-12-21 06:26:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:26:41 --> Total execution time: 0.0305
DEBUG - 2021-12-21 06:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:28:03 --> Total execution time: 0.0511
DEBUG - 2021-12-21 06:28:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:28:37 --> Total execution time: 0.0543
DEBUG - 2021-12-21 06:28:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:28:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:28:47 --> Total execution time: 0.0413
DEBUG - 2021-12-21 06:28:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:28:49 --> Total execution time: 0.0252
DEBUG - 2021-12-21 06:28:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:28:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 06:28:50 --> 404 Page Not Found: Lamaran/index
DEBUG - 2021-12-21 06:28:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:28:51 --> Total execution time: 0.0268
DEBUG - 2021-12-21 06:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 06:29:17 --> 404 Page Not Found: Acara/index
DEBUG - 2021-12-21 06:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:29:18 --> Total execution time: 0.0253
DEBUG - 2021-12-21 06:37:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:37:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:37:35 --> Total execution time: 0.0280
DEBUG - 2021-12-21 06:37:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:37:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 58
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 59
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 58
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 59
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 81
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 82
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 83
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined variable $date_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 121
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined variable $place_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 129
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 81
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 82
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 83
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined variable $date_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 121
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined variable $place_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 129
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 233
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 234
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 235
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 233
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 234
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 235
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 310
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 310
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:37:36 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
DEBUG - 2021-12-21 06:37:36 --> Total execution time: 0.0406
DEBUG - 2021-12-21 06:38:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 81
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 82
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 83
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined variable $date_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 121
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined variable $place_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 129
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 81
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 82
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 83
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined variable $date_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 121
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined variable $place_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 129
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 233
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 234
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 235
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 233
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 234
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 235
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 310
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 310
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:38:15 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
DEBUG - 2021-12-21 06:38:15 --> Total execution time: 0.0616
DEBUG - 2021-12-21 06:38:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:38:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:38:21 --> Total execution time: 0.0434
DEBUG - 2021-12-21 06:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 81
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 82
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 83
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined variable $date_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 121
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined variable $place_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 129
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 81
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 82
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 83
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined variable $date_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 121
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined variable $place_a C:\xampp\htdocs\nesnu\application\views\acara\index.php 129
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 233
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 234
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 235
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 233
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 234
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 235
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 310
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 310
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:38:24 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
DEBUG - 2021-12-21 06:38:24 --> Total execution time: 0.0498
DEBUG - 2021-12-21 06:39:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 233
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 234
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 235
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 233
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 234
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 235
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 310
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 310
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:39:09 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
DEBUG - 2021-12-21 06:39:09 --> Total execution time: 0.0414
DEBUG - 2021-12-21 06:39:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 313
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined array key "date" C:\xampp\htdocs\nesnu\application\views\acara\index.php 311
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined array key "w_prewed" C:\xampp\htdocs\nesnu\application\views\acara\index.php 312
ERROR - 2021-12-21 06:39:44 --> Severity: Warning --> Undefined array key "place_p" C:\xampp\htdocs\nesnu\application\views\acara\index.php 313
DEBUG - 2021-12-21 06:39:44 --> Total execution time: 0.0531
DEBUG - 2021-12-21 06:40:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:40:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 337
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 338
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 345
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 337
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 338
ERROR - 2021-12-21 06:40:29 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 345
DEBUG - 2021-12-21 06:40:29 --> Total execution time: 0.0589
DEBUG - 2021-12-21 06:41:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:41:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:41:36 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:41:36 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:41:36 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:41:36 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:41:36 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
ERROR - 2021-12-21 06:41:36 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:41:36 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:41:36 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
DEBUG - 2021-12-21 06:41:36 --> Total execution time: 0.0542
DEBUG - 2021-12-21 06:41:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:41:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:41:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 06:41:47 --> 404 Page Not Found: Acaraa/index
DEBUG - 2021-12-21 06:41:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:41:50 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:41:50 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:41:50 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:41:50 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
DEBUG - 2021-12-21 06:41:50 --> Total execution time: 0.0308
DEBUG - 2021-12-21 06:42:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:42:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:42:32 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:42:32 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:42:32 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:42:32 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
DEBUG - 2021-12-21 06:42:32 --> Total execution time: 0.0461
DEBUG - 2021-12-21 06:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:42:33 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 122
ERROR - 2021-12-21 06:42:33 --> Severity: Warning --> Undefined variable $date C:\xampp\htdocs\nesnu\application\views\acara\index.php 253
ERROR - 2021-12-21 06:42:33 --> Severity: Warning --> Undefined variable $place_p C:\xampp\htdocs\nesnu\application\views\acara\index.php 272
ERROR - 2021-12-21 06:42:33 --> Severity: Warning --> Undefined variable $w_prewed C:\xampp\htdocs\nesnu\application\views\acara\index.php 278
DEBUG - 2021-12-21 06:42:33 --> Total execution time: 0.0480
DEBUG - 2021-12-21 06:44:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:44:10 --> Total execution time: 0.0446
DEBUG - 2021-12-21 06:44:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:44:47 --> Query error: Unknown column 'date_l' in 'field list' - Invalid query: UPDATE `acara` SET `name` = 'Fanie & Graha a', `phone` = '082126036382', `date_l` = NULL, `place_l` = NULL, `w_lamaran` = NULL, `photograper` = 'Ardi,Nano', `videograper` = 'Gian,Fadil', `crew` = 'Tebi', `note` = 'sdadasd'
WHERE `id` = '2'
DEBUG - 2021-12-21 06:44:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:44:57 --> Total execution time: 0.0504
DEBUG - 2021-12-21 06:54:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:54:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:54:47 --> Total execution time: 0.0564
DEBUG - 2021-12-21 06:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:55:28 --> Total execution time: 0.0521
DEBUG - 2021-12-21 06:55:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:55:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:55:56 --> Query error: Unknown column 'date_l' in 'field list' - Invalid query: INSERT INTO `prewedding` (`name`, `phone`, `date_l`, `place_l`, `w_lamaran`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Livia D. Y & Barugu A. F Agradriya', '081222303810', NULL, 'dsad', '00:00:00', 'Ardi', 'Gian', 'Kewong', 'dasds')
DEBUG - 2021-12-21 06:56:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:56:03 --> Total execution time: 0.0506
DEBUG - 2021-12-21 06:57:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:57:03 --> Query error: Column 'date_l' cannot be null - Invalid query: INSERT INTO `lamaran` (`name`, `phone`, `date_l`, `place_l`, `w_lamaran`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Livia D. Y & Barugu A. F Agradriya', '081222303810', NULL, 'dsad', '01:00:00', 'Ardi', 'Gian', 'Kewong', 'dasds')
DEBUG - 2021-12-21 06:57:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:57:06 --> Total execution time: 0.0477
DEBUG - 2021-12-21 06:57:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:57:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:57:24 --> Query error: Column 'date_l' cannot be null - Invalid query: INSERT INTO `lamaran` (`name`, `phone`, `date_l`, `place_l`, `w_lamaran`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Livia D. Y & Barugu A. F Agradriya', '081222303810', NULL, 'dsad', '01:00:00', 'Ardi', 'Gian', 'Kewong', 'dasds')
DEBUG - 2021-12-21 06:57:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:57:56 --> Total execution time: 0.0442
DEBUG - 2021-12-21 06:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:58:04 --> Total execution time: 0.0304
DEBUG - 2021-12-21 06:58:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 06:58:06 --> 404 Page Not Found: Lamaran/index
DEBUG - 2021-12-21 06:58:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:58:07 --> Total execution time: 0.0470
DEBUG - 2021-12-21 06:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:58:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:58:30 --> Total execution time: 0.0289
DEBUG - 2021-12-21 06:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:58:31 --> Total execution time: 0.0367
DEBUG - 2021-12-21 06:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 06:58:41 --> 404 Page Not Found: Acaraa/index
DEBUG - 2021-12-21 06:58:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:58:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 06:58:44 --> Total execution time: 0.0437
DEBUG - 2021-12-21 06:59:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 06:59:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 06:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 06:59:13 --> Query error: Unknown column 'date_l' in 'field list' - Invalid query: UPDATE `acara` SET `name` = 'Livia D. Y & Barugu A. F Agradriya', `phone` = '081222303810', `date_l` = NULL, `place_l` = NULL, `w_lamaran` = NULL, `photograper` = 'Nano', `videograper` = 'Fadil', `crew` = 'Tebi', `note` = 'dasd'
WHERE `id` = '3'
DEBUG - 2021-12-21 07:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:00:22 --> Total execution time: 0.0472
DEBUG - 2021-12-21 07:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:00:26 --> Total execution time: 0.0259
DEBUG - 2021-12-21 07:00:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:00:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:00:49 --> Total execution time: 0.0295
DEBUG - 2021-12-21 07:00:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:00:50 --> Total execution time: 0.0390
DEBUG - 2021-12-21 07:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 07:00:51 --> 404 Page Not Found: Lamaran/index
DEBUG - 2021-12-21 07:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:00:52 --> Total execution time: 0.0277
DEBUG - 2021-12-21 07:00:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:00:54 --> Total execution time: 0.0397
DEBUG - 2021-12-21 07:05:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:05:27 --> Total execution time: 0.0452
DEBUG - 2021-12-21 07:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:05:28 --> Severity: error --> Exception: Unable to locate the model you have specified: Lamaran_model C:\xampp\htdocs\nesnu\system\core\Loader.php 348
DEBUG - 2021-12-21 07:06:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:06:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:06:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:06:14 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 75
ERROR - 2021-12-21 07:06:14 --> Severity: Warning --> Undefined array key "date_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 78
ERROR - 2021-12-21 07:06:14 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 228
ERROR - 2021-12-21 07:06:14 --> Severity: Warning --> Undefined array key "date_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 231
DEBUG - 2021-12-21 07:06:14 --> Total execution time: 0.0484
DEBUG - 2021-12-21 07:07:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:07:33 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 75
ERROR - 2021-12-21 07:07:33 --> Severity: Warning --> Undefined array key "date_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 78
ERROR - 2021-12-21 07:07:33 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 228
ERROR - 2021-12-21 07:07:33 --> Severity: Warning --> Undefined array key "date_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 231
DEBUG - 2021-12-21 07:07:33 --> Total execution time: 0.0466
DEBUG - 2021-12-21 07:07:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:07:36 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 75
ERROR - 2021-12-21 07:07:36 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 228
DEBUG - 2021-12-21 07:07:36 --> Total execution time: 0.0479
DEBUG - 2021-12-21 07:07:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:07:37 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 75
ERROR - 2021-12-21 07:07:37 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 228
DEBUG - 2021-12-21 07:07:37 --> Total execution time: 0.0444
DEBUG - 2021-12-21 07:08:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:08:16 --> Total execution time: 0.0367
DEBUG - 2021-12-21 07:08:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:08:40 --> Severity: Warning --> Undefined array key "name_a" C:\xampp\htdocs\nesnu\application\views\lamaran\index.php 219
DEBUG - 2021-12-21 07:08:40 --> Total execution time: 0.0284
DEBUG - 2021-12-21 07:09:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:09:06 --> Total execution time: 0.0267
DEBUG - 2021-12-21 07:09:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:09:12 --> Total execution time: 0.0258
DEBUG - 2021-12-21 07:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:09:14 --> Total execution time: 0.0494
DEBUG - 2021-12-21 07:09:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:09:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:09:31 --> Total execution time: 0.0451
DEBUG - 2021-12-21 07:09:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:09:33 --> Total execution time: 0.0355
DEBUG - 2021-12-21 07:10:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:10:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:10:18 --> Total execution time: 0.0442
DEBUG - 2021-12-21 07:10:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:10:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:10:30 --> Total execution time: 0.0266
DEBUG - 2021-12-21 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:10:43 --> Total execution time: 0.0374
DEBUG - 2021-12-21 07:10:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:10:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:10:44 --> Total execution time: 0.0464
DEBUG - 2021-12-21 07:10:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:10:45 --> Total execution time: 0.0491
DEBUG - 2021-12-21 07:11:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:11:16 --> Total execution time: 0.0467
DEBUG - 2021-12-21 07:11:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:11:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:11:17 --> Total execution time: 0.0417
DEBUG - 2021-12-21 07:11:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:11:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:11:18 --> Total execution time: 0.0524
DEBUG - 2021-12-21 07:11:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:11:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:11:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:11:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:11:30 --> Total execution time: 0.0295
DEBUG - 2021-12-21 07:11:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:11:32 --> Total execution time: 0.0433
DEBUG - 2021-12-21 07:12:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:12:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:12:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:12:17 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\wedding.php 32
DEBUG - 2021-12-21 07:12:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:12:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:12:19 --> Total execution time: 0.0481
DEBUG - 2021-12-21 07:12:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:12:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:12:28 --> Total execution time: 0.0415
DEBUG - 2021-12-21 07:12:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:12:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:12:52 --> Total execution time: 0.0378
DEBUG - 2021-12-21 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:01 --> Total execution time: 0.0446
DEBUG - 2021-12-21 07:13:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:23 --> Total execution time: 0.0390
DEBUG - 2021-12-21 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:32 --> Total execution time: 0.0438
DEBUG - 2021-12-21 07:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:36 --> Total execution time: 0.0479
DEBUG - 2021-12-21 07:13:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:46 --> Total execution time: 0.0434
DEBUG - 2021-12-21 07:13:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:13:58 --> Total execution time: 0.0495
DEBUG - 2021-12-21 07:14:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:14:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:14:11 --> Total execution time: 0.0462
DEBUG - 2021-12-21 07:14:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:14:14 --> Total execution time: 0.0407
DEBUG - 2021-12-21 07:14:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:14:15 --> Total execution time: 0.0493
DEBUG - 2021-12-21 07:14:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:14:40 --> Total execution time: 0.0261
DEBUG - 2021-12-21 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:14:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:14:46 --> Total execution time: 0.0417
DEBUG - 2021-12-21 07:16:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:16:54 --> Total execution time: 0.0436
DEBUG - 2021-12-21 07:17:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:17:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:17:03 --> Total execution time: 0.0495
DEBUG - 2021-12-21 07:17:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:17:30 --> Total execution time: 0.0260
DEBUG - 2021-12-21 07:18:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:18:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:18:16 --> Total execution time: 0.0408
DEBUG - 2021-12-21 07:18:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:18:47 --> Total execution time: 0.0272
DEBUG - 2021-12-21 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:18 --> Total execution time: 0.0433
DEBUG - 2021-12-21 07:19:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:19 --> Total execution time: 0.0444
DEBUG - 2021-12-21 07:19:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:34 --> Total execution time: 0.0507
DEBUG - 2021-12-21 07:19:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:36 --> Total execution time: 0.0259
DEBUG - 2021-12-21 07:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:37 --> Total execution time: 0.0428
DEBUG - 2021-12-21 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:39 --> Total execution time: 0.0423
DEBUG - 2021-12-21 07:19:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:40 --> Total execution time: 0.0465
DEBUG - 2021-12-21 07:19:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:41 --> Total execution time: 0.0386
DEBUG - 2021-12-21 07:19:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:19:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:19:54 --> Total execution time: 0.0480
DEBUG - 2021-12-21 07:26:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:26:46 --> Total execution time: 0.0495
DEBUG - 2021-12-21 07:27:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:27:06 --> Total execution time: 0.0393
DEBUG - 2021-12-21 07:32:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:32:22 --> Total execution time: 0.0467
DEBUG - 2021-12-21 07:32:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:32:37 --> Total execution time: 0.0531
DEBUG - 2021-12-21 07:32:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:32:53 --> Total execution time: 0.0491
DEBUG - 2021-12-21 07:33:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:33:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:33:47 --> Total execution time: 0.0447
DEBUG - 2021-12-21 07:38:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:38:21 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\appointment.php 28
DEBUG - 2021-12-21 07:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:38:23 --> Total execution time: 0.0274
DEBUG - 2021-12-21 07:38:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:38:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:38:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:38:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:38:37 --> Total execution time: 0.0409
DEBUG - 2021-12-21 07:38:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:38:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:38:39 --> Total execution time: 0.0441
DEBUG - 2021-12-21 07:38:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:38:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:38:46 --> Total execution time: 0.0288
DEBUG - 2021-12-21 07:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:39:41 --> Total execution time: 0.0407
DEBUG - 2021-12-21 07:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:40:17 --> Total execution time: 0.0412
DEBUG - 2021-12-21 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:40:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:40:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:40:42 --> Total execution time: 0.0443
DEBUG - 2021-12-21 07:41:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:00 --> Total execution time: 0.0287
DEBUG - 2021-12-21 07:41:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:18 --> Total execution time: 0.0445
DEBUG - 2021-12-21 07:41:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 07:41:42 --> 404 Page Not Found: Spk/spk_pengaji
DEBUG - 2021-12-21 07:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:44 --> Total execution time: 0.0409
DEBUG - 2021-12-21 07:41:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:51 --> Total execution time: 0.0456
DEBUG - 2021-12-21 07:41:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:52 --> Total execution time: 0.0342
DEBUG - 2021-12-21 07:41:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:56 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:56 --> Total execution time: 0.0421
DEBUG - 2021-12-21 07:41:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:41:58 --> Total execution time: 0.0469
DEBUG - 2021-12-21 07:42:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:42:09 --> Total execution time: 0.0508
DEBUG - 2021-12-21 07:42:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:42:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:42:38 --> Total execution time: 0.0412
DEBUG - 2021-12-21 07:43:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:43:39 --> Total execution time: 0.0483
DEBUG - 2021-12-21 07:44:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:44:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:44:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:44:27 --> Total execution time: 0.0439
DEBUG - 2021-12-21 07:44:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 07:44:30 --> 404 Page Not Found: Pengajian/index
DEBUG - 2021-12-21 07:44:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:44:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:44:31 --> Total execution time: 0.0401
DEBUG - 2021-12-21 07:49:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:49:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:49:15 --> Total execution time: 0.0501
DEBUG - 2021-12-21 07:50:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:50:32 --> Total execution time: 0.0289
DEBUG - 2021-12-21 07:51:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:51:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:51:06 --> Query error: Column 'date_m' cannot be null - Invalid query: INSERT INTO `pengajian` (`name`, `phone`, `date_m`, `w_siram`, `place_m`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Farhan & FItri', '085158666069', NULL, NULL, NULL, 'Rogen,Jiwa', '', ',Tebi', 'ok')
DEBUG - 2021-12-21 07:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:51:44 --> Total execution time: 0.0509
DEBUG - 2021-12-21 07:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:51:44 --> Total execution time: 0.0289
DEBUG - 2021-12-21 07:52:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:52:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:52:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:52:01 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\spk.php 120
DEBUG - 2021-12-21 07:52:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:52:06 --> Total execution time: 0.0382
DEBUG - 2021-12-21 07:52:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:52:15 --> Severity: error --> Exception: implode(): Argument #1 ($pieces) must be of type array, string given C:\xampp\htdocs\nesnu\application\controllers\spk.php 120
DEBUG - 2021-12-21 07:52:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:52:46 --> Total execution time: 0.0430
DEBUG - 2021-12-21 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:52:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:52:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:52:59 --> Total execution time: 0.0471
DEBUG - 2021-12-21 07:54:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:54:44 --> Total execution time: 0.0494
DEBUG - 2021-12-21 07:55:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:55:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:55:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:55:30 --> Total execution time: 0.0291
DEBUG - 2021-12-21 07:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:14 --> Total execution time: 0.0416
DEBUG - 2021-12-21 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:24 --> Total execution time: 0.0460
DEBUG - 2021-12-21 07:56:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:29 --> Total execution time: 0.0257
DEBUG - 2021-12-21 07:56:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:30 --> Total execution time: 0.0396
DEBUG - 2021-12-21 07:56:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:31 --> Total execution time: 0.0456
DEBUG - 2021-12-21 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:35 --> Total execution time: 0.0445
DEBUG - 2021-12-21 07:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:37 --> Total execution time: 0.0540
DEBUG - 2021-12-21 07:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:38 --> Total execution time: 0.0425
DEBUG - 2021-12-21 07:56:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:41 --> Total execution time: 0.0430
DEBUG - 2021-12-21 07:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:43 --> Total execution time: 0.0357
DEBUG - 2021-12-21 07:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:56:45 --> Total execution time: 0.0351
DEBUG - 2021-12-21 07:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:57:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:57:43 --> Total execution time: 0.0425
DEBUG - 2021-12-21 07:58:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:11 --> Total execution time: 0.0481
DEBUG - 2021-12-21 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:13 --> Total execution time: 0.0354
DEBUG - 2021-12-21 07:58:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:13 --> Total execution time: 0.0475
DEBUG - 2021-12-21 07:58:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:14 --> Total execution time: 0.0256
DEBUG - 2021-12-21 07:58:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:15 --> Total execution time: 0.0250
DEBUG - 2021-12-21 07:58:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:16 --> Total execution time: 0.0380
DEBUG - 2021-12-21 07:58:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:17 --> Total execution time: 0.0270
DEBUG - 2021-12-21 07:58:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:17 --> Total execution time: 0.0499
DEBUG - 2021-12-21 07:58:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:18 --> Total execution time: 0.0502
DEBUG - 2021-12-21 07:58:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:20 --> Total execution time: 0.0377
DEBUG - 2021-12-21 07:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:22 --> Total execution time: 0.0385
DEBUG - 2021-12-21 07:58:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:23 --> Total execution time: 0.0456
DEBUG - 2021-12-21 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:25 --> Total execution time: 0.0492
DEBUG - 2021-12-21 07:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:25 --> Total execution time: 0.0257
DEBUG - 2021-12-21 07:58:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:26 --> Total execution time: 0.0419
DEBUG - 2021-12-21 07:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:27 --> Total execution time: 0.0407
DEBUG - 2021-12-21 07:58:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:27 --> Total execution time: 0.0484
DEBUG - 2021-12-21 07:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:28 --> Total execution time: 0.0463
DEBUG - 2021-12-21 07:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:29 --> Total execution time: 0.0396
DEBUG - 2021-12-21 07:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:29 --> Total execution time: 0.0254
DEBUG - 2021-12-21 07:58:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:57 --> Total execution time: 0.0386
DEBUG - 2021-12-21 07:58:57 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:57 --> Total execution time: 0.0424
DEBUG - 2021-12-21 07:58:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:58:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:58:58 --> Total execution time: 0.0448
DEBUG - 2021-12-21 07:59:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:00 --> Total execution time: 0.0432
DEBUG - 2021-12-21 07:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:01 --> Total execution time: 0.0433
DEBUG - 2021-12-21 07:59:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 07:59:28 --> Severity: error --> Exception: C:\xampp\htdocs\nesnu\application\models/Pengajian_model.php exists, but doesn't declare class Pengajian_model C:\xampp\htdocs\nesnu\system\core\Loader.php 340
DEBUG - 2021-12-21 07:59:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:30 --> Total execution time: 0.0495
DEBUG - 2021-12-21 07:59:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:31 --> Total execution time: 0.0376
DEBUG - 2021-12-21 07:59:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:31 --> Total execution time: 0.0454
DEBUG - 2021-12-21 07:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:32 --> Total execution time: 0.0507
DEBUG - 2021-12-21 07:59:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:32 --> Total execution time: 0.0361
DEBUG - 2021-12-21 07:59:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:33 --> Total execution time: 0.0359
DEBUG - 2021-12-21 07:59:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:34 --> Total execution time: 0.0593
DEBUG - 2021-12-21 07:59:34 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:34 --> Total execution time: 0.0389
DEBUG - 2021-12-21 07:59:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:36 --> Total execution time: 0.0479
DEBUG - 2021-12-21 07:59:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:36 --> Total execution time: 0.0363
DEBUG - 2021-12-21 07:59:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:37 --> Total execution time: 0.0269
DEBUG - 2021-12-21 07:59:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:38 --> Total execution time: 0.0407
DEBUG - 2021-12-21 07:59:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 07:59:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 07:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 07:59:39 --> Total execution time: 0.0384
DEBUG - 2021-12-21 08:00:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:00:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:00:08 --> Total execution time: 0.0280
DEBUG - 2021-12-21 08:00:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:00:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:00:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:00:11 --> Total execution time: 0.0262
DEBUG - 2021-12-21 08:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:00:13 --> Total execution time: 0.0515
DEBUG - 2021-12-21 08:03:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:03:18 --> Total execution time: 0.0413
DEBUG - 2021-12-21 08:03:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:03:20 --> Total execution time: 0.0449
DEBUG - 2021-12-21 08:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:03:21 --> Total execution time: 0.0423
DEBUG - 2021-12-21 08:03:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:03:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:03:22 --> Total execution time: 0.0370
DEBUG - 2021-12-21 08:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:04:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 08:04:32 --> Severity: Warning --> Undefined variable $Category C:\xampp\htdocs\nesnu\application\views\editor\index.php 225
DEBUG - 2021-12-21 08:04:32 --> Total execution time: 0.0460
DEBUG - 2021-12-21 08:04:45 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:04:45 --> Total execution time: 0.0508
DEBUG - 2021-12-21 08:04:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:04:58 --> Total execution time: 0.0393
DEBUG - 2021-12-21 08:04:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:04:59 --> Total execution time: 0.0462
DEBUG - 2021-12-21 08:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 08:05:25 --> 404 Page Not Found: Pengaji/spk_edit
DEBUG - 2021-12-21 08:06:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:11 --> Total execution time: 0.0423
DEBUG - 2021-12-21 08:06:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:12 --> Total execution time: 0.0452
DEBUG - 2021-12-21 08:06:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:21 --> Total execution time: 0.0434
DEBUG - 2021-12-21 08:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 08:06:27 --> 404 Page Not Found: Live/index
DEBUG - 2021-12-21 08:06:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:28 --> Total execution time: 0.0530
DEBUG - 2021-12-21 08:06:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:50 --> Total execution time: 0.0452
DEBUG - 2021-12-21 08:06:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:51 --> Total execution time: 0.0537
DEBUG - 2021-12-21 08:06:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:51 --> Total execution time: 0.0409
DEBUG - 2021-12-21 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:52 --> Total execution time: 0.0445
DEBUG - 2021-12-21 08:06:52 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:52 --> Total execution time: 0.0416
DEBUG - 2021-12-21 08:06:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:53 --> Total execution time: 0.0472
DEBUG - 2021-12-21 08:06:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:06:53 --> Total execution time: 0.0348
DEBUG - 2021-12-21 08:11:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:11:06 --> Total execution time: 0.4762
DEBUG - 2021-12-21 08:11:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:11:07 --> Total execution time: 0.0422
DEBUG - 2021-12-21 08:25:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:25:37 --> Total execution time: 0.0700
DEBUG - 2021-12-21 08:25:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:25:37 --> Total execution time: 0.0517
DEBUG - 2021-12-21 08:25:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:25:38 --> Total execution time: 0.0510
DEBUG - 2021-12-21 08:25:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:25:38 --> Total execution time: 0.0761
DEBUG - 2021-12-21 08:25:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:25:38 --> Total execution time: 0.0726
DEBUG - 2021-12-21 08:25:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:25:39 --> Total execution time: 0.0388
DEBUG - 2021-12-21 08:25:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 08:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 08:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 08:25:39 --> Total execution time: 0.0371
DEBUG - 2021-12-21 09:05:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:05:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:05:27 --> Total execution time: 0.0531
DEBUG - 2021-12-21 09:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:05:28 --> Total execution time: 0.0466
DEBUG - 2021-12-21 09:08:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:08:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:08:54 --> Severity: Warning --> Undefined property: Menu::$form_validation C:\xampp\htdocs\nesnu\application\controllers\menu.php 13
ERROR - 2021-12-21 09:08:54 --> Severity: error --> Exception: Call to a member function run() on null C:\xampp\htdocs\nesnu\application\controllers\menu.php 13
DEBUG - 2021-12-21 09:09:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:09:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:09:11 --> Total execution time: 0.0547
DEBUG - 2021-12-21 09:09:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:09:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:09:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:09:15 --> Total execution time: 0.0450
DEBUG - 2021-12-21 09:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:09:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 09:09:16 --> Total execution time: 0.0833
DEBUG - 2021-12-21 09:09:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:09:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:09:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 09:09:16 --> Total execution time: 0.0911
DEBUG - 2021-12-21 09:09:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:09:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 09:09:17 --> Total execution time: 0.0446
DEBUG - 2021-12-21 09:09:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:09:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:09:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 09:09:17 --> Total execution time: 0.0290
DEBUG - 2021-12-21 09:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:09:19 --> Total execution time: 0.0500
DEBUG - 2021-12-21 09:09:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:09:20 --> Total execution time: 0.0447
DEBUG - 2021-12-21 09:11:46 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:11:46 --> Total execution time: 0.0542
DEBUG - 2021-12-21 09:14:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:14:15 --> Total execution time: 0.0509
DEBUG - 2021-12-21 09:14:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:14:17 --> Total execution time: 0.0459
DEBUG - 2021-12-21 09:14:31 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:14:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:14:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:14:31 --> Total execution time: 0.0511
DEBUG - 2021-12-21 09:15:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:15:08 --> Total execution time: 0.0378
DEBUG - 2021-12-21 09:19:27 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:19:27 --> Total execution time: 0.0445
DEBUG - 2021-12-21 09:19:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:19:33 --> Total execution time: 0.0479
DEBUG - 2021-12-21 09:19:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:19:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:19:36 --> Total execution time: 0.0435
DEBUG - 2021-12-21 09:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:19:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 09:19:37 --> Total execution time: 0.0462
DEBUG - 2021-12-21 09:19:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:19:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:19:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:19:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-21 09:19:38 --> Total execution time: 0.0493
DEBUG - 2021-12-21 09:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:19:39 --> Total execution time: 0.0461
DEBUG - 2021-12-21 09:19:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:19:44 --> Query error: Table 'admin_nesnu.iser_menu' doesn't exist - Invalid query: INSERT INTO `iser_menu` (`menu`) VALUES ('test')
DEBUG - 2021-12-21 09:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:19:58 --> Total execution time: 0.0285
DEBUG - 2021-12-21 09:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:20:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:20:00 --> Total execution time: 0.0393
DEBUG - 2021-12-21 09:25:53 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:25:53 --> Severity: Warning --> Undefined variable $surat C:\xampp\htdocs\nesnu\application\views\menu\index.php 111
ERROR - 2021-12-21 09:25:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\menu\index.php 111
DEBUG - 2021-12-21 09:25:53 --> Total execution time: 0.0475
DEBUG - 2021-12-21 09:26:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:26:29 --> Severity: Warning --> Undefined variable $surat C:\xampp\htdocs\nesnu\application\views\menu\index.php 111
ERROR - 2021-12-21 09:26:29 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\xampp\htdocs\nesnu\application\views\menu\index.php 111
DEBUG - 2021-12-21 09:26:29 --> Total execution time: 0.0524
DEBUG - 2021-12-21 09:27:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:27:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:27:04 --> Total execution time: 0.0438
DEBUG - 2021-12-21 09:27:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:27:07 --> Total execution time: 0.0444
DEBUG - 2021-12-21 09:28:07 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:28:07 --> Total execution time: 0.0522
DEBUG - 2021-12-21 09:28:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:28:20 --> Total execution time: 0.0274
DEBUG - 2021-12-21 09:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:29:17 --> Total execution time: 0.0286
DEBUG - 2021-12-21 09:29:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:29:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:29:23 --> Severity: Warning --> Undefined property: Menu::$Menu_model C:\xampp\htdocs\nesnu\application\controllers\menu.php 35
ERROR - 2021-12-21 09:29:23 --> Severity: error --> Exception: Call to a member function edit() on null C:\xampp\htdocs\nesnu\application\controllers\menu.php 35
DEBUG - 2021-12-21 09:29:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:29:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:29:54 --> Total execution time: 0.0271
DEBUG - 2021-12-21 09:30:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:30:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:30:00 --> Query error: Table 'admin_nesnu.menu' doesn't exist - Invalid query: UPDATE `menu` SET `menu` = 'ok'
WHERE `id` = '1'
DEBUG - 2021-12-21 09:30:35 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:30:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:30:35 --> Total execution time: 0.0290
DEBUG - 2021-12-21 09:30:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:30:38 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:30:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:30:38 --> Total execution time: 0.0402
DEBUG - 2021-12-21 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:30:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:30:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:30:41 --> Total execution time: 0.0449
DEBUG - 2021-12-21 09:34:48 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:34:48 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 117
DEBUG - 2021-12-21 09:34:48 --> Total execution time: 0.0476
DEBUG - 2021-12-21 09:35:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:35:02 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 145
DEBUG - 2021-12-21 09:35:02 --> Total execution time: 0.0535
DEBUG - 2021-12-21 09:35:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:35:16 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 143
DEBUG - 2021-12-21 09:35:16 --> Total execution time: 0.0396
DEBUG - 2021-12-21 09:35:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-21 09:35:26 --> 404 Page Not Found: Menu/edit
DEBUG - 2021-12-21 09:35:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:35:29 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 143
DEBUG - 2021-12-21 09:35:29 --> Total execution time: 0.0409
DEBUG - 2021-12-21 09:35:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:35:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:35:39 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 143
DEBUG - 2021-12-21 09:35:39 --> Total execution time: 0.0291
DEBUG - 2021-12-21 09:35:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:35:44 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:35:44 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 143
DEBUG - 2021-12-21 09:35:44 --> Total execution time: 0.0450
DEBUG - 2021-12-21 09:37:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:37:21 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 123
DEBUG - 2021-12-21 09:37:21 --> Total execution time: 0.0549
DEBUG - 2021-12-21 09:38:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2021-12-21 09:38:13 --> Severity: Warning --> foreach() argument must be of type array|object, string given C:\xampp\htdocs\nesnu\application\views\menu\index.php 123
DEBUG - 2021-12-21 09:38:13 --> Total execution time: 0.0293
DEBUG - 2021-12-21 09:38:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:38:50 --> Total execution time: 0.0412
DEBUG - 2021-12-21 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:38:54 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:38:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:38:54 --> Total execution time: 0.0415
DEBUG - 2021-12-21 09:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:40:01 --> Total execution time: 0.0491
DEBUG - 2021-12-21 09:40:59 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:40:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:40:59 --> Total execution time: 0.0451
DEBUG - 2021-12-21 09:41:09 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:41:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:41:10 --> Total execution time: 0.0283
DEBUG - 2021-12-21 09:41:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:41:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:41:40 --> Total execution time: 0.0385
DEBUG - 2021-12-21 09:42:33 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:42:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:42:33 --> Total execution time: 0.0434
DEBUG - 2021-12-21 09:44:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:44:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:44:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:44:47 --> Total execution time: 0.0477
DEBUG - 2021-12-21 09:46:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-21 09:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-21 09:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-21 09:46:39 --> Total execution time: 0.0422
