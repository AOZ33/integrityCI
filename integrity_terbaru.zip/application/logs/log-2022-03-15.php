<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-15 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 09:57:17 --> No URI present. Default controller set.
DEBUG - 2022-03-15 09:57:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 09:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 09:57:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 09:57:17 --> Total execution time: 0.0309
DEBUG - 2022-03-15 09:57:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 09:57:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-15 09:57:17 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-15 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 09:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 09:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 09:57:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 09:57:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 09:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 09:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 09:57:20 --> Total execution time: 0.0063
DEBUG - 2022-03-15 09:57:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 09:57:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 09:57:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 09:57:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 09:57:22 --> Total execution time: 0.0131
DEBUG - 2022-03-15 09:59:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 09:59:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 09:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 09:59:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 09:59:46 --> Total execution time: 0.0356
DEBUG - 2022-03-15 11:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:01:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:01:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:01:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:01:21 --> Total execution time: 0.0071
DEBUG - 2022-03-15 11:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:03:24 --> No URI present. Default controller set.
DEBUG - 2022-03-15 11:03:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:03:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:03:24 --> Total execution time: 0.0310
DEBUG - 2022-03-15 11:03:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:03:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-15 11:03:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-15 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:08:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:08:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:08:03 --> Total execution time: 0.0066
DEBUG - 2022-03-15 11:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:21:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:21:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:21:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:21:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:21:08 --> Total execution time: 0.0072
DEBUG - 2022-03-15 11:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:25:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:25:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:25:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:25:21 --> Total execution time: 0.0065
DEBUG - 2022-03-15 11:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:34:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:34:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:34:44 --> Total execution time: 0.0061
DEBUG - 2022-03-15 11:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:47:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:47:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:47:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:47:07 --> Total execution time: 0.0062
DEBUG - 2022-03-15 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:53:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:53:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 11:53:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 11:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 11:53:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 11:53:33 --> Total execution time: 0.0063
DEBUG - 2022-03-15 12:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 12:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 12:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 12:01:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 12:01:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 12:01:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 12:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 12:01:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 12:01:29 --> Total execution time: 0.0056
DEBUG - 2022-03-15 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 12:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 12:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 12:57:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 12:57:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 12:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 12:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 12:57:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 12:57:44 --> Total execution time: 0.0074
DEBUG - 2022-03-15 13:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:03:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:03:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:03:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:03:41 --> Total execution time: 0.0066
DEBUG - 2022-03-15 13:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:17:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:17:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:17:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:17:56 --> Total execution time: 0.0069
DEBUG - 2022-03-15 13:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:28:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:28:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:28:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:28:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:28:18 --> Total execution time: 0.0072
DEBUG - 2022-03-15 13:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:29:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:29:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:29:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:29:58 --> Total execution time: 0.0047
DEBUG - 2022-03-15 13:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:35:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:35:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:35:23 --> Total execution time: 0.0069
DEBUG - 2022-03-15 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:44:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:44:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:44:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:44:09 --> Total execution time: 0.0068
DEBUG - 2022-03-15 13:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:55:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:55:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:55:26 --> Total execution time: 0.0063
DEBUG - 2022-03-15 13:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:57:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:57:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:57:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:57:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:57:40 --> Total execution time: 0.0067
DEBUG - 2022-03-15 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:58:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:58:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:58:32 --> Total execution time: 0.0030
DEBUG - 2022-03-15 13:58:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-15 13:58:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-15 13:59:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:59:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:59:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:59:07 --> Total execution time: 0.0055
DEBUG - 2022-03-15 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:59:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:59:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:59:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:59:20 --> Total execution time: 0.0031
DEBUG - 2022-03-15 13:59:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:59:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-15 13:59:20 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-15 13:59:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:59:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:59:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:59:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 13:59:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 13:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 13:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 13:59:54 --> Total execution time: 0.0037
DEBUG - 2022-03-15 14:00:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:00:48 --> Total execution time: 0.0053
DEBUG - 2022-03-15 14:00:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:00:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-15 14:00:49 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-15 14:00:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:00:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:00:58 --> Total execution time: 0.0109
DEBUG - 2022-03-15 14:01:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:01:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:01:31 --> Total execution time: 0.0046
DEBUG - 2022-03-15 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:02:05 --> Total execution time: 0.0051
DEBUG - 2022-03-15 14:02:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:02:41 --> Total execution time: 0.0054
DEBUG - 2022-03-15 14:03:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:03:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:03:08 --> Total execution time: 0.0070
DEBUG - 2022-03-15 14:03:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:03:40 --> Total execution time: 0.0055
DEBUG - 2022-03-15 14:04:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:04:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:04:11 --> Total execution time: 0.0087
DEBUG - 2022-03-15 14:04:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:04:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:04:12 --> Total execution time: 0.0045
DEBUG - 2022-03-15 14:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:12:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:12:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:12:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:12:39 --> Total execution time: 0.0066
DEBUG - 2022-03-15 14:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:15:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:15:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:15:59 --> Total execution time: 0.0057
DEBUG - 2022-03-15 14:56:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:56:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:56:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:56:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 14:56:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 14:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 14:56:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 14:56:21 --> Total execution time: 0.0066
DEBUG - 2022-03-15 15:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 15:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 15:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 15:11:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 15:11:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 15:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 15:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 15:11:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 15:11:53 --> Total execution time: 0.0068
DEBUG - 2022-03-15 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 15:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 15:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 15:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 15:17:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 15:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 15:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 15:17:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 15:17:17 --> Total execution time: 0.0063
DEBUG - 2022-03-15 16:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:20:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:20:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:20:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:20:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:20:20 --> Total execution time: 0.0068
DEBUG - 2022-03-15 16:21:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:21:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:21:07 --> Total execution time: 0.0130
DEBUG - 2022-03-15 16:21:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:21:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:21:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:21:09 --> Total execution time: 0.0042
DEBUG - 2022-03-15 16:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:24:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:24:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:24:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:24:59 --> Total execution time: 0.0060
DEBUG - 2022-03-15 16:25:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:25:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:25:01 --> Total execution time: 0.0114
DEBUG - 2022-03-15 16:25:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:25:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:25:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:25:06 --> Total execution time: 0.0095
DEBUG - 2022-03-15 16:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:25:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:25:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:25:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:25:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:25:20 --> Total execution time: 0.0085
DEBUG - 2022-03-15 16:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:25:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:25:23 --> Total execution time: 0.0093
DEBUG - 2022-03-15 16:25:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:25:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:25:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:25:28 --> Total execution time: 0.0037
DEBUG - 2022-03-15 16:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:28:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:28:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-15 16:28:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-15 16:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-15 16:28:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-15 16:28:09 --> Total execution time: 0.0046
