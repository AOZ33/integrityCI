<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-14 09:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:26:49 --> No URI present. Default controller set.
DEBUG - 2022-03-14 09:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:26:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:26:49 --> Total execution time: 0.0311
DEBUG - 2022-03-14 09:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:26:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 09:26:49 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-14 09:26:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:26:50 --> No URI present. Default controller set.
DEBUG - 2022-03-14 09:26:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:26:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:26:50 --> Total execution time: 0.0029
DEBUG - 2022-03-14 09:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:26:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:26:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:26:52 --> Total execution time: 0.0066
DEBUG - 2022-03-14 09:26:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:26:57 --> Total execution time: 0.0045
DEBUG - 2022-03-14 09:26:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:26:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 09:26:58 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-14 09:35:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:35:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:35:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:35:45 --> Total execution time: 0.0424
DEBUG - 2022-03-14 09:35:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:35:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:35:47 --> Total execution time: 0.0044
DEBUG - 2022-03-14 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 09:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 09:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 09:54:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 09:54:16 --> Total execution time: 0.0073
DEBUG - 2022-03-14 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:01:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:01:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:01:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:01:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:01:22 --> Total execution time: 0.0064
DEBUG - 2022-03-14 10:11:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:11:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:11:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:11:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:11:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:11:48 --> Total execution time: 0.0060
DEBUG - 2022-03-14 10:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:22:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:22:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:22:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:22:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:22:49 --> Total execution time: 0.0070
DEBUG - 2022-03-14 10:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:32:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:32:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:32:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:32:26 --> Total execution time: 0.0058
DEBUG - 2022-03-14 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:41:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:41:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:41:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:41:49 --> Total execution time: 0.0067
DEBUG - 2022-03-14 10:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:47:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:47:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:47:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:47:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:47:38 --> Total execution time: 0.0064
DEBUG - 2022-03-14 10:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:58:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:58:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 10:58:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 10:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 10:58:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 10:58:18 --> Total execution time: 0.0068
DEBUG - 2022-03-14 11:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 11:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 11:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 11:04:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 11:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 11:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 11:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 11:04:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 11:04:23 --> Total execution time: 0.0071
DEBUG - 2022-03-14 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 11:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 11:07:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 11:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 11:07:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 11:07:48 --> Total execution time: 0.0084
DEBUG - 2022-03-14 12:01:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:01:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:01:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:01:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:01:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:01:25 --> Total execution time: 0.0070
DEBUG - 2022-03-14 12:07:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:07:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:07:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:07:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:07:12 --> Total execution time: 0.0062
DEBUG - 2022-03-14 12:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:10:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:10:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:10:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:10:09 --> Total execution time: 0.0053
DEBUG - 2022-03-14 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:12:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:12:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:12:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:12:55 --> Total execution time: 0.0051
DEBUG - 2022-03-14 12:16:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:16:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:16:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:16:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:16:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:16:22 --> Total execution time: 0.0066
DEBUG - 2022-03-14 12:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:20:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:20:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:20:01 --> Total execution time: 0.0061
DEBUG - 2022-03-14 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:23:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:23:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:23:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:23:06 --> Total execution time: 0.0050
DEBUG - 2022-03-14 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:48:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:48:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:48:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:48:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:48:55 --> Total execution time: 0.0065
DEBUG - 2022-03-14 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:57:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:57:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 12:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 12:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 12:57:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 12:57:52 --> Total execution time: 0.0065
DEBUG - 2022-03-14 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 13:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 13:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 13:06:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 13:06:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 13:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 13:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 13:06:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 13:06:03 --> Total execution time: 0.0070
DEBUG - 2022-03-14 13:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 13:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 13:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 13:16:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 13:16:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 13:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 13:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 13:16:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 13:16:52 --> Total execution time: 0.0067
DEBUG - 2022-03-14 13:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 13:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 13:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 13:47:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 13:47:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 13:47:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 13:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 13:47:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 13:47:37 --> Total execution time: 0.0097
DEBUG - 2022-03-14 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:05:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:05:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:05:58 --> Total execution time: 0.0068
DEBUG - 2022-03-14 14:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:35:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:35:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:35:51 --> Total execution time: 0.0079
DEBUG - 2022-03-14 14:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:54:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:54:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:54:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:54:06 --> Total execution time: 0.0062
DEBUG - 2022-03-14 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:54:54 --> No URI present. Default controller set.
DEBUG - 2022-03-14 14:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:54:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:54:54 --> Total execution time: 0.0056
DEBUG - 2022-03-14 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:54:54 --> No URI present. Default controller set.
DEBUG - 2022-03-14 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:54:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:54:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 14:54:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-14 14:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:54:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:54:54 --> Total execution time: 0.0034
DEBUG - 2022-03-14 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:54:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 14:54:54 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-14 14:54:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:54:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 14:54:54 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-03-14 14:55:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:55:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:55:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:55:04 --> Total execution time: 0.0055
DEBUG - 2022-03-14 14:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:55:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:55:07 --> Total execution time: 0.0118
DEBUG - 2022-03-14 14:55:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:55:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:55:23 --> Total execution time: 0.0085
DEBUG - 2022-03-14 14:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:55:26 --> Total execution time: 0.0039
DEBUG - 2022-03-14 14:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 14:55:26 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-14 14:55:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 14:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 14:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 14:55:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 14:55:28 --> Total execution time: 0.0068
DEBUG - 2022-03-14 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:07:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:07:57 --> Total execution time: 0.0348
DEBUG - 2022-03-14 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:32:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:32:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:32:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:32:31 --> Total execution time: 0.0069
DEBUG - 2022-03-14 15:34:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:34:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:34:00 --> Total execution time: 0.0324
DEBUG - 2022-03-14 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:34:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:34:01 --> Total execution time: 0.0040
DEBUG - 2022-03-14 15:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:34:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 15:34:01 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-14 15:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:34:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:34:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:34:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:34:57 --> Total execution time: 0.0029
DEBUG - 2022-03-14 15:34:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:34:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 15:34:57 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-14 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:35:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:35:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:35:09 --> Total execution time: 0.0041
DEBUG - 2022-03-14 15:35:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:35:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 15:35:09 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-14 15:35:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:35:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:35:12 --> Total execution time: 0.0033
DEBUG - 2022-03-14 15:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:35:18 --> No URI present. Default controller set.
DEBUG - 2022-03-14 15:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:35:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:35:18 --> Total execution time: 0.0032
DEBUG - 2022-03-14 15:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 15:35:19 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-14 15:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:35:22 --> No URI present. Default controller set.
DEBUG - 2022-03-14 15:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:35:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:35:22 --> Total execution time: 0.0031
DEBUG - 2022-03-14 15:35:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:35:28 --> No URI present. Default controller set.
DEBUG - 2022-03-14 15:35:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:35:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:35:28 --> Total execution time: 0.0032
DEBUG - 2022-03-14 15:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:36:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:36:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:36:04 --> Total execution time: 0.0030
DEBUG - 2022-03-14 15:36:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 15:36:04 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-14 15:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:24 --> No URI present. Default controller set.
DEBUG - 2022-03-14 15:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:36:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:36:24 --> Total execution time: 0.0040
DEBUG - 2022-03-14 15:36:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-14 15:36:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-14 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:36:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:36:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:36:28 --> Total execution time: 0.0037
DEBUG - 2022-03-14 15:36:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:36:31 --> Total execution time: 0.0038
DEBUG - 2022-03-14 15:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:36:59 --> Total execution time: 0.0132
DEBUG - 2022-03-14 15:37:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:37:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:37:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:37:42 --> Total execution time: 0.0140
DEBUG - 2022-03-14 15:37:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:37:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:37:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:37:49 --> Total execution time: 0.0123
DEBUG - 2022-03-14 15:38:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:38:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:38:38 --> Total execution time: 0.0147
DEBUG - 2022-03-14 15:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:39:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:39:03 --> Total execution time: 0.0056
DEBUG - 2022-03-14 15:41:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:41:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:41:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:41:08 --> Total execution time: 0.0351
DEBUG - 2022-03-14 15:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:41:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:41:15 --> Total execution time: 0.0079
DEBUG - 2022-03-14 15:41:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:41:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:41:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:41:27 --> Total execution time: 0.0073
DEBUG - 2022-03-14 15:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:44:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:44:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:44:33 --> Total execution time: 0.0048
DEBUG - 2022-03-14 15:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:48:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:48:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:48:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:48:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:48:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:48:10 --> Total execution time: 0.0064
DEBUG - 2022-03-14 15:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:50:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:50:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:50:28 --> Total execution time: 0.0054
DEBUG - 2022-03-14 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:51:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:51:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:51:31 --> Total execution time: 0.0038
DEBUG - 2022-03-14 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:53:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:53:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:53:20 --> Total execution time: 0.0054
DEBUG - 2022-03-14 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:57:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:57:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:57:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:57:16 --> Total execution time: 0.0067
DEBUG - 2022-03-14 15:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:58:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:58:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:58:25 --> Total execution time: 0.0039
DEBUG - 2022-03-14 15:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:59:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:59:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 15:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 15:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 15:59:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 15:59:57 --> Total execution time: 0.0051
DEBUG - 2022-03-14 16:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:03:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:03:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:03:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:03:51 --> Total execution time: 0.0050
DEBUG - 2022-03-14 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:04:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:04:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:04:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:04:07 --> Total execution time: 0.0052
DEBUG - 2022-03-14 16:04:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:04:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:04:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:04:10 --> Total execution time: 0.0133
DEBUG - 2022-03-14 16:04:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:04:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:04:14 --> Total execution time: 0.0094
DEBUG - 2022-03-14 16:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:04:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:04:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:04:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:04:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:04:20 --> Total execution time: 0.0075
DEBUG - 2022-03-14 16:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:05:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:05:58 --> Total execution time: 0.0372
DEBUG - 2022-03-14 16:05:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:05:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:05:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:05:58 --> Total execution time: 0.0042
DEBUG - 2022-03-14 16:06:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:06:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:06:08 --> Total execution time: 0.0071
DEBUG - 2022-03-14 16:06:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:06:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:06:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:06:10 --> Total execution time: 0.0095
DEBUG - 2022-03-14 16:07:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:07:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:07:57 --> Total execution time: 0.0327
DEBUG - 2022-03-14 16:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:09:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:09:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:09:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:09:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:09:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:09:58 --> Total execution time: 0.0059
DEBUG - 2022-03-14 16:10:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:10:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:10:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:10:56 --> Total execution time: 0.0057
DEBUG - 2022-03-14 16:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:10:58 --> Total execution time: 0.0043
DEBUG - 2022-03-14 16:11:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:11:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:11:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:11:21 --> Total execution time: 0.0058
DEBUG - 2022-03-14 16:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:11:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:11:23 --> Total execution time: 0.0042
DEBUG - 2022-03-14 16:11:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:11:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:11:49 --> Total execution time: 0.0058
DEBUG - 2022-03-14 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:15:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:15:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:15:15 --> Total execution time: 0.0048
DEBUG - 2022-03-14 16:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:15:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:15:22 --> Total execution time: 0.0120
DEBUG - 2022-03-14 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:15:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:15:25 --> Total execution time: 0.0107
DEBUG - 2022-03-14 16:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:15:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:15:39 --> Total execution time: 0.0057
DEBUG - 2022-03-14 16:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:20:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:20:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:20:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:20:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:20:16 --> Total execution time: 0.0072
DEBUG - 2022-03-14 16:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:25:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:25:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:25:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:25:34 --> Total execution time: 0.0064
DEBUG - 2022-03-14 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:28:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:28:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:28:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:28:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:28:30 --> Total execution time: 0.0049
DEBUG - 2022-03-14 16:28:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:28:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:28:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:28:49 --> Total execution time: 0.0052
DEBUG - 2022-03-14 16:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:29:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:29:06 --> Total execution time: 0.0052
DEBUG - 2022-03-14 16:29:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:29:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:29:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:29:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:29:33 --> Total execution time: 0.0057
DEBUG - 2022-03-14 16:30:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:30:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:30:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:30:04 --> Total execution time: 0.0053
DEBUG - 2022-03-14 16:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:30:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:30:21 --> Total execution time: 0.0146
DEBUG - 2022-03-14 16:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:30:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:30:25 --> Total execution time: 0.0040
DEBUG - 2022-03-14 16:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:32:11 --> Total execution time: 0.0055
DEBUG - 2022-03-14 16:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:36:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:36:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:36:55 --> Total execution time: 0.0064
DEBUG - 2022-03-14 16:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:41:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:41:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:41:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:41:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:41:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:41:15 --> Total execution time: 0.0062
DEBUG - 2022-03-14 16:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:44:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:44:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:44:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:44:10 --> Total execution time: 0.0051
DEBUG - 2022-03-14 16:44:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:44:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:44:26 --> Total execution time: 0.0133
DEBUG - 2022-03-14 16:44:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:44:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:44:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:44:29 --> Total execution time: 0.0047
DEBUG - 2022-03-14 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:47:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:47:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:47:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:47:25 --> Total execution time: 0.0057
DEBUG - 2022-03-14 16:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:49:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:49:43 --> Total execution time: 0.0335
DEBUG - 2022-03-14 16:49:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:49:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:49:53 --> Total execution time: 0.0113
DEBUG - 2022-03-14 16:49:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:49:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:49:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:49:56 --> Total execution time: 0.0088
DEBUG - 2022-03-14 16:50:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:50:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:50:00 --> Total execution time: 0.0036
DEBUG - 2022-03-14 16:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:52:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-14 16:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-14 16:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-14 16:52:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-14 16:52:17 --> Total execution time: 0.0056
