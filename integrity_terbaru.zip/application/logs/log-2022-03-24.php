<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-24 09:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:36:59 --> No URI present. Default controller set.
DEBUG - 2022-03-24 09:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 09:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 09:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 09:36:59 --> Total execution time: 0.0313
DEBUG - 2022-03-24 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 09:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-24 09:37:00 --> 404 Page Not Found: Js/jquery.min.js
ERROR - 2022-03-24 09:37:00 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-03-24 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-24 09:37:00 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-03-24 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-24 09:37:00 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-03-24 09:37:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:37:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-24 09:37:00 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-24 09:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 09:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 09:37:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 09:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 09:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 09:37:02 --> Total execution time: 0.0062
DEBUG - 2022-03-24 09:44:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:44:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 09:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 09:44:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 09:44:01 --> Total execution time: 0.0416
DEBUG - 2022-03-24 09:44:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 09:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 09:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 09:44:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 09:44:02 --> Total execution time: 0.0044
DEBUG - 2022-03-24 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:03:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:03:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:03:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:03:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:03:26 --> Total execution time: 0.0065
DEBUG - 2022-03-24 10:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:09:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:09:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:09:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:09:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:09:27 --> Total execution time: 0.0055
DEBUG - 2022-03-24 10:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:43:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:43:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:43:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:43:41 --> Total execution time: 0.0070
DEBUG - 2022-03-24 10:52:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:52:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:52:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:52:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:52:41 --> Total execution time: 0.0061
DEBUG - 2022-03-24 10:57:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:57:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:57:45 --> Total execution time: 0.0351
DEBUG - 2022-03-24 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:57:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:57:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 10:57:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 10:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 10:57:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 10:57:46 --> Total execution time: 0.0034
DEBUG - 2022-03-24 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:00:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:00:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:00:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:00:19 --> Total execution time: 0.0053
DEBUG - 2022-03-24 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:01:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:01:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:01:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:01:55 --> Total execution time: 0.0035
DEBUG - 2022-03-24 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:04:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:04:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:04:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:04:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:04:00 --> Total execution time: 0.0056
DEBUG - 2022-03-24 11:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:07:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:07:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:07:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:07:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:07:59 --> Total execution time: 0.0050
DEBUG - 2022-03-24 11:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:10:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:10:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:10:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:10:27 --> Total execution time: 0.0040
DEBUG - 2022-03-24 11:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:14:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:14:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:14:43 --> Total execution time: 0.0067
DEBUG - 2022-03-24 11:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:18:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:18:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:18:47 --> Total execution time: 0.0062
DEBUG - 2022-03-24 11:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:21:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:21:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:21:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:21:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:21:01 --> Total execution time: 0.0054
DEBUG - 2022-03-24 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:23:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:23:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:23:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:23:10 --> Total execution time: 0.0049
DEBUG - 2022-03-24 11:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:23:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:23:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:23:51 --> Total execution time: 0.0036
DEBUG - 2022-03-24 11:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:25:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:25:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:25:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:25:00 --> Total execution time: 0.0038
DEBUG - 2022-03-24 11:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:33:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:33:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:33:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:33:48 --> Total execution time: 0.0074
DEBUG - 2022-03-24 11:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:37:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:37:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:37:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:37:57 --> Total execution time: 0.0059
DEBUG - 2022-03-24 11:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:42:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:42:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:42:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:42:22 --> Total execution time: 0.0051
DEBUG - 2022-03-24 11:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:45:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:45:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:45:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:45:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:45:24 --> Total execution time: 0.0048
DEBUG - 2022-03-24 11:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:46:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:46:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:46:45 --> Total execution time: 0.0042
DEBUG - 2022-03-24 11:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:49:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:49:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:49:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:49:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:49:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:49:47 --> Total execution time: 0.0065
DEBUG - 2022-03-24 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:52:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:52:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:52:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:52:02 --> Total execution time: 0.0046
DEBUG - 2022-03-24 11:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:53:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:53:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:53:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:53:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:53:48 --> Total execution time: 0.0048
DEBUG - 2022-03-24 11:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:55:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:55:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:55:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:55:15 --> Total execution time: 0.0043
DEBUG - 2022-03-24 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:56:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:56:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 11:56:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 11:56:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 11:56:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 11:56:26 --> Total execution time: 0.0040
DEBUG - 2022-03-24 12:38:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:38:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:38:48 --> Total execution time: 0.0425
DEBUG - 2022-03-24 12:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:38:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:38:52 --> Total execution time: 0.0136
DEBUG - 2022-03-24 12:39:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:39:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:39:05 --> Total execution time: 0.0053
DEBUG - 2022-03-24 12:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:40:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:40:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:40:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:40:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:40:58 --> Total execution time: 0.0053
DEBUG - 2022-03-24 12:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:43:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:43:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:43:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:43:25 --> Total execution time: 0.0043
DEBUG - 2022-03-24 12:56:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:56:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:56:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:56:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 12:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 12:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 12:56:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 12:56:34 --> Total execution time: 0.0068
DEBUG - 2022-03-24 13:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:00:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:00:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:00:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:00:35 --> Total execution time: 0.0055
DEBUG - 2022-03-24 13:10:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:10:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:10:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:10:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:10:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:10:08 --> Total execution time: 0.0064
DEBUG - 2022-03-24 13:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:15:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:15:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:15:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:15:14 --> Total execution time: 0.0063
DEBUG - 2022-03-24 13:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:20:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:20:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:20:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:20:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:20:13 --> Total execution time: 0.0067
DEBUG - 2022-03-24 13:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:27:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:27:14 --> Total execution time: 0.0057
DEBUG - 2022-03-24 13:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:30:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:30:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:30:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:30:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:30:31 --> Total execution time: 0.0043
DEBUG - 2022-03-24 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:33:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:33:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:33:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:33:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:33:13 --> Total execution time: 0.0046
DEBUG - 2022-03-24 13:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:47:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:47:51 --> Total execution time: 0.0348
DEBUG - 2022-03-24 13:51:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:51:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:51:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:51:27 --> Total execution time: 0.0449
DEBUG - 2022-03-24 13:51:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:51:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:51:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:51:30 --> Total execution time: 0.0082
DEBUG - 2022-03-24 13:52:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:52:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:52:00 --> Total execution time: 0.0132
DEBUG - 2022-03-24 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:52:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:52:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:52:15 --> Total execution time: 0.0151
DEBUG - 2022-03-24 13:52:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:52:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:52:17 --> Total execution time: 0.0043
DEBUG - 2022-03-24 13:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:54:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:54:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:54:25 --> Total execution time: 0.0047
DEBUG - 2022-03-24 13:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:57:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:57:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 13:57:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 13:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 13:57:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 13:57:50 --> Total execution time: 0.0062
DEBUG - 2022-03-24 14:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:01:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:01:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:01:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:01:08 --> Total execution time: 0.0064
DEBUG - 2022-03-24 14:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:03:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:03:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:03:18 --> Total execution time: 0.0049
DEBUG - 2022-03-24 14:03:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:03:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:03:21 --> Total execution time: 0.0183
DEBUG - 2022-03-24 14:03:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:03:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:03:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:03:23 --> Total execution time: 0.0089
DEBUG - 2022-03-24 14:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:03:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:03:28 --> Total execution time: 0.0037
DEBUG - 2022-03-24 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:05:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:05:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:05:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:05:33 --> Total execution time: 0.0047
DEBUG - 2022-03-24 14:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:09:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:09:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:09:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:09:43 --> Total execution time: 0.0061
DEBUG - 2022-03-24 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:10:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:10:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:10:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:10:57 --> Total execution time: 0.0054
DEBUG - 2022-03-24 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:12:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:12:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:12:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:12:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:12:28 --> Total execution time: 0.0049
DEBUG - 2022-03-24 14:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:14:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:14:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:14:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:14:18 --> Total execution time: 0.0053
DEBUG - 2022-03-24 14:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:16:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:16:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:16:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:16:36 --> Total execution time: 0.0051
DEBUG - 2022-03-24 14:16:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:16:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:16:40 --> Total execution time: 0.0121
DEBUG - 2022-03-24 14:16:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:16:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:16:43 --> Total execution time: 0.0101
DEBUG - 2022-03-24 14:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:16:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:16:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:16:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:16:57 --> Total execution time: 0.0083
DEBUG - 2022-03-24 14:17:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:17:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:17:00 --> Total execution time: 0.0110
DEBUG - 2022-03-24 14:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:17:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:17:03 --> Total execution time: 0.0042
DEBUG - 2022-03-24 14:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:17:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:17:15 --> Total execution time: 0.0086
DEBUG - 2022-03-24 14:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:17:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:17:16 --> Total execution time: 0.0038
DEBUG - 2022-03-24 14:17:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:17:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:17:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:17:38 --> Total execution time: 0.0079
DEBUG - 2022-03-24 14:17:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:17:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:17:40 --> Total execution time: 0.0036
DEBUG - 2022-03-24 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:19:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:19:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:19:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:19:20 --> Total execution time: 0.0048
DEBUG - 2022-03-24 14:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:22:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:22:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:22:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:22:41 --> Total execution time: 0.0045
DEBUG - 2022-03-24 14:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:24:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:24:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:24:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:24:42 --> Total execution time: 0.0052
DEBUG - 2022-03-24 14:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:28:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:28:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:28:33 --> Total execution time: 0.0051
DEBUG - 2022-03-24 14:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:31:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:31:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:31:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:31:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:31:11 --> Total execution time: 0.0052
DEBUG - 2022-03-24 14:32:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:32:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:32:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:32:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:32:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:32:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:32:40 --> Total execution time: 0.0051
DEBUG - 2022-03-24 14:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:35:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:35:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:35:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:35:35 --> Total execution time: 0.0049
DEBUG - 2022-03-24 14:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:37:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:37:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:37:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:37:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:37:38 --> Total execution time: 0.0049
DEBUG - 2022-03-24 14:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:40:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:40:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:40:05 --> Total execution time: 0.0050
DEBUG - 2022-03-24 14:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:41:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:41:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:41:16 --> Total execution time: 0.0040
DEBUG - 2022-03-24 14:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:48:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:48:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:48:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:48:58 --> Total execution time: 0.0074
DEBUG - 2022-03-24 14:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:51:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:51:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:51:12 --> Total execution time: 0.0051
DEBUG - 2022-03-24 14:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:52:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:52:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:52:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:52:41 --> Total execution time: 0.0046
DEBUG - 2022-03-24 14:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:57:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:57:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 14:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 14:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 14:57:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 14:57:05 --> Total execution time: 0.0072
DEBUG - 2022-03-24 15:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:00:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:00:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:00:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:00:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:00:15 --> Total execution time: 0.0051
DEBUG - 2022-03-24 15:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:02:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:02:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:02:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:02:34 --> Total execution time: 0.0051
DEBUG - 2022-03-24 15:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:04:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:04:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:04:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:04:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:04:19 --> Total execution time: 0.0055
DEBUG - 2022-03-24 15:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:06:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:06:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:06:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:06:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:06:37 --> Total execution time: 0.0047
DEBUG - 2022-03-24 15:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:09:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:09:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:09:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:09:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:09:31 --> Total execution time: 0.0050
DEBUG - 2022-03-24 15:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:19:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:19:12 --> Total execution time: 0.0410
DEBUG - 2022-03-24 15:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:19:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:19:15 --> Total execution time: 0.0037
DEBUG - 2022-03-24 15:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:26:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:26:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:26:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:26:15 --> Total execution time: 0.0063
DEBUG - 2022-03-24 15:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:28:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:28:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:28:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:28:21 --> Total execution time: 0.0044
DEBUG - 2022-03-24 15:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:30:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:30:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:30:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:30:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:30:12 --> Total execution time: 0.0066
DEBUG - 2022-03-24 15:32:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:32:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:32:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:32:11 --> Total execution time: 0.0035
DEBUG - 2022-03-24 15:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:35:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:35:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:35:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:35:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:35:43 --> Total execution time: 0.0059
DEBUG - 2022-03-24 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:37:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:37:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:37:08 --> Total execution time: 0.0033
DEBUG - 2022-03-24 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:38:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:38:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:38:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:38:43 --> Total execution time: 0.0054
DEBUG - 2022-03-24 15:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:40:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:40:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:40:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:40:43 --> Total execution time: 0.0038
DEBUG - 2022-03-24 15:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:42:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:42:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:42:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:42:19 --> Total execution time: 0.0041
DEBUG - 2022-03-24 15:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:45:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:45:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:45:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:45:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:45:51 --> Total execution time: 0.0056
DEBUG - 2022-03-24 15:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:47:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:47:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:47:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:47:51 --> Total execution time: 0.0053
DEBUG - 2022-03-24 15:50:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:50:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:50:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:50:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:50:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:50:04 --> Total execution time: 0.0064
DEBUG - 2022-03-24 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:54:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:54:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:54:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:54:04 --> Total execution time: 0.0063
DEBUG - 2022-03-24 15:57:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:57:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:57:35 --> Total execution time: 0.0053
DEBUG - 2022-03-24 15:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:59:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 15:59:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 15:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 15:59:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 15:59:42 --> Total execution time: 0.0052
DEBUG - 2022-03-24 16:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:01:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:01:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:01:37 --> Total execution time: 0.0047
DEBUG - 2022-03-24 16:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:05:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:05:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:05:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:05:17 --> Total execution time: 0.0050
DEBUG - 2022-03-24 16:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:07:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:07:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:07:55 --> Total execution time: 0.0048
DEBUG - 2022-03-24 16:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:10:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:10:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:10:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:10:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:10:51 --> Total execution time: 0.0048
DEBUG - 2022-03-24 16:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:14:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:14:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:14:02 --> Total execution time: 0.0049
DEBUG - 2022-03-24 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:15:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:15:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:15:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:15:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:15:28 --> Total execution time: 0.0049
DEBUG - 2022-03-24 16:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:17:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:17:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:17:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:17:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:17:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:17:22 --> Total execution time: 0.0046
DEBUG - 2022-03-24 16:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:19:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:19:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:19:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:19:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:19:21 --> Total execution time: 0.0049
DEBUG - 2022-03-24 16:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:20:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:20:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:20:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:20:28 --> Total execution time: 0.0040
DEBUG - 2022-03-24 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:22:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:22:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:22:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:22:15 --> Total execution time: 0.0048
DEBUG - 2022-03-24 16:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:24:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:24:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:24:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:24:46 --> Total execution time: 0.0053
DEBUG - 2022-03-24 16:25:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:25:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:25:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:25:15 --> Total execution time: 0.0137
DEBUG - 2022-03-24 16:25:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:25:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:25:24 --> Total execution time: 0.0046
DEBUG - 2022-03-24 16:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:27:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:27:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:27:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:27:26 --> Total execution time: 0.0051
DEBUG - 2022-03-24 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:29:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:29:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:29:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:29:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:29:05 --> Total execution time: 0.0036
DEBUG - 2022-03-24 16:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:32:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:32:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:32:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:32:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:32:00 --> Total execution time: 0.0050
DEBUG - 2022-03-24 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:33:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:33:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:33:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:33:24 --> Total execution time: 0.0035
DEBUG - 2022-03-24 16:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:35:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:35:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:35:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:35:51 --> Total execution time: 0.0048
DEBUG - 2022-03-24 16:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:37:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:37:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:37:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:37:21 --> Total execution time: 0.0039
DEBUG - 2022-03-24 16:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:39:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:39:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:39:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:39:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:39:03 --> Total execution time: 0.0053
DEBUG - 2022-03-24 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:42:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:42:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:42:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:42:02 --> Total execution time: 0.0066
DEBUG - 2022-03-24 16:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:43:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:43:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:43:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:43:42 --> Total execution time: 0.0046
DEBUG - 2022-03-24 16:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:45:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:45:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:45:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:45:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:45:23 --> Total execution time: 0.0037
DEBUG - 2022-03-24 16:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:49:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:49:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:49:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:49:02 --> Total execution time: 0.0060
DEBUG - 2022-03-24 16:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:50:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:50:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:50:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:50:54 --> Total execution time: 0.0033
DEBUG - 2022-03-24 16:51:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-24 16:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-24 16:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-24 16:51:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-24 16:51:03 --> Total execution time: 0.0136
