<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-29 21:43:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-29 21:43:45 --> No URI present. Default controller set.
DEBUG - 2022-04-29 21:43:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-29 21:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-29 21:43:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-29 21:43:45 --> Total execution time: 0.0493
