<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-01-20 00:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 00:10:25 --> No URI present. Default controller set.
DEBUG - 2022-01-20 00:10:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 00:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 00:10:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 00:10:25 --> Total execution time: 0.0304
DEBUG - 2022-01-20 00:10:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 00:10:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-20 00:10:25 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-20 09:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 09:37:10 --> No URI present. Default controller set.
DEBUG - 2022-01-20 09:37:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 09:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 09:37:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 09:37:10 --> Total execution time: 0.0315
DEBUG - 2022-01-20 09:37:10 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 09:37:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-20 09:37:10 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-20 09:37:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 09:37:20 --> No URI present. Default controller set.
DEBUG - 2022-01-20 09:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 09:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 09:37:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 09:37:20 --> Total execution time: 0.0035
DEBUG - 2022-01-20 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 09:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 09:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 09:41:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 09:41:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 09:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 09:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 09:41:05 --> Total execution time: 0.0055
DEBUG - 2022-01-20 09:41:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 09:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 09:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 09:41:06 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-20 09:41:07 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 102102816 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-20 09:41:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 09:41:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 09:41:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 09:41:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 09:41:11 --> Total execution time: 0.0043
DEBUG - 2022-01-20 10:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 10:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 10:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 10:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 10:13:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 10:13:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 10:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 10:13:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 10:13:59 --> Total execution time: 0.0072
DEBUG - 2022-01-20 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 10:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 10:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 10:31:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 10:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 10:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 10:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 10:31:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 10:31:54 --> Total execution time: 0.0068
DEBUG - 2022-01-20 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 10:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 10:44:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 10:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 10:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 10:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 10:44:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 10:44:58 --> Total execution time: 0.0057
DEBUG - 2022-01-20 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:01:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:01:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:01:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:01:11 --> Total execution time: 0.0067
DEBUG - 2022-01-20 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:07:29 --> Total execution time: 0.0062
DEBUG - 2022-01-20 11:10:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:10:46 --> Total execution time: 0.0327
DEBUG - 2022-01-20 11:12:37 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:12:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:12:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:12:37 --> Total execution time: 0.0344
DEBUG - 2022-01-20 11:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:22:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:22:59 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:22:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:22:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:22:59 --> Total execution time: 0.0061
DEBUG - 2022-01-20 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:30:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:30:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:30:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:30:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:30:25 --> Total execution time: 0.0057
DEBUG - 2022-01-20 11:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:47:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:47:26 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 11:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 11:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 11:47:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 11:47:26 --> Total execution time: 0.0060
DEBUG - 2022-01-20 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 12:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 12:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 12:06:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 12:06:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 12:06:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 12:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 12:06:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 12:06:20 --> Total execution time: 0.0065
DEBUG - 2022-01-20 12:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 12:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 12:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 12:16:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 12:16:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 12:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 12:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 12:16:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 12:16:45 --> Total execution time: 0.0068
DEBUG - 2022-01-20 12:17:05 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 12:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 12:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 12:17:05 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-20 12:17:05 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 103319904 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-20 12:20:25 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 12:20:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 12:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 12:20:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 12:20:25 --> Total execution time: 0.0332
DEBUG - 2022-01-20 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 12:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 12:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 12:26:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 12:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 12:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 12:26:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 12:26:49 --> Total execution time: 0.0061
DEBUG - 2022-01-20 14:07:29 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:07:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:07:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:07:29 --> Total execution time: 0.0356
DEBUG - 2022-01-20 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:07:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:07:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:07:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:07:31 --> Total execution time: 0.0033
DEBUG - 2022-01-20 14:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:15:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:15:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:15:50 --> Total execution time: 0.0062
DEBUG - 2022-01-20 14:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:28:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:28:41 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:28:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:28:41 --> Total execution time: 0.0064
DEBUG - 2022-01-20 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:34:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:34:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:34:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:34:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:34:43 --> Total execution time: 0.0063
DEBUG - 2022-01-20 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:40:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:40:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:40:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:40:06 --> Total execution time: 0.0059
DEBUG - 2022-01-20 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:46:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:46:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:46:45 --> Total execution time: 0.0064
DEBUG - 2022-01-20 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:49:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:49:46 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:49:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:49:46 --> Total execution time: 0.0062
DEBUG - 2022-01-20 14:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:55:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:55:06 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 14:55:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 14:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 14:55:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 14:55:06 --> Total execution time: 0.0060
DEBUG - 2022-01-20 15:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:05:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:05:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:05:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:05:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:05:57 --> Total execution time: 0.0066
DEBUG - 2022-01-20 15:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:12:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:12:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:12:53 --> Total execution time: 0.0059
DEBUG - 2022-01-20 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:25:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:25:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:25:17 --> Total execution time: 0.0060
DEBUG - 2022-01-20 15:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:35:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:35:16 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:35:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:35:16 --> Total execution time: 0.0062
DEBUG - 2022-01-20 15:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:43:57 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 15:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 15:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 15:43:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 15:43:57 --> Total execution time: 0.0059
DEBUG - 2022-01-20 16:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:31 --> No URI present. Default controller set.
DEBUG - 2022-01-20 16:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:11:31 --> Total execution time: 0.0323
DEBUG - 2022-01-20 16:11:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-20 16:11:31 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-20 16:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:34 --> No URI present. Default controller set.
DEBUG - 2022-01-20 16:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:11:34 --> Total execution time: 0.0038
DEBUG - 2022-01-20 16:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-20 16:11:34 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-20 16:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-20 16:11:34 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-01-20 16:11:34 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:34 --> No URI present. Default controller set.
DEBUG - 2022-01-20 16:11:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:11:34 --> Total execution time: 0.0032
DEBUG - 2022-01-20 16:11:35 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:11:35 --> Total execution time: 0.0073
DEBUG - 2022-01-20 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:11:43 --> Total execution time: 0.0048
DEBUG - 2022-01-20 16:11:43 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-01-20 16:11:43 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-01-20 16:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:11:54 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:54 --> Total execution time: 0.0054
DEBUG - 2022-01-20 16:11:56 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:11:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:11:56 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-01-20 16:11:57 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 105024576 bytes) /home/dunr4521/public_html/integrity/system/core/Output.php 198
DEBUG - 2022-01-20 16:12:01 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:12:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:12:01 --> Total execution time: 0.0047
DEBUG - 2022-01-20 16:12:04 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:12:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:12:04 --> Total execution time: 0.0046
DEBUG - 2022-01-20 16:13:31 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:13:31 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:13:32 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:13:32 --> Total execution time: 0.0060
DEBUG - 2022-01-20 16:13:38 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:13:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:13:38 --> Total execution time: 0.0039
DEBUG - 2022-01-20 16:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:15:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:15:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:15:11 --> Total execution time: 0.0062
DEBUG - 2022-01-20 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:27:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:27:47 --> Total execution time: 0.0060
DEBUG - 2022-01-20 16:28:02 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:28:02 --> No URI present. Default controller set.
DEBUG - 2022-01-20 16:28:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:28:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:28:02 --> Total execution time: 0.0048
DEBUG - 2022-01-20 16:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:34:30 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:34:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:34:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:34:30 --> Total execution time: 0.0063
DEBUG - 2022-01-20 16:38:12 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:38:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:38:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:38:12 --> Total execution time: 0.0334
DEBUG - 2022-01-20 16:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:45:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:45:20 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:45:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:45:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:45:20 --> Total execution time: 0.0063
DEBUG - 2022-01-20 16:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 16:56:45 --> No URI present. Default controller set.
DEBUG - 2022-01-20 16:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 16:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 16:56:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 16:56:45 --> Total execution time: 0.0305
DEBUG - 2022-01-20 17:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 17:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 17:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 17:02:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 17:02:21 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 17:02:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 17:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 17:02:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 17:02:21 --> Total execution time: 0.0067
DEBUG - 2022-01-20 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 17:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 17:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 17:04:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2022-01-20 17:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-01-20 17:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-01-20 17:04:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-01-20 17:04:49 --> Total execution time: 0.0062
