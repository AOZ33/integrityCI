<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-05-04 09:18:43 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:43 --> No URI present. Default controller set.
DEBUG - 2022-05-04 09:18:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-05-04 09:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-05-04 09:18:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-05-04 09:18:43 --> Total execution time: 0.0471
DEBUG - 2022-05-04 09:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:48 --> 404 Page Not Found: Robotstxt/index
DEBUG - 2022-05-04 09:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:49 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-05-04 09:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:49 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-04 09:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:50 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-05-04 09:18:50 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:50 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-04 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:58 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-05-04 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:58 --> 404 Page Not Found: App-adstxt/index
DEBUG - 2022-05-04 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:58 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-05-04 09:18:58 --> UTF-8 Support Enabled
DEBUG - 2022-05-04 09:18:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-05-04 09:18:58 --> 404 Page Not Found: Adstxt/index
