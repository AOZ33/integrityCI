<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-12-30 10:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:27:14 --> No URI present. Default controller set.
DEBUG - 2021-12-30 10:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 10:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 10:27:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 10:27:14 --> Total execution time: 0.0306
DEBUG - 2021-12-30 10:27:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 10:27:17 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-30 10:27:17 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:27:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 10:27:17 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-12-30 10:39:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:39:00 --> No URI present. Default controller set.
DEBUG - 2021-12-30 10:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 10:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 10:39:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 10:39:00 --> Total execution time: 0.0312
DEBUG - 2021-12-30 10:39:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:39:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 10:39:02 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-30 10:47:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 10:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 10:47:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 10:47:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 10:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 10:47:24 --> Total execution time: 0.0073
DEBUG - 2021-12-30 10:50:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:50:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 10:50:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 10:50:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 10:50:02 --> Total execution time: 0.0566
DEBUG - 2021-12-30 10:50:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 10:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 10:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 10:50:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 10:50:06 --> Total execution time: 0.0057
DEBUG - 2021-12-30 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:17:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:17:44 --> Total execution time: 0.0349
DEBUG - 2021-12-30 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:19:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:19:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:19:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:19:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:19:26 --> Total execution time: 0.0069
DEBUG - 2021-12-30 11:19:29 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:19:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:19:30 --> Total execution time: 0.0287
DEBUG - 2021-12-30 11:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:19:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:19:42 --> Total execution time: 0.0055
DEBUG - 2021-12-30 11:25:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:25:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:25:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:25:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:25:41 --> Total execution time: 0.0071
DEBUG - 2021-12-30 11:36:49 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:36:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:36:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:36:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:36:51 --> Total execution time: 0.0078
DEBUG - 2021-12-30 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:42:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:42:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 11:42:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 11:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 11:42:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 11:42:13 --> Total execution time: 0.0074
DEBUG - 2021-12-30 12:07:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 12:07:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 12:07:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 12:07:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 12:07:51 --> Total execution time: 0.0082
DEBUG - 2021-12-30 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 12:59:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 12:59:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 12:59:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 12:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 12:59:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 12:59:19 --> Total execution time: 0.0074
DEBUG - 2021-12-30 13:03:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:03:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:03:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:03:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:03:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:03:41 --> Total execution time: 0.0075
DEBUG - 2021-12-30 13:08:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:08:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:08:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:08:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:08:12 --> Total execution time: 0.0074
DEBUG - 2021-12-30 13:19:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:19:00 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2021-12-30 13:19:00 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2021-12-30 13:19:00 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Yunita & Rido', 'Yunita & Rido', '13 jt + Tanpa Pengsir 1jt ', NULL, '4R(10)', 'Leather 2 in 1 akrilik atas', '20RP(2)', '16RP(1)', '', 'Acara & Grup', '', '', '10-20m', '', '', 'Paraae regency blok C42 Antapani Parakansaat', '0821190011937', 'ridoutama91@gmail.com', '@ridoutama & @yunitalstri', 'Rp. 12.000.000', 'Rp. 2.400.000', 'Rp. 4.800.000', 'Rp. 4.800.000', '', '', '', '', '', '2021-08-28', '15:00', '20:00', '', '', '', '', '', '', '', '', '', '', 'Maximo Hotel Puri Setiabudi', '', '2021-05-27', '2021-07-25', '2021-08-27', '', '', '', 'Tanpa', '', '')
DEBUG - 2021-12-30 13:19:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:19:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:19:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:19:00 --> Total execution time: 0.0079
DEBUG - 2021-12-30 13:21:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:21:00 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:21:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:21:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:21:00 --> Total execution time: 0.0073
DEBUG - 2021-12-30 13:22:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:22:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:22:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:22:04 --> Total execution time: 0.0568
DEBUG - 2021-12-30 13:25:18 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:25:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:25:18 --> Total execution time: 0.0354
DEBUG - 2021-12-30 13:31:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:31:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:31:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:31:05 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:31:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:31:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:31:05 --> Total execution time: 0.0071
DEBUG - 2021-12-30 13:44:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:44:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:44:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:44:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:44:13 --> Total execution time: 0.0073
DEBUG - 2021-12-30 13:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:50:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 13:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 13:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 13:50:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 13:50:36 --> Total execution time: 0.0074
DEBUG - 2021-12-30 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:02:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:02:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:02:55 --> Total execution time: 0.0073
DEBUG - 2021-12-30 14:11:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:11:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:11:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:11:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:11:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:11:47 --> Total execution time: 0.0075
DEBUG - 2021-12-30 14:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:19:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:19:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:19:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:19:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:19:42 --> Total execution time: 0.0073
DEBUG - 2021-12-30 14:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:19:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:19:52 --> Total execution time: 0.0323
DEBUG - 2021-12-30 14:26:43 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:26:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:26:43 --> Total execution time: 0.0350
DEBUG - 2021-12-30 14:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:38:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:38:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:38:08 --> Total execution time: 0.0075
DEBUG - 2021-12-30 14:38:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:38:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:38:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:38:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:38:20 --> Total execution time: 0.0350
DEBUG - 2021-12-30 14:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:38:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:38:41 --> Total execution time: 0.0050
DEBUG - 2021-12-30 14:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:44:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:44:40 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:44:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:44:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:44:40 --> Total execution time: 0.0071
DEBUG - 2021-12-30 14:51:16 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 14:51:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 14:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 14:51:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 14:51:16 --> Total execution time: 0.0663
DEBUG - 2021-12-30 15:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:00:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:00:42 --> Total execution time: 0.0351
DEBUG - 2021-12-30 15:04:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:04:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:04:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:04:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:04:12 --> Total execution time: 0.0075
DEBUG - 2021-12-30 15:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:07:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:07:50 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:07:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:07:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:07:50 --> Total execution time: 0.0072
DEBUG - 2021-12-30 15:09:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:09:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:09:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:09:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:09:21 --> Total execution time: 0.0065
DEBUG - 2021-12-30 15:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:09:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:09:23 --> Total execution time: 0.0350
DEBUG - 2021-12-30 15:09:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:09:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:09:32 --> Total execution time: 0.0054
DEBUG - 2021-12-30 15:21:39 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:21:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:21:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:21:39 --> Total execution time: 0.0659
DEBUG - 2021-12-30 15:23:15 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:23:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:23:15 --> Total execution time: 0.0324
DEBUG - 2021-12-30 15:29:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:29:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:29:03 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:29:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:29:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:29:03 --> Total execution time: 0.0069
DEBUG - 2021-12-30 15:36:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:36:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:36:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:36:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:36:21 --> Total execution time: 0.0077
DEBUG - 2021-12-30 15:41:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:41:13 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:41:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:41:13 --> Total execution time: 0.0066
DEBUG - 2021-12-30 15:45:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:45:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:45:06 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:45:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:45:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:45:06 --> Total execution time: 0.0076
DEBUG - 2021-12-30 15:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:47:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:47:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:47:22 --> Total execution time: 0.0072
DEBUG - 2021-12-30 15:47:24 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:47:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:47:24 --> Total execution time: 0.0370
DEBUG - 2021-12-30 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:52:02 --> No URI present. Default controller set.
DEBUG - 2021-12-30 15:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:52:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:52:02 --> Total execution time: 0.0309
DEBUG - 2021-12-30 15:52:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:52:04 --> No URI present. Default controller set.
DEBUG - 2021-12-30 15:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:52:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:52:04 --> Total execution time: 0.0044
DEBUG - 2021-12-30 15:52:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:52:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 15:52:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-30 15:59:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:59:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 15:59:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 15:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 15:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 15:59:08 --> Total execution time: 0.0070
DEBUG - 2021-12-30 16:02:26 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:02:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:02:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:02:27 --> Total execution time: 0.0659
DEBUG - 2021-12-30 16:05:04 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:05:05 --> Total execution time: 0.0658
DEBUG - 2021-12-30 16:05:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:05:08 --> Total execution time: 0.0059
DEBUG - 2021-12-30 16:05:08 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:05:09 --> Total execution time: 0.0052
DEBUG - 2021-12-30 16:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:12 --> No URI present. Default controller set.
DEBUG - 2021-12-30 16:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:05:12 --> Total execution time: 0.0049
DEBUG - 2021-12-30 16:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:12 --> No URI present. Default controller set.
DEBUG - 2021-12-30 16:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:05:12 --> Total execution time: 0.0045
DEBUG - 2021-12-30 16:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-12-30 16:05:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2021-12-30 16:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:19 --> Total execution time: 0.0053
DEBUG - 2021-12-30 16:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:05:21 --> Total execution time: 0.0354
DEBUG - 2021-12-30 16:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:05:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:05:28 --> Total execution time: 0.0053
DEBUG - 2021-12-30 16:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:12:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:12:21 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:12:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:12:21 --> Total execution time: 0.0072
DEBUG - 2021-12-30 16:17:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:17:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:17:11 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:17:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:17:11 --> Total execution time: 0.0075
DEBUG - 2021-12-30 16:17:23 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:17:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:17:23 --> Total execution time: 0.0358
DEBUG - 2021-12-30 16:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:17:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:17:32 --> Total execution time: 0.0049
DEBUG - 2021-12-30 16:18:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:18:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:18:47 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:18:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:18:47 --> Total execution time: 0.0057
DEBUG - 2021-12-30 16:20:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:20:10 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:20:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:20:10 --> Total execution time: 0.0062
DEBUG - 2021-12-30 16:21:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:21:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:21:30 --> UTF-8 Support Enabled
DEBUG - 2021-12-30 16:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-12-30 16:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-12-30 16:21:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2021-12-30 16:21:30 --> Total execution time: 0.0070
