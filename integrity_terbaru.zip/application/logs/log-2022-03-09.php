<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-03-09 07:26:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 07:26:46 --> No URI present. Default controller set.
DEBUG - 2022-03-09 07:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 07:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 07:26:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 07:26:46 --> Total execution time: 0.0305
DEBUG - 2022-03-09 09:34:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 09:34:02 --> No URI present. Default controller set.
DEBUG - 2022-03-09 09:34:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 09:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 09:34:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 09:34:02 --> Total execution time: 0.0299
DEBUG - 2022-03-09 09:34:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 09:34:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 09:34:03 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-09 09:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 09:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 09:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 09:34:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 09:34:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 09:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 09:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 09:34:07 --> Total execution time: 0.0072
DEBUG - 2022-03-09 09:34:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 09:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 09:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 09:34:18 --> Total execution time: 0.0046
DEBUG - 2022-03-09 09:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 09:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 09:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 09:34:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 09:34:21 --> Total execution time: 0.0132
DEBUG - 2022-03-09 09:34:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 09:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 09:34:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 09:34:27 --> Total execution time: 0.0036
DEBUG - 2022-03-09 10:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:07:32 --> Total execution time: 0.0337
DEBUG - 2022-03-09 10:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:08:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:08:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:08:08 --> Total execution time: 0.0049
DEBUG - 2022-03-09 10:24:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:24:22 --> Total execution time: 0.0348
DEBUG - 2022-03-09 10:26:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:26:08 --> Total execution time: 0.0328
DEBUG - 2022-03-09 10:33:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:33:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:33:51 --> Total execution time: 0.0422
DEBUG - 2022-03-09 10:33:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:33:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:33:53 --> Total execution time: 0.0061
DEBUG - 2022-03-09 10:33:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:33:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:33:57 --> Total execution time: 0.0044
DEBUG - 2022-03-09 10:35:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:35:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:35:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:35:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:35:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:35:20 --> Total execution time: 0.0052
DEBUG - 2022-03-09 10:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:35:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:35:22 --> Total execution time: 0.0114
DEBUG - 2022-03-09 10:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:35:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:35:27 --> Total execution time: 0.0089
DEBUG - 2022-03-09 10:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:36:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:36:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:36:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:36:17 --> Total execution time: 0.0098
DEBUG - 2022-03-09 10:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:36:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:36:30 --> Total execution time: 0.0049
DEBUG - 2022-03-09 10:42:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:42:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:42:46 --> Total execution time: 0.0357
DEBUG - 2022-03-09 10:53:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:53:16 --> Total execution time: 0.0341
DEBUG - 2022-03-09 10:53:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:53:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 10:53:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dunr4521/public_html/integrity/application/views/lamaran/index.php 72
ERROR - 2022-03-09 10:53:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dunr4521/public_html/integrity/application/views/lamaran/index.php 111
ERROR - 2022-03-09 10:53:57 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dunr4521/public_html/integrity/application/views/lamaran/index.php 259
DEBUG - 2022-03-09 10:53:57 --> Total execution time: 0.0091
DEBUG - 2022-03-09 10:54:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:54:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:54:44 --> Total execution time: 0.0058
DEBUG - 2022-03-09 10:56:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:07 --> Total execution time: 0.0345
DEBUG - 2022-03-09 10:56:09 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:09 --> Total execution time: 0.0044
DEBUG - 2022-03-09 10:56:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:56:16 --> Total execution time: 0.0115
DEBUG - 2022-03-09 10:56:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:56:22 --> Total execution time: 0.0063
DEBUG - 2022-03-09 10:56:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 10:56:45 --> Total execution time: 0.0081
DEBUG - 2022-03-09 10:56:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:48 --> Total execution time: 0.0047
DEBUG - 2022-03-09 10:56:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:53 --> Total execution time: 0.0042
DEBUG - 2022-03-09 10:56:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:56:56 --> Total execution time: 0.0042
DEBUG - 2022-03-09 10:57:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:57:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:57:01 --> Total execution time: 0.0049
DEBUG - 2022-03-09 10:57:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:57:02 --> Total execution time: 0.0039
DEBUG - 2022-03-09 10:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:57:07 --> Total execution time: 0.0041
DEBUG - 2022-03-09 10:57:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:57:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:57:14 --> Total execution time: 0.0046
DEBUG - 2022-03-09 10:57:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 10:57:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 10:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 10:57:21 --> Total execution time: 0.0041
DEBUG - 2022-03-09 11:01:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:01:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:01:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:01:15 --> Total execution time: 0.0447
DEBUG - 2022-03-09 11:01:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:01:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:01:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:01:20 --> Total execution time: 0.0047
DEBUG - 2022-03-09 11:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:01:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:01:35 --> Total execution time: 0.0057
DEBUG - 2022-03-09 11:03:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:03:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:03:05 --> Total execution time: 0.0351
DEBUG - 2022-03-09 11:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:03:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dunr4521/public_html/integrity/application/views/lamaran/index.php 72
ERROR - 2022-03-09 11:03:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dunr4521/public_html/integrity/application/views/lamaran/index.php 111
ERROR - 2022-03-09 11:03:10 --> Severity: Warning --> Invalid argument supplied for foreach() /home/dunr4521/public_html/integrity/application/views/lamaran/index.php 259
DEBUG - 2022-03-09 11:03:10 --> Total execution time: 0.0061
DEBUG - 2022-03-09 11:04:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:04:41 --> Severity: error --> Exception: Call to a member function create_links() on null /home/dunr4521/public_html/integrity/application/views/lamaran/index.php 103
DEBUG - 2022-03-09 11:05:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:05:07 --> Total execution time: 0.0050
DEBUG - 2022-03-09 11:05:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:05:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:05:10 --> Total execution time: 0.0078
DEBUG - 2022-03-09 11:05:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:05:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:05:54 --> Total execution time: 0.0056
DEBUG - 2022-03-09 11:06:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:06:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:06:54 --> Total execution time: 0.0052
DEBUG - 2022-03-09 11:06:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:06:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:06:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:06:56 --> Total execution time: 0.0045
DEBUG - 2022-03-09 11:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:23 --> No URI present. Default controller set.
DEBUG - 2022-03-09 11:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:23 --> Total execution time: 0.0045
DEBUG - 2022-03-09 11:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 11:07:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-09 11:07:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:24 --> No URI present. Default controller set.
DEBUG - 2022-03-09 11:07:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:24 --> Total execution time: 0.0039
DEBUG - 2022-03-09 11:07:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:27 --> Total execution time: 0.0051
DEBUG - 2022-03-09 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:28 --> Total execution time: 0.0049
DEBUG - 2022-03-09 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:32 --> Total execution time: 0.0123
DEBUG - 2022-03-09 11:07:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:32 --> Total execution time: 0.0062
DEBUG - 2022-03-09 11:07:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:37 --> Total execution time: 0.0060
DEBUG - 2022-03-09 11:07:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:40 --> Total execution time: 0.0121
DEBUG - 2022-03-09 11:07:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:41 --> Total execution time: 0.0066
DEBUG - 2022-03-09 11:07:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:44 --> Total execution time: 0.0056
DEBUG - 2022-03-09 11:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:46 --> Total execution time: 0.0086
DEBUG - 2022-03-09 11:07:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:07:55 --> Total execution time: 0.0032
DEBUG - 2022-03-09 11:07:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:07:56 --> Total execution time: 0.0041
DEBUG - 2022-03-09 11:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:11:11 --> No URI present. Default controller set.
DEBUG - 2022-03-09 11:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:11:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:11:11 --> Total execution time: 0.0305
DEBUG - 2022-03-09 11:11:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:11:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 11:11:12 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-09 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:11:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:11:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:11:13 --> Total execution time: 0.0043
DEBUG - 2022-03-09 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:11:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:11:16 --> Total execution time: 0.0092
DEBUG - 2022-03-09 11:12:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:12:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:12:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:12:29 --> Total execution time: 0.0374
DEBUG - 2022-03-09 11:12:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:12:36 --> Total execution time: 0.0055
DEBUG - 2022-03-09 11:12:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:12:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:12:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:12:41 --> Total execution time: 0.0043
DEBUG - 2022-03-09 11:12:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:12:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:12:46 --> Total execution time: 0.0049
DEBUG - 2022-03-09 11:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:12:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 11:12:53 --> Total execution time: 0.0124
DEBUG - 2022-03-09 11:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:13:48 --> Total execution time: 0.0058
DEBUG - 2022-03-09 11:14:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:14:02 --> Total execution time: 0.0060
DEBUG - 2022-03-09 11:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:14:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:14:08 --> Total execution time: 0.0041
DEBUG - 2022-03-09 11:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:14:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:14:17 --> Total execution time: 0.0038
DEBUG - 2022-03-09 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:14:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:14:29 --> Total execution time: 0.0047
DEBUG - 2022-03-09 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:17:43 --> Total execution time: 0.0065
DEBUG - 2022-03-09 11:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:17:53 --> Total execution time: 0.0051
DEBUG - 2022-03-09 11:18:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:18:06 --> Total execution time: 0.0065
DEBUG - 2022-03-09 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:18:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:18:16 --> Total execution time: 0.0039
DEBUG - 2022-03-09 11:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:18:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:18:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:18:19 --> Total execution time: 0.0037
DEBUG - 2022-03-09 11:18:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:18:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:18:23 --> Total execution time: 0.0052
DEBUG - 2022-03-09 11:18:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:18:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:18:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:18:24 --> Total execution time: 0.0041
DEBUG - 2022-03-09 11:18:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:18:57 --> Total execution time: 0.0056
DEBUG - 2022-03-09 11:30:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:30:21 --> Query error: Unknown column 'date_p' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
ERROR - 2022-03-09 11:30:21 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/dunr4521/public_html/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-03-09 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:31:54 --> Total execution time: 0.0363
DEBUG - 2022-03-09 11:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:31:54 --> Total execution time: 0.0036
DEBUG - 2022-03-09 11:32:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:32:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:32:02 --> Query error: Unknown column 'date_p' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
ERROR - 2022-03-09 11:32:02 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/dunr4521/public_html/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-03-09 11:33:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:33:30 --> Query error: Unknown column 'date_p' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
ERROR - 2022-03-09 11:33:30 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/dunr4521/public_html/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-03-09 11:33:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:33:31 --> Query error: Unknown column 'date_p' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
ERROR - 2022-03-09 11:33:31 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/dunr4521/public_html/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-03-09 11:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:35:21 --> Query error: Unknown column 'date_p' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
ERROR - 2022-03-09 11:35:21 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/dunr4521/public_html/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-03-09 11:35:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:35:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:35:22 --> Total execution time: 0.0053
DEBUG - 2022-03-09 11:35:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:35:27 --> Total execution time: 0.0044
DEBUG - 2022-03-09 11:35:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:35:36 --> Query error: Unknown column 'date_p' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
ERROR - 2022-03-09 11:35:36 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/dunr4521/public_html/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-03-09 11:37:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:37:01 --> Query error: Not unique table/alias: 'prewedding' - Invalid query: SELECT *
FROM `prewedding`, `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
 LIMIT 12
ERROR - 2022-03-09 11:37:01 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/models/Prewedding_model.php 27
DEBUG - 2022-03-09 11:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:37:02 --> Query error: Not unique table/alias: 'prewedding' - Invalid query: SELECT *
FROM `prewedding`, `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
 LIMIT 12
ERROR - 2022-03-09 11:37:02 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/models/Prewedding_model.php 27
DEBUG - 2022-03-09 11:39:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:39:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 11:39:08 --> Query error: Unknown column 'date_p' in 'where clause' - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `prewedding`
WHERE `name` LIKE '%%' ESCAPE '!'
OR  `phone` LIKE '%%' ESCAPE '!'
OR  `date_p` LIKE '%%' ESCAPE '!'
OR  `place_p` LIKE '%%' ESCAPE '!'
OR  `w_prewed` LIKE '%%' ESCAPE '!'
OR  `photograper` LIKE '%%' ESCAPE '!'
OR  `videograper` LIKE '%%' ESCAPE '!'
OR  `crew` LIKE '%%' ESCAPE '!'
ERROR - 2022-03-09 11:39:08 --> Severity: error --> Exception: Call to a member function num_rows() on bool /home/dunr4521/public_html/integrity/system/database/DB_query_builder.php 1429
DEBUG - 2022-03-09 11:41:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:41:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:41:24 --> Total execution time: 0.0348
DEBUG - 2022-03-09 11:42:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:42:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:42:07 --> Total execution time: 0.0051
DEBUG - 2022-03-09 11:42:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:42:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:42:17 --> Total execution time: 0.0063
DEBUG - 2022-03-09 11:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:43:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:43:59 --> Total execution time: 0.0065
DEBUG - 2022-03-09 11:44:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:44:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:44:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:44:28 --> Total execution time: 0.0081
DEBUG - 2022-03-09 11:44:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:44:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:44:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:44:30 --> Total execution time: 0.0041
DEBUG - 2022-03-09 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:44:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:44:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:44:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:44:58 --> Total execution time: 0.0044
DEBUG - 2022-03-09 11:45:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:45:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:45:04 --> Total execution time: 0.0057
DEBUG - 2022-03-09 11:45:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:45:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:45:07 --> Total execution time: 0.0043
DEBUG - 2022-03-09 11:55:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:55:47 --> Total execution time: 0.0363
DEBUG - 2022-03-09 11:55:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 11:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 11:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 11:55:49 --> Total execution time: 0.0052
DEBUG - 2022-03-09 12:03:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:03:10 --> Total execution time: 0.0380
DEBUG - 2022-03-09 12:03:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:03:11 --> Total execution time: 0.0045
DEBUG - 2022-03-09 12:03:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:03:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 282
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 294
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 304
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 314
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 315
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 316
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 317
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 375
DEBUG - 2022-03-09 12:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 110
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> session_start(): Cannot start session when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 143
ERROR - 2022-03-09 12:03:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-09 12:03:14 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
ERROR - 2022-03-09 12:03:14 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/application/controllers/Pengajian.php:1) /home/dunr4521/public_html/integrity/system/core/Common.php 570
DEBUG - 2022-03-09 12:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:04:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 282
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 294
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 304
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 314
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 315
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 316
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 317
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 375
DEBUG - 2022-03-09 12:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 110
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> session_start(): Cannot start session when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 143
ERROR - 2022-03-09 12:04:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-09 12:04:23 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
ERROR - 2022-03-09 12:04:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/application/controllers/Pengajian.php:1) /home/dunr4521/public_html/integrity/system/core/Common.php 570
DEBUG - 2022-03-09 12:04:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:04:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:04:24 --> Total execution time: 0.0040
DEBUG - 2022-03-09 12:04:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:04:27 --> Total execution time: 0.0062
DEBUG - 2022-03-09 12:04:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:04:29 --> Total execution time: 0.0039
DEBUG - 2022-03-09 12:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 282
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 294
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 304
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 314
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 315
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 316
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 317
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 375
DEBUG - 2022-03-09 12:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 110
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> session_start(): Cannot start session when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 143
ERROR - 2022-03-09 12:04:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-09 12:04:31 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
ERROR - 2022-03-09 12:04:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/application/controllers/Pengajian.php:1) /home/dunr4521/public_html/integrity/system/core/Common.php 570
DEBUG - 2022-03-09 12:06:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:06:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 282
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 294
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 304
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 314
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 315
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 316
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 317
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 375
DEBUG - 2022-03-09 12:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 110
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> session_start(): Cannot start session when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 143
ERROR - 2022-03-09 12:06:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-09 12:06:50 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
ERROR - 2022-03-09 12:06:50 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/application/controllers/Pengajian.php:1) /home/dunr4521/public_html/integrity/system/core/Common.php 570
DEBUG - 2022-03-09 12:08:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:08:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 282
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 294
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 304
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 314
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 315
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 316
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 317
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 375
DEBUG - 2022-03-09 12:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 110
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> session_start(): Cannot start session when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 143
ERROR - 2022-03-09 12:08:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-09 12:08:45 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
ERROR - 2022-03-09 12:08:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/application/controllers/Pengajian.php:1) /home/dunr4521/public_html/integrity/system/core/Common.php 570
DEBUG - 2022-03-09 12:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:09:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 282
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 294
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 304
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 314
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 315
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 316
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 317
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 375
DEBUG - 2022-03-09 12:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 110
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> session_start(): Cannot start session when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 143
ERROR - 2022-03-09 12:09:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-09 12:09:26 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
ERROR - 2022-03-09 12:09:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/application/controllers/Pengajian.php:1) /home/dunr4521/public_html/integrity/system/core/Common.php 570
DEBUG - 2022-03-09 12:09:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:09:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:09:28 --> Total execution time: 0.0058
DEBUG - 2022-03-09 12:09:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:09:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 282
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> session_set_cookie_params(): Cannot change session cookie parameters when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 294
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 304
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 314
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 315
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 316
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 317
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> ini_set(): Headers already sent. You cannot change the session module's ini settings at this time /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 375
DEBUG - 2022-03-09 12:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> session_set_save_handler(): Cannot change save handler when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 110
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> session_start(): Cannot start session when headers already sent /home/dunr4521/public_html/integrity/system/libraries/Session/Session.php 143
ERROR - 2022-03-09 12:09:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-03-09 12:09:30 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/dunr4521/public_html/integrity/application/views/templates/sidebar.php 23
ERROR - 2022-03-09 12:09:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/application/controllers/Pengajian.php:1) /home/dunr4521/public_html/integrity/system/core/Common.php 570
DEBUG - 2022-03-09 12:12:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:12:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 12:12:00 --> Severity: error --> Exception: Call to a member function create_links() on null /home/dunr4521/public_html/integrity/application/views/pengajian/index.php 103
DEBUG - 2022-03-09 12:12:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:12:34 --> Total execution time: 0.0052
DEBUG - 2022-03-09 12:12:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:12:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:12:53 --> Total execution time: 0.0049
DEBUG - 2022-03-09 12:13:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:13:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:13:48 --> Total execution time: 0.0072
DEBUG - 2022-03-09 12:14:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:14:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:14:22 --> Total execution time: 0.0067
DEBUG - 2022-03-09 12:14:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:14:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:14:43 --> Total execution time: 0.0059
DEBUG - 2022-03-09 12:14:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:14:45 --> Total execution time: 0.0054
DEBUG - 2022-03-09 12:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:14:47 --> Total execution time: 0.0052
DEBUG - 2022-03-09 12:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:14:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:14:58 --> Total execution time: 0.0114
DEBUG - 2022-03-09 12:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:15:13 --> Total execution time: 0.0079
DEBUG - 2022-03-09 12:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:18 --> Total execution time: 0.0046
DEBUG - 2022-03-09 12:15:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:22 --> Total execution time: 0.0062
DEBUG - 2022-03-09 12:15:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:27 --> Total execution time: 0.0050
DEBUG - 2022-03-09 12:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:34 --> Total execution time: 0.0059
DEBUG - 2022-03-09 12:15:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:38 --> Total execution time: 0.0053
DEBUG - 2022-03-09 12:15:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:41 --> Total execution time: 0.0054
DEBUG - 2022-03-09 12:15:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:15:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:15:45 --> Total execution time: 0.0043
DEBUG - 2022-03-09 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:16:00 --> Total execution time: 0.0050
DEBUG - 2022-03-09 12:17:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:17:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:17:11 --> Total execution time: 0.0059
DEBUG - 2022-03-09 12:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:17:21 --> Total execution time: 0.0043
DEBUG - 2022-03-09 12:17:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:17:53 --> Total execution time: 0.0054
DEBUG - 2022-03-09 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:17:59 --> Total execution time: 0.0043
DEBUG - 2022-03-09 12:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:17:59 --> Total execution time: 0.0039
DEBUG - 2022-03-09 12:18:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:02 --> Total execution time: 0.0047
DEBUG - 2022-03-09 12:18:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:18:05 --> Total execution time: 0.0073
DEBUG - 2022-03-09 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:18:13 --> Total execution time: 0.0071
DEBUG - 2022-03-09 12:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:18:17 --> Total execution time: 0.0067
DEBUG - 2022-03-09 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:18:20 --> Total execution time: 0.0065
DEBUG - 2022-03-09 12:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:22 --> Total execution time: 0.0047
DEBUG - 2022-03-09 12:18:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:25 --> Total execution time: 0.0043
DEBUG - 2022-03-09 12:18:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:28 --> Total execution time: 0.0056
DEBUG - 2022-03-09 12:18:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:18:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:18:30 --> Total execution time: 0.0043
DEBUG - 2022-03-09 12:19:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:19:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:19:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:19:04 --> Total execution time: 0.0052
DEBUG - 2022-03-09 12:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:19:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:19:08 --> Total execution time: 0.0037
DEBUG - 2022-03-09 12:19:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:19:10 --> Total execution time: 0.0044
DEBUG - 2022-03-09 12:19:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:19:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:19:13 --> Total execution time: 0.0040
DEBUG - 2022-03-09 12:21:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:10 --> Total execution time: 0.0057
DEBUG - 2022-03-09 12:21:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:13 --> Total execution time: 0.0047
DEBUG - 2022-03-09 12:21:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:20 --> Total execution time: 0.0039
DEBUG - 2022-03-09 12:21:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:24 --> Total execution time: 0.0059
DEBUG - 2022-03-09 12:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:49 --> Total execution time: 0.0053
DEBUG - 2022-03-09 12:21:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:53 --> Total execution time: 0.0041
DEBUG - 2022-03-09 12:21:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:55 --> Total execution time: 0.0050
DEBUG - 2022-03-09 12:21:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:21:58 --> Total execution time: 0.0043
DEBUG - 2022-03-09 12:22:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:22:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:22:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:22:02 --> Total execution time: 0.0041
DEBUG - 2022-03-09 12:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:22:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:22:05 --> Total execution time: 0.0045
DEBUG - 2022-03-09 12:22:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:22:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:22:34 --> Total execution time: 0.0057
DEBUG - 2022-03-09 12:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:22:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:22:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:22:37 --> Total execution time: 0.0040
DEBUG - 2022-03-09 12:23:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:23:32 --> Total execution time: 0.0058
DEBUG - 2022-03-09 12:23:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:23:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:23:34 --> Total execution time: 0.0112
DEBUG - 2022-03-09 12:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:23:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:23:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:23:51 --> Total execution time: 0.0085
DEBUG - 2022-03-09 12:23:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:23:55 --> Total execution time: 0.0062
DEBUG - 2022-03-09 12:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:24:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:24:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:24:07 --> Total execution time: 0.0043
DEBUG - 2022-03-09 12:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:24:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:24:15 --> Total execution time: 0.0048
DEBUG - 2022-03-09 12:24:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:24:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:24:38 --> Total execution time: 0.0056
DEBUG - 2022-03-09 12:24:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:24:39 --> Total execution time: 0.0040
DEBUG - 2022-03-09 12:26:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:26:12 --> Total execution time: 0.0102
DEBUG - 2022-03-09 12:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:26:18 --> Total execution time: 0.0070
DEBUG - 2022-03-09 12:26:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:20 --> Total execution time: 0.0060
DEBUG - 2022-03-09 12:26:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:22 --> Total execution time: 0.0040
DEBUG - 2022-03-09 12:26:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:26:33 --> Total execution time: 0.0095
DEBUG - 2022-03-09 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:26:42 --> Total execution time: 0.0093
DEBUG - 2022-03-09 12:26:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:45 --> Total execution time: 0.0040
DEBUG - 2022-03-09 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:26:49 --> Total execution time: 0.0044
DEBUG - 2022-03-09 12:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:27:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:27:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:27:00 --> Total execution time: 0.0048
DEBUG - 2022-03-09 12:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:27:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:27:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:27:12 --> Total execution time: 0.0042
DEBUG - 2022-03-09 12:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:28:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:28:37 --> Total execution time: 0.0368
DEBUG - 2022-03-09 12:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:28:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:28:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:28:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:28:54 --> Total execution time: 0.0059
DEBUG - 2022-03-09 12:28:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:28:58 --> Total execution time: 0.0059
DEBUG - 2022-03-09 12:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:29:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:29:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:29:06 --> Total execution time: 0.0044
DEBUG - 2022-03-09 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:29:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:29:15 --> Total execution time: 0.0046
DEBUG - 2022-03-09 12:30:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:30:55 --> Total execution time: 0.0346
DEBUG - 2022-03-09 12:31:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:31:01 --> Total execution time: 0.0078
DEBUG - 2022-03-09 12:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 12:31:18 --> Total execution time: 0.0076
DEBUG - 2022-03-09 12:31:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:25 --> Total execution time: 0.0052
DEBUG - 2022-03-09 12:31:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:30 --> Total execution time: 0.0047
DEBUG - 2022-03-09 12:31:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:34 --> Total execution time: 0.0047
DEBUG - 2022-03-09 12:31:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:37 --> Total execution time: 0.0045
DEBUG - 2022-03-09 12:31:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:41 --> Total execution time: 0.0041
DEBUG - 2022-03-09 12:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:45 --> Total execution time: 0.0046
DEBUG - 2022-03-09 12:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:31:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:31:54 --> Total execution time: 0.0037
DEBUG - 2022-03-09 12:39:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:39:24 --> Total execution time: 0.0371
DEBUG - 2022-03-09 12:39:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:39:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:39:26 --> Total execution time: 0.0056
DEBUG - 2022-03-09 12:39:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:39:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:39:51 --> Total execution time: 0.0058
DEBUG - 2022-03-09 12:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:39:52 --> Total execution time: 0.0040
DEBUG - 2022-03-09 12:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:39:52 --> Total execution time: 0.0051
DEBUG - 2022-03-09 12:39:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:39:53 --> Total execution time: 0.0038
DEBUG - 2022-03-09 12:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:40:21 --> Total execution time: 0.0060
DEBUG - 2022-03-09 12:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:42:16 --> Total execution time: 0.0335
DEBUG - 2022-03-09 12:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:42:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:42:29 --> Total execution time: 0.0044
DEBUG - 2022-03-09 12:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:42:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:42:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:42:37 --> Total execution time: 0.0040
DEBUG - 2022-03-09 12:42:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:42:43 --> Total execution time: 0.0065
DEBUG - 2022-03-09 12:49:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:49:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:49:43 --> Total execution time: 0.0074
DEBUG - 2022-03-09 12:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:49:45 --> Total execution time: 0.0052
DEBUG - 2022-03-09 12:57:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:57:35 --> Total execution time: 0.0371
DEBUG - 2022-03-09 12:58:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:58:00 --> Total execution time: 0.0063
DEBUG - 2022-03-09 12:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:58:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:58:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:58:08 --> Total execution time: 0.0036
DEBUG - 2022-03-09 12:58:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:58:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:58:23 --> Total execution time: 0.0057
DEBUG - 2022-03-09 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:58:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:58:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:58:33 --> Total execution time: 0.0049
DEBUG - 2022-03-09 12:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:58:47 --> Total execution time: 0.0051
DEBUG - 2022-03-09 12:59:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:59:22 --> Total execution time: 0.0062
DEBUG - 2022-03-09 12:59:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 12:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 12:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 12:59:24 --> Total execution time: 0.0051
DEBUG - 2022-03-09 13:00:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:00:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:00:16 --> Total execution time: 0.0052
DEBUG - 2022-03-09 13:01:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:01:56 --> Total execution time: 0.0329
DEBUG - 2022-03-09 13:05:53 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:05:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:05:53 --> Total execution time: 0.0362
DEBUG - 2022-03-09 13:06:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:06:15 --> Total execution time: 0.0061
DEBUG - 2022-03-09 13:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:06:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:06:31 --> Total execution time: 0.0042
DEBUG - 2022-03-09 13:07:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:07:13 --> Total execution time: 0.0063
DEBUG - 2022-03-09 13:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:07:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:07:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:07:23 --> Total execution time: 0.0043
DEBUG - 2022-03-09 13:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:07:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:07:27 --> Total execution time: 0.0041
DEBUG - 2022-03-09 13:08:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:08:04 --> Total execution time: 0.0056
DEBUG - 2022-03-09 13:08:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:08:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:08:29 --> Total execution time: 0.0066
DEBUG - 2022-03-09 13:15:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:15:46 --> Total execution time: 0.0357
DEBUG - 2022-03-09 13:15:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:15:50 --> Total execution time: 0.0047
DEBUG - 2022-03-09 13:15:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:15:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:15:54 --> Total execution time: 0.0048
DEBUG - 2022-03-09 13:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:15:57 --> Total execution time: 0.0039
DEBUG - 2022-03-09 13:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:16:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:16:13 --> Total execution time: 0.0041
DEBUG - 2022-03-09 13:16:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:16:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:16:23 --> Total execution time: 0.0048
DEBUG - 2022-03-09 13:16:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 13:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 13:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 13:16:35 --> Total execution time: 0.0063
DEBUG - 2022-03-09 14:15:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:15:59 --> No URI present. Default controller set.
DEBUG - 2022-03-09 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:16:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:16:00 --> Total execution time: 0.0300
DEBUG - 2022-03-09 14:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:16:00 --> No URI present. Default controller set.
DEBUG - 2022-03-09 14:16:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:16:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:16:00 --> Total execution time: 0.0031
DEBUG - 2022-03-09 14:16:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:16:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 14:16:00 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-03-09 14:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:16:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:16:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:16:32 --> Total execution time: 0.0063
DEBUG - 2022-03-09 14:16:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:16:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:16:59 --> Total execution time: 0.0136
DEBUG - 2022-03-09 14:17:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:17:03 --> Total execution time: 0.0046
DEBUG - 2022-03-09 14:17:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:16 --> Total execution time: 0.0088
DEBUG - 2022-03-09 14:17:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:20 --> Total execution time: 0.0038
DEBUG - 2022-03-09 14:17:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:21 --> Total execution time: 0.0055
DEBUG - 2022-03-09 14:17:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:23 --> Total execution time: 0.0059
DEBUG - 2022-03-09 14:17:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:25 --> Total execution time: 0.0057
DEBUG - 2022-03-09 14:17:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:32 --> Total execution time: 0.0055
DEBUG - 2022-03-09 14:17:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:34 --> Total execution time: 0.0055
DEBUG - 2022-03-09 14:17:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:39 --> Total execution time: 0.0052
DEBUG - 2022-03-09 14:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:41 --> Total execution time: 0.0041
DEBUG - 2022-03-09 14:17:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:43 --> Total execution time: 0.0037
DEBUG - 2022-03-09 14:17:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:17:45 --> Total execution time: 0.0041
DEBUG - 2022-03-09 14:19:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:01 --> Total execution time: 0.0049
DEBUG - 2022-03-09 14:19:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:12 --> Total execution time: 0.0040
DEBUG - 2022-03-09 14:19:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:15 --> Total execution time: 0.0045
DEBUG - 2022-03-09 14:19:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:19:18 --> Total execution time: 0.0064
DEBUG - 2022-03-09 14:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:19:39 --> Total execution time: 0.0074
DEBUG - 2022-03-09 14:19:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:43 --> Total execution time: 0.0041
DEBUG - 2022-03-09 14:19:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:47 --> Total execution time: 0.0038
DEBUG - 2022-03-09 14:19:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:19:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:19:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:19:52 --> Total execution time: 0.0061
DEBUG - 2022-03-09 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:20:14 --> Total execution time: 0.0079
DEBUG - 2022-03-09 14:20:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:17 --> Total execution time: 0.0049
DEBUG - 2022-03-09 14:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:22 --> Total execution time: 0.0043
DEBUG - 2022-03-09 14:20:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:24 --> Total execution time: 0.0039
DEBUG - 2022-03-09 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:51 --> Total execution time: 0.0054
DEBUG - 2022-03-09 14:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:20:58 --> Total execution time: 0.0036
DEBUG - 2022-03-09 14:21:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:21:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:21:12 --> Total execution time: 0.0039
DEBUG - 2022-03-09 14:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:21:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:21:23 --> Total execution time: 0.0040
DEBUG - 2022-03-09 14:21:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:21:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:21:26 --> Total execution time: 0.0039
DEBUG - 2022-03-09 14:23:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:23:12 --> Total execution time: 0.0324
DEBUG - 2022-03-09 14:23:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:23:20 --> Total execution time: 0.0059
DEBUG - 2022-03-09 14:23:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:23:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:23:24 --> Total execution time: 0.0047
DEBUG - 2022-03-09 14:23:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:23:27 --> Total execution time: 0.0036
DEBUG - 2022-03-09 14:23:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:23:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:23:29 --> Total execution time: 0.0040
DEBUG - 2022-03-09 14:23:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:23:33 --> Total execution time: 0.0036
DEBUG - 2022-03-09 14:27:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:27:48 --> Total execution time: 0.0363
DEBUG - 2022-03-09 14:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:27:50 --> Total execution time: 0.0060
DEBUG - 2022-03-09 14:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:31:14 --> Total execution time: 0.0352
DEBUG - 2022-03-09 14:31:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:31:14 --> Total execution time: 0.0050
DEBUG - 2022-03-09 14:31:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:31:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:31:17 --> Total execution time: 0.0096
DEBUG - 2022-03-09 14:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:31:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:31:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:31:46 --> Total execution time: 0.0112
DEBUG - 2022-03-09 14:35:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:35:18 --> Total execution time: 0.0358
DEBUG - 2022-03-09 14:35:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:35:21 --> Total execution time: 0.0046
DEBUG - 2022-03-09 14:36:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:36:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:36:03 --> Total execution time: 0.0057
DEBUG - 2022-03-09 14:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:36:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:36:26 --> Total execution time: 0.0055
DEBUG - 2022-03-09 14:37:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:37:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:37:02 --> Total execution time: 0.0053
DEBUG - 2022-03-09 14:37:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:37:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:37:43 --> Total execution time: 0.0055
DEBUG - 2022-03-09 14:37:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:37:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:37:47 --> Total execution time: 0.0038
DEBUG - 2022-03-09 14:38:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:38:04 --> Total execution time: 0.0056
DEBUG - 2022-03-09 14:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:38:25 --> Total execution time: 0.0052
DEBUG - 2022-03-09 14:39:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:39:07 --> Total execution time: 0.0055
DEBUG - 2022-03-09 14:39:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:39:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:39:34 --> Total execution time: 0.0052
DEBUG - 2022-03-09 14:39:37 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:39:37 --> Total execution time: 0.0043
DEBUG - 2022-03-09 14:39:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:39:59 --> Total execution time: 0.0051
DEBUG - 2022-03-09 14:40:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:40:34 --> Total execution time: 0.0055
DEBUG - 2022-03-09 14:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:41:28 --> Total execution time: 0.0056
DEBUG - 2022-03-09 14:41:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:41:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:41:51 --> Total execution time: 0.0059
DEBUG - 2022-03-09 14:42:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:42:14 --> Total execution time: 0.0048
DEBUG - 2022-03-09 14:42:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:42:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:42:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:42:25 --> Total execution time: 0.0053
DEBUG - 2022-03-09 14:43:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:43:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:43:31 --> Total execution time: 0.0055
DEBUG - 2022-03-09 14:44:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:44:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:44:13 --> Total execution time: 0.0056
DEBUG - 2022-03-09 14:44:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:44:14 --> Total execution time: 0.0053
DEBUG - 2022-03-09 14:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:44:32 --> Total execution time: 0.0049
DEBUG - 2022-03-09 14:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:44:33 --> Total execution time: 0.0038
DEBUG - 2022-03-09 14:44:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:44:41 --> Total execution time: 0.0043
DEBUG - 2022-03-09 14:45:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:45:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:45:00 --> Total execution time: 0.0050
DEBUG - 2022-03-09 14:46:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:03 --> Total execution time: 0.0059
DEBUG - 2022-03-09 14:46:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:12 --> Total execution time: 0.0046
DEBUG - 2022-03-09 14:46:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:19 --> Total execution time: 0.0039
DEBUG - 2022-03-09 14:46:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:46:36 --> Total execution time: 0.0127
DEBUG - 2022-03-09 14:46:43 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:46:43 --> Total execution time: 0.0133
DEBUG - 2022-03-09 14:46:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:46:51 --> Total execution time: 0.0125
DEBUG - 2022-03-09 14:46:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:46:54 --> Total execution time: 0.0124
DEBUG - 2022-03-09 14:46:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:46:57 --> Total execution time: 0.0120
DEBUG - 2022-03-09 14:46:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:46:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:46:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:46:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:46:59 --> Total execution time: 0.0133
DEBUG - 2022-03-09 14:47:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:47:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:47:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:47:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:47:03 --> Total execution time: 0.0069
DEBUG - 2022-03-09 14:54:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:54:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:54:13 --> Total execution time: 0.0403
DEBUG - 2022-03-09 14:54:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:54:16 --> Total execution time: 0.0052
DEBUG - 2022-03-09 14:54:17 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:54:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:54:17 --> Total execution time: 0.0050
DEBUG - 2022-03-09 14:54:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:54:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:54:21 --> Total execution time: 0.0073
DEBUG - 2022-03-09 14:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:54:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:54:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 14:54:46 --> Total execution time: 0.0082
DEBUG - 2022-03-09 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:54:50 --> Total execution time: 0.0042
DEBUG - 2022-03-09 14:54:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:54:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:54:52 --> Total execution time: 0.0039
DEBUG - 2022-03-09 14:55:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:55:26 --> Total execution time: 0.0050
DEBUG - 2022-03-09 14:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:56:02 --> Total execution time: 0.0051
DEBUG - 2022-03-09 14:56:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:56:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:56:23 --> Total execution time: 0.0053
DEBUG - 2022-03-09 14:56:45 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 14:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 14:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 14:56:45 --> Total execution time: 0.0054
DEBUG - 2022-03-09 15:04:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:04:23 --> Total execution time: 0.0351
DEBUG - 2022-03-09 15:04:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:04:28 --> Total execution time: 0.0066
DEBUG - 2022-03-09 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:04:31 --> Total execution time: 0.0047
DEBUG - 2022-03-09 15:04:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 15:04:31 --> 404 Page Not Found: Assets/img
DEBUG - 2022-03-09 15:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:04:48 --> Total execution time: 0.0048
DEBUG - 2022-03-09 15:04:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 15:04:48 --> 404 Page Not Found: Assets/img
DEBUG - 2022-03-09 15:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:04:58 --> Total execution time: 0.0039
DEBUG - 2022-03-09 15:04:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 15:04:58 --> 404 Page Not Found: Assets/img
DEBUG - 2022-03-09 15:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:04:59 --> Total execution time: 0.0041
DEBUG - 2022-03-09 15:04:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:04:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 15:04:59 --> 404 Page Not Found: Assets/img
DEBUG - 2022-03-09 15:05:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:05:52 --> Total execution time: 0.0048
DEBUG - 2022-03-09 15:06:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:06:55 --> Total execution time: 0.0052
DEBUG - 2022-03-09 15:07:15 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:07:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:07:15 --> Total execution time: 0.0049
DEBUG - 2022-03-09 15:10:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:10:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:10:16 --> Total execution time: 0.0337
DEBUG - 2022-03-09 15:10:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:10:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:10:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:10:22 --> Total execution time: 0.0119
DEBUG - 2022-03-09 15:10:24 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:10:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:10:24 --> Total execution time: 0.0057
DEBUG - 2022-03-09 15:10:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:10:26 --> Total execution time: 0.0037
DEBUG - 2022-03-09 15:10:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:10:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:10:54 --> Total execution time: 0.0059
DEBUG - 2022-03-09 15:11:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:11:05 --> Total execution time: 0.0037
DEBUG - 2022-03-09 15:11:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:11:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:11:10 --> Total execution time: 0.0049
DEBUG - 2022-03-09 15:11:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:11:11 --> Total execution time: 0.0038
DEBUG - 2022-03-09 15:11:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:11:40 --> Total execution time: 0.0055
DEBUG - 2022-03-09 15:12:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:12:03 --> Total execution time: 0.0048
DEBUG - 2022-03-09 15:13:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:13:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:13:05 --> Total execution time: 0.0056
DEBUG - 2022-03-09 15:13:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:13:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:13:13 --> Total execution time: 0.0041
DEBUG - 2022-03-09 15:13:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 15:13:14 --> 404 Page Not Found: Assets/img
DEBUG - 2022-03-09 15:13:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:13:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:13:46 --> Total execution time: 0.0049
DEBUG - 2022-03-09 15:13:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:13:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:13:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:13:47 --> Total execution time: 0.0039
DEBUG - 2022-03-09 15:14:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:14:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:14:27 --> Total execution time: 0.0055
DEBUG - 2022-03-09 15:14:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:14:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:14:28 --> Total execution time: 0.0045
DEBUG - 2022-03-09 15:14:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:14:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:14:38 --> Total execution time: 0.0037
DEBUG - 2022-03-09 15:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:14:56 --> Total execution time: 0.0053
DEBUG - 2022-03-09 15:16:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:16:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:16:20 --> Total execution time: 0.0327
DEBUG - 2022-03-09 15:16:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:16:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:16:48 --> Total execution time: 0.0047
DEBUG - 2022-03-09 15:16:51 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:16:51 --> Total execution time: 0.0075
DEBUG - 2022-03-09 15:16:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:16:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:16:54 --> Total execution time: 0.0046
DEBUG - 2022-03-09 15:17:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:17:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:17:41 --> Total execution time: 0.0051
DEBUG - 2022-03-09 15:20:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:20:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:20:27 --> Total execution time: 0.0347
DEBUG - 2022-03-09 15:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:35:46 --> Total execution time: 0.0375
DEBUG - 2022-03-09 15:35:48 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:35:48 --> Total execution time: 0.0046
DEBUG - 2022-03-09 15:35:49 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:36:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:36:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:36:05 --> Total execution time: 0.0050
DEBUG - 2022-03-09 15:36:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:36:20 --> Total execution time: 0.0050
DEBUG - 2022-03-09 15:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:36:25 --> Total execution time: 0.0068
DEBUG - 2022-03-09 15:36:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:36:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:36:28 --> Total execution time: 0.0057
DEBUG - 2022-03-09 15:36:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:36:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:36:30 --> Total execution time: 0.0110
DEBUG - 2022-03-09 15:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:37:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:37:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:37:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:37:03 --> Total execution time: 0.0073
DEBUG - 2022-03-09 15:37:06 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:37:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:37:06 --> Total execution time: 0.0049
DEBUG - 2022-03-09 15:37:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:37:08 --> Total execution time: 0.0039
DEBUG - 2022-03-09 15:38:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:38:08 --> Total execution time: 0.0059
DEBUG - 2022-03-09 15:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:39:00 --> Total execution time: 0.0051
DEBUG - 2022-03-09 15:39:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:39:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:39:52 --> Total execution time: 0.0054
DEBUG - 2022-03-09 15:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:40:02 --> Total execution time: 0.0065
DEBUG - 2022-03-09 15:40:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:40:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:40:05 --> Total execution time: 0.0066
DEBUG - 2022-03-09 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:40:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:40:41 --> Total execution time: 0.0072
DEBUG - 2022-03-09 15:40:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:40:52 --> Total execution time: 0.0074
DEBUG - 2022-03-09 15:40:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:40:54 --> Total execution time: 0.0057
DEBUG - 2022-03-09 15:40:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:40:56 --> Total execution time: 0.0040
DEBUG - 2022-03-09 15:41:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:41:01 --> Total execution time: 0.0046
DEBUG - 2022-03-09 15:42:18 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:42:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:42:18 --> Total execution time: 0.0338
DEBUG - 2022-03-09 15:42:40 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:42:40 --> Total execution time: 0.0053
DEBUG - 2022-03-09 15:54:12 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:54:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:54:12 --> Total execution time: 0.0354
DEBUG - 2022-03-09 15:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:54:25 --> Total execution time: 0.0081
DEBUG - 2022-03-09 15:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:54:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:54:28 --> Total execution time: 0.0130
DEBUG - 2022-03-09 15:54:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2022-03-09 15:54:59 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Spk.php 184
ERROR - 2022-03-09 15:54:59 --> Query error: Column 'photograper' cannot be null - Invalid query: INSERT INTO `live` (`name`, `phone`, `date_s`, `w_live`, `place_s`, `photograper`, `videograper`, `crew`, `note`) VALUES ('Hanny Alia Hasanah & Ahmad Siddik', '081322286608', '2022-03-24', '12:00', 'Garut', NULL, 'Gian,Jodski', '', 'we')
ERROR - 2022-03-09 15:54:59 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /home/dunr4521/public_html/integrity/system/core/Exceptions.php:271) /home/dunr4521/public_html/integrity/system/helpers/url_helper.php 564
DEBUG - 2022-03-09 15:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:55:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 15:55:07 --> Total execution time: 0.0079
DEBUG - 2022-03-09 15:55:10 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:55:10 --> Total execution time: 0.0065
DEBUG - 2022-03-09 15:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 15:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 15:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 15:55:14 --> Total execution time: 0.0041
DEBUG - 2022-03-09 16:11:23 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:11:23 --> Total execution time: 0.0345
DEBUG - 2022-03-09 16:13:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:13:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:13:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:13:11 --> Total execution time: 0.0320
DEBUG - 2022-03-09 16:14:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:14:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 16:14:11 --> Total execution time: 0.0135
DEBUG - 2022-03-09 16:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:14:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:14:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:14:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 16:14:56 --> Total execution time: 0.0074
DEBUG - 2022-03-09 16:15:01 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:01 --> Total execution time: 0.0052
DEBUG - 2022-03-09 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:04 --> Total execution time: 0.0054
DEBUG - 2022-03-09 16:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:11 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:11 --> Total execution time: 0.0041
DEBUG - 2022-03-09 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:16 --> Total execution time: 0.0038
DEBUG - 2022-03-09 16:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:19 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:19 --> Total execution time: 0.0041
DEBUG - 2022-03-09 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:25 --> Total execution time: 0.0040
DEBUG - 2022-03-09 16:15:36 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:36 --> Total execution time: 0.0041
DEBUG - 2022-03-09 16:15:39 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:39 --> Total execution time: 0.0036
DEBUG - 2022-03-09 16:15:57 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:15:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:15:57 --> Total execution time: 0.0050
DEBUG - 2022-03-09 16:16:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:16:30 --> Total execution time: 0.0061
DEBUG - 2022-03-09 16:16:58 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:16:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:16:58 --> Total execution time: 0.0050
DEBUG - 2022-03-09 16:17:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:17:30 --> Total execution time: 0.0048
DEBUG - 2022-03-09 16:18:38 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:18:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:18:38 --> Total execution time: 0.0062
DEBUG - 2022-03-09 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:19:22 --> Total execution time: 0.0053
DEBUG - 2022-03-09 16:19:27 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:19:27 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 16:19:27 --> Total execution time: 0.0070
DEBUG - 2022-03-09 16:19:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:19:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:19:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:19:30 --> Total execution time: 0.0035
DEBUG - 2022-03-09 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:22:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:22:35 --> Total execution time: 0.0323
DEBUG - 2022-03-09 16:22:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:22:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:22:35 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:23:30 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:23:30 --> Total execution time: 0.0048
DEBUG - 2022-03-09 16:23:31 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:23:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:23:31 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:24:05 --> Total execution time: 0.0052
DEBUG - 2022-03-09 16:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:24:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:24:05 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:24:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:24:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:24:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 16:24:13 --> Total execution time: 0.0124
DEBUG - 2022-03-09 16:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:25:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 16:25:42 --> Total execution time: 0.0376
DEBUG - 2022-03-09 16:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:25:46 --> Total execution time: 0.0039
DEBUG - 2022-03-09 16:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:25:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:25:46 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:25:47 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:25:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:25:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 16:25:47 --> Total execution time: 0.0070
DEBUG - 2022-03-09 16:25:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:25:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:25:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 16:25:52 --> Total execution time: 0.0063
DEBUG - 2022-03-09 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:25:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:25:54 --> Total execution time: 0.0038
DEBUG - 2022-03-09 16:25:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:25:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:25:54 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:27:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:27:08 --> Total execution time: 0.0322
DEBUG - 2022-03-09 16:27:08 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:27:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:27:08 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:27:34 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:27:34 --> Total execution time: 0.0049
DEBUG - 2022-03-09 16:27:35 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:27:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:27:35 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:34:44 --> Total execution time: 0.0340
DEBUG - 2022-03-09 16:34:44 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:34:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:34:44 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:35:52 --> Total execution time: 0.0050
DEBUG - 2022-03-09 16:35:52 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:35:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:35:52 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:36:25 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:36:25 --> Total execution time: 0.0052
DEBUG - 2022-03-09 16:36:26 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:36:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:36:26 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:36:41 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:36:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:36:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:36:41 --> Total execution time: 0.0049
DEBUG - 2022-03-09 16:36:42 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:36:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:36:42 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:36:55 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:36:55 --> Total execution time: 0.0049
DEBUG - 2022-03-09 16:36:56 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:36:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:36:56 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:37:13 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:37:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:37:13 --> Total execution time: 0.0052
DEBUG - 2022-03-09 16:37:14 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:37:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:37:14 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:37:32 --> Total execution time: 0.0047
DEBUG - 2022-03-09 16:37:33 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:37:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:37:33 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:37:54 --> Total execution time: 0.0053
DEBUG - 2022-03-09 16:37:54 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:37:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:37:54 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:37:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:37:59 --> Total execution time: 0.0041
DEBUG - 2022-03-09 16:37:59 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:37:59 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:38:21 --> Total execution time: 0.0063
DEBUG - 2022-03-09 16:38:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:38:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:38:21 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 16:39:28 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:39:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 16:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 16:39:28 --> Total execution time: 0.0067
DEBUG - 2022-03-09 16:39:29 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 16:39:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 16:39:29 --> 404 Page Not Found: Img/undraw_posting_photo.svg
DEBUG - 2022-03-09 21:40:02 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 21:40:02 --> No URI present. Default controller set.
DEBUG - 2022-03-09 21:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 21:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 21:40:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 21:40:02 --> Total execution time: 0.0302
DEBUG - 2022-03-09 21:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 21:40:03 --> No URI present. Default controller set.
DEBUG - 2022-03-09 21:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 21:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 21:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 21:40:03 --> Total execution time: 0.0043
DEBUG - 2022-03-09 21:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 21:40:03 --> No URI present. Default controller set.
DEBUG - 2022-03-09 21:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 21:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 21:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 21:40:03 --> Total execution time: 0.0031
DEBUG - 2022-03-09 21:40:04 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 21:40:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 21:40:04 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-03-09 21:40:20 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 21:40:20 --> No URI present. Default controller set.
DEBUG - 2022-03-09 21:40:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 21:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 21:40:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 21:40:20 --> Total execution time: 0.0040
DEBUG - 2022-03-09 21:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 21:40:21 --> No URI present. Default controller set.
DEBUG - 2022-03-09 21:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 21:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 21:40:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 21:40:21 --> Total execution time: 0.0035
DEBUG - 2022-03-09 21:40:21 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 21:40:21 --> No URI present. Default controller set.
DEBUG - 2022-03-09 21:40:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-03-09 21:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-03-09 21:40:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-03-09 21:40:21 --> Total execution time: 0.0041
DEBUG - 2022-03-09 21:40:22 --> UTF-8 Support Enabled
DEBUG - 2022-03-09 21:40:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-03-09 21:40:22 --> 404 Page Not Found: Faviconpng/index
