<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-04-05 00:05:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 00:05:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 00:05:44 --> 404 Page Not Found: Env/index
DEBUG - 2022-04-05 00:05:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 00:05:45 --> No URI present. Default controller set.
DEBUG - 2022-04-05 00:05:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 00:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 00:05:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 00:05:46 --> Total execution time: 0.0316
DEBUG - 2022-04-05 02:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:17:50 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-04-05 02:17:50 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'ORDER BY `user_access_menu`.`menu_id` ASC' at line 5 - Invalid query: SELECT `user_menu`.`id`,`menu`,`icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                    ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = 
                    ORDER BY `user_access_menu`.`menu_id` ASC
                    
ERROR - 2022-04-05 02:17:50 --> Severity: error --> Exception: Call to a member function result_array() on bool /home/nsnmt.com/integrity/application/views/templates/sidebar.php 23
DEBUG - 2022-04-05 02:17:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 02:17:50 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-05 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:57 --> No URI present. Default controller set.
DEBUG - 2022-04-05 02:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:17:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:17:57 --> Total execution time: 0.0020
DEBUG - 2022-04-05 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 02:17:57 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-05 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 02:17:57 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-05 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 02:17:57 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-05 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 02:17:57 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-05 02:17:57 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 02:17:57 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-05 02:17:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:17:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:17:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:17:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:17:59 --> Total execution time: 0.0029
DEBUG - 2022-04-05 02:18:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:18:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:18:01 --> Total execution time: 0.0102
DEBUG - 2022-04-05 02:19:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:19:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:19:49 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:19:49 --> Total execution time: 0.0035
DEBUG - 2022-04-05 02:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:24:50 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:24:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:24:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:24:50 --> Total execution time: 0.0038
DEBUG - 2022-04-05 02:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:27:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:27:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:27:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:27:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:27:11 --> Total execution time: 0.0041
DEBUG - 2022-04-05 02:31:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:31:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:31:52 --> Total execution time: 0.0384
DEBUG - 2022-04-05 02:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:34:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:34:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:34:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:34:15 --> Total execution time: 0.0047
DEBUG - 2022-04-05 02:34:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:34:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:34:59 --> Total execution time: 0.0035
DEBUG - 2022-04-05 02:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:35:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:35:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:35:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:35:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:35:54 --> Total execution time: 0.0024
DEBUG - 2022-04-05 02:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:38:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:38:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:38:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:38:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:38:11 --> Total execution time: 0.0027
DEBUG - 2022-04-05 02:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:38:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:38:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:38:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:38:51 --> Total execution time: 0.0018
DEBUG - 2022-04-05 02:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:41:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:41:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:41:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:41:10 --> Total execution time: 0.0025
DEBUG - 2022-04-05 02:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:47:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:47:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:47:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:47:22 --> Total execution time: 0.0056
DEBUG - 2022-04-05 02:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:48:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:48:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:48:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:48:53 --> Total execution time: 0.0019
DEBUG - 2022-04-05 02:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:50:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:50:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:50:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:50:45 --> Total execution time: 0.0020
DEBUG - 2022-04-05 02:52:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:52:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:52:08 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:52:08 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:52:08 --> Total execution time: 0.0020
DEBUG - 2022-04-05 02:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:55:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:55:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:55:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:55:48 --> Total execution time: 0.0043
DEBUG - 2022-04-05 02:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:58:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:58:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:58:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:58:13 --> Total execution time: 0.0044
DEBUG - 2022-04-05 02:58:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:58:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:58:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:58:15 --> Total execution time: 0.0134
DEBUG - 2022-04-05 02:58:17 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:58:17 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:58:17 --> Total execution time: 0.0110
DEBUG - 2022-04-05 02:58:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 02:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 02:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 02:58:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 02:58:47 --> Total execution time: 0.0024
DEBUG - 2022-04-05 03:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:01:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:01:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:01:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:01:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:01:18 --> Total execution time: 0.0019
DEBUG - 2022-04-05 03:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:04:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:04:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:04:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:04:15 --> Total execution time: 0.0043
DEBUG - 2022-04-05 03:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:05:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:05:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:05:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:05:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:05:59 --> Total execution time: 0.0018
DEBUG - 2022-04-05 03:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:08:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:08:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:08:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:08:22 --> Total execution time: 0.0050
DEBUG - 2022-04-05 03:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:12:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:12:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:12:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:12:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:12:16 --> Total execution time: 0.0045
DEBUG - 2022-04-05 03:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:17:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:17:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:17:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:17:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:17:15 --> Total execution time: 0.0021
DEBUG - 2022-04-05 03:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:21:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:21:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:21:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:21:59 --> Total execution time: 0.0039
DEBUG - 2022-04-05 03:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:25:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:25:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:25:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:25:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:25:36 --> Total execution time: 0.0021
DEBUG - 2022-04-05 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:29:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:29:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:29:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:29:36 --> Total execution time: 0.0040
DEBUG - 2022-04-05 03:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:31:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:31:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:31:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:31:53 --> Total execution time: 0.0042
DEBUG - 2022-04-05 03:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:35:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:35:44 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:35:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:35:44 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:35:44 --> Total execution time: 0.0040
DEBUG - 2022-04-05 03:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:38:25 --> Total execution time: 0.0040
DEBUG - 2022-04-05 03:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:40:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:40:15 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:40:15 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:40:15 --> Total execution time: 0.0051
DEBUG - 2022-04-05 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:42:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:42:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:42:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:42:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:42:16 --> Total execution time: 0.0019
DEBUG - 2022-04-05 03:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:44:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:44:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:44:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:44:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:44:56 --> Total execution time: 0.0039
DEBUG - 2022-04-05 03:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:46:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:46:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:46:13 --> Total execution time: 0.0020
DEBUG - 2022-04-05 03:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:48:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:48:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:48:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:48:52 --> Total execution time: 0.0043
DEBUG - 2022-04-05 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:49:45 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:49:45 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:49:45 --> Total execution time: 0.0019
DEBUG - 2022-04-05 03:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:52:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:52:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:52:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:52:37 --> Total execution time: 0.0039
DEBUG - 2022-04-05 03:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:54:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:54:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:54:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:54:25 --> Total execution time: 0.0042
DEBUG - 2022-04-05 03:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:58:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:58:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 03:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 03:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 03:58:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 03:58:24 --> Total execution time: 0.0039
DEBUG - 2022-04-05 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:00:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:00:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:00:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:00:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:00:38 --> Total execution time: 0.0042
DEBUG - 2022-04-05 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:03:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:03:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:03:28 --> Total execution time: 0.0052
DEBUG - 2022-04-05 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:09:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:09:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:09:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:09:47 --> Total execution time: 0.0039
DEBUG - 2022-04-05 04:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:10:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:10:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:10:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:10:58 --> Total execution time: 0.0019
DEBUG - 2022-04-05 04:14:47 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:47 --> No URI present. Default controller set.
DEBUG - 2022-04-05 04:14:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:14:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:14:47 --> Total execution time: 0.0363
DEBUG - 2022-04-05 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:14:48 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-05 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:14:48 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-05 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:14:48 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-05 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:14:48 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-05 04:14:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:14:48 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-05 04:14:49 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:14:49 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-05 04:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:14:58 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:14:58 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:14:58 --> Total execution time: 0.0032
DEBUG - 2022-04-05 04:15:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:15:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:15:07 --> Total execution time: 0.0162
DEBUG - 2022-04-05 04:15:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:15:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:15:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:15:09 --> Total execution time: 0.0050
DEBUG - 2022-04-05 04:15:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:15:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:15:16 --> Total execution time: 0.0035
DEBUG - 2022-04-05 04:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:18:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:18:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:18:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:18:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:18:10 --> Total execution time: 0.0042
DEBUG - 2022-04-05 04:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:20:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:20:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:20:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:20:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:20:46 --> Total execution time: 0.0044
DEBUG - 2022-04-05 04:22:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:22:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:22:53 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:22:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:22:53 --> Total execution time: 0.0048
DEBUG - 2022-04-05 04:34:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:34:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:34:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:34:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:34:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:34:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:34:21 --> Total execution time: 0.0045
DEBUG - 2022-04-05 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:37:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:37:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:37:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:37:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:37:32 --> Total execution time: 0.0040
DEBUG - 2022-04-05 04:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:38:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:38:52 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:38:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:38:52 --> Total execution time: 0.0029
DEBUG - 2022-04-05 04:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:41:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:41:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:41:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:41:41 --> Total execution time: 0.0044
DEBUG - 2022-04-05 04:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:42:09 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:42:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:42:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:42:09 --> Total execution time: 0.0020
DEBUG - 2022-04-05 04:46:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:46:23 --> No URI present. Default controller set.
DEBUG - 2022-04-05 04:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:46:24 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:46:24 --> Total execution time: 0.0623
DEBUG - 2022-04-05 04:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:46:24 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-05 04:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:46:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:46:24 --> 404 Page Not Found: Js/popper.js
ERROR - 2022-04-05 04:46:24 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-05 04:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:46:24 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-05 04:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:46:24 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-05 04:46:24 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:46:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 04:46:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2022-04-05 04:49:20 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:49:20 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:49:20 --> Total execution time: 0.0120
DEBUG - 2022-04-05 04:49:21 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:49:21 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:49:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 04:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 04:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 04:49:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 04:49:22 --> Total execution time: 0.0018
DEBUG - 2022-04-05 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:07:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:07:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:07:46 --> Total execution time: 0.0041
DEBUG - 2022-04-05 05:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:09:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:09:26 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:09:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:09:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:09:26 --> Total execution time: 0.0024
DEBUG - 2022-04-05 05:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:11:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:11:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:11:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:11:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:11:25 --> Total execution time: 0.0020
DEBUG - 2022-04-05 05:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:14:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:14:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:14:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:14:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:14:05 --> Total execution time: 0.0043
DEBUG - 2022-04-05 05:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:15:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:15:18 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:15:18 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:15:18 --> Total execution time: 0.0019
DEBUG - 2022-04-05 05:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:18:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:18:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:18:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:18:46 --> Total execution time: 0.0019
DEBUG - 2022-04-05 05:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:20:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:20:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:20:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:20:43 --> Total execution time: 0.0018
DEBUG - 2022-04-05 05:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:22:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:22:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:22:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:22:07 --> Total execution time: 0.0020
DEBUG - 2022-04-05 05:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:24:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:24:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:24:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:24:33 --> Total execution time: 0.0017
DEBUG - 2022-04-05 05:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:26:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:26:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:26:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:26:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:26:16 --> Total execution time: 0.0020
DEBUG - 2022-04-05 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:29:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:29:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:29:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:29:32 --> Total execution time: 0.0042
DEBUG - 2022-04-05 05:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:31:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:31:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:31:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:31:23 --> Total execution time: 0.0018
DEBUG - 2022-04-05 05:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:34:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:34:01 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:34:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:34:01 --> Total execution time: 0.0020
DEBUG - 2022-04-05 05:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:36:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:36:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:36:59 --> Total execution time: 0.0043
DEBUG - 2022-04-05 05:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:39:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:39:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:39:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:39:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:39:00 --> Total execution time: 0.0045
DEBUG - 2022-04-05 05:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:41:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:41:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:41:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:41:28 --> Total execution time: 0.0023
DEBUG - 2022-04-05 05:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:43:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:43:40 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:43:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:43:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:43:40 --> Total execution time: 0.0042
DEBUG - 2022-04-05 05:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:45:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:45:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:45:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:45:13 --> Total execution time: 0.0023
DEBUG - 2022-04-05 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:46:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:46:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:46:37 --> Total execution time: 0.0023
DEBUG - 2022-04-05 05:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:53:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:53:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:53:10 --> Total execution time: 0.0040
DEBUG - 2022-04-05 05:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:55:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:55:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:55:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:55:07 --> Total execution time: 0.0040
DEBUG - 2022-04-05 05:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:57:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:57:07 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:57:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:57:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:57:07 --> Total execution time: 0.0022
DEBUG - 2022-04-05 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:58:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:58:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 05:58:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 05:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 05:58:36 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 05:58:36 --> Total execution time: 0.0042
DEBUG - 2022-04-05 06:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:00:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:00:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:00:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:00:25 --> Total execution time: 0.0039
DEBUG - 2022-04-05 06:01:36 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:01:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:01:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:01:37 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:01:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:01:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:01:37 --> Total execution time: 0.0042
DEBUG - 2022-04-05 06:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:02:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:02:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:02:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:02:16 --> Total execution time: 0.0022
DEBUG - 2022-04-05 06:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:03:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:03:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:03:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:03:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:03:48 --> Total execution time: 0.0043
DEBUG - 2022-04-05 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:05:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:05:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:05:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:05:48 --> Total execution time: 0.0022
DEBUG - 2022-04-05 06:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:07:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:07:38 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:07:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:07:38 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:07:38 --> Total execution time: 0.0019
DEBUG - 2022-04-05 06:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:08:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:08:41 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:08:41 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:08:41 --> Total execution time: 0.0018
DEBUG - 2022-04-05 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:26:32 --> No URI present. Default controller set.
DEBUG - 2022-04-05 06:26:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:26:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:26:32 --> Total execution time: 0.0674
DEBUG - 2022-04-05 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 06:26:32 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-05 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 06:26:32 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-05 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 06:26:32 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-05 06:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 06:26:32 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-05 06:26:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:26:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 06:26:32 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-05 06:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:35:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:35:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:35:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:35:46 --> Total execution time: 0.0043
DEBUG - 2022-04-05 06:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:39:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:39:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:39:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:39:02 --> Total execution time: 0.0039
DEBUG - 2022-04-05 06:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:41:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:41:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:41:29 --> Total execution time: 0.0040
DEBUG - 2022-04-05 06:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:42:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:42:54 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:42:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:42:54 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:42:54 --> Total execution time: 0.0039
DEBUG - 2022-04-05 06:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:45:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:45:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:45:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:45:05 --> Total execution time: 0.0045
DEBUG - 2022-04-05 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:48:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:48:29 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:48:29 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:48:29 --> Total execution time: 0.0041
DEBUG - 2022-04-05 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:50:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:50:16 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:50:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:50:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:50:16 --> Total execution time: 0.0023
DEBUG - 2022-04-05 06:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:52:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:52:42 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:52:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:52:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:52:42 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:52:42 --> Total execution time: 0.0041
DEBUG - 2022-04-05 06:54:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:54:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:54:35 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 06:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 06:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 06:54:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 06:54:35 --> Total execution time: 0.0019
DEBUG - 2022-04-05 07:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:02:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:02:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:02:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:02:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:02:02 --> Total execution time: 0.0050
DEBUG - 2022-04-05 07:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:07:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:07:51 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:07:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:07:51 --> Total execution time: 0.0041
DEBUG - 2022-04-05 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:10:43 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:10:43 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:10:43 --> Total execution time: 0.0044
DEBUG - 2022-04-05 07:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:15:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:15:34 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:15:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:15:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:15:34 --> Total execution time: 0.0046
DEBUG - 2022-04-05 07:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:18:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:18:11 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:18:11 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:18:11 --> Total execution time: 0.0042
DEBUG - 2022-04-05 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:19:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:19:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:19:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:19:56 --> Total execution time: 0.0021
DEBUG - 2022-04-05 07:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:22:56 --> No URI present. Default controller set.
DEBUG - 2022-04-05 07:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:22:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:22:56 --> Total execution time: 0.0370
DEBUG - 2022-04-05 07:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 07:22:56 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-04-05 07:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 07:22:56 --> 404 Page Not Found: Js/jquery.min.js
DEBUG - 2022-04-05 07:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:22:56 --> UTF-8 Support Enabled
ERROR - 2022-04-05 07:22:56 --> 404 Page Not Found: Js/bootstrap.min.js
DEBUG - 2022-04-05 07:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 07:22:56 --> 404 Page Not Found: Js/popper.js
DEBUG - 2022-04-05 07:22:56 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:22:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-04-05 07:22:56 --> 404 Page Not Found: Js/main.js
DEBUG - 2022-04-05 07:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:23:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:23:00 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:23:00 --> Total execution time: 0.0058
DEBUG - 2022-04-05 07:23:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:23:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:23:02 --> Total execution time: 0.0156
DEBUG - 2022-04-05 07:23:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:23:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:23:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:23:03 --> Total execution time: 0.0024
DEBUG - 2022-04-05 07:23:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:23:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:23:59 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:23:59 --> Total execution time: 0.0067
DEBUG - 2022-04-05 07:24:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:24:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:24:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:24:02 --> Total execution time: 0.0127
DEBUG - 2022-04-05 07:24:05 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:24:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:24:05 --> Total execution time: 0.0019
DEBUG - 2022-04-05 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:25:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:25:23 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:25:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:25:23 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:25:23 --> Total execution time: 0.0031
DEBUG - 2022-04-05 07:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:40:03 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:40:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:40:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:40:03 --> Total execution time: 0.0064
DEBUG - 2022-04-05 07:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:41:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:41:46 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:41:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:41:46 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:41:46 --> Total execution time: 0.0028
DEBUG - 2022-04-05 07:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:43:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:43:48 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:43:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:43:48 --> Total execution time: 0.0019
DEBUG - 2022-04-05 07:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:45:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:45:33 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:45:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:45:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:45:33 --> Total execution time: 0.0021
DEBUG - 2022-04-05 07:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:47:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:47:55 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:47:55 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:47:55 --> Total execution time: 0.0021
DEBUG - 2022-04-05 07:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:49:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:49:32 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:49:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:49:32 --> Total execution time: 0.0040
DEBUG - 2022-04-05 07:51:12 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:51:12 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:51:13 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:51:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:51:13 --> Total execution time: 0.0022
DEBUG - 2022-04-05 07:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:53:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:53:10 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:53:10 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:53:10 --> Total execution time: 0.0020
DEBUG - 2022-04-05 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:54:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:54:28 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:54:28 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:54:28 --> Total execution time: 0.0021
DEBUG - 2022-04-05 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:56:02 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 07:56:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 07:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 07:56:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 07:56:02 --> Total execution time: 0.0019
DEBUG - 2022-04-05 16:38:25 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 16:38:25 --> No URI present. Default controller set.
DEBUG - 2022-04-05 16:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 16:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 16:38:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 16:38:25 --> Total execution time: 0.0502
DEBUG - 2022-04-05 17:44:22 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 17:44:22 --> No URI present. Default controller set.
DEBUG - 2022-04-05 17:44:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 17:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 17:44:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 17:44:22 --> Total execution time: 0.0346
DEBUG - 2022-04-05 22:57:06 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 22:57:06 --> No URI present. Default controller set.
DEBUG - 2022-04-05 22:57:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 22:57:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 22:57:06 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 22:57:06 --> Total execution time: 0.0371
DEBUG - 2022-04-05 23:06:59 --> UTF-8 Support Enabled
DEBUG - 2022-04-05 23:06:59 --> No URI present. Default controller set.
DEBUG - 2022-04-05 23:06:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-04-05 23:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-04-05 23:07:00 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-04-05 23:07:00 --> Total execution time: 0.0355
