<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-07-20 04:18:14 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 04:18:14 --> No URI present. Default controller set.
DEBUG - 2022-07-20 04:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 04:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 04:18:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 04:18:14 --> Total execution time: 0.1785
DEBUG - 2022-07-20 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 04:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 04:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 04:18:22 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 04:18:22 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 04:18:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 04:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 04:18:22 --> Total execution time: 0.1236
DEBUG - 2022-07-20 06:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 06:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 06:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 06:48:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 06:48:05 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 06:48:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 06:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 06:48:05 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 06:48:05 --> Total execution time: 0.0957
DEBUG - 2022-07-20 06:49:30 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 06:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 06:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 06:49:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 06:49:30 --> Total execution time: 0.0971
DEBUG - 2022-07-20 06:50:01 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 06:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 06:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 06:50:01 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 06:50:01 --> Total execution time: 0.1612
DEBUG - 2022-07-20 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 06:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 06:50:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 06:50:47 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 06:50:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 06:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 06:50:47 --> Total execution time: 0.1070
DEBUG - 2022-07-20 09:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 09:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 09:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 09:23:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 09:23:16 --> UTF-8 Support Enabled
DEBUG - 2022-07-20 09:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-07-20 09:23:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-07-20 09:23:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-07-20 09:23:16 --> Total execution time: 0.0954
