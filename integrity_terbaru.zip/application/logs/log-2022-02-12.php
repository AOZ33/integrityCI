<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2022-02-12 13:08:07 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:08:07 --> No URI present. Default controller set.
DEBUG - 2022-02-12 13:08:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:08:07 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 13:08:07 --> Total execution time: 0.0305
DEBUG - 2022-02-12 13:08:08 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:08:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-12 13:08:08 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-12 13:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:10:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 13:10:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:10:53 --> Total execution time: 0.0050
DEBUG - 2022-02-12 13:10:55 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:10:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:10:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:10:55 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-12 13:10:55 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 186185592 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-12 13:19:53 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:19:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 13:19:53 --> Total execution time: 0.0330
DEBUG - 2022-02-12 13:25:29 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:25:29 --> Total execution time: 0.0329
DEBUG - 2022-02-12 13:25:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:25:39 --> Total execution time: 0.0038
DEBUG - 2022-02-12 13:25:42 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:25:42 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-12 13:25:42 --> Severity: Error --> Allowed memory size of 268435456 bytes exhausted (tried to allocate 186185592 bytes) /home/dunr4521/public_html/integrity/system/core/Loader.php 996
DEBUG - 2022-02-12 13:25:46 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:25:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:25:46 --> Total execution time: 0.0035
DEBUG - 2022-02-12 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:28:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 13:28:37 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:28:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:28:37 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 13:28:37 --> Total execution time: 0.0049
DEBUG - 2022-02-12 13:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:41:52 --> Form_validation class already loaded. Second attempt ignored.
ERROR - 2022-02-12 13:41:52 --> Severity: Warning --> implode(): Invalid arguments passed /home/dunr4521/public_html/integrity/application/controllers/Appointment.php 28
ERROR - 2022-02-12 13:41:52 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `appointment` (`name`, `name_a`, `package`, `description`, `photo_g`, `box`, `ukuran_p`, `ukuran_w`, `tambahan`, `u20x30`, `u25x30`, `u30x30`, `video`, `lainnya`, `wedding_book`, `address`, `phone`, `email`, `instagram`, `price`, `dp`, `nilai`, `uang`, `date_l`, `w_lamaran`, `place_l`, `date_p`, `w_prewed`, `date_w`, `w_akad`, `w_resepsi`, `date_m`, `w_siram`, `place_m`, `date_s`, `w_live`, `place_s`, `date_a`, `n_acara`, `w_lain`, `place_p`, `place_w`, `place_a`, `date_dp`, `date_n`, `date_u`, `more`, `more_p`, `more_w`, `more_m`, `more_s`, `more_a`) VALUES ('Ratih & Radithya', '', '', NULL, '10 (4R)', 'custom laci', '4 (20RP)', '2 (16RP)', '', '', 'prewed+acara+group', '', 'full editing', '', '', 'Jl. Terusan Ciliwung Gang Guyub II No.1', '087825583383', 'radithya777@gmail.com', '', 'Rp. 13.750.000', 'Rp. 2.750.000', 'Rp. 5.500.000', 'Rp. 4.500.000', '', '', '', '', '', '2018-01-13', '', '', '2018-01-11', '', '', '', '', '', '', '', '', '', 'Gedung Tekmira', '', '2017-09-12', '2017-11-12', '2018-07-01', '', '', '', '', '', '')
DEBUG - 2022-02-12 13:41:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:41:52 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 13:41:52 --> Total execution time: 0.0064
DEBUG - 2022-02-12 13:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:53:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 13:53:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 13:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 13:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 13:53:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 13:53:26 --> Total execution time: 0.0060
DEBUG - 2022-02-12 14:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:04:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:04:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:04:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:04:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:04:35 --> Total execution time: 0.0060
DEBUG - 2022-02-12 14:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:11:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:11:51 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:11:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:11:51 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:11:51 --> Total execution time: 0.0057
DEBUG - 2022-02-12 14:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:22:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:22:26 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:22:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:22:26 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:22:26 --> Total execution time: 0.0054
DEBUG - 2022-02-12 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:29:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:29:04 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:29:04 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:29:04 --> Total execution time: 0.0051
DEBUG - 2022-02-12 14:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:46:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:46:25 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:46:25 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:46:25 --> Total execution time: 0.0053
DEBUG - 2022-02-12 14:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:57:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:57:30 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 14:57:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 14:57:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 14:57:30 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 14:57:30 --> Total execution time: 0.0057
DEBUG - 2022-02-12 15:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:15:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:15:56 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:15:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:15:56 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:15:56 --> Total execution time: 0.0058
DEBUG - 2022-02-12 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:27:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:27:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:27:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:27:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:27:50 --> Total execution time: 0.0050
DEBUG - 2022-02-12 15:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:33:16 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:33:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:33:16 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:33:16 --> Total execution time: 0.0056
DEBUG - 2022-02-12 15:44:32 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:44:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:44:32 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:44:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:44:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:44:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:44:33 --> Total execution time: 0.0056
DEBUG - 2022-02-12 15:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:48:13 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:48:13 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:48:14 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:48:14 --> Total execution time: 0.0759
DEBUG - 2022-02-12 15:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:55:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:55:34 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 15:55:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 15:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 15:55:34 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 15:55:34 --> Total execution time: 0.0057
DEBUG - 2022-02-12 16:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:01:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:01:35 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:01:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:01:35 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:01:35 --> Total execution time: 0.0061
DEBUG - 2022-02-12 16:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:06:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:06:09 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:06:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:06:09 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:06:09 --> Total execution time: 0.0057
DEBUG - 2022-02-12 16:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:15:03 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:15:03 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:15:03 --> Total execution time: 0.0058
DEBUG - 2022-02-12 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:24:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:24:19 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:24:19 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:24:19 --> Total execution time: 0.0051
DEBUG - 2022-02-12 16:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:33:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:33:02 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:33:02 --> Total execution time: 0.0058
DEBUG - 2022-02-12 16:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:36:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:36:57 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:36:57 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:36:57 --> Total execution time: 0.0052
DEBUG - 2022-02-12 16:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:41:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:41:50 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:41:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:41:50 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:41:50 --> Total execution time: 0.0050
DEBUG - 2022-02-12 16:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:45:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:45:40 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:45:40 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:45:40 --> Total execution time: 0.0049
DEBUG - 2022-02-12 16:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:54:39 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:54:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:54:39 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:54:39 --> Total execution time: 0.0059
DEBUG - 2022-02-12 16:54:58 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:54:58 --> Total execution time: 0.0063
DEBUG - 2022-02-12 16:55:01 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:55:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:55:01 --> Total execution time: 0.0066
DEBUG - 2022-02-12 16:55:02 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:55:02 --> Total execution time: 0.0048
DEBUG - 2022-02-12 16:55:14 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:55:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:55:14 --> Total execution time: 0.0064
DEBUG - 2022-02-12 16:55:17 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:55:17 --> Total execution time: 0.0057
DEBUG - 2022-02-12 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:55:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:55:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 16:55:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 16:55:33 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 16:55:33 --> Total execution time: 0.0034
DEBUG - 2022-02-12 16:55:33 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 16:55:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-12 16:55:33 --> 404 Page Not Found: Assets/https:
DEBUG - 2022-02-12 19:18:47 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 19:18:47 --> No URI present. Default controller set.
DEBUG - 2022-02-12 19:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 19:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 19:18:47 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 19:18:47 --> Total execution time: 0.0315
DEBUG - 2022-02-12 19:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 19:18:48 --> No URI present. Default controller set.
DEBUG - 2022-02-12 19:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 19:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 19:18:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 19:18:48 --> Total execution time: 0.0034
DEBUG - 2022-02-12 19:18:48 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 19:18:48 --> No URI present. Default controller set.
DEBUG - 2022-02-12 19:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 19:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 19:18:48 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 19:18:48 --> Total execution time: 0.0042
DEBUG - 2022-02-12 19:18:49 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 19:18:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2022-02-12 19:18:49 --> 404 Page Not Found: Faviconpng/index
DEBUG - 2022-02-12 20:47:52 --> UTF-8 Support Enabled
DEBUG - 2022-02-12 20:47:52 --> No URI present. Default controller set.
DEBUG - 2022-02-12 20:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2022-02-12 20:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2022-02-12 20:47:53 --> Form_validation class already loaded. Second attempt ignored.
DEBUG - 2022-02-12 20:47:53 --> Total execution time: 0.0310
